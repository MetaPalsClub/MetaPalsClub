import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../58dc566a-2add-4326-b61c-0fdf46903195/src/item"
import Script2 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script3 from "../85cf3207-2792-4349-9938-21fd82ea2168/src/item"
import Script4 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"
import Script5 from "../7e78cd70-5414-4ec4-be5f-198ec9879a5e/src/item"
import Script6 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script7 from "../0ee46c79-338c-445a-a506-ea26d80fbe46/src/item"
import Script8 from "../a3401af9-8e2b-4b2b-915e-ccb8ed611c88/src/item"
import Script9 from "../a0c742c7-c376-465c-832d-305deb1c4b78/src/item"
import Script10 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script11 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script12 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const wallPlainGlass7 = new Entity('wallPlainGlass7')
engine.addEntity(wallPlainGlass7)
wallPlainGlass7.setParent(_scene)
const gltfShape = new GLTFShape("ceed966710028a407635a309e91f31236a72714a515035e8330211b84c9b8445/PlainGlassWall.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
wallPlainGlass7.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(14.469249725341797, 4.305078506469727, 4.4976806640625),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(11.620848655700684, 0.15269853174686432, 0.03615935891866684)
})
wallPlainGlass7.addComponentOrReplace(transform2)

const wallPlainGlass10 = new Entity('wallPlainGlass10')
engine.addEntity(wallPlainGlass10)
wallPlainGlass10.setParent(_scene)
wallPlainGlass10.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(14.442209243774414, 12.091370582580566, 4.3062028884887695),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(11.620859146118164, 0.14414067566394806, 0.03615936264395714)
})
wallPlainGlass10.addComponentOrReplace(transform3)

const wallPlainGlass15 = new Entity('wallPlainGlass15')
engine.addEntity(wallPlainGlass15)
wallPlainGlass15.setParent(_scene)
wallPlainGlass15.addComponentOrReplace(gltfShape)
const transform4 = new Transform({
  position: new Vector3(14.442209243774414, 19.839523315429688, 4.3062028884887695),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(11.620865821838379, 0.13161930441856384, 0.036159366369247437)
})
wallPlainGlass15.addComponentOrReplace(transform4)

const wallPlainGlass19 = new Entity('wallPlainGlass19')
engine.addEntity(wallPlainGlass19)
wallPlainGlass19.setParent(_scene)
wallPlainGlass19.addComponentOrReplace(gltfShape)
const transform5 = new Transform({
  position: new Vector3(14.442209243774414, 27.23605728149414, 8.422428131103516),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(9.606719017028809, 0.2660794258117676, 0.03615950420498848)
})
wallPlainGlass19.addComponentOrReplace(transform5)

const wallPlainGlass21 = new Entity('wallPlainGlass21')
engine.addEntity(wallPlainGlass21)
wallPlainGlass21.setParent(_scene)
wallPlainGlass21.addComponentOrReplace(gltfShape)
const transform6 = new Transform({
  position: new Vector3(1.5577888488769531, 27.23605728149414, 3.8427562713623047),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(10.075043678283691, 0.2660794258117676, 0.03615949675440788)
})
wallPlainGlass21.addComponentOrReplace(transform6)

const wallPlainGlass25 = new Entity('wallPlainGlass25')
engine.addEntity(wallPlainGlass25)
wallPlainGlass25.setParent(_scene)
wallPlainGlass25.addComponentOrReplace(gltfShape)
const transform7 = new Transform({
  position: new Vector3(1.5577888488769531, 19.839523315429688, 4.306203365325928),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(11.6209077835083, 0.13161930441856384, 0.036159493029117584)
})
wallPlainGlass25.addComponentOrReplace(transform7)

const wallPlainGlass29 = new Entity('wallPlainGlass29')
engine.addEntity(wallPlainGlass29)
wallPlainGlass29.setParent(_scene)
wallPlainGlass29.addComponentOrReplace(gltfShape)
const transform8 = new Transform({
  position: new Vector3(1.5577888488769531, 12.091370582580566, 4.306203365325928),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(11.62091064453125, 0.14414067566394806, 0.036159515380859375)
})
wallPlainGlass29.addComponentOrReplace(transform8)

const wallPlainGlass33 = new Entity('wallPlainGlass33')
engine.addEntity(wallPlainGlass33)
wallPlainGlass33.setParent(_scene)
wallPlainGlass33.addComponentOrReplace(gltfShape)
const transform9 = new Transform({
  position: new Vector3(1.5577888488769531, 4.30507755279541, 4.306203365325928),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(11.620911598205566, 0.15269853174686432, 0.036159515380859375)
})
wallPlainGlass33.addComponentOrReplace(transform9)

const wallPlainGlass70 = new Entity('wallPlainGlass70')
engine.addEntity(wallPlainGlass70)
wallPlainGlass70.setParent(_scene)
wallPlainGlass70.addComponentOrReplace(gltfShape)
const transform10 = new Transform({
  position: new Vector3(14.123201370239258, 11.277368545532227, 4.258681297302246),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.144708633422852, 5.812131404876709, 0.04486265778541565)
})
wallPlainGlass70.addComponentOrReplace(transform10)

const wallPlainGlass72 = new Entity('wallPlainGlass72')
engine.addEntity(wallPlainGlass72)
wallPlainGlass72.setParent(_scene)
wallPlainGlass72.addComponentOrReplace(gltfShape)
const transform11 = new Transform({
  position: new Vector3(14.356664657592773, 3.4645633697509766, 4.357087135314941),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.144708633422852, 5.812126636505127, 0.044862620532512665)
})
wallPlainGlass72.addComponentOrReplace(transform11)

const blueNeonTube = new Entity('blueNeonTube')
engine.addEntity(blueNeonTube)
blueNeonTube.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(3.201199531555176, 15.433354377746582, 31.934165954589844),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.888731002807617, 1.0000028610229492, 1)
})
blueNeonTube.addComponentOrReplace(transform12)
const gltfShape2 = new GLTFShape("5287dee154b36f5774cd251c16e19cf3c9e01d86c83887d3919ef9eaf6c54f9f/NeonLightTube_04/NeonLightTube_04.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
blueNeonTube.addComponentOrReplace(gltfShape2)

const blueNeonTube2 = new Entity('blueNeonTube2')
engine.addEntity(blueNeonTube2)
blueNeonTube2.setParent(_scene)
blueNeonTube2.addComponentOrReplace(gltfShape2)
const transform13 = new Transform({
  position: new Vector3(15.867472648620605, 15.433354377746582, 27.654504776000977),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.888742446899414, 1.0000035762786865, 1)
})
blueNeonTube2.addComponentOrReplace(transform13)

const blueNeonTube3 = new Entity('blueNeonTube3')
engine.addEntity(blueNeonTube3)
blueNeonTube3.setParent(_scene)
blueNeonTube3.addComponentOrReplace(gltfShape2)
const transform14 = new Transform({
  position: new Vector3(12.721363067626953, 15.433354377746582, 31.934165954589844),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.888734817504883, 1.0000030994415283, 1)
})
blueNeonTube3.addComponentOrReplace(transform14)

const blueNeonTube4 = new Entity('blueNeonTube4')
engine.addEntity(blueNeonTube4)
blueNeonTube4.setParent(_scene)
blueNeonTube4.addComponentOrReplace(gltfShape2)
const transform15 = new Transform({
  position: new Vector3(15.867472648620605, 15.433354377746582, 4.467877388000488),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.88874626159668, 1.0000038146972656, 1)
})
blueNeonTube4.addComponentOrReplace(transform15)

const blueNeonTube5 = new Entity('blueNeonTube5')
engine.addEntity(blueNeonTube5)
blueNeonTube5.setParent(_scene)
blueNeonTube5.addComponentOrReplace(gltfShape2)
const transform16 = new Transform({
  position: new Vector3(12.805741310119629, 15.433354377746582, 0.06400811672210693),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.88875389099121, 1.0000042915344238, 1)
})
blueNeonTube5.addComponentOrReplace(transform16)

const blueNeonTube6 = new Entity('blueNeonTube6')
engine.addEntity(blueNeonTube6)
blueNeonTube6.setParent(_scene)
blueNeonTube6.addComponentOrReplace(gltfShape2)
const transform17 = new Transform({
  position: new Vector3(3.256746292114258, 15.433354377746582, 0.06400922685861588),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.888757705688477, 1.000004529953003, 1)
})
blueNeonTube6.addComponentOrReplace(transform17)

const blueNeonTube7 = new Entity('blueNeonTube7')
engine.addEntity(blueNeonTube7)
blueNeonTube7.setParent(_scene)
blueNeonTube7.addComponentOrReplace(gltfShape2)
const transform18 = new Transform({
  position: new Vector3(0, 15.433354377746582, 4.289268493652344),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.888765335083008, 1.0000050067901611, 1)
})
blueNeonTube7.addComponentOrReplace(transform18)

const blueNeonTube8 = new Entity('blueNeonTube8')
engine.addEntity(blueNeonTube8)
blueNeonTube8.setParent(_scene)
blueNeonTube8.addComponentOrReplace(gltfShape2)
const transform19 = new Transform({
  position: new Vector3(0, 15.433354377746582, 27.644121170043945),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(17.888769149780273, 1.0000052452087402, 1)
})
blueNeonTube8.addComponentOrReplace(transform19)

const verticalPlatform2 = new Entity('verticalPlatform2')
engine.addEntity(verticalPlatform2)
verticalPlatform2.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(10.403763771057129, 0, 29.91393280029297),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.764219284057617, 0.44578856229782104, 1.6867200136184692)
})
verticalPlatform2.addComponentOrReplace(transform20)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(8, 0, 2.1933021545410156),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7, 1, 1.5)
})
verticalBlackPad.addComponentOrReplace(transform21)

const wallPlainGlass20 = new Entity('wallPlainGlass20')
engine.addEntity(wallPlainGlass20)
wallPlainGlass20.setParent(_scene)
wallPlainGlass20.addComponentOrReplace(gltfShape)
const transform22 = new Transform({
  position: new Vector3(13.042866706848145, 0.013605130836367607, 6.958372116088867),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.2302241325378418, 4.692201137542725, 0.025500958785414696)
})
wallPlainGlass20.addComponentOrReplace(transform22)

const wallPlainGlass22 = new Entity('wallPlainGlass22')
engine.addEntity(wallPlainGlass22)
wallPlainGlass22.setParent(_scene)
wallPlainGlass22.addComponentOrReplace(gltfShape)
const transform23 = new Transform({
  position: new Vector3(13.071372985839844, 0.01360516157001257, 6.958373069763184),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.1816303730010986, 4.692201137542725, 0.022238658741116524)
})
wallPlainGlass22.addComponentOrReplace(transform23)

const wallPlainGlass3 = new Entity('wallPlainGlass3')
engine.addEntity(wallPlainGlass3)
wallPlainGlass3.setParent(_scene)
wallPlainGlass3.addComponentOrReplace(gltfShape)
const transform24 = new Transform({
  position: new Vector3(7.5, 0, 10.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
wallPlainGlass3.addComponentOrReplace(transform24)

const wallPlainGlass4 = new Entity('wallPlainGlass4')
engine.addEntity(wallPlainGlass4)
wallPlainGlass4.setParent(_scene)
wallPlainGlass4.addComponentOrReplace(gltfShape)
const transform25 = new Transform({
  position: new Vector3(9.738865852355957, 0.01360516157001257, 17.597410202026367),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.6675465106964111, 4.751029014587402, 0.030359096825122833)
})
wallPlainGlass4.addComponentOrReplace(transform25)

const wallPlainGlass5 = new Entity('wallPlainGlass5')
engine.addEntity(wallPlainGlass5)
wallPlainGlass5.setParent(_scene)
wallPlainGlass5.addComponentOrReplace(gltfShape)
const transform26 = new Transform({
  position: new Vector3(9.738865852355957, 0.01360516157001257, 14.234880447387695),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.6675465106964111, 4.751029014587402, 0.030359096825122833)
})
wallPlainGlass5.addComponentOrReplace(transform26)

const wallPlainGlass6 = new Entity('wallPlainGlass6')
engine.addEntity(wallPlainGlass6)
wallPlainGlass6.setParent(_scene)
wallPlainGlass6.addComponentOrReplace(gltfShape)
const transform27 = new Transform({
  position: new Vector3(9.698636054992676, 0.01360512524843216, 11.483604431152344),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(3.057624340057373, 4.751029014587402, 0.03598758950829506)
})
wallPlainGlass6.addComponentOrReplace(transform27)

const blueNeonTube9 = new Entity('blueNeonTube9')
engine.addEntity(blueNeonTube9)
blueNeonTube9.setParent(_scene)
blueNeonTube9.addComponentOrReplace(gltfShape2)
const transform28 = new Transform({
  position: new Vector3(6.534296989440918, 9.485735893249512, 17.467880249023438),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(10.95981216430664, 1.0000088214874268, 1)
})
blueNeonTube9.addComponentOrReplace(transform28)

const blueNeonTube10 = new Entity('blueNeonTube10')
engine.addEntity(blueNeonTube10)
blueNeonTube10.setParent(_scene)
blueNeonTube10.addComponentOrReplace(gltfShape2)
const transform29 = new Transform({
  position: new Vector3(6.402960777282715, 9.485735893249512, 14.411060333251953),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(10.959817886352539, 1.000009536743164, 1)
})
blueNeonTube10.addComponentOrReplace(transform29)

const blueNeonTube11 = new Entity('blueNeonTube11')
engine.addEntity(blueNeonTube11)
blueNeonTube11.setParent(_scene)
blueNeonTube11.addComponentOrReplace(gltfShape2)
const transform30 = new Transform({
  position: new Vector3(9.402961730957031, 9.485735893249512, 14.411060333251953),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(10.959820747375488, 1.0000097751617432, 1)
})
blueNeonTube11.addComponentOrReplace(transform30)

const blueNeonTube12 = new Entity('blueNeonTube12')
engine.addEntity(blueNeonTube12)
blueNeonTube12.setParent(_scene)
blueNeonTube12.addComponentOrReplace(gltfShape2)
const transform31 = new Transform({
  position: new Vector3(9.534296989440918, 9.485735893249512, 17.467880249023438),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(10.959817886352539, 1.000009536743164, 1)
})
blueNeonTube12.addComponentOrReplace(transform31)

const bigTube = new Entity('bigTube')
engine.addEntity(bigTube)
bigTube.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(2.940619945526123, 1.5495452880859375, 29.5),
  rotation: new Quaternion(-2.125636804431192e-15, -0.5691615343093872, 6.784932082837258e-8, -0.82222580909729),
  scale: new Vector3(0.38964951038360596, 2, 0.5000007748603821)
})
bigTube.addComponentOrReplace(transform32)
const gltfShape3 = new GLTFShape("19e794f0ac6ab8e7a71d8d072b72e0c1ef93fce96597a84caf28614844f11e10/Big_Tube.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
bigTube.addComponentOrReplace(gltfShape3)

const ringRedLight = new Entity('ringRedLight')
engine.addEntity(ringRedLight)
ringRedLight.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(1.4861879348754883, 25.70052719116211, 28.780797958374023),
  rotation: new Quaternion(-0.6766590476036072, -0.20526230335235596, -0.2052621692419052, 0.6766590476036072),
  scale: new Vector3(0.9999998807907104, 1.000002145767212, 4.733758449554443)
})
ringRedLight.addComponentOrReplace(transform33)
const gltfShape4 = new GLTFShape("798af9512168e700b9170601ab68167b1ce3cacf8bd144bba1f15423214ec012/Ring_Red_Light.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
ringRedLight.addComponentOrReplace(gltfShape4)

const ringRedLight2 = new Entity('ringRedLight2')
engine.addEntity(ringRedLight2)
ringRedLight2.setParent(_scene)
ringRedLight2.addComponentOrReplace(gltfShape4)
const transform34 = new Transform({
  position: new Vector3(7.946210861206055, 0.3844165802001953, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000061988830566, 7.274844169616699)
})
ringRedLight2.addComponentOrReplace(transform34)

const ringRedLight4 = new Entity('ringRedLight4')
engine.addEntity(ringRedLight4)
ringRedLight4.setParent(_scene)
ringRedLight4.addComponentOrReplace(gltfShape4)
const transform35 = new Transform({
  position: new Vector3(7.946210861206055, 3.3844165802001953, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000066757202148, 7.274844169616699)
})
ringRedLight4.addComponentOrReplace(transform35)

const ringRedLight5 = new Entity('ringRedLight5')
engine.addEntity(ringRedLight5)
ringRedLight5.setParent(_scene)
ringRedLight5.addComponentOrReplace(gltfShape4)
const transform36 = new Transform({
  position: new Vector3(7.946210861206055, 11.234633445739746, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000081062316895, 7.274844169616699)
})
ringRedLight5.addComponentOrReplace(transform36)

const ringRedLight8 = new Entity('ringRedLight8')
engine.addEntity(ringRedLight8)
ringRedLight8.setParent(_scene)
ringRedLight8.addComponentOrReplace(gltfShape4)
const transform37 = new Transform({
  position: new Vector3(7.946210861206055, 26.846097946166992, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.000009536743164, 7.274844169616699)
})
ringRedLight8.addComponentOrReplace(transform37)

const ringRedLight9 = new Entity('ringRedLight9')
engine.addEntity(ringRedLight9)
ringRedLight9.setParent(_scene)
ringRedLight9.addComponentOrReplace(gltfShape4)
const transform38 = new Transform({
  position: new Vector3(7.946210861206055, 30.66687774658203, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000104904174805, 7.274844169616699)
})
ringRedLight9.addComponentOrReplace(transform38)

const ringRedLight11 = new Entity('ringRedLight11')
engine.addEntity(ringRedLight11)
ringRedLight11.setParent(_scene)
ringRedLight11.addComponentOrReplace(gltfShape4)
const transform39 = new Transform({
  position: new Vector3(7.946210861206055, 18.884416580200195, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000076293945312, 7.274844169616699)
})
ringRedLight11.addComponentOrReplace(transform39)

const ringRedLight12 = new Entity('ringRedLight12')
engine.addEntity(ringRedLight12)
ringRedLight12.setParent(_scene)
ringRedLight12.addComponentOrReplace(gltfShape4)
const transform40 = new Transform({
  position: new Vector3(7.946210861206055, 30.66687774658203, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000104904174805, 7.274844169616699)
})
ringRedLight12.addComponentOrReplace(transform40)

const ringRedLight13 = new Entity('ringRedLight13')
engine.addEntity(ringRedLight13)
ringRedLight13.setParent(_scene)
ringRedLight13.addComponentOrReplace(gltfShape4)
const transform41 = new Transform({
  position: new Vector3(7.946210861206055, 30.66687774658203, 2.177241086959839),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 1.1920928955078125e-7),
  scale: new Vector3(1.6509339809417725, 1.0000104904174805, 7.274844169616699)
})
ringRedLight13.addComponentOrReplace(transform41)

const ringGreenLight = new Entity('ringGreenLight')
engine.addEntity(ringGreenLight)
ringGreenLight.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(10.386185646057129, 0.17365574836730957, 31.835729598999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight.addComponentOrReplace(transform42)
const gltfShape5 = new GLTFShape("df3883c9b595615e44d5a4ac65f4a047cd662f5c249639910366eafe5fb716ac/Ring_Green_Light.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
ringGreenLight.addComponentOrReplace(gltfShape5)

const ringGreenLight2 = new Entity('ringGreenLight2')
engine.addEntity(ringGreenLight2)
ringGreenLight2.setParent(_scene)
ringGreenLight2.addComponentOrReplace(gltfShape5)
const transform43 = new Transform({
  position: new Vector3(10.386185646057129, 0.17365574836730957, 27.576772689819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight2.addComponentOrReplace(transform43)

const ringGreenLight3 = new Entity('ringGreenLight3')
engine.addEntity(ringGreenLight3)
ringGreenLight3.setParent(_scene)
ringGreenLight3.addComponentOrReplace(gltfShape5)
const transform44 = new Transform({
  position: new Vector3(15.672699928283691, 0.17365574836730957, 29.72549057006836),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380403995513916, 1, -0.01825249381363392)
})
ringGreenLight3.addComponentOrReplace(transform44)

const ringGreenLight4 = new Entity('ringGreenLight4')
engine.addEntity(ringGreenLight4)
ringGreenLight4.setParent(_scene)
ringGreenLight4.addComponentOrReplace(gltfShape5)
const transform45 = new Transform({
  position: new Vector3(5.1456708908081055, 0.17365574836730957, 29.68307876586914),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.03804087638855, 1, -0.018252497538924217)
})
ringGreenLight4.addComponentOrReplace(transform45)

const ringGreenLight5 = new Entity('ringGreenLight5')
engine.addEntity(ringGreenLight5)
ringGreenLight5.setParent(_scene)
ringGreenLight5.addComponentOrReplace(gltfShape5)
const transform46 = new Transform({
  position: new Vector3(15.672699928283691, 3.2198352813720703, 29.72549057006836),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.038041830062866, 1, -0.018252504989504814)
})
ringGreenLight5.addComponentOrReplace(transform46)

const ringGreenLight6 = new Entity('ringGreenLight6')
engine.addEntity(ringGreenLight6)
ringGreenLight6.setParent(_scene)
ringGreenLight6.addComponentOrReplace(gltfShape5)
const transform47 = new Transform({
  position: new Vector3(10.386185646057129, 3.2198352813720703, 27.576772689819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight6.addComponentOrReplace(transform47)

const ringGreenLight7 = new Entity('ringGreenLight7')
engine.addEntity(ringGreenLight7)
ringGreenLight7.setParent(_scene)
ringGreenLight7.addComponentOrReplace(gltfShape5)
const transform48 = new Transform({
  position: new Vector3(5.1456708908081055, 3.2198352813720703, 29.68307876586914),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380423069000244, 1, -0.018252508714795113)
})
ringGreenLight7.addComponentOrReplace(transform48)

const ringGreenLight8 = new Entity('ringGreenLight8')
engine.addEntity(ringGreenLight8)
ringGreenLight8.setParent(_scene)
ringGreenLight8.addComponentOrReplace(gltfShape5)
const transform49 = new Transform({
  position: new Vector3(10.386185646057129, 3.2198352813720703, 31.835729598999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight8.addComponentOrReplace(transform49)

const ringGreenLight13 = new Entity('ringGreenLight13')
engine.addEntity(ringGreenLight13)
ringGreenLight13.setParent(_scene)
ringGreenLight13.addComponentOrReplace(gltfShape5)
const transform50 = new Transform({
  position: new Vector3(15.672699928283691, 11.196188926696777, 29.72549057006836),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380442142486572, 1, -0.018252523615956306)
})
ringGreenLight13.addComponentOrReplace(transform50)

const ringGreenLight14 = new Entity('ringGreenLight14')
engine.addEntity(ringGreenLight14)
ringGreenLight14.setParent(_scene)
ringGreenLight14.addComponentOrReplace(gltfShape5)
const transform51 = new Transform({
  position: new Vector3(10.386185646057129, 11.196188926696777, 27.576772689819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight14.addComponentOrReplace(transform51)

const ringGreenLight15 = new Entity('ringGreenLight15')
engine.addEntity(ringGreenLight15)
ringGreenLight15.setParent(_scene)
ringGreenLight15.addComponentOrReplace(gltfShape5)
const transform52 = new Transform({
  position: new Vector3(5.1456708908081055, 11.196188926696777, 29.68307876586914),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380446910858154, 1, -0.018252527341246605)
})
ringGreenLight15.addComponentOrReplace(transform52)

const ringGreenLight16 = new Entity('ringGreenLight16')
engine.addEntity(ringGreenLight16)
ringGreenLight16.setParent(_scene)
ringGreenLight16.addComponentOrReplace(gltfShape5)
const transform53 = new Transform({
  position: new Vector3(10.386185646057129, 11.196188926696777, 31.835729598999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight16.addComponentOrReplace(transform53)

const ringGreenLight21 = new Entity('ringGreenLight21')
engine.addEntity(ringGreenLight21)
ringGreenLight21.setParent(_scene)
ringGreenLight21.addComponentOrReplace(gltfShape5)
const transform54 = new Transform({
  position: new Vector3(15.672699928283691, 19.00489616394043, 29.72549057006836),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.03804612159729, 1, -0.0182525385171175)
})
ringGreenLight21.addComponentOrReplace(transform54)

const ringGreenLight22 = new Entity('ringGreenLight22')
engine.addEntity(ringGreenLight22)
ringGreenLight22.setParent(_scene)
ringGreenLight22.addComponentOrReplace(gltfShape5)
const transform55 = new Transform({
  position: new Vector3(10.386185646057129, 19.00489616394043, 27.576772689819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight22.addComponentOrReplace(transform55)

const ringGreenLight23 = new Entity('ringGreenLight23')
engine.addEntity(ringGreenLight23)
ringGreenLight23.setParent(_scene)
ringGreenLight23.addComponentOrReplace(gltfShape5)
const transform56 = new Transform({
  position: new Vector3(5.1456708908081055, 19.00489616394043, 29.68307876586914),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380465984344482, 1, -0.0182525422424078)
})
ringGreenLight23.addComponentOrReplace(transform56)

const ringGreenLight24 = new Entity('ringGreenLight24')
engine.addEntity(ringGreenLight24)
ringGreenLight24.setParent(_scene)
ringGreenLight24.addComponentOrReplace(gltfShape5)
const transform57 = new Transform({
  position: new Vector3(10.386185646057129, 19.00489616394043, 31.835729598999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight24.addComponentOrReplace(transform57)

const ringGreenLight29 = new Entity('ringGreenLight29')
engine.addEntity(ringGreenLight29)
ringGreenLight29.setParent(_scene)
ringGreenLight29.addComponentOrReplace(gltfShape5)
const transform58 = new Transform({
  position: new Vector3(15.672699928283691, 26.65900421142578, 29.72549057006836),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380494594573975, 1, -0.01825256459414959)
})
ringGreenLight29.addComponentOrReplace(transform58)

const ringGreenLight30 = new Entity('ringGreenLight30')
engine.addEntity(ringGreenLight30)
ringGreenLight30.setParent(_scene)
ringGreenLight30.addComponentOrReplace(gltfShape5)
const transform59 = new Transform({
  position: new Vector3(10.386185646057129, 26.65900421142578, 27.576772689819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight30.addComponentOrReplace(transform59)

const ringGreenLight31 = new Entity('ringGreenLight31')
engine.addEntity(ringGreenLight31)
ringGreenLight31.setParent(_scene)
ringGreenLight31.addComponentOrReplace(gltfShape5)
const transform60 = new Transform({
  position: new Vector3(5.1456708908081055, 26.65900421142578, 29.68307876586914),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.0380499362945557, 1, -0.018252568319439888)
})
ringGreenLight31.addComponentOrReplace(transform60)

const ringGreenLight32 = new Entity('ringGreenLight32')
engine.addEntity(ringGreenLight32)
ringGreenLight32.setParent(_scene)
ringGreenLight32.addComponentOrReplace(gltfShape5)
const transform61 = new Transform({
  position: new Vector3(10.386185646057129, 26.65900421142578, 31.835729598999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight32.addComponentOrReplace(transform61)

const ringGreenLight33 = new Entity('ringGreenLight33')
engine.addEntity(ringGreenLight33)
ringGreenLight33.setParent(_scene)
ringGreenLight33.addComponentOrReplace(gltfShape5)
const transform62 = new Transform({
  position: new Vector3(15.672699928283691, 30.823429107666016, 29.72549057006836),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.038050413131714, 1, -0.018252572044730186)
})
ringGreenLight33.addComponentOrReplace(transform62)

const ringGreenLight34 = new Entity('ringGreenLight34')
engine.addEntity(ringGreenLight34)
ringGreenLight34.setParent(_scene)
ringGreenLight34.addComponentOrReplace(gltfShape5)
const transform63 = new Transform({
  position: new Vector3(10.386185646057129, 30.823429107666016, 27.576772689819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight34.addComponentOrReplace(transform63)

const ringGreenLight35 = new Entity('ringGreenLight35')
engine.addEntity(ringGreenLight35)
ringGreenLight35.setParent(_scene)
ringGreenLight35.addComponentOrReplace(gltfShape5)
const transform64 = new Transform({
  position: new Vector3(5.1456708908081055, 30.823429107666016, 29.68307876586914),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.038050889968872, 1, -0.018252575770020485)
})
ringGreenLight35.addComponentOrReplace(transform64)

const ringGreenLight36 = new Entity('ringGreenLight36')
engine.addEntity(ringGreenLight36)
ringGreenLight36.setParent(_scene)
ringGreenLight36.addComponentOrReplace(gltfShape5)
const transform65 = new Transform({
  position: new Vector3(10.386185646057129, 30.823429107666016, 31.835729598999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.242948532104492, 1, -0.018252478912472725)
})
ringGreenLight36.addComponentOrReplace(transform65)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape6 = new GLTFShape("bfc932843fa883cacaa9d8ffd5fc94069b36c6facc8756ee4768097f7545c2c4/CityTile.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
entity.addComponentOrReplace(gltfShape6)
const transform66 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform66)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape6)
const transform67 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform67)

const wallPlainGlass2 = new Entity('wallPlainGlass2')
engine.addEntity(wallPlainGlass2)
wallPlainGlass2.setParent(_scene)
wallPlainGlass2.addComponentOrReplace(gltfShape)
const transform68 = new Transform({
  position: new Vector3(14.318726539611816, 26.743492126464844, 4.308701038360596),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.192761421203613, 5.812151908874512, 0.04486281797289848)
})
wallPlainGlass2.addComponentOrReplace(transform68)

const catStatue = new Entity('catStatue')
engine.addEntity(catStatue)
catStatue.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(8.053505897521973, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
catStatue.addComponentOrReplace(transform69)
const gltfShape7 = new GLTFShape("fd939e7c429d71efa4b1519a3cf84668f50757c68175b3ee6c81946a773c5aa4/PillarCat_01/PillarCat_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
catStatue.addComponentOrReplace(gltfShape7)

const rainLight = new Entity('rainLight')
engine.addEntity(rainLight)
rainLight.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(7.9506940841674805, 0.3192225694656372, 15.909666061401367),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rainLight.addComponentOrReplace(transform70)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(8.073719024658203, 26.761348724365234, 15.924810409545898),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.058440089225769, 1, 675.666748046875)
})
ropeLight3.addComponentOrReplace(transform71)

const wallPlainGlass37 = new Entity('wallPlainGlass37')
engine.addEntity(wallPlainGlass37)
wallPlainGlass37.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(15.958259582519531, 0.23387718200683594, 24.464319229125977),
  rotation: new Quaternion(-0.3068655729293823, 1.2372452765354935e-16, 3.658122338379144e-8, 0.9517529010772705),
  scale: new Vector3(0.8000903129577637, 8.21101188659668, 1.0622649192810059)
})
wallPlainGlass37.addComponentOrReplace(transform72)
wallPlainGlass37.addComponentOrReplace(gltfShape)

const wallPlainGlass38 = new Entity('wallPlainGlass38')
engine.addEntity(wallPlainGlass38)
wallPlainGlass38.setParent(_scene)
wallPlainGlass38.addComponentOrReplace(gltfShape)
const transform73 = new Transform({
  position: new Vector3(0.45825958251953125, 0.22404909133911133, 8.490684509277344),
  rotation: new Quaternion(-2.743591132059464e-8, -0.9517529606819153, -0.3068654537200928, -2.836444856768594e-8),
  scale: new Vector3(0.8000929951667786, 8.21101188659668, 1.0622684955596924)
})
wallPlainGlass38.addComponentOrReplace(transform73)

const purpleNeonTube = new Entity('purpleNeonTube')
engine.addEntity(purpleNeonTube)
purpleNeonTube.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(0.3865623474121094, 14.241661071777344, 17.59054183959961),
  rotation: new Quaternion(-0.318628191947937, -0.6312496066093445, 0.3186282813549042, 0.6312495470046997),
  scale: new Vector3(18.056724548339844, 1.4020735025405884, 1.0000027418136597)
})
purpleNeonTube.addComponentOrReplace(transform74)
const gltfShape8 = new GLTFShape("00275d6f5388dcf1693543bf5b54f855f5ef5bb6669e2a57cb7932bb876ccf57/NeonLightTube_03/NeonLightTube_03.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
purpleNeonTube.addComponentOrReplace(gltfShape8)

const purpleNeonTube2 = new Entity('purpleNeonTube2')
engine.addEntity(purpleNeonTube2)
purpleNeonTube2.setParent(_scene)
purpleNeonTube2.addComponentOrReplace(gltfShape8)
const transform75 = new Transform({
  position: new Vector3(15.830509185791016, 14.241661071777344, 15.391386032104492),
  rotation: new Quaternion(0.3186282217502594, 0.6312496066093445, 0.31862813234329224, 0.631249725818634),
  scale: new Vector3(18.0567569732666, 1.4020740985870361, 1.0000038146972656)
})
purpleNeonTube2.addComponentOrReplace(transform75)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(8.123703956604004, 22.88597297668457, 7.1201372146606445),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0578125715255737, 1.0000033378601074, 226.8037872314453)
})
ropeLight4.addComponentOrReplace(transform76)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(8.011205673217773, 22.88597297668457, 24.52874755859375),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0506391525268555, 1.0000042915344238, 226.8040313720703)
})
ropeLight5.addComponentOrReplace(transform77)

const purpleNeonTube3 = new Entity('purpleNeonTube3')
engine.addEntity(purpleNeonTube3)
purpleNeonTube3.setParent(_scene)
purpleNeonTube3.addComponentOrReplace(gltfShape8)
const transform78 = new Transform({
  position: new Vector3(15.830509185791016, 14.241661071777344, 15.391386032104492),
  rotation: new Quaternion(0.6310019493103027, 0.3191187381744385, 0.6310017108917236, 0.3191188871860504),
  scale: new Vector3(18.056766510009766, 1.4020748138427734, 1.0000041723251343)
})
purpleNeonTube3.addComponentOrReplace(transform78)

const purpleNeonTube4 = new Entity('purpleNeonTube4')
engine.addEntity(purpleNeonTube4)
purpleNeonTube4.setParent(_scene)
purpleNeonTube4.addComponentOrReplace(gltfShape8)
const transform79 = new Transform({
  position: new Vector3(0.31766289472579956, 14.241661071777344, 15.391386032104492),
  rotation: new Quaternion(0.3186282217502594, 0.6312496066093445, 0.31862813234329224, 0.631249725818634),
  scale: new Vector3(18.056774139404297, 1.4020748138427734, 1.000004529953003)
})
purpleNeonTube4.addComponentOrReplace(transform79)

const wallPlainGlass39 = new Entity('wallPlainGlass39')
engine.addEntity(wallPlainGlass39)
wallPlainGlass39.setParent(_scene)
wallPlainGlass39.addComponentOrReplace(gltfShape)
const transform80 = new Transform({
  position: new Vector3(12.11775016784668, 27.23605728149414, 3.8618688583374023),
  rotation: new Quaternion(1.1920927533992653e-7, -1, 3.2523316552651293e-15, -5.960464477539063e-8),
  scale: new Vector3(1.7488000392913818, 0.2660794258117676, -0.036159493029117584)
})
wallPlainGlass39.addComponentOrReplace(transform80)

const wallPlainGlass40 = new Entity('wallPlainGlass40')
engine.addEntity(wallPlainGlass40)
wallPlainGlass40.setParent(_scene)
wallPlainGlass40.addComponentOrReplace(gltfShape)
const transform81 = new Transform({
  position: new Vector3(0.05565361678600311, 27.23605728149414, 27.86186981201172),
  rotation: new Quaternion(1.1920927533992653e-7, -1, 3.2523316552651293e-15, -5.960464477539063e-8),
  scale: new Vector3(2.3966755867004395, 0.2660794258117676, -0.036159493029117584)
})
wallPlainGlass40.addComponentOrReplace(transform81)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(2, 8.5, 29),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071067690849304),
  scale: new Vector3(0.2633627951145172, -1, 12.281957626342773)
})
ropeLight.addComponentOrReplace(transform82)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(2.5400867462158203, 20, 30.5150089263916),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071067690849304),
  scale: new Vector3(0.5136696100234985, 1, 12.281957626342773)
})
ropeLight8.addComponentOrReplace(transform83)

const ropeLight9 = new Entity('ropeLight9')
engine.addEntity(ropeLight9)
ropeLight9.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(2.0400867462158203, 8, 28.853988647460938),
  rotation: new Quaternion(0.44858381152153015, -0.44858378171920776, 0.5466009974479675, -0.546600878238678),
  scale: new Vector3(0.3023296594619751, 1, 12.28195858001709)
})
ropeLight9.addComponentOrReplace(transform84)

const ropeLight10 = new Entity('ropeLight10')
engine.addEntity(ropeLight10)
ropeLight10.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(4.04008674621582, 17.464252471923828, 29.5150089263916),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071067690849304),
  scale: new Vector3(0.5106279253959656, 1, 12.281957626342773)
})
ropeLight10.addComponentOrReplace(transform85)

const signpostTree = new Entity('signpostTree')
engine.addEntity(signpostTree)
signpostTree.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(8.22509765625, 24.225231170654297, 26.090171813964844),
  rotation: new Quaternion(-0.2059214562177658, 1.1619284303546212e-16, 2.454774694626849e-8, -0.9785685539245605),
  scale: new Vector3(1.9848078489303589, 1.9298043251037598, 1.1353209018707275)
})
signpostTree.addComponentOrReplace(transform86)

const neonRectangleSign = new Entity('neonRectangleSign')
engine.addEntity(neonRectangleSign)
neonRectangleSign.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(1.659536361694336, 19.53022575378418, 24.221521377563477),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(14.268533706665039, 12.922225952148438, 1.0000066757202148)
})
neonRectangleSign.addComponentOrReplace(transform87)
const gltfShape9 = new GLTFShape("f34ddbc5bc1c9c7536bec7be42a018a6df2833c63609f99f4637552e5d6cd10a/Neon_Rectangle_Sign.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
neonRectangleSign.addComponentOrReplace(gltfShape9)

const signpostTree5 = new Entity('signpostTree5')
engine.addEntity(signpostTree5)
signpostTree5.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(1.4624786376953125, 20.73393440246582, 15.664310455322266),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(8.47229290008545, 4.45513916015625, 1.000007152557373)
})
signpostTree5.addComponentOrReplace(transform88)

const signpostTree6 = new Entity('signpostTree6')
engine.addEntity(signpostTree6)
signpostTree6.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(14.748597145080566, 20.77931785583496, 15.620570182800293),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(8.472307205200195, 4.45513916015625, 1.0000078678131104)
})
signpostTree6.addComponentOrReplace(transform89)

const neonRectangleSign2 = new Entity('neonRectangleSign2')
engine.addEntity(neonRectangleSign2)
neonRectangleSign2.setParent(_scene)
neonRectangleSign2.addComponentOrReplace(gltfShape9)
const transform90 = new Transform({
  position: new Vector3(14.551539421081543, 19.57560920715332, 7.063356399536133),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(14.268547058105469, 12.922225952148438, 1.0000073909759521)
})
neonRectangleSign2.addComponentOrReplace(transform90)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(1.718827247619629, 21.80491065979004, 17.79495620727539),
  rotation: new Quaternion(-1.0508663438133642e-14, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(5.062510967254639, 5.0625, 1.0000104904174805)
})
nftPictureFrame4.addComponentOrReplace(transform91)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(1.7188262939453125, 21.80491065979004, 13.7335205078125),
  rotation: new Quaternion(-1.0508663438133642e-14, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(5.06249475479126, 5.0625, 1.0000100135803223)
})
nftPictureFrame5.addComponentOrReplace(transform92)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(1.748377799987793, 21.80491065979004, 9.36910343170166),
  rotation: new Quaternion(-1.0508663438133642e-14, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(5.062506675720215, 5.0625, 1.000009298324585)
})
nftPictureFrame6.addComponentOrReplace(transform93)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(14.431965827941895, 21.90736961364746, 13.500133514404297),
  rotation: new Quaternion(-5.5683547847012495e-15, -0.7071068286895752, 8.429370268459024e-8, 0.7071068286895752),
  scale: new Vector3(5.062502861022949, 5.0625, 1.0000100135803223)
})
nftPictureFrame8.addComponentOrReplace(transform94)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(1.7443373203277588, 21.804912567138672, 22.078693389892578),
  rotation: new Quaternion(3.685195560981704e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(5.062509059906006, 5.0625, 1.0000112056732178)
})
nftPictureFrame9.addComponentOrReplace(transform95)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(14.431965827941895, 21.92662811279297, 17.719268798828125),
  rotation: new Quaternion(2.349811697218568e-15, 0.7071068286895752, -8.429371689544496e-8, -0.7071068286895752),
  scale: new Vector3(5.062501430511475, 5.0625, 1.0000083446502686)
})
nftPictureFrame10.addComponentOrReplace(transform96)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(14.431964874267578, 21.926626205444336, 9.465394020080566),
  rotation: new Quaternion(2.349811697218568e-15, 0.7071068286895752, -8.429371689544496e-8, -0.7071068286895752),
  scale: new Vector3(5.062514781951904, 5.0625, 1.0000083446502686)
})
nftPictureFrame11.addComponentOrReplace(transform97)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(14.431963920593262, 21.9266300201416, 21.711652755737305),
  rotation: new Quaternion(2.349811697218568e-15, 0.7071068286895752, -8.429371689544496e-8, -0.7071068286895752),
  scale: new Vector3(5.062502861022949, 5.0625, 1.0000083446502686)
})
nftPictureFrame12.addComponentOrReplace(transform98)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(6.376828193664551, 4.2237420082092285, 15.899234771728516),
  rotation: new Quaternion(-2.977848511125005e-15, -0.7071068286895752, 8.42937097900176e-8, 0.7071068286895752),
  scale: new Vector3(5.062516212463379, 5.0625, 1.0000083446502686)
})
nftPictureFrame13.addComponentOrReplace(transform99)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(10.5, 4.2237420082092285, 17),
  rotation: new Quaternion(-1.0508663438133642e-14, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(5.062516212463379, 5.0625, 1.0000083446502686)
})
nftPictureFrame14.addComponentOrReplace(transform100)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(9.727269172668457, 8.169832229614258, 15.899234771728516),
  rotation: new Quaternion(-1.0508663438133642e-14, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(5.062519073486328, 5.0625, 1.0000085830688477)
})
nftPictureFrame17.addComponentOrReplace(transform101)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(8, 8, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame18.addComponentOrReplace(transform102)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(9.727269172668457, 11.9979887008667, 15.899234771728516),
  rotation: new Quaternion(-1.0508663438133642e-14, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(5.062523365020752, 5.0625, 1.0000090599060059)
})
nftPictureFrame21.addComponentOrReplace(transform103)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform104 = new Transform({
  position: new Vector3(8.10891056060791, 11.9979887008667, 14.496968269348145),
  rotation: new Quaternion(-3.893702885343717e-15, -1, 1.1920928244535389e-7, 3.725290298461914e-8),
  scale: new Vector3(5.06252384185791, 5.0625, 1.0000077486038208)
})
nftPictureFrame22.addComponentOrReplace(transform104)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(8.10891056060791, 11.9979887008667, 17.632204055786133),
  rotation: new Quaternion(2.7895026884900125e-15, 5.960464477539063e-8, 6.016896423238554e-15, 1),
  scale: new Vector3(5.06252384185791, 5.0625, 1.0000077486038208)
})
nftPictureFrame23.addComponentOrReplace(transform105)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform106 = new Transform({
  position: new Vector3(6.376828193664551, 11.9979887008667, 15.899234771728516),
  rotation: new Quaternion(-2.977848511125005e-15, -0.7071068286895752, 8.42937097900176e-8, 0.7071068286895752),
  scale: new Vector3(5.062526226043701, 5.0625, 1.000009298324585)
})
nftPictureFrame24.addComponentOrReplace(transform106)

const nftPictureFrame29 = new Entity('nftPictureFrame29')
engine.addEntity(nftPictureFrame29)
nftPictureFrame29.setParent(_scene)
const transform107 = new Transform({
  position: new Vector3(9.727269172668457, 15.810830116271973, 15.899234771728516),
  rotation: new Quaternion(-5.2683581941437296e-8, -0.7071068286895752, 3.1610131401293984e-8, -0.7071068286895752),
  scale: new Vector3(5.062525272369385, 5.0625, 1.0000097751617432)
})
nftPictureFrame29.addComponentOrReplace(transform107)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(8.10891056060791, 15.810830116271973, 17.632204055786133),
  rotation: new Quaternion(2.7895026884900125e-15, 5.960464477539063e-8, 6.016896423238554e-15, 1),
  scale: new Vector3(5.06252384185791, 5.0625, 1.0000077486038208)
})
nftPictureFrame30.addComponentOrReplace(transform108)

const nftPictureFrame31 = new Entity('nftPictureFrame31')
engine.addEntity(nftPictureFrame31)
nftPictureFrame31.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(8.10891056060791, 15.810830116271973, 14.496968269348145),
  rotation: new Quaternion(-3.893702885343717e-15, -1, 1.1920928244535389e-7, 3.725290298461914e-8),
  scale: new Vector3(5.06252384185791, 5.0625, 1.0000077486038208)
})
nftPictureFrame31.addComponentOrReplace(transform109)

const nftPictureFrame32 = new Entity('nftPictureFrame32')
engine.addEntity(nftPictureFrame32)
nftPictureFrame32.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(6.376828193664551, 15.810830116271973, 15.899234771728516),
  rotation: new Quaternion(-2.977848511125005e-15, -0.7071068286895752, 8.42937097900176e-8, 0.7071068286895752),
  scale: new Vector3(5.062528133392334, 5.0625, 1.0000097751617432)
})
nftPictureFrame32.addComponentOrReplace(transform110)

const lightDecor = new Entity('lightDecor')
engine.addEntity(lightDecor)
lightDecor.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(8, 29, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.652709722518921, 1, 3.3454084396362305)
})
lightDecor.addComponentOrReplace(transform111)
const gltfShape10 = new GLTFShape("f7f880dd5ac73fcdcfacde07dd87d390134eb8a6e30c29353c2103f22ee135e6/Light_Decor9.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
lightDecor.addComponentOrReplace(gltfShape10)

const lightDecor2 = new Entity('lightDecor2')
engine.addEntity(lightDecor2)
lightDecor2.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(8, 30.947509765625, 27.189102172851562),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.5106024742126465, 4.866870880126953, 1.0000030994415283)
})
lightDecor2.addComponentOrReplace(transform112)
const gltfShape11 = new GLTFShape("3be0e7a0630f7839f22d945fa8442637baabfb733400d34ce2ff4a6ece0355d4/Light_Decor7.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
lightDecor2.addComponentOrReplace(gltfShape11)

const wallPlainGlass41 = new Entity('wallPlainGlass41')
engine.addEntity(wallPlainGlass41)
wallPlainGlass41.setParent(_scene)
wallPlainGlass41.addComponentOrReplace(gltfShape)
const transform113 = new Transform({
  position: new Vector3(1.5691354274749756, 27.23605728149414, 3.8618690967559814),
  rotation: new Quaternion(1.1920927533992653e-7, -1, 3.2523316552651293e-15, -5.960464477539063e-8),
  scale: new Vector3(1.7488000392913818, 0.2660794258117676, -0.036159493029117584)
})
wallPlainGlass41.addComponentOrReplace(transform113)

const wallPlainGlass8 = new Entity('wallPlainGlass8')
engine.addEntity(wallPlainGlass8)
wallPlainGlass8.setParent(_scene)
wallPlainGlass8.addComponentOrReplace(gltfShape)
const transform114 = new Transform({
  position: new Vector3(3.192462921142578, 0.01360516157001257, 6.958373069763184),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.2302241325378418, 4.692201137542725, 0.025500943884253502)
})
wallPlainGlass8.addComponentOrReplace(transform114)

const wallPlainGlass14 = new Entity('wallPlainGlass14')
engine.addEntity(wallPlainGlass14)
wallPlainGlass14.setParent(_scene)
wallPlainGlass14.addComponentOrReplace(gltfShape)
const transform115 = new Transform({
  position: new Vector3(5.571372985839844, 0.01360516157001257, 6.958373069763184),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.1816303730010986, 4.692201137542725, 0.022238658741116524)
})
wallPlainGlass14.addComponentOrReplace(transform115)

const wallPlainGlass24 = new Entity('wallPlainGlass24')
engine.addEntity(wallPlainGlass24)
wallPlainGlass24.setParent(_scene)
wallPlainGlass24.addComponentOrReplace(gltfShape)
const transform116 = new Transform({
  position: new Vector3(3, 0.013605117797851562, 21.5),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.230224847793579, 4.692201137542725, 0.025500979274511337)
})
wallPlainGlass24.addComponentOrReplace(transform116)

const wallPlainGlass26 = new Entity('wallPlainGlass26')
engine.addEntity(wallPlainGlass26)
wallPlainGlass26.setParent(_scene)
wallPlainGlass26.addComponentOrReplace(gltfShape)
const transform117 = new Transform({
  position: new Vector3(5.571372985839844, 0.01360516157001257, 24.25666618347168),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.1816303730010986, 4.692201137542725, 0.022238658741116524)
})
wallPlainGlass26.addComponentOrReplace(transform117)

const wallPlainGlass32 = new Entity('wallPlainGlass32')
engine.addEntity(wallPlainGlass32)
wallPlainGlass32.setParent(_scene)
wallPlainGlass32.addComponentOrReplace(gltfShape)
const transform118 = new Transform({
  position: new Vector3(13.042866706848145, 0.01360512524843216, 21.793546676635742),
  rotation: new Quaternion(-4.4183853743008953e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.230224609375, 4.692201137542725, 0.025500988587737083)
})
wallPlainGlass32.addComponentOrReplace(transform118)

const wallPlainGlass36 = new Entity('wallPlainGlass36')
engine.addEntity(wallPlainGlass36)
wallPlainGlass36.setParent(_scene)
wallPlainGlass36.addComponentOrReplace(gltfShape)
const transform119 = new Transform({
  position: new Vector3(13.071372985839844, 0.01360516157001257, 24.25666618347168),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.1816303730010986, 4.692201137542725, 0.022238658741116524)
})
wallPlainGlass36.addComponentOrReplace(transform119)

const redNeonTube = new Entity('redNeonTube')
engine.addEntity(redNeonTube)
redNeonTube.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(12.940983772277832, 13.418595314025879, 24.18865394592285),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.602400779724121, 1.0000035762786865, 1)
})
redNeonTube.addComponentOrReplace(transform120)
const gltfShape12 = new GLTFShape("0164b32d524bb895e2bfd83b09c7e1a9cbd0b669c3840a7e748cbe214c4975fb/NeonLightTube_06/NeonLightTube_06.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
redNeonTube.addComponentOrReplace(gltfShape12)

const redNeonTube14 = new Entity('redNeonTube14')
engine.addEntity(redNeonTube14)
redNeonTube14.setParent(_scene)
redNeonTube14.addComponentOrReplace(gltfShape12)
const transform121 = new Transform({
  position: new Vector3(3.213441848754883, 13.418595314025879, 24.226299285888672),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.602423667907715, 1.0000050067901611, 1)
})
redNeonTube14.addComponentOrReplace(transform121)

const greenNeonTube = new Entity('greenNeonTube')
engine.addEntity(greenNeonTube)
greenNeonTube.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(12.926185607910156, 13.249517440795898, 7.14825439453125),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.58128547668457, 1.0000050067901611, 1)
})
greenNeonTube.addComponentOrReplace(transform122)
const gltfShape13 = new GLTFShape("0ae6c1ca8330479d14631630916abe5e9aa4a8c364232dc22884bec85b6707d5/NeonLightTube_05/NeonLightTube_05.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
greenNeonTube.addComponentOrReplace(gltfShape13)

const greenNeonTube6 = new Entity('greenNeonTube6')
engine.addEntity(greenNeonTube6)
greenNeonTube6.setParent(_scene)
greenNeonTube6.addComponentOrReplace(gltfShape13)
const transform123 = new Transform({
  position: new Vector3(3.102597236633301, 13.249517440795898, 6.990976810455322),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.581300735473633, 1.0000059604644775, 1)
})
greenNeonTube6.addComponentOrReplace(transform123)

const armchairD = new Entity('armchairD')
engine.addEntity(armchairD)
armchairD.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(2.8523731231689453, 26.84649658203125, 11.399323463439941),
  rotation: new Quaternion(-2.2437129855202046e-15, 0.9358304142951965, -1.115596717227163e-7, 0.35245081782341003),
  scale: new Vector3(1.000002145767212, 1, 1.000002145767212)
})
armchairD.addComponentOrReplace(transform124)
const gltfShape14 = new GLTFShape("6a85c86f62f8a98faaed338cbaac75267b42ec2f355a6fbcf1ae8bffdac90bd4/Armchair_D.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
armchairD.addComponentOrReplace(gltfShape14)

const armchairC = new Entity('armchairC')
engine.addEntity(armchairC)
armchairC.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(12.766463279724121, 26.857885360717773, 11.818690299987793),
  rotation: new Quaternion(1.5769249436724752e-15, 0.7993157505989075, -9.528585565021785e-8, -0.6009113788604736),
  scale: new Vector3(1.0000009536743164, 1, 1.0000009536743164)
})
armchairC.addComponentOrReplace(transform125)
const gltfShape15 = new GLTFShape("1b718eeeda8c2621cc36ef79025dbee79117692a7d4a6e6ca74d558c5f6581e8/Armchair_C.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
armchairC.addComponentOrReplace(gltfShape15)

const coffeeTable = new Entity('coffeeTable')
engine.addEntity(coffeeTable)
coffeeTable.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(4.2556538581848145, 26.79202651977539, 9.800572395324707),
  rotation: new Quaternion(-4.4196858345727267e-16, 0.4125116765499115, -4.917522034020294e-8, 0.9109523892402649),
  scale: new Vector3(1.499999761581421, 1, 1.499999761581421)
})
coffeeTable.addComponentOrReplace(transform126)
const gltfShape16 = new GLTFShape("c80d6609e7808171cdf1547900bf1a9ff87a102f4860d580b066aab37751483f/Coffee_Table.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
coffeeTable.addComponentOrReplace(gltfShape16)

const armchairD2 = new Entity('armchairD2')
engine.addEntity(armchairD2)
armchairD2.setParent(_scene)
armchairD2.addComponentOrReplace(gltfShape14)
const transform127 = new Transform({
  position: new Vector3(2.8135056495666504, 26.85574722290039, 8.61854076385498),
  rotation: new Quaternion(-2.868591848841041e-15, 0.4125116765499115, -4.917522034020294e-8, 0.9109523892402649),
  scale: new Vector3(1.0000011920928955, 1, 1.0000011920928955)
})
armchairD2.addComponentOrReplace(transform127)

const armchairC2 = new Entity('armchairC2')
engine.addEntity(armchairC2)
armchairC2.setParent(_scene)
armchairC2.addComponentOrReplace(gltfShape15)
const transform128 = new Transform({
  position: new Vector3(13.389286994934082, 26.857885360717773, 9.496940612792969),
  rotation: new Quaternion(4.337902209476923e-15, 0.47139668464660645, -5.6194863873315626e-8, -0.8819212913513184),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
armchairC2.addComponentOrReplace(transform128)

const signpostTree2 = new Entity('signpostTree2')
engine.addEntity(signpostTree2)
signpostTree2.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(8.183094024658203, 24.36920928955078, 5.392889022827148),
  rotation: new Quaternion(-2.46176110607621e-8, 0.9784449934959412, -0.2065075784921646, 1.887379141862766e-15),
  scale: new Vector3(1.9848086833953857, 1.9298039674758911, 1.135321021080017)
})
signpostTree2.addComponentOrReplace(transform129)

const neonRectangleSign3 = new Entity('neonRectangleSign3')
engine.addEntity(neonRectangleSign3)
neonRectangleSign3.setParent(_scene)
neonRectangleSign3.addComponentOrReplace(gltfShape9)
const transform130 = new Transform({
  position: new Vector3(5.819705486297607, 23.835386276245117, 5.683835983276367),
  rotation: new Quaternion(2.4617603955334744e-8, -0.9784449934959412, 0.2065075784921646, -3.3029134982598407e-15),
  scale: new Vector3(3.930509090423584, 5.873829364776611, 1.1353298425674438)
})
neonRectangleSign3.addComponentOrReplace(transform130)

const neonRectangleSign4 = new Entity('neonRectangleSign4')
engine.addEntity(neonRectangleSign4)
neonRectangleSign4.setParent(_scene)
neonRectangleSign4.addComponentOrReplace(gltfShape9)
const transform131 = new Transform({
  position: new Vector3(10.58028507232666, 23.768749237060547, 25.72220230102539),
  rotation: new Quaternion(0.2059214562177658, -1.7532065819188432e-15, -2.4547739840841132e-8, 0.9785685539245605),
  scale: new Vector3(3.9305074214935303, 5.8738298416137695, 1.1353297233581543)
})
neonRectangleSign4.addComponentOrReplace(transform131)

const wallPlainGlass = new Entity('wallPlainGlass')
engine.addEntity(wallPlainGlass)
wallPlainGlass.setParent(_scene)
wallPlainGlass.addComponentOrReplace(gltfShape)
const transform132 = new Transform({
  position: new Vector3(2.290606737136841, 22.348804473876953, 29.142059326171875),
  rotation: new Quaternion(0.1093096137046814, -0.32301148772239685, 0.6986067891120911, 0.6290180683135986),
  scale: new Vector3(2.3966782093048096, 0.2660795748233795, -0.03615952283143997)
})
wallPlainGlass.addComponentOrReplace(transform132)

const signpostTree3 = new Entity('signpostTree3')
engine.addEntity(signpostTree3)
signpostTree3.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(8.155925750732422, 8.64456844329834, 6.732294082641602),
  rotation: new Quaternion(-4.783441116216211e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(2.2869091033935547, 1.6997877359390259, 1)
})
signpostTree3.addComponentOrReplace(transform133)

const neonRectangleSign5 = new Entity('neonRectangleSign5')
engine.addEntity(neonRectangleSign5)
neonRectangleSign5.setParent(_scene)
neonRectangleSign5.addComponentOrReplace(gltfShape9)
const transform134 = new Transform({
  position: new Vector3(5.43281364440918, 8.110915184020996, 6.776693344116211),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(4.528757095336914, 5.173717498779297, 1.0000078678131104)
})
neonRectangleSign5.addComponentOrReplace(transform134)

const signpostTree4 = new Entity('signpostTree4')
engine.addEntity(signpostTree4)
signpostTree4.setParent(_scene)
const transform135 = new Transform({
  position: new Vector3(8.155925750732422, 8.64456844329834, 24.390405654907227),
  rotation: new Quaternion(1.4210854715202004e-14, 2.9802322387695312e-8, -2.012328698857216e-14, 1),
  scale: new Vector3(2.2869091033935547, 1.6997877359390259, 1)
})
signpostTree4.addComponentOrReplace(transform135)

const neonRectangleSign6 = new Entity('neonRectangleSign6')
engine.addEntity(neonRectangleSign6)
neonRectangleSign6.setParent(_scene)
neonRectangleSign6.addComponentOrReplace(gltfShape9)
const transform136 = new Transform({
  position: new Vector3(5.43281364440918, 8.110915184020996, 24.27669334411621),
  rotation: new Quaternion(-2.177062080483132e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(4.528757095336914, 5.173717498779297, 1.0000078678131104)
})
neonRectangleSign6.addComponentOrReplace(transform136)

const signpostTree7 = new Entity('signpostTree7')
engine.addEntity(signpostTree7)
signpostTree7.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(14.329307556152344, 8.641963005065918, 15.968681335449219),
  rotation: new Quaternion(-1.1190326754963696e-14, 0.7071068286895752, -8.42937097900176e-8, 0.7071068286895752),
  scale: new Vector3(2.6223487854003906, 1.6997877359390259, 1.0000033378601074)
})
signpostTree7.addComponentOrReplace(transform137)

const neonRectangleSign7 = new Entity('neonRectangleSign7')
engine.addEntity(neonRectangleSign7)
neonRectangleSign7.setParent(_scene)
neonRectangleSign7.addComponentOrReplace(gltfShape9)
const transform138 = new Transform({
  position: new Vector3(14.329307556152344, 8.108309745788574, 12.84614372253418),
  rotation: new Quaternion(-1.5394154660318578e-15, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(5.193039894104004, 5.173717498779297, 1.0000109672546387)
})
neonRectangleSign7.addComponentOrReplace(transform138)

const signpostTree8 = new Entity('signpostTree8')
engine.addEntity(signpostTree8)
signpostTree8.setParent(_scene)
const transform139 = new Transform({
  position: new Vector3(1.629817008972168, 8.641963005065918, 15.846144676208496),
  rotation: new Quaternion(3.4947329183082285e-14, -0.7071067690849304, 8.429369557916289e-8, 0.70710688829422),
  scale: new Vector3(2.62235951423645, 1.6997877359390259, 1.000004529953003)
})
signpostTree8.addComponentOrReplace(transform139)

const neonRectangleSign8 = new Entity('neonRectangleSign8')
engine.addEntity(neonRectangleSign8)
neonRectangleSign8.setParent(_scene)
neonRectangleSign8.addComponentOrReplace(gltfShape9)
const transform140 = new Transform({
  position: new Vector3(1.6298174858093262, 8.10831069946289, 18.96868133544922),
  rotation: new Quaternion(-4.731725943138074e-15, -0.7071067690849304, 8.429368136830817e-8, 0.70710688829422),
  scale: new Vector3(5.193051815032959, 5.173717498779297, 1.0000121593475342)
})
neonRectangleSign8.addComponentOrReplace(transform140)

const signpostTree9 = new Entity('signpostTree9')
engine.addEntity(signpostTree9)
signpostTree9.setParent(_scene)
const transform141 = new Transform({
  position: new Vector3(8.155925750732422, 16.276363372802734, 6.680644512176514),
  rotation: new Quaternion(-1.1689306411710731e-8, 0.9951807856559753, -0.0980570986866951, 9.153165082972058e-16),
  scale: new Vector3(2.2869091033935547, 1.6997876167297363, 0.9999999403953552)
})
signpostTree9.addComponentOrReplace(transform141)

const neonRectangleSign9 = new Entity('neonRectangleSign9')
engine.addEntity(neonRectangleSign9)
neonRectangleSign9.setParent(_scene)
neonRectangleSign9.addComponentOrReplace(gltfShape9)
const transform142 = new Transform({
  position: new Vector3(5.43281364440918, 15.761638641357422, 6.828342914581299),
  rotation: new Quaternion(1.1689300194461794e-8, -0.9951807856559753, 0.0980570986866951, -1.5978423164258017e-15),
  scale: new Vector3(4.528757095336914, 5.173717498779297, 1.0000078678131104)
})
neonRectangleSign9.addComponentOrReplace(transform142)

const signpostTree10 = new Entity('signpostTree10')
engine.addEntity(signpostTree10)
signpostTree10.setParent(_scene)
const transform143 = new Transform({
  position: new Vector3(8.095446586608887, 16.266889572143555, 24.420913696289062),
  rotation: new Quaternion(-0.15170086920261383, 1.2648192429932752e-16, 1.8084149289165907e-8, -0.9884264469146729),
  scale: new Vector3(2.2869091033935547, 1.6997878551483154, 1)
})
signpostTree10.addComponentOrReplace(transform143)

const neonRectangleSign10 = new Entity('neonRectangleSign10')
engine.addEntity(neonRectangleSign10)
neonRectangleSign10.setParent(_scene)
neonRectangleSign10.addComponentOrReplace(gltfShape9)
const transform144 = new Transform({
  position: new Vector3(10.818558692932129, 15.771112442016602, 24.218521118164062),
  rotation: new Quaternion(0.15170086920261383, -1.1823953139289065e-15, -1.808414396009539e-8, 0.9884264469146729),
  scale: new Vector3(4.528757095336914, 5.173717498779297, 1.0000078678131104)
})
neonRectangleSign10.addComponentOrReplace(transform144)

const floorBlueSmall2 = new Entity('floorBlueSmall2')
engine.addEntity(floorBlueSmall2)
floorBlueSmall2.setParent(_scene)
const transform145 = new Transform({
  position: new Vector3(13.5, 26.849355697631836, 26.746356964111328),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.5, 1, 10.789840698242188)
})
floorBlueSmall2.addComponentOrReplace(transform145)
const gltfShape17 = new GLTFShape("f974d0280dadd9bcf66393868f48623fd152c315c8fcf7cc3e6f8c510ae61277/BlueFloor_Small.glb")
gltfShape17.withCollisions = true
gltfShape17.isPointerBlocker = true
gltfShape17.visible = true
floorBlueSmall2.addComponentOrReplace(gltfShape17)

const floorBlueSmall3 = new Entity('floorBlueSmall3')
engine.addEntity(floorBlueSmall3)
floorBlueSmall3.setParent(_scene)
floorBlueSmall3.addComponentOrReplace(gltfShape17)
const transform146 = new Transform({
  position: new Vector3(13.5, 26.664812088012695, 26.746356964111328),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.5, 1, 10.789840698242188)
})
floorBlueSmall3.addComponentOrReplace(transform146)

const teleport = new Entity('teleport')
engine.addEntity(teleport)
teleport.setParent(_scene)
const transform147 = new Transform({
  position: new Vector3(0.1625593900680542, 29.887096405029297, 14.585798263549805),
  rotation: new Quaternion(-0.7071068286895752, -0.7071067690849304, 8.429368847373553e-8, -8.429369557916289e-8),
  scale: new Vector3(0.5646691918373108, 0.31157588958740234, 0.5156487226486206)
})
teleport.addComponentOrReplace(transform147)

const teleport2 = new Entity('teleport2')
engine.addEntity(teleport2)
teleport2.setParent(_scene)
const transform148 = new Transform({
  position: new Vector3(0.17147254943847656, 29.887096405029297, 17.05791473388672),
  rotation: new Quaternion(0.7071068286895752, 0.7071067690849304, -6.848861744401802e-8, 1.0009875950345304e-7),
  scale: new Vector3(0.5646691918373108, 0.27382659912109375, 0.5156487226486206)
})
teleport2.addComponentOrReplace(transform148)

const armchairA = new Entity('armchairA')
engine.addEntity(armchairA)
armchairA.setParent(_scene)
const transform149 = new Transform({
  position: new Vector3(13.307324409484863, 26.838136672973633, 23.069568634033203),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.8314696550369263, 9.911889975455779e-8, 0.5555702447891235),
  scale: new Vector3(1.0000011920928955, 1, 1.0000011920928955)
})
armchairA.addComponentOrReplace(transform149)
const gltfShape18 = new GLTFShape("6d438521cb88b97f69ce2a9826872cc0193b825ad7a651bdd5016f9faa6ac30d/Armchair_A.glb")
gltfShape18.withCollisions = true
gltfShape18.isPointerBlocker = true
gltfShape18.visible = true
armchairA.addComponentOrReplace(gltfShape18)

const armchairA2 = new Entity('armchairA2')
engine.addEntity(armchairA2)
armchairA2.setParent(_scene)
armchairA2.addComponentOrReplace(gltfShape18)
const transform150 = new Transform({
  position: new Vector3(13.233817100524902, 26.838136672973633, 20.069568634033203),
  rotation: new Quaternion(-1.6751692247300677e-15, 0.4713967740535736, -5.619487453145666e-8, -0.8819212317466736),
  scale: new Vector3(1.0000004768371582, 1, 1.0000004768371582)
})
armchairA2.addComponentOrReplace(transform150)

const armchairB = new Entity('armchairB')
engine.addEntity(armchairB)
armchairB.setParent(_scene)
const transform151 = new Transform({
  position: new Vector3(2.919966220855713, 26.877656936645508, 22.290027618408203),
  rotation: new Quaternion(-1.4444982245119618e-15, 0.8314696550369263, -9.911890685998515e-8, 0.5555702447891235),
  scale: new Vector3(1.0000028610229492, 1, 1.0000028610229492)
})
armchairB.addComponentOrReplace(transform151)
const gltfShape19 = new GLTFShape("0cd1c963c7efe037c7f520b4836f655568dae5efae72295029d6f8fd826c50c7/Armchair_B.glb")
gltfShape19.withCollisions = true
gltfShape19.isPointerBlocker = true
gltfShape19.visible = true
armchairB.addComponentOrReplace(gltfShape19)

const armchairB2 = new Entity('armchairB2')
engine.addEntity(armchairB2)
armchairB2.setParent(_scene)
armchairB2.addComponentOrReplace(gltfShape19)
const transform152 = new Transform({
  position: new Vector3(3.43914794921875, 26.877656936645508, 19.769874572753906),
  rotation: new Quaternion(2.0216306876290205e-15, 0.5431766510009766, -6.475170977182643e-8, 0.839618444442749),
  scale: new Vector3(1.0000017881393433, 1, 1.0000017881393433)
})
armchairB2.addComponentOrReplace(transform152)

const dclLogo = new Entity('dclLogo')
engine.addEntity(dclLogo)
dclLogo.setParent(_scene)
const transform153 = new Transform({
  position: new Vector3(12.183624267578125, 26.76656150817871, 15.872186660766602),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(4.274353981018066, 5.062524318695068, 5.0625)
})
dclLogo.addComponentOrReplace(transform153)
const gltfShape20 = new GLTFShape("096328824448d45480a4e7d7870cf89bb71a3b64c9b253739ebd02ad5607b61f/DecentralandLogo_01/DecentralandLogo_01.glb")
gltfShape20.withCollisions = true
gltfShape20.isPointerBlocker = true
gltfShape20.visible = true
dclLogo.addComponentOrReplace(gltfShape20)

const doorframeBlue = new Entity('doorframeBlue')
engine.addEntity(doorframeBlue)
doorframeBlue.setParent(_scene)
const transform154 = new Transform({
  position: new Vector3(9.792301177978516, 19.072284698486328, 7.118083953857422),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5593492984771729, 1.1886787414550781, 0.4769110679626465)
})
doorframeBlue.addComponentOrReplace(transform154)
const gltfShape21 = new GLTFShape("7a9c166ce6e070be687052971a343060bb8460bd5d6744b6f10da1cd837567fd/BlueDoorframe.glb")
gltfShape21.withCollisions = true
gltfShape21.isPointerBlocker = true
gltfShape21.visible = true
doorframeBlue.addComponentOrReplace(gltfShape21)

const doorframeBlue2 = new Entity('doorframeBlue2')
engine.addEntity(doorframeBlue2)
doorframeBlue2.setParent(_scene)
doorframeBlue2.addComponentOrReplace(gltfShape21)
const transform155 = new Transform({
  position: new Vector3(9.792301177978516, 19.064285278320312, 24.575366973876953),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5593492984771729, 1.1886787414550781, 0.4769110679626465)
})
doorframeBlue2.addComponentOrReplace(transform155)

const signpostTree11 = new Entity('signpostTree11')
engine.addEntity(signpostTree11)
signpostTree11.setParent(_scene)
const transform156 = new Transform({
  position: new Vector3(14.224873542785645, 8.641963005065918, 15.968681335449219),
  rotation: new Quaternion(-1.8338432714645053e-14, 0.7071068286895752, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(2.6223487854003906, 1.6997877359390259, 1.0000038146972656)
})
signpostTree11.addComponentOrReplace(transform156)

const signpostTree12 = new Entity('signpostTree12')
engine.addEntity(signpostTree12)
signpostTree12.setParent(_scene)
const transform157 = new Transform({
  position: new Vector3(8.155925750732422, 8.64456844329834, 6.828989028930664),
  rotation: new Quaternion(0, -1.184319275145457e-22, -9.93479014603938e-16, -1),
  scale: new Vector3(2.2869091033935547, 1.6997877359390259, 1)
})
signpostTree12.addComponentOrReplace(transform157)

const signpostTree13 = new Entity('signpostTree13')
engine.addEntity(signpostTree13)
signpostTree13.setParent(_scene)
const transform158 = new Transform({
  position: new Vector3(1.67789888381958, 8.641963005065918, 15.846144676208496),
  rotation: new Quaternion(2.9778480876085315e-15, 0.70710688829422, -8.429373110629967e-8, 0.7071067690849304),
  scale: new Vector3(2.62235951423645, 1.6997877359390259, 1.0000050067901611)
})
signpostTree13.addComponentOrReplace(transform158)

const signpostTree14 = new Entity('signpostTree14')
engine.addEntity(signpostTree14)
signpostTree14.setParent(_scene)
const transform159 = new Transform({
  position: new Vector3(8.155925750732422, 8.64456844329834, 24.212482452392578),
  rotation: new Quaternion(2.5028287073598256e-14, -1, 1.1920928955078125e-7, 7.450580596923828e-9),
  scale: new Vector3(2.2869091033935547, 1.6997877359390259, 1)
})
signpostTree14.addComponentOrReplace(transform159)

const nft = new Entity('nft')
engine.addEntity(nft)
nft.setParent(_scene)
const transform160 = new Transform({
  position: new Vector3(9.660174369812012, 1.5, 16),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(2.3548808097839355, 2.3548758029937744, 0.0064355190843343735)
})
nft.addComponentOrReplace(transform160)
const nftShape = new NFTShape("ethereum://0x959e104e1a4db6317fa58f8295f586e1a978c297/3412")
nftShape.withCollisions = true
nftShape.isPointerBlocker = true
nftShape.visible = true
nftShape.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft.addComponentOrReplace(nftShape)

const floorBlueSmall5 = new Entity('floorBlueSmall5')
engine.addEntity(floorBlueSmall5)
floorBlueSmall5.setParent(_scene)
floorBlueSmall5.addComponentOrReplace(gltfShape17)
const transform161 = new Transform({
  position: new Vector3(13.750170707702637, 11.304039001464844, 6.8634419441223145),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.746909141540527, 1, 1.176720142364502)
})
floorBlueSmall5.addComponentOrReplace(transform161)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform162 = new Transform({
  position: new Vector3(7.983872890472412, 11.183219909667969, 5.471276760101318),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1016253232955933, 1, 86.93523406982422)
})
ropeLight6.addComponentOrReplace(transform162)

const floorBlueSmall6 = new Entity('floorBlueSmall6')
engine.addEntity(floorBlueSmall6)
floorBlueSmall6.setParent(_scene)
floorBlueSmall6.addComponentOrReplace(gltfShape17)
const transform163 = new Transform({
  position: new Vector3(13.406343460083008, 11.101601600646973, 6.819692611694336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.5069122314453125, 1, 1.149562954902649)
})
floorBlueSmall6.addComponentOrReplace(transform163)

const floorBlueSmall7 = new Entity('floorBlueSmall7')
engine.addEntity(floorBlueSmall7)
floorBlueSmall7.setParent(_scene)
floorBlueSmall7.addComponentOrReplace(gltfShape17)
const transform164 = new Transform({
  position: new Vector3(13.750170707702637, 3.500232696533203, 6.863441467285156),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.746909141540527, 1, 1.176720142364502)
})
floorBlueSmall7.addComponentOrReplace(transform164)

const floorBlueSmall8 = new Entity('floorBlueSmall8')
engine.addEntity(floorBlueSmall8)
floorBlueSmall8.setParent(_scene)
floorBlueSmall8.addComponentOrReplace(gltfShape17)
const transform165 = new Transform({
  position: new Vector3(13.406343460083008, 3.297795295715332, 6.819692611694336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.5069122314453125, 1, 1.149562954902649)
})
floorBlueSmall8.addComponentOrReplace(transform165)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform166 = new Transform({
  position: new Vector3(7.983872890472412, 3.379413604736328, 5.471276760101318),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1016253232955933, 1, 86.93523406982422)
})
ropeLight7.addComponentOrReplace(transform166)

const floorBlueSmall9 = new Entity('floorBlueSmall9')
engine.addEntity(floorBlueSmall9)
floorBlueSmall9.setParent(_scene)
floorBlueSmall9.addComponentOrReplace(gltfShape17)
const transform167 = new Transform({
  position: new Vector3(2.180778980255127, 3.509500026702881, 24.35879898071289),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(5.746909141540527, 1, 1.3554596900939941)
})
floorBlueSmall9.addComponentOrReplace(transform167)

const floorBlueSmall10 = new Entity('floorBlueSmall10')
engine.addEntity(floorBlueSmall10)
floorBlueSmall10.setParent(_scene)
floorBlueSmall10.addComponentOrReplace(gltfShape17)
const transform168 = new Transform({
  position: new Vector3(2.524606704711914, 3.3070626258850098, 24.409194946289062),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(5.5069122314453125, 1, 1.3241772651672363)
})
floorBlueSmall10.addComponentOrReplace(transform168)

const ropeLight11 = new Entity('ropeLight11')
engine.addEntity(ropeLight11)
ropeLight11.setParent(_scene)
const transform169 = new Transform({
  position: new Vector3(7.947076320648193, 3.388681411743164, 25.96242904663086),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(1.1016253232955933, 1, 100.14037322998047)
})
ropeLight11.addComponentOrReplace(transform169)

const floorBlueSmall11 = new Entity('floorBlueSmall11')
engine.addEntity(floorBlueSmall11)
floorBlueSmall11.setParent(_scene)
floorBlueSmall11.addComponentOrReplace(gltfShape17)
const transform170 = new Transform({
  position: new Vector3(2.180778980255127, 11.3583402633667, 24.35879898071289),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(5.746909141540527, 1, 1.3554596900939941)
})
floorBlueSmall11.addComponentOrReplace(transform170)

const floorBlueSmall12 = new Entity('floorBlueSmall12')
engine.addEntity(floorBlueSmall12)
floorBlueSmall12.setParent(_scene)
floorBlueSmall12.addComponentOrReplace(gltfShape17)
const transform171 = new Transform({
  position: new Vector3(2.524606227874756, 11.155903816223145, 24.409194946289062),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(5.5069122314453125, 1, 1.3241772651672363)
})
floorBlueSmall12.addComponentOrReplace(transform171)

const ropeLight12 = new Entity('ropeLight12')
engine.addEntity(ropeLight12)
ropeLight12.setParent(_scene)
const transform172 = new Transform({
  position: new Vector3(7.947076320648193, 11.23752212524414, 25.96242904663086),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(1.1016253232955933, 1, 100.14037322998047)
})
ropeLight12.addComponentOrReplace(transform172)

const dclLogo3 = new Entity('dclLogo3')
engine.addEntity(dclLogo3)
dclLogo3.setParent(_scene)
dclLogo3.addComponentOrReplace(gltfShape20)
const transform173 = new Transform({
  position: new Vector3(4.509479999542236, 19.010974884033203, 13.800329208374023),
  rotation: new Quaternion(0.6839380264282227, 0.6839380264282227, 0.179523766040802, 0.17952392995357513),
  scale: new Vector3(2.6651604175567627, 5.06253719329834, 5.062519073486328)
})
dclLogo3.addComponentOrReplace(transform173)

const spotlightStripLight = new Entity('spotlightStripLight')
engine.addEntity(spotlightStripLight)
spotlightStripLight.setParent(_scene)
const transform174 = new Transform({
  position: new Vector3(14, 22, 11.108933448791504),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
spotlightStripLight.addComponentOrReplace(transform174)

const spotlightStripLight2 = new Entity('spotlightStripLight2')
engine.addEntity(spotlightStripLight2)
spotlightStripLight2.setParent(_scene)
const transform175 = new Transform({
  position: new Vector3(2.201350212097168, 22, 11.108933448791504),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
spotlightStripLight2.addComponentOrReplace(transform175)

const spotlightStripLight3 = new Entity('spotlightStripLight3')
engine.addEntity(spotlightStripLight3)
spotlightStripLight3.setParent(_scene)
const transform176 = new Transform({
  position: new Vector3(2.201350212097168, 22, 19.477842330932617),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
spotlightStripLight3.addComponentOrReplace(transform176)

const spotlightStripLight4 = new Entity('spotlightStripLight4')
engine.addEntity(spotlightStripLight4)
spotlightStripLight4.setParent(_scene)
const transform177 = new Transform({
  position: new Vector3(14, 22, 19.477842330932617),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
spotlightStripLight4.addComponentOrReplace(transform177)

const wallLightStreetlamp = new Entity('wallLightStreetlamp')
engine.addEntity(wallLightStreetlamp)
wallLightStreetlamp.setParent(_scene)
const transform178 = new Transform({
  position: new Vector3(15.831933975219727, 30.248756408691406, 21.5),
  rotation: new Quaternion(-1.9012774702195515e-15, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.4993095397949219, 1.4993095397949219, 1.4993095397949219)
})
wallLightStreetlamp.addComponentOrReplace(transform178)

const wallLightStreetlamp2 = new Entity('wallLightStreetlamp2')
engine.addEntity(wallLightStreetlamp2)
wallLightStreetlamp2.setParent(_scene)
const transform179 = new Transform({
  position: new Vector3(15.831933975219727, 30.248756408691406, 10.130349159240723),
  rotation: new Quaternion(-1.9012774702195515e-15, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.4993095397949219, 1.4993095397949219, 1.4993095397949219)
})
wallLightStreetlamp2.addComponentOrReplace(transform179)

const wallLightStreetlamp3 = new Entity('wallLightStreetlamp3')
engine.addEntity(wallLightStreetlamp3)
wallLightStreetlamp3.setParent(_scene)
const transform180 = new Transform({
  position: new Vector3(0.1666593849658966, 30.248756408691406, 10.130349159240723),
  rotation: new Quaternion(4.755615660382434e-15, 0.7071068286895752, -8.429370268459024e-8, 0.7071067690849304),
  scale: new Vector3(1.4993095397949219, 1.4993095397949219, 1.4993095397949219)
})
wallLightStreetlamp3.addComponentOrReplace(transform180)

const wallLightStreetlamp4 = new Entity('wallLightStreetlamp4')
engine.addEntity(wallLightStreetlamp4)
wallLightStreetlamp4.setParent(_scene)
const transform181 = new Transform({
  position: new Vector3(0.1666593849658966, 30.248756408691406, 21.42283058166504),
  rotation: new Quaternion(4.755615660382434e-15, 0.7071068286895752, -8.429370268459024e-8, 0.7071067690849304),
  scale: new Vector3(1.4993095397949219, 1.4993095397949219, 1.4993095397949219)
})
wallLightStreetlamp4.addComponentOrReplace(transform181)

const signpostTree15 = new Entity('signpostTree15')
engine.addEntity(signpostTree15)
signpostTree15.setParent(_scene)
const transform182 = new Transform({
  position: new Vector3(14.329307556152344, 5.275376319885254, 16.03957748413086),
  rotation: new Quaternion(-1.1190326754963696e-14, 0.7071068286895752, -8.42937097900176e-8, 0.7071068286895752),
  scale: new Vector3(5.656806468963623, 2.5496816635131836, 1.000004768371582)
})
signpostTree15.addComponentOrReplace(transform182)

const neonRectangleSign11 = new Entity('neonRectangleSign11')
engine.addEntity(neonRectangleSign11)
neonRectangleSign11.setParent(_scene)
neonRectangleSign11.addComponentOrReplace(gltfShape9)
const transform183 = new Transform({
  position: new Vector3(14.329307556152344, 4.474896430969238, 9.303792953491211),
  rotation: new Quaternion(-1.5394154660318578e-15, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(11.202179908752441, 7.760576248168945, 1.0000123977661133)
})
neonRectangleSign11.addComponentOrReplace(transform183)

const signpostTree16 = new Entity('signpostTree16')
engine.addEntity(signpostTree16)
signpostTree16.setParent(_scene)
const transform184 = new Transform({
  position: new Vector3(1.629817008972168, 5.275376319885254, 15.775248527526855),
  rotation: new Quaternion(3.4947329183082285e-14, -0.7071067690849304, 8.429369557916289e-8, 0.70710688829422),
  scale: new Vector3(5.656830310821533, 2.5496816635131836, 1.0000059604644775)
})
signpostTree16.addComponentOrReplace(transform184)

const neonRectangleSign12 = new Entity('neonRectangleSign12')
engine.addEntity(neonRectangleSign12)
neonRectangleSign12.setParent(_scene)
neonRectangleSign12.addComponentOrReplace(gltfShape9)
const transform185 = new Transform({
  position: new Vector3(1.6298174858093262, 4.474897861480713, 22.511032104492188),
  rotation: new Quaternion(-4.731725943138074e-15, -0.7071067690849304, 8.429368136830817e-8, 0.70710688829422),
  scale: new Vector3(11.202208518981934, 7.760576248168945, 1.0000135898590088)
})
neonRectangleSign12.addComponentOrReplace(transform185)

const verticalBlackPad2 = new Entity('verticalBlackPad2')
engine.addEntity(verticalBlackPad2)
verticalBlackPad2.setParent(_scene)
const transform186 = new Transform({
  position: new Vector3(8, 0, 12.88689136505127),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4967598915100098, 1, 1.3121752738952637)
})
verticalBlackPad2.addComponentOrReplace(transform186)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform187 = new Transform({
  position: new Vector3(12, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform187)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform188 = new Transform({
  position: new Vector3(8, 0, 13),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.095231056213379, 18.9824161529541, 2.095231056213379)
})
triggerArea.addComponentOrReplace(transform188)

const signpostTree17 = new Entity('signpostTree17')
engine.addEntity(signpostTree17)
signpostTree17.setParent(_scene)
const transform189 = new Transform({
  position: new Vector3(7.991495132446289, 2.407445192337036, 11.355329513549805),
  rotation: new Quaternion(-9.409856227549085e-10, 0.9999688863754272, -0.0078936368227005, -5.769553008821846e-17),
  scale: new Vector3(0.9952192902565002, 0.7290912866592407, 0.5692350268363953)
})
signpostTree17.addComponentOrReplace(transform189)

const neonRectangleSign13 = new Entity('neonRectangleSign13')
engine.addEntity(neonRectangleSign13)
neonRectangleSign13.setParent(_scene)
neonRectangleSign13.addComponentOrReplace(gltfShape9)
const transform190 = new Transform({
  position: new Vector3(6.806455135345459, 2.1788930892944336, 11.385398864746094),
  rotation: new Quaternion(9.409781842606435e-10, -0.9999688863754272, 0.0078936368227005, 5.769553008821846e-17),
  scale: new Vector3(1.9708291292190552, 2.2191646099090576, 0.5692392587661743)
})
neonRectangleSign13.addComponentOrReplace(transform190)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform191 = new Transform({
  position: new Vector3(8.10891056060791, 4.169832229614258, 17.632204055786133),
  rotation: new Quaternion(2.7895026884900125e-15, 5.960464477539063e-8, 6.016896423238554e-15, 1),
  scale: new Vector3(5.06252384185791, 5.0625, 1.0000077486038208)
})
nftPictureFrame15.addComponentOrReplace(transform191)

const ropeLight13 = new Entity('ropeLight13')
engine.addEntity(ropeLight13)
ropeLight13.setParent(_scene)
const transform192 = new Transform({
  position: new Vector3(3.6536755561828613, 18.948274612426758, 15.905716896057129),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3326146602630615, 2.4465692043304443, 645.1431884765625)
})
ropeLight13.addComponentOrReplace(transform192)

const ropeLight14 = new Entity('ropeLight14')
engine.addEntity(ropeLight14)
ropeLight14.setParent(_scene)
const transform193 = new Transform({
  position: new Vector3(12.358497619628906, 18.948274612426758, 15.905716896057129),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3326146602630615, 2.4465692043304443, 645.1431884765625)
})
ropeLight14.addComponentOrReplace(transform193)

const wallPlainGlass12 = new Entity('wallPlainGlass12')
engine.addEntity(wallPlainGlass12)
wallPlainGlass12.setParent(_scene)
wallPlainGlass12.addComponentOrReplace(gltfShape)
const transform194 = new Transform({
  position: new Vector3(9.69459056854248, 3.4559969902038574, 11.455880165100098),
  rotation: new Quaternion(7.856866389889668e-16, 0, 4.732596481249614e-16, 1),
  scale: new Vector3(1.6675465106964111, 2.1731553077697754, 0.030359096825122833)
})
wallPlainGlass12.addComponentOrReplace(transform194)

const wallPlainGlass13 = new Entity('wallPlainGlass13')
engine.addEntity(wallPlainGlass13)
wallPlainGlass13.setParent(_scene)
wallPlainGlass13.addComponentOrReplace(gltfShape)
const transform195 = new Transform({
  position: new Vector3(14.123201370239258, 19.046350479125977, 4.258681297302246),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.144708633422852, 5.812131404876709, 0.04486265778541565)
})
wallPlainGlass13.addComponentOrReplace(transform195)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform196 = new Transform({
  position: new Vector3(4.669233322143555, 27.282773971557617, 10.027261734008789),
  rotation: new Quaternion(-8.498840601547583e-16, 0.4219997227191925, -5.030628358326794e-8, 0.9065960049629211),
  scale: new Vector3(1, 1, 1)
})
radio.addComponentOrReplace(transform196)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform197 = new Transform({
  position: new Vector3(14.733247756958008, 21.5, 20.293928146362305),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.556641101837158, 4.5566301345825195, 1.6299958229064941)
})
nftPictureFrame.addComponentOrReplace(transform197)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform198 = new Transform({
  position: new Vector3(1.4740982055664062, 21.5, 10.907761573791504),
  rotation: new Quaternion(5.92002592374229e-15, -0.7071068286895752, 8.429370268459024e-8, 0.7071068286895752),
  scale: new Vector3(4.55664587020874, 4.5566301345825195, 1.6299983263015747)
})
nftPictureFrame2.addComponentOrReplace(transform198)

const armchairA3 = new Entity('armchairA3')
engine.addEntity(armchairA3)
armchairA3.setParent(_scene)
armchairA3.addComponentOrReplace(gltfShape18)
const transform199 = new Transform({
  position: new Vector3(13.591050148010254, 3.4302151203155518, 18.85575294494629),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.8314696550369263, 9.911889975455779e-8, 0.5555702447891235),
  scale: new Vector3(1.0000038146972656, 1, 1.0000038146972656)
})
armchairA3.addComponentOrReplace(transform199)

const armchairC3 = new Entity('armchairC3')
engine.addEntity(armchairC3)
armchairC3.setParent(_scene)
armchairC3.addComponentOrReplace(gltfShape15)
const transform200 = new Transform({
  position: new Vector3(13.626479148864746, 3.4785990715026855, 13.635705947875977),
  rotation: new Quaternion(4.337902209476923e-15, 0.47139668464660645, -5.6194863873315626e-8, -0.8819212913513184),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
armchairC3.addComponentOrReplace(transform200)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
const script9 = new Script9()
const script10 = new Script10()
const script11 = new Script11()
const script12 = new Script12()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script9.init(options)
script10.init(options)
script11.init(options)
script12.init(options)
script1.spawn(verticalPlatform2, {"distance":59,"speed":5,"autoStart":true,"onReachEnd":[{"entityName":"verticalPlatform2","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalPlatform2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalPlatform2, channelBus))
script2.spawn(verticalBlackPad, {"distance":30,"speed":5,"autoStart":true,"onReachEnd":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalBlackPad, channelBus))
script3.spawn(rainLight, {"startOn":true,"clickable":true,"onActivate":[{"entityName":"rainLight","actionId":"activate","values":{}}],"onDeactivate":[{"entityName":"rainLight","actionId":"activate","values":{}}]}, createChannel(channelId, rainLight, channelBus))
script4.spawn(ropeLight3, {"startOn":false,"clickable":false,"onActivate":[]}, createChannel(channelId, ropeLight3, channelBus))
script4.spawn(ropeLight4, {"startOn":false,"clickable":false,"onDeactivate":[{"entityName":"verticalPlatform2","actionId":"goToEnd","values":{}}],"onActivate":[{"entityName":"verticalPlatform2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, ropeLight4, channelBus))
script4.spawn(ropeLight5, {"startOn":false,"clickable":false,"onDeactivate":[{"entityName":"verticalPlatform2","actionId":"goToEnd","values":{}}],"onActivate":[{"entityName":"verticalPlatform2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, ropeLight5, channelBus))
script4.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script4.spawn(ropeLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight8, channelBus))
script4.spawn(ropeLight9, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight9, channelBus))
script4.spawn(ropeLight10, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight10, channelBus))
script5.spawn(signpostTree, {"text":"ART BLOCLS CURATED","fontSize":60}, createChannel(channelId, signpostTree, channelBus))
script5.spawn(signpostTree5, {"text":"ART BLOCKS CURATED","fontSize":36.5}, createChannel(channelId, signpostTree5, channelBus))
script5.spawn(signpostTree6, {"text":"ART BLOCKS CURATED ","fontSize":42.5}, createChannel(channelId, signpostTree6, channelBus))
script6.spawn(nftPictureFrame4, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3 \nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script6.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301147041979432961","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2 \nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script6.spawn(nftPictureFrame6, {"id":"72405646120007613708465591283795435405784754144165659770746301143743444549633","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2 \nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script6.spawn(nftPictureFrame8, {"id":"72405646120007613708465591283795435405784754144165659770746301145942467805185","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2 \nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script6.spawn(nftPictureFrame9, {"id":"72405646120007613708465591283795435405784754144165659770746301150340514316289","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2 \nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script6.spawn(nftPictureFrame10, {"id":"72405646120007613708465591283795435405784754144165659770746301149241002688513","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2 \nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script6.spawn(nftPictureFrame11, {"id":"72405646120007613708465591283795435405784754144165659770746301142643932921857","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3 \nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script6.spawn(nftPictureFrame12, {"id":"72405646120007613708465591283795435405784754144165659770746301154738560827393","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2 \nPrice: .04 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script6.spawn(nftPictureFrame13, {"id":"11000026","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame13, channelBus))
script6.spawn(nftPictureFrame14, {"id":"29000839","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame14, channelBus))
script6.spawn(nftPictureFrame17, {"id":"9000269","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame17, channelBus))
script6.spawn(nftPictureFrame18, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 \nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script6.spawn(nftPictureFrame21, {"id":"74000375","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame21, channelBus))
script6.spawn(nftPictureFrame22, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 \nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script6.spawn(nftPictureFrame23, {"id":"62000056","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame23, channelBus))
script6.spawn(nftPictureFrame24, {"id":"114000115","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame24, channelBus))
script6.spawn(nftPictureFrame29, {"id":"40000102","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame29, channelBus))
script6.spawn(nftPictureFrame30, {"id":"59000149","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 \nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script6.spawn(nftPictureFrame31, {"id":"72405646120007613708465591283795435405784754144165659770746301131648816644097","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 \nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame31, channelBus))
script6.spawn(nftPictureFrame32, {"id":"72405646120007613708465591283795435405784754144165659770746301151440025944065","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame32, channelBus))
script5.spawn(signpostTree2, {"text":"","fontSize":60}, createChannel(channelId, signpostTree2, channelBus))
script5.spawn(signpostTree3, {"text":"ART BLOCKS CURATED \nGENERATIVE ART ","fontSize":34}, createChannel(channelId, signpostTree3, channelBus))
script5.spawn(signpostTree4, {"text":"ART BLOCKS CURATED \n","fontSize":33}, createChannel(channelId, signpostTree4, channelBus))
script5.spawn(signpostTree7, {"text":"ART BLOCKS CURATED","fontSize":40}, createChannel(channelId, signpostTree7, channelBus))
script5.spawn(signpostTree8, {"text":"ART BLOCKS CURATED\n","fontSize":40}, createChannel(channelId, signpostTree8, channelBus))
script5.spawn(signpostTree9, {"text":"ART BLOCKS CURATED","fontSize":45}, createChannel(channelId, signpostTree9, channelBus))
script5.spawn(signpostTree10, {"text":"Ignore \"Not For\nSale\" Text In UI","fontSize":45}, createChannel(channelId, signpostTree10, channelBus))
script7.spawn(teleport, {"x":"109","y":"-29","name":"Sango's Gallery"}, createChannel(channelId, teleport, channelBus))
script7.spawn(teleport2, {"x":"-21","y":"-129","name":"The Zoo"}, createChannel(channelId, teleport2, channelBus))
script5.spawn(signpostTree11, {"text":"Get Yours Now!\nPrices Double With\nEach New Mint!","fontSize":40}, createChannel(channelId, signpostTree11, channelBus))
script5.spawn(signpostTree12, {"text":"https://opensea.io/cliffnick24","fontSize":33}, createChannel(channelId, signpostTree12, channelBus))
script5.spawn(signpostTree13, {"text":"CLIFFNICK24 ON OPENSEA\n\nhttps://opensea.io/cliffnick24","fontSize":40}, createChannel(channelId, signpostTree13, channelBus))
script5.spawn(signpostTree14, {"text":"Snatch Up These \nCrypto Collectibles For\nSale Now On OpenSea!","fontSize":33}, createChannel(channelId, signpostTree14, channelBus))
script4.spawn(ropeLight6, {"startOn":false,"clickable":false,"onDeactivate":[],"onActivate":[]}, createChannel(channelId, ropeLight6, channelBus))
script4.spawn(ropeLight7, {"startOn":false,"clickable":false,"onDeactivate":[],"onActivate":[]}, createChannel(channelId, ropeLight7, channelBus))
script4.spawn(ropeLight11, {"startOn":false,"clickable":false,"onDeactivate":[],"onActivate":[]}, createChannel(channelId, ropeLight11, channelBus))
script4.spawn(ropeLight12, {"startOn":false,"clickable":false,"onDeactivate":[],"onActivate":[]}, createChannel(channelId, ropeLight12, channelBus))
script8.spawn(spotlightStripLight, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightStripLight, channelBus))
script8.spawn(spotlightStripLight2, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightStripLight2, channelBus))
script8.spawn(spotlightStripLight3, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightStripLight3, channelBus))
script8.spawn(spotlightStripLight4, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightStripLight4, channelBus))
script9.spawn(wallLightStreetlamp, {"startOn":true,"clickable":true}, createChannel(channelId, wallLightStreetlamp, channelBus))
script9.spawn(wallLightStreetlamp2, {"startOn":true,"clickable":true}, createChannel(channelId, wallLightStreetlamp2, channelBus))
script9.spawn(wallLightStreetlamp3, {"startOn":true,"clickable":true}, createChannel(channelId, wallLightStreetlamp3, channelBus))
script9.spawn(wallLightStreetlamp4, {"startOn":true,"clickable":true}, createChannel(channelId, wallLightStreetlamp4, channelBus))
script5.spawn(signpostTree15, {"text":"ART BLOCKS CURATED COLLECTION\nTHE BEST OF GENERATIVE ART!","fontSize":29.5}, createChannel(channelId, signpostTree15, channelBus))
script5.spawn(signpostTree16, {"text":"THE BEST OF GENERATIVE ART \n(CLIFFNICK24@GMAIL.COM FOR LEASE/BUY THIS LAND&GALLARY)","fontSize":25.5}, createChannel(channelId, signpostTree16, channelBus))
script2.spawn(verticalBlackPad2, {"distance":24,"speed":5,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad2","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad2, channelBus))
script10.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script11.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad2","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad2","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script5.spawn(signpostTree17, {"text":"Take This\nLift To See\nMature Content","fontSize":45}, createChannel(channelId, signpostTree17, channelBus))
script6.spawn(nftPictureFrame15, {"id":"27000075","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame15, channelBus))
script4.spawn(ropeLight13, {"startOn":false,"clickable":false,"onDeactivate":[],"onActivate":[]}, createChannel(channelId, ropeLight13, channelBus))
script4.spawn(ropeLight14, {"startOn":false,"clickable":false,"onDeactivate":[],"onActivate":[]}, createChannel(channelId, ropeLight14, channelBus))
script12.spawn(radio, {"startOn":true,"volume":0.6,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmWiz4AbpLH4JL8WPUsc6JQ4VQGb8TUvYigkPzEpsnLavD"}, createChannel(channelId, radio, channelBus))
script6.spawn(nftPictureFrame, {"id":"138000499","contract":"0xa7d8d9ef8D8Ce8992Df33D8b8CF4Aebabd5bD270","style":"Metal_Slim","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame, channelBus))
script6.spawn(nftPictureFrame2, {"id":"72405646120007613708465591283795435405784754144165659770746301152539537571841","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Metal_Slim","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame2, channelBus))