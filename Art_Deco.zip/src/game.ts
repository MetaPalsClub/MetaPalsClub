import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"
import Script2 from "../9a4e5e6d-c523-4cf9-a1fa-47417a068303/src/item"
import Script3 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script4 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script5 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script6 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script7 from "../27de7a4b-c63b-4c88-b521-e60a321abbb7/src/item"
import Script8 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const dwMetal2 = new Entity('dwMetal2')
engine.addEntity(dwMetal2)
dwMetal2.setParent(_scene)
const gltfShape = new GLTFShape("models/DW_7171_Metal.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
dwMetal2.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(14.722558975219727, 8.567523956298828, 12.118675231933594),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358659982681274, 0.39359405636787415, 0.207969531416893)
})
dwMetal2.addComponentOrReplace(transform2)

const dwMetal3 = new Entity('dwMetal3')
engine.addEntity(dwMetal3)
dwMetal3.setParent(_scene)
dwMetal3.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(14.722558975219727, 7.5, 12.948748588562012),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358636140823364, 0.3935917913913727, 0.20796871185302734)
})
dwMetal3.addComponentOrReplace(transform3)

const dwMetal4 = new Entity('dwMetal4')
engine.addEntity(dwMetal4)
dwMetal4.setParent(_scene)
dwMetal4.addComponentOrReplace(gltfShape)
const transform4 = new Transform({
  position: new Vector3(14.722558975219727, 6.687231540679932, 13.778502464294434),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358655214309692, 0.3935932517051697, 0.20796965062618256)
})
dwMetal4.addComponentOrReplace(transform4)

const dwMetal = new Entity('dwMetal')
engine.addEntity(dwMetal)
dwMetal.setParent(_scene)
dwMetal.addComponentOrReplace(gltfShape)
const transform5 = new Transform({
  position: new Vector3(14.722558975219727, 9.505022048950195, 11.286266326904297),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358664751052856, 0.3935944139957428, 0.20796963572502136)
})
dwMetal.addComponentOrReplace(transform5)

const dwMetal5 = new Entity('dwMetal5')
engine.addEntity(dwMetal5)
dwMetal5.setParent(_scene)
dwMetal5.addComponentOrReplace(gltfShape)
const transform6 = new Transform({
  position: new Vector3(14.722558975219727, 10.317790985107422, 10.456512451171875),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358645677566528, 0.39359307289123535, 0.20796871185302734)
})
dwMetal5.addComponentOrReplace(transform6)

const dwMetal6 = new Entity('dwMetal6')
engine.addEntity(dwMetal6)
dwMetal6.setParent(_scene)
dwMetal6.addComponentOrReplace(gltfShape)
const transform7 = new Transform({
  position: new Vector3(14.722558975219727, 11.38531494140625, 9.626439094543457),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358669519424438, 0.393595427274704, 0.20796939730644226)
})
dwMetal6.addComponentOrReplace(transform7)

const dwMetal7 = new Entity('dwMetal7')
engine.addEntity(dwMetal7)
dwMetal7.setParent(_scene)
dwMetal7.addComponentOrReplace(gltfShape)
const transform8 = new Transform({
  position: new Vector3(14.722558975219727, 11.38531494140625, 6.2647786140441895),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867190361023, 0.3935956656932831, 0.20796942710876465)
})
dwMetal7.addComponentOrReplace(transform8)

const dwMetal8 = new Entity('dwMetal8')
engine.addEntity(dwMetal8)
dwMetal8.setParent(_scene)
dwMetal8.addComponentOrReplace(gltfShape)
const transform9 = new Transform({
  position: new Vector3(14.722558975219727, 10.317790985107422, 5.435916900634766),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358655214309692, 0.39359408617019653, 0.20796871185302734)
})
dwMetal8.addComponentOrReplace(transform9)

const dwMetal9 = new Entity('dwMetal9')
engine.addEntity(dwMetal9)
dwMetal9.setParent(_scene)
dwMetal9.addComponentOrReplace(gltfShape)
const transform10 = new Transform({
  position: new Vector3(14.722558975219727, 9.505022048950195, 4.6054487228393555),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358669519424438, 0.3935951888561249, 0.2079695165157318)
})
dwMetal9.addComponentOrReplace(transform10)

const dwMetal10 = new Entity('dwMetal10')
engine.addEntity(dwMetal10)
dwMetal10.setParent(_scene)
dwMetal10.addComponentOrReplace(gltfShape)
const transform11 = new Transform({
  position: new Vector3(14.722558975219727, 8.567523956298828, 3.772843837738037),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867428779602, 0.39359578490257263, 0.20796950161457062)
})
dwMetal10.addComponentOrReplace(transform11)

const dwMetal11 = new Entity('dwMetal11')
engine.addEntity(dwMetal11)
dwMetal11.setParent(_scene)
dwMetal11.addComponentOrReplace(gltfShape)
const transform12 = new Transform({
  position: new Vector3(14.722558975219727, 7.5, 2.9439821243286133),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358657598495483, 0.3935942053794861, 0.20796871185302734)
})
dwMetal11.addComponentOrReplace(transform12)

const dwMetal12 = new Entity('dwMetal12')
engine.addEntity(dwMetal12)
dwMetal12.setParent(_scene)
dwMetal12.addComponentOrReplace(gltfShape)
const transform13 = new Transform({
  position: new Vector3(14.722558975219727, 6.687231540679932, 2.113513946533203),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867190361023, 0.3935953378677368, 0.20796959102153778)
})
dwMetal12.addComponentOrReplace(transform13)

const dwMetal13 = new Entity('dwMetal13')
engine.addEntity(dwMetal13)
dwMetal13.setParent(_scene)
dwMetal13.addComponentOrReplace(gltfShape)
const transform14 = new Transform({
  position: new Vector3(1.0016436576843262, 9.505022048950195, 4.605449199676514),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867190361023, 0.39359599351882935, 0.20796924829483032)
})
dwMetal13.addComponentOrReplace(transform14)

const dwMetal14 = new Entity('dwMetal14')
engine.addEntity(dwMetal14)
dwMetal14.setParent(_scene)
dwMetal14.addComponentOrReplace(gltfShape)
const transform15 = new Transform({
  position: new Vector3(1.0016436576843262, 10.317790985107422, 5.435917377471924),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358657598495483, 0.3935948610305786, 0.20796871185302734)
})
dwMetal14.addComponentOrReplace(transform15)

const dwMetal15 = new Entity('dwMetal15')
engine.addEntity(dwMetal15)
dwMetal15.setParent(_scene)
dwMetal15.addComponentOrReplace(gltfShape)
const transform16 = new Transform({
  position: new Vector3(1.0016436576843262, 11.38531494140625, 6.264779090881348),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867428779602, 0.39359644055366516, 0.20796915888786316)
})
dwMetal15.addComponentOrReplace(transform16)

const dwMetal16 = new Entity('dwMetal16')
engine.addEntity(dwMetal16)
dwMetal16.setParent(_scene)
dwMetal16.addComponentOrReplace(gltfShape)
const transform17 = new Transform({
  position: new Vector3(1.0016436576843262, 11.38531494140625, 9.626440048217773),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867190361023, 0.39359623193740845, 0.20796912908554077)
})
dwMetal16.addComponentOrReplace(transform17)

const dwMetal17 = new Entity('dwMetal17')
engine.addEntity(dwMetal17)
dwMetal17.setParent(_scene)
dwMetal17.addComponentOrReplace(gltfShape)
const transform18 = new Transform({
  position: new Vector3(1.0016436576843262, 10.317790985107422, 10.456512451171875),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358648061752319, 0.39359384775161743, 0.20796871185302734)
})
dwMetal17.addComponentOrReplace(transform18)

const dwMetal18 = new Entity('dwMetal18')
engine.addEntity(dwMetal18)
dwMetal18.setParent(_scene)
dwMetal18.addComponentOrReplace(gltfShape)
const transform19 = new Transform({
  position: new Vector3(1.0016436576843262, 9.505022048950195, 11.286266326904297),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358667135238647, 0.3935951888561249, 0.20796936750411987)
})
dwMetal18.addComponentOrReplace(transform19)

const dwMetal19 = new Entity('dwMetal19')
engine.addEntity(dwMetal19)
dwMetal19.setParent(_scene)
dwMetal19.addComponentOrReplace(gltfShape)
const transform20 = new Transform({
  position: new Vector3(1.0016436576843262, 6.687231540679932, 2.1135144233703613),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.935867428779602, 0.3935961425304413, 0.2079693228006363)
})
dwMetal19.addComponentOrReplace(transform20)

const dwMetal20 = new Entity('dwMetal20')
engine.addEntity(dwMetal20)
dwMetal20.setParent(_scene)
dwMetal20.addComponentOrReplace(gltfShape)
const transform21 = new Transform({
  position: new Vector3(1.0016436576843262, 7.5, 2.9439826011657715),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358659982681274, 0.39359501004219055, 0.20796871185302734)
})
dwMetal20.addComponentOrReplace(transform21)

const dwMetal21 = new Entity('dwMetal21')
engine.addEntity(dwMetal21)
dwMetal21.setParent(_scene)
dwMetal21.addComponentOrReplace(gltfShape)
const transform22 = new Transform({
  position: new Vector3(1.0016436576843262, 8.567523956298828, 3.7728443145751953),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358676671981812, 0.3935965895652771, 0.20796923339366913)
})
dwMetal21.addComponentOrReplace(transform22)

const dwMetal22 = new Entity('dwMetal22')
engine.addEntity(dwMetal22)
dwMetal22.setParent(_scene)
dwMetal22.addComponentOrReplace(gltfShape)
const transform23 = new Transform({
  position: new Vector3(1.0016436576843262, 6.687231540679932, 13.77850341796875),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358657598495483, 0.39359405636787415, 0.20796938240528107)
})
dwMetal22.addComponentOrReplace(transform23)

const dwMetal23 = new Entity('dwMetal23')
engine.addEntity(dwMetal23)
dwMetal23.setParent(_scene)
dwMetal23.addComponentOrReplace(gltfShape)
const transform24 = new Transform({
  position: new Vector3(1.0016436576843262, 7.5, 12.948749542236328),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.9358638525009155, 0.39359256625175476, 0.20796871185302734)
})
dwMetal23.addComponentOrReplace(transform24)

const dwMetal24 = new Entity('dwMetal24')
engine.addEntity(dwMetal24)
dwMetal24.setParent(_scene)
dwMetal24.addComponentOrReplace(gltfShape)
const transform25 = new Transform({
  position: new Vector3(1.0016436576843262, 8.567523956298828, 12.118675231933594),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(0.9358662366867065, 0.3935948312282562, 0.20796926319599152)
})
dwMetal24.addComponentOrReplace(transform25)

const dwMetal25 = new Entity('dwMetal25')
engine.addEntity(dwMetal25)
dwMetal25.setParent(_scene)
dwMetal25.addComponentOrReplace(gltfShape)
const transform26 = new Transform({
  position: new Vector3(4.689107894897461, 9.505023002624512, 14.869635581970215),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358670711517334, 0.3895198702812195, 0.20796982944011688)
})
dwMetal25.addComponentOrReplace(transform26)

const dwMetal26 = new Entity('dwMetal26')
engine.addEntity(dwMetal26)
dwMetal26.setParent(_scene)
dwMetal26.addComponentOrReplace(gltfShape)
const transform27 = new Transform({
  position: new Vector3(5.519576549530029, 10.317791938781738, 14.869634628295898),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358656406402588, 0.3895190358161926, 0.2079687863588333)
})
dwMetal26.addComponentOrReplace(transform27)

const dwMetal27 = new Entity('dwMetal27')
engine.addEntity(dwMetal27)
dwMetal27.setParent(_scene)
dwMetal27.addComponentOrReplace(gltfShape)
const transform28 = new Transform({
  position: new Vector3(6.348438262939453, 11.385315895080566, 14.869634628295898),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358673095703125, 0.38952043652534485, 0.20796968042850494)
})
dwMetal27.addComponentOrReplace(transform28)

const dwMetal28 = new Entity('dwMetal28')
engine.addEntity(dwMetal28)
dwMetal28.setParent(_scene)
dwMetal28.addComponentOrReplace(gltfShape)
const transform29 = new Transform({
  position: new Vector3(9.710100173950195, 11.385315895080566, 14.869633674621582),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358670711517334, 0.3895202577114105, 0.20796962082386017)
})
dwMetal28.addComponentOrReplace(transform29)

const dwMetal29 = new Entity('dwMetal29')
engine.addEntity(dwMetal29)
dwMetal29.setParent(_scene)
dwMetal29.addComponentOrReplace(gltfShape)
const transform30 = new Transform({
  position: new Vector3(10.540172576904297, 10.317790985107422, 14.869633674621582),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358646869659424, 0.38951820135116577, 0.2079687863588333)
})
dwMetal29.addComponentOrReplace(transform30)

const dwMetal30 = new Entity('dwMetal30')
engine.addEntity(dwMetal30)
dwMetal30.setParent(_scene)
dwMetal30.addComponentOrReplace(gltfShape)
const transform31 = new Transform({
  position: new Vector3(11.369926452636719, 9.505022048950195, 14.869633674621582),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358665943145752, 0.3895193636417389, 0.2079697996377945)
})
dwMetal30.addComponentOrReplace(transform31)

const dwMetal31 = new Entity('dwMetal31')
engine.addEntity(dwMetal31)
dwMetal31.setParent(_scene)
dwMetal31.addComponentOrReplace(gltfShape)
const transform32 = new Transform({
  position: new Vector3(2.1971726417541504, 6.687232971191406, 14.869635581970215),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358673095703125, 0.3895198404788971, 0.20796999335289001)
})
dwMetal31.addComponentOrReplace(transform32)

const dwMetal32 = new Entity('dwMetal32')
engine.addEntity(dwMetal32)
dwMetal32.setParent(_scene)
dwMetal32.addComponentOrReplace(gltfShape)
const transform33 = new Transform({
  position: new Vector3(3.0276412963867188, 7.500001430511475, 14.869635581970215),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358658790588379, 0.38951900601387024, 0.2079687863588333)
})
dwMetal32.addComponentOrReplace(transform33)

const dwMetal33 = new Entity('dwMetal33')
engine.addEntity(dwMetal33)
dwMetal33.setParent(_scene)
dwMetal33.addComponentOrReplace(gltfShape)
const transform34 = new Transform({
  position: new Vector3(3.8565030097961426, 8.567524909973145, 14.869635581970215),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358675479888916, 0.38952040672302246, 0.20796984434127808)
})
dwMetal33.addComponentOrReplace(transform34)

const dwMetal34 = new Entity('dwMetal34')
engine.addEntity(dwMetal34)
dwMetal34.setParent(_scene)
dwMetal34.addComponentOrReplace(gltfShape)
const transform35 = new Transform({
  position: new Vector3(13.862161636352539, 6.68723201751709, 14.869634628295898),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358656406402588, 0.3895183801651001, 0.20796972513198853)
})
dwMetal34.addComponentOrReplace(transform35)

const dwMetal35 = new Entity('dwMetal35')
engine.addEntity(dwMetal35)
dwMetal35.setParent(_scene)
dwMetal35.addComponentOrReplace(gltfShape)
const transform36 = new Transform({
  position: new Vector3(13.03240966796875, 7.5, 14.869633674621582),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.935863733291626, 0.3895171284675598, 0.2079687863588333)
})
dwMetal35.addComponentOrReplace(transform36)

const dwMetal36 = new Entity('dwMetal36')
engine.addEntity(dwMetal36)
dwMetal36.setParent(_scene)
dwMetal36.addComponentOrReplace(gltfShape)
const transform37 = new Transform({
  position: new Vector3(12.202335357666016, 8.567523956298828, 14.869633674621582),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.935866117477417, 0.389519065618515, 0.20796966552734375)
})
dwMetal36.addComponentOrReplace(transform37)

const dwMetal37 = new Entity('dwMetal37')
engine.addEntity(dwMetal37)
dwMetal37.setParent(_scene)
dwMetal37.addComponentOrReplace(gltfShape)
const transform38 = new Transform({
  position: new Vector3(13.862159729003906, 6.687230110168457, 1.2907614707946777),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358654022216797, 0.38951829075813293, 0.20796963572502136)
})
dwMetal37.addComponentOrReplace(transform38)

const dwMetal38 = new Entity('dwMetal38')
engine.addEntity(dwMetal38)
dwMetal38.setParent(_scene)
dwMetal38.addComponentOrReplace(gltfShape)
const transform39 = new Transform({
  position: new Vector3(13.032405853271484, 7.499998569488525, 1.2907609939575195),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358634948730469, 0.38951700925827026, 0.2079687863588333)
})
dwMetal38.addComponentOrReplace(transform39)

const dwMetal39 = new Entity('dwMetal39')
engine.addEntity(dwMetal39)
dwMetal39.setParent(_scene)
dwMetal39.addComponentOrReplace(gltfShape)
const transform40 = new Transform({
  position: new Vector3(12.202333450317383, 8.567523002624512, 1.2907609939575195),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358658790588379, 0.38951894640922546, 0.2079695761203766)
})
dwMetal39.addComponentOrReplace(transform40)

const dwMetal40 = new Entity('dwMetal40')
engine.addEntity(dwMetal40)
dwMetal40.setParent(_scene)
dwMetal40.addComponentOrReplace(gltfShape)
const transform41 = new Transform({
  position: new Vector3(11.369924545288086, 9.505021095275879, 1.2907609939575195),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358663558959961, 0.38951924443244934, 0.20796971023082733)
})
dwMetal40.addComponentOrReplace(transform41)

const dwMetal41 = new Entity('dwMetal41')
engine.addEntity(dwMetal41)
dwMetal41.setParent(_scene)
dwMetal41.addComponentOrReplace(gltfShape)
const transform42 = new Transform({
  position: new Vector3(10.540170669555664, 10.317790031433105, 1.2907609939575195),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358644485473633, 0.3895180821418762, 0.2079687863588333)
})
dwMetal41.addComponentOrReplace(transform42)

const dwMetal42 = new Entity('dwMetal42')
engine.addEntity(dwMetal42)
dwMetal42.setParent(_scene)
dwMetal42.addComponentOrReplace(gltfShape)
const transform43 = new Transform({
  position: new Vector3(9.71009635925293, 11.385313987731934, 1.2907609939575195),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358668327331543, 0.38952013850212097, 0.207969531416893)
})
dwMetal42.addComponentOrReplace(transform43)

const dwMetal43 = new Entity('dwMetal43')
engine.addEntity(dwMetal43)
dwMetal43.setParent(_scene)
dwMetal43.addComponentOrReplace(gltfShape)
const transform44 = new Transform({
  position: new Vector3(6.348435878753662, 11.385313987731934, 1.2907614707946777),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358670711517334, 0.3895203173160553, 0.20796959102153778)
})
dwMetal43.addComponentOrReplace(transform44)

const dwMetal44 = new Entity('dwMetal44')
engine.addEntity(dwMetal44)
dwMetal44.setParent(_scene)
dwMetal44.addComponentOrReplace(gltfShape)
const transform45 = new Transform({
  position: new Vector3(5.519574165344238, 10.317790985107422, 1.2907609939575195),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358654022216797, 0.3895189166069031, 0.2079687863588333)
})
dwMetal44.addComponentOrReplace(transform45)

const dwMetal45 = new Entity('dwMetal45')
engine.addEntity(dwMetal45)
dwMetal45.setParent(_scene)
dwMetal45.addComponentOrReplace(gltfShape)
const transform46 = new Transform({
  position: new Vector3(4.68910551071167, 9.505022048950195, 1.2907624244689941),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358668327331543, 0.38951975107192993, 0.20796974003314972)
})
dwMetal45.addComponentOrReplace(transform46)

const dwMetal46 = new Entity('dwMetal46')
engine.addEntity(dwMetal46)
dwMetal46.setParent(_scene)
dwMetal46.addComponentOrReplace(gltfShape)
const transform47 = new Transform({
  position: new Vector3(3.8565006256103516, 8.567523956298828, 1.290761947631836),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358673095703125, 0.3895202875137329, 0.2079697549343109)
})
dwMetal46.addComponentOrReplace(transform47)

const dwMetal47 = new Entity('dwMetal47')
engine.addEntity(dwMetal47)
dwMetal47.setParent(_scene)
dwMetal47.addComponentOrReplace(gltfShape)
const transform48 = new Transform({
  position: new Vector3(3.0276389122009277, 7.5, 1.2907624244689941),
  rotation: new Quaternion(-0.5, 0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.9358656406402588, 0.3895188868045807, 0.2079687863588333)
})
dwMetal47.addComponentOrReplace(transform48)

const dwMetal48 = new Entity('dwMetal48')
engine.addEntity(dwMetal48)
dwMetal48.setParent(_scene)
dwMetal48.addComponentOrReplace(gltfShape)
const transform49 = new Transform({
  position: new Vector3(2.1971702575683594, 6.687231063842773, 1.290761947631836),
  rotation: new Quaternion(-0.4999999403953552, -0.49999991059303284, 0.5000001192092896, 0.5),
  scale: new Vector3(0.9358670711517334, 0.38951972126960754, 0.20796990394592285)
})
dwMetal48.addComponentOrReplace(transform49)

const woodParquetWall2 = new Entity('woodParquetWall2')
engine.addEntity(woodParquetWall2)
woodParquetWall2.setParent(_scene)
const gltfShape2 = new GLTFShape("models/Wood_Parquet Wall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
woodParquetWall2.addComponentOrReplace(gltfShape2)
const transform50 = new Transform({
  position: new Vector3(14.760181427001953, 0, 14.753156661987305),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.237026214599609, 65.38916015625, 467.77703857421875)
})
woodParquetWall2.addComponentOrReplace(transform50)

const woodParquetWall4 = new Entity('woodParquetWall4')
engine.addEntity(woodParquetWall4)
woodParquetWall4.setParent(_scene)
woodParquetWall4.addComponentOrReplace(gltfShape2)
const transform51 = new Transform({
  position: new Vector3(1.2601814270019531, 0, 14.753156661987305),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.237026214599609, 65.38916015625, 467.77703857421875)
})
woodParquetWall4.addComponentOrReplace(transform51)

const woodParquetWall6 = new Entity('woodParquetWall6')
engine.addEntity(woodParquetWall6)
woodParquetWall6.setParent(_scene)
woodParquetWall6.addComponentOrReplace(gltfShape2)
const transform52 = new Transform({
  position: new Vector3(1.2601814270019531, 0, 1.2531566619873047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.237026214599609, 65.38916015625, 467.77703857421875)
})
woodParquetWall6.addComponentOrReplace(transform52)

const woodParquetWall8 = new Entity('woodParquetWall8')
engine.addEntity(woodParquetWall8)
woodParquetWall8.setParent(_scene)
woodParquetWall8.addComponentOrReplace(gltfShape2)
const transform53 = new Transform({
  position: new Vector3(14.760181427001953, 0, 1.2531557083129883),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.237026214599609, 65.38916015625, 467.77703857421875)
})
woodParquetWall8.addComponentOrReplace(transform53)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(7.374085426330566, 13.541047096252441, 14.743703842163086),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.099280834197998, 18.435325622558594, 10.00161075592041)
})
ropeLight.addComponentOrReplace(transform54)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(7.374085426330566, 13.541047096252441, 1.0992076396942139),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.0992815494537354, 18.43533706665039, 10.00161075592041)
})
ropeLight2.addComponentOrReplace(transform55)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(14.91456413269043, 13.541047096252441, 7.291350364685059),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, 0.5000000596046448),
  scale: new Vector3(1.099282145500183, 18.435348510742188, 10.001614570617676)
})
ropeLight3.addComponentOrReplace(transform56)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(1.0951248407363892, 13.541047096252441, 7.291350364685059),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, 0.5000000596046448),
  scale: new Vector3(1.099282145500183, 18.435348510742188, 10.001614570617676)
})
ropeLight4.addComponentOrReplace(transform57)

const ceilingCrossLight = new Entity('ceilingCrossLight')
engine.addEntity(ceilingCrossLight)
ceilingCrossLight.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(16, 15.960309982299805, 10.344497680664062),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.024861335754395, 1, 14.928967475891113)
})
ceilingCrossLight.addComponentOrReplace(transform58)

const rainbowAnodizedMetalWall = new Entity('rainbowAnodizedMetalWall')
engine.addEntity(rainbowAnodizedMetalWall)
rainbowAnodizedMetalWall.setParent(_scene)
const transform59 = new Transform({
  position: new Vector3(8.034611701965332, 19.881080627441406, 15.185928344726562),
  rotation: new Quaternion(0.7071068286895752, -4.740640117874978e-15, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(14.78273868560791, 72.78781127929688, 1.0000035762786865)
})
rainbowAnodizedMetalWall.addComponentOrReplace(transform59)
const gltfShape3 = new GLTFShape("models/Rainbow_Anodized Metal Wall.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
rainbowAnodizedMetalWall.addComponentOrReplace(gltfShape3)

const rainbowAnodizedMetalWall2 = new Entity('rainbowAnodizedMetalWall2')
engine.addEntity(rainbowAnodizedMetalWall2)
rainbowAnodizedMetalWall2.setParent(_scene)
rainbowAnodizedMetalWall2.addComponentOrReplace(gltfShape3)
const transform60 = new Transform({
  position: new Vector3(15.253214836120605, 19.881080627441406, 8.116556167602539),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(14.782744407653809, 72.787841796875, 1.0000039339065552)
})
rainbowAnodizedMetalWall2.addComponentOrReplace(transform60)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape4 = new GLTFShape("models/CityTile.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
entity.addComponentOrReplace(gltfShape4)
const transform61 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform61)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
verticalBlackPad.addComponentOrReplace(transform62)

const ringWhiteLight = new Entity('ringWhiteLight')
engine.addEntity(ringWhiteLight)
ringWhiteLight.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringWhiteLight.addComponentOrReplace(transform63)
const gltfShape5 = new GLTFShape("models/Ring_White_Light.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
ringWhiteLight.addComponentOrReplace(gltfShape5)

const ringWhiteLight2 = new Entity('ringWhiteLight2')
engine.addEntity(ringWhiteLight2)
ringWhiteLight2.setParent(_scene)
ringWhiteLight2.addComponentOrReplace(gltfShape5)
const transform64 = new Transform({
  position: new Vector3(8, 2.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 83.18620300292969, 1)
})
ringWhiteLight2.addComponentOrReplace(transform64)

const wallPlainGlass = new Entity('wallPlainGlass')
engine.addEntity(wallPlainGlass)
wallPlainGlass.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(14.795053482055664, 11.851530075073242, 1.187006950378418),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.79210090637207, 3.3676133155822754, 0.12500086426734924)
})
wallPlainGlass.addComponentOrReplace(transform65)
const gltfShape6 = new GLTFShape("models/PlainGlassWall.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
wallPlainGlass.addComponentOrReplace(gltfShape6)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(1.2987773418426514, 13.30949592590332, 7.982001304626465),
  rotation: new Quaternion(-1.0700026180368517e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.5000031590461731, 0.5, 0.1729094237089157)
})
radio.addComponentOrReplace(transform66)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 16.16377067565918, 1)
})
triggerArea.addComponentOrReplace(transform67)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(7.942919731140137, 12.129150390625, 14.580275535583496),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(10.918410301208496, 2.4532437324523926, 0.06250002980232239)
})
invisibleWall.addComponentOrReplace(transform68)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(7.942919731140137, 12.129150390625, 1.282033920288086),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(10.918410301208496, 2.4532437324523926, 0.06250002980232239)
})
invisibleWall2.addComponentOrReplace(transform69)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(1.2522921562194824, 12.129150390625, 7.931155681610107),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(11.161136627197266, 2.471331834793091, 0.06250016391277313)
})
invisibleWall3.addComponentOrReplace(transform70)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(14.592041015625, 12.129150390625, 7.931153774261475),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(11.16113567352295, 2.471331834793091, 0.06250014901161194)
})
invisibleWall4.addComponentOrReplace(transform71)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(1.2937979698181152, 16.9893798828125, 7.931155204772949),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(2.7010421752929688, 0.6965453028678894, 0.0625002384185791)
})
invisibleWall7.addComponentOrReplace(transform72)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(14.592041015625, 16.9893798828125, 7.931154251098633),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(2.701043128967285, 0.6965453028678894, 0.0625002384185791)
})
invisibleWall8.addComponentOrReplace(transform73)

const invisibleWall10 = new Entity('invisibleWall10')
engine.addEntity(invisibleWall10)
invisibleWall10.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(7.942920684814453, 16.9893798828125, 14.580276489257812),
  rotation: new Quaternion(1.248542763757955e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(2.701045513153076, 0.6965453028678894, 0.06250026822090149)
})
invisibleWall10.addComponentOrReplace(transform74)

const invisibleWall12 = new Entity('invisibleWall12')
engine.addEntity(invisibleWall12)
invisibleWall12.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(7.942917823791504, 16.9893798828125, 1.2820320129394531),
  rotation: new Quaternion(1.248542763757955e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(2.701045513153076, 0.6965453028678894, 0.06250026822090149)
})
invisibleWall12.addComponentOrReplace(transform75)

const invisibleWall13 = new Entity('invisibleWall13')
engine.addEntity(invisibleWall13)
invisibleWall13.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(0.6388844847679138, 0, 14.750297546386719),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.186611294746399, 13.075058937072754, 0.06250038743019104)
})
invisibleWall13.addComponentOrReplace(transform76)

const invisibleWall14 = new Entity('invisibleWall14')
engine.addEntity(invisibleWall14)
invisibleWall14.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(1.8905863761901855, 0, 14.750297546386719),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.186611533164978, 13.075058937072754, 0.06250040233135223)
})
invisibleWall14.addComponentOrReplace(transform77)

const invisibleWall15 = new Entity('invisibleWall15')
engine.addEntity(invisibleWall15)
invisibleWall15.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(1.264735460281372, 0, 14.124446868896484),
  rotation: new Quaternion(1.5357410371066686e-15, -1.0000001192092896, 1.1920928955078125e-7, 0),
  scale: new Vector3(1.1866123676300049, 13.075058937072754, 0.06250044703483582)
})
invisibleWall15.addComponentOrReplace(transform78)

const invisibleWall16 = new Entity('invisibleWall16')
engine.addEntity(invisibleWall16)
invisibleWall16.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(1.264735460281372, 7.460725015562275e-8, 15.376148223876953),
  rotation: new Quaternion(1.5357410371066686e-15, -1.0000001192092896, 1.1920928955078125e-7, 0),
  scale: new Vector3(1.1866121292114258, 13.075058937072754, 0.06250043213367462)
})
invisibleWall16.addComponentOrReplace(transform79)

const invisibleWall17 = new Entity('invisibleWall17')
engine.addEntity(invisibleWall17)
invisibleWall17.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(1.264735460281372, 7.460725015562275e-8, 1.8761482238769531),
  rotation: new Quaternion(1.5357408253484318e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.1866121292114258, 13.075058937072754, 0.06250043213367462)
})
invisibleWall17.addComponentOrReplace(transform80)

const invisibleWall18 = new Entity('invisibleWall18')
engine.addEntity(invisibleWall18)
invisibleWall18.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(1.264735460281372, 0, 0.6244468688964844),
  rotation: new Quaternion(1.5357408253484318e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.1866123676300049, 13.075058937072754, 0.06250044703483582)
})
invisibleWall18.addComponentOrReplace(transform81)

const invisibleWall19 = new Entity('invisibleWall19')
engine.addEntity(invisibleWall19)
invisibleWall19.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(1.8905863761901855, 0, 1.2502975463867188),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866117715835571, 13.075058937072754, 0.06250041723251343)
})
invisibleWall19.addComponentOrReplace(transform82)

const invisibleWall20 = new Entity('invisibleWall20')
engine.addEntity(invisibleWall20)
invisibleWall20.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(0.6388844847679138, 0, 1.2502975463867188),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.186611533164978, 13.075058937072754, 0.06250040233135223)
})
invisibleWall20.addComponentOrReplace(transform83)

const invisibleWall21 = new Entity('invisibleWall21')
engine.addEntity(invisibleWall21)
invisibleWall21.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(14.76473617553711, 7.460725015562275e-8, 1.876147985458374),
  rotation: new Quaternion(1.5357408253484318e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.1866121292114258, 13.075058937072754, 0.06250043213367462)
})
invisibleWall21.addComponentOrReplace(transform84)

const invisibleWall22 = new Entity('invisibleWall22')
engine.addEntity(invisibleWall22)
invisibleWall22.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(14.76473617553711, 0, 0.6244466304779053),
  rotation: new Quaternion(1.5357408253484318e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.1866123676300049, 13.075058937072754, 0.06250044703483582)
})
invisibleWall22.addComponentOrReplace(transform85)

const invisibleWall23 = new Entity('invisibleWall23')
engine.addEntity(invisibleWall23)
invisibleWall23.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(15.390586853027344, 0, 1.2502973079681396),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866120100021362, 13.075058937072754, 0.06250043213367462)
})
invisibleWall23.addComponentOrReplace(transform86)

const invisibleWall24 = new Entity('invisibleWall24')
engine.addEntity(invisibleWall24)
invisibleWall24.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(14.138885498046875, 0, 1.2502973079681396),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866117715835571, 13.075058937072754, 0.06250041723251343)
})
invisibleWall24.addComponentOrReplace(transform87)

const invisibleWall25 = new Entity('invisibleWall25')
engine.addEntity(invisibleWall25)
invisibleWall25.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(14.76473617553711, 7.460725015562275e-8, 15.376148223876953),
  rotation: new Quaternion(1.5357408253484318e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.1866121292114258, 13.075058937072754, 0.06250043213367462)
})
invisibleWall25.addComponentOrReplace(transform88)

const invisibleWall26 = new Entity('invisibleWall26')
engine.addEntity(invisibleWall26)
invisibleWall26.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(14.76473617553711, 0, 14.124446868896484),
  rotation: new Quaternion(1.5357408253484318e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(1.1866123676300049, 13.075058937072754, 0.06250044703483582)
})
invisibleWall26.addComponentOrReplace(transform89)

const invisibleWall27 = new Entity('invisibleWall27')
engine.addEntity(invisibleWall27)
invisibleWall27.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(15.390586853027344, 0, 14.750297546386719),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866122484207153, 13.075058937072754, 0.06250044703483582)
})
invisibleWall27.addComponentOrReplace(transform90)

const invisibleWall28 = new Entity('invisibleWall28')
engine.addEntity(invisibleWall28)
invisibleWall28.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(14.138885498046875, 0, 14.750297546386719),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866120100021362, 13.075058937072754, 0.06250043213367462)
})
invisibleWall28.addComponentOrReplace(transform91)

const invisibleWall29 = new Entity('invisibleWall29')
engine.addEntity(invisibleWall29)
invisibleWall29.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(15.390586853027344, 13.046974182128906, 1.2502973079681396),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1866118907928467, 1.2257864475250244, 0.06250046193599701)
})
invisibleWall29.addComponentOrReplace(transform92)

const invisibleWall30 = new Entity('invisibleWall30')
engine.addEntity(invisibleWall30)
invisibleWall30.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(15.390586853027344, 13.046974182128906, 14.750297546386719),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1866118907928467, 1.2257864475250244, 0.06250046193599701)
})
invisibleWall30.addComponentOrReplace(transform93)

const invisibleWall31 = new Entity('invisibleWall31')
engine.addEntity(invisibleWall31)
invisibleWall31.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(1.8905866146087646, 13.046974182128906, 14.750297546386719),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1866118907928467, 1.2257864475250244, 0.06250046193599701)
})
invisibleWall31.addComponentOrReplace(transform94)

const invisibleWall32 = new Entity('invisibleWall32')
engine.addEntity(invisibleWall32)
invisibleWall32.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(2.8905868530273438, 13.046974182128906, 1.2502975463867188),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1866118907928467, 1.2257864475250244, 0.06250046193599701)
})
invisibleWall32.addComponentOrReplace(transform95)

const invisibleWall33 = new Entity('invisibleWall33')
engine.addEntity(invisibleWall33)
invisibleWall33.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(1.117497444152832, 1.5, 2.7502975463867188),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866124868392944, 15.996395111083984, 0.06250046193599701)
})
invisibleWall33.addComponentOrReplace(transform96)

const invisibleWall34 = new Entity('invisibleWall34')
engine.addEntity(invisibleWall34)
invisibleWall34.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(1.117497444152832, 1.5, 12.982305526733398),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866127252578735, 15.996395111083984, 0.0625004768371582)
})
invisibleWall34.addComponentOrReplace(transform97)

const invisibleWall35 = new Entity('invisibleWall35')
engine.addEntity(invisibleWall35)
invisibleWall35.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(14.911056518554688, 1.5, 12.982304573059082),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866129636764526, 15.996395111083984, 0.0625004917383194)
})
invisibleWall35.addComponentOrReplace(transform98)

const invisibleWall36 = new Entity('invisibleWall36')
engine.addEntity(invisibleWall36)
invisibleWall36.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(14.911056518554688, 1.5, 2.7502965927124023),
  rotation: new Quaternion(2.262906752104987e-16, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1866127252578735, 15.996395111083984, 0.0625004768371582)
})
invisibleWall36.addComponentOrReplace(transform99)

const invisibleWall37 = new Entity('invisibleWall37')
engine.addEntity(invisibleWall37)
invisibleWall37.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(13.130282402038574, 1.500000238418579, 14.760322570800781),
  rotation: new Quaternion(-6.9469267408625145e-15, 1, -1.1920926823449918e-7, 0),
  scale: new Vector3(1.1866133213043213, 15.996395111083984, 0.06250050663948059)
})
invisibleWall37.addComponentOrReplace(transform100)

const invisibleWall38 = new Entity('invisibleWall38')
engine.addEntity(invisibleWall38)
invisibleWall38.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(2.898273468017578, 1.5000017881393433, 14.760323524475098),
  rotation: new Quaternion(-6.9469267408625145e-15, 1, -1.1920926823449918e-7, 0),
  scale: new Vector3(1.1866130828857422, 15.996395111083984, 0.0625004917383194)
})
invisibleWall38.addComponentOrReplace(transform101)

const invisibleWall39 = new Entity('invisibleWall39')
engine.addEntity(invisibleWall39)
invisibleWall39.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(13.130279541015625, 1.4999982118606567, 1.0245628356933594),
  rotation: new Quaternion(-6.9469267408625145e-15, 1, -1.1920926823449918e-7, 0),
  scale: new Vector3(1.1866135597229004, 15.996395111083984, 0.06250052154064178)
})
invisibleWall39.addComponentOrReplace(transform102)

const invisibleWall40 = new Entity('invisibleWall40')
engine.addEntity(invisibleWall40)
invisibleWall40.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(2.898270606994629, 1.5, 1.024564266204834),
  rotation: new Quaternion(-6.9469267408625145e-15, 1, -1.1920926823449918e-7, 0),
  scale: new Vector3(1.1866133213043213, 15.996395111083984, 0.06250050663948059)
})
invisibleWall40.addComponentOrReplace(transform103)

const wallBrass = new Entity('wallBrass')
engine.addEntity(wallBrass)
wallBrass.setParent(_scene)
const transform104 = new Transform({
  position: new Vector3(8.000000953674316, 6.290892601013184, 14.758729934692383),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.08266090601682663, 0.3650328814983368, 0.24125294387340546)
})
wallBrass.addComponentOrReplace(transform104)
const gltfShape7 = new GLTFShape("models/Wall_- Brass.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
wallBrass.addComponentOrReplace(gltfShape7)

const wallBrass2 = new Entity('wallBrass2')
engine.addEntity(wallBrass2)
wallBrass2.setParent(_scene)
wallBrass2.addComponentOrReplace(gltfShape7)
const transform105 = new Transform({
  position: new Vector3(8.000000953674316, 6.290892601013184, 1.115694284439087),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.08266090601682663, 0.3650328814983368, 0.24125294387340546)
})
wallBrass2.addComponentOrReplace(transform105)

const wallBrass3 = new Entity('wallBrass3')
engine.addEntity(wallBrass3)
wallBrass3.setParent(_scene)
wallBrass3.addComponentOrReplace(gltfShape7)
const transform106 = new Transform({
  position: new Vector3(1.0764808654785156, 6.2908935546875, 7.937212944030762),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.08266092091798782, 0.3650328814983368, 0.241253063082695)
})
wallBrass3.addComponentOrReplace(transform106)

const wallBrass4 = new Entity('wallBrass4')
engine.addEntity(wallBrass4)
wallBrass4.setParent(_scene)
wallBrass4.addComponentOrReplace(gltfShape7)
const transform107 = new Transform({
  position: new Vector3(14.897222518920898, 6.290891647338867, 7.937211036682129),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.08266091346740723, 0.3650328814983368, 0.241253063082695)
})
wallBrass4.addComponentOrReplace(transform107)

const ringWhiteLight3 = new Entity('ringWhiteLight3')
engine.addEntity(ringWhiteLight3)
ringWhiteLight3.setParent(_scene)
ringWhiteLight3.addComponentOrReplace(gltfShape5)
const transform108 = new Transform({
  position: new Vector3(8, 19.689064025878906, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.984771728515625, 2.491715431213379, 7.916168212890625)
})
ringWhiteLight3.addComponentOrReplace(transform108)

const invisibleDome = new Entity('invisibleDome')
engine.addEntity(invisibleDome)
invisibleDome.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(7.986108779907227, 16.343477249145508, 7.919525146484375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(13.199446678161621, 0.23613491654396057, 13.199446678161621)
})
invisibleDome.addComponentOrReplace(transform109)

const discMetal = new Entity('discMetal')
engine.addEntity(discMetal)
discMetal.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(7.978650093078613, 16.44778060913086, 7.929079055786133),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7480999827384949, 0.7480999827384949, 0.7480999827384949)
})
discMetal.addComponentOrReplace(transform110)
const gltfShape8 = new GLTFShape("models/Disc_- Metal.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
discMetal.addComponentOrReplace(gltfShape8)

const invisibleWall41 = new Entity('invisibleWall41')
engine.addEntity(invisibleWall41)
invisibleWall41.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(5.398411750793457, 16.9893798828125, 14.074140548706055),
  rotation: new Quaternion(-3.801727812766109e-15, 0.9807853698730469, -1.1691871293351142e-7, 0.19509035348892212),
  scale: new Vector3(2.7010445594787598, 0.6965453028678894, 0.06250029802322388)
})
invisibleWall41.addComponentOrReplace(transform111)

const invisibleWall42 = new Entity('invisibleWall42')
engine.addEntity(invisibleWall42)
invisibleWall42.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(14.085907936096191, 16.9893798828125, 10.475661277770996),
  rotation: new Quaternion(-1.1571167802884043e-15, 0.8314696550369263, -9.911889975455779e-8, -0.5555702447891235),
  scale: new Vector3(2.7010467052459717, 0.6965453028678894, 0.06250029802322388)
})
invisibleWall42.addComponentOrReplace(transform112)

const invisibleWall43 = new Entity('invisibleWall43')
engine.addEntity(invisibleWall43)
invisibleWall43.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(10.487427711486816, 16.9893798828125, 1.7881669998168945),
  rotation: new Quaternion(-3.801727812766109e-15, 0.9807853698730469, -1.1691871293351142e-7, 0.19509035348892212),
  scale: new Vector3(2.701045513153076, 0.6965453028678894, 0.06250029802322388)
})
invisibleWall43.addComponentOrReplace(transform113)

const invisibleWall44 = new Entity('invisibleWall44')
engine.addEntity(invisibleWall44)
invisibleWall44.setParent(_scene)
const transform114 = new Transform({
  position: new Vector3(1.7999305725097656, 16.9893798828125, 5.3866472244262695),
  rotation: new Quaternion(-1.1571167802884043e-15, 0.8314696550369263, -9.911889975455779e-8, -0.5555702447891235),
  scale: new Vector3(2.7010467052459717, 0.6965453028678894, 0.06250029802322388)
})
invisibleWall44.addComponentOrReplace(transform114)

const invisibleWall45 = new Entity('invisibleWall45')
engine.addEntity(invisibleWall45)
invisibleWall45.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(5.398408889770508, 16.9893798828125, 1.7881665229797363),
  rotation: new Quaternion(-3.0009091948722403e-15, 0.9807853102684021, -1.1691870582808406e-7, -0.19509030878543854),
  scale: new Vector3(2.7010459899902344, 0.6965453028678894, 0.06250027567148209)
})
invisibleWall45.addComponentOrReplace(transform115)

const invisibleWall46 = new Entity('invisibleWall46')
engine.addEntity(invisibleWall46)
invisibleWall46.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(14.085906982421875, 16.9893798828125, 5.386645317077637),
  rotation: new Quaternion(-2.0768040844725607e-15, 0.831469714641571, -9.911889975455779e-8, 0.5555703043937683),
  scale: new Vector3(2.7010443210601807, 0.6965453028678894, 0.06250026822090149)
})
invisibleWall46.addComponentOrReplace(transform116)

const invisibleWall47 = new Entity('invisibleWall47')
engine.addEntity(invisibleWall47)
invisibleWall47.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(1.7999324798583984, 16.9893798828125, 10.475664138793945),
  rotation: new Quaternion(-2.0768040844725607e-15, 0.831469714641571, -9.911889975455779e-8, 0.5555703043937683),
  scale: new Vector3(2.701043128967285, 0.6965453028678894, 0.06250026822090149)
})
invisibleWall47.addComponentOrReplace(transform117)

const invisibleWall48 = new Entity('invisibleWall48')
engine.addEntity(invisibleWall48)
invisibleWall48.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(10.48742961883545, 16.9893798828125, 14.074142456054688),
  rotation: new Quaternion(-3.0009091948722403e-15, 0.9807853102684021, -1.1691870582808406e-7, -0.19509030878543854),
  scale: new Vector3(2.7010459899902344, 0.6965453028678894, 0.06250027567148209)
})
invisibleWall48.addComponentOrReplace(transform118)

const ringWhiteLight4 = new Entity('ringWhiteLight4')
engine.addEntity(ringWhiteLight4)
ringWhiteLight4.setParent(_scene)
ringWhiteLight4.addComponentOrReplace(gltfShape5)
const transform119 = new Transform({
  position: new Vector3(8, 15.284087181091309, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 10.398275375366211, 1)
})
ringWhiteLight4.addComponentOrReplace(transform119)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(0.9999999403953552, 14, 1.000000238418579),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(4.06644344329834, 4.066443920135498, 1.016610860824585)
})
nftPictureFrame.addComponentOrReplace(transform120)

const woodParquetWall = new Entity('woodParquetWall')
engine.addEntity(woodParquetWall)
woodParquetWall.setParent(_scene)
woodParquetWall.addComponentOrReplace(gltfShape2)
const transform121 = new Transform({
  position: new Vector3(1.4085465669631958, 13, 1.411401391029358),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(9.355539321899414, 0.5108528137207031, 701.66552734375)
})
woodParquetWall.addComponentOrReplace(transform121)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script1.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script1.spawn(ropeLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight2, channelBus))
script1.spawn(ropeLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight3, channelBus))
script1.spawn(ropeLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight4, channelBus))
script2.spawn(ceilingCrossLight, {"startOn":true,"clickable":false}, createChannel(channelId, ceilingCrossLight, channelBus))
script3.spawn(verticalBlackPad, {"distance":17,"speed":6,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad, channelBus))
script4.spawn(radio, {"startOn":true,"volume":0.38,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/Qmbvps2kDnrUcAMc7hJq9kJoAfFNEixbFEQkyGQKJdPT6n"}, createChannel(channelId, radio, channelBus))
script5.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script6.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script6.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script6.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script6.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script6.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script6.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script6.spawn(invisibleWall10, {"enabled":true}, createChannel(channelId, invisibleWall10, channelBus))
script6.spawn(invisibleWall12, {"enabled":true}, createChannel(channelId, invisibleWall12, channelBus))
script6.spawn(invisibleWall13, {"enabled":true}, createChannel(channelId, invisibleWall13, channelBus))
script6.spawn(invisibleWall14, {"enabled":true}, createChannel(channelId, invisibleWall14, channelBus))
script6.spawn(invisibleWall15, {"enabled":true}, createChannel(channelId, invisibleWall15, channelBus))
script6.spawn(invisibleWall16, {"enabled":true}, createChannel(channelId, invisibleWall16, channelBus))
script6.spawn(invisibleWall17, {"enabled":true}, createChannel(channelId, invisibleWall17, channelBus))
script6.spawn(invisibleWall18, {"enabled":true}, createChannel(channelId, invisibleWall18, channelBus))
script6.spawn(invisibleWall19, {"enabled":true}, createChannel(channelId, invisibleWall19, channelBus))
script6.spawn(invisibleWall20, {"enabled":true}, createChannel(channelId, invisibleWall20, channelBus))
script6.spawn(invisibleWall21, {"enabled":true}, createChannel(channelId, invisibleWall21, channelBus))
script6.spawn(invisibleWall22, {"enabled":true}, createChannel(channelId, invisibleWall22, channelBus))
script6.spawn(invisibleWall23, {"enabled":true}, createChannel(channelId, invisibleWall23, channelBus))
script6.spawn(invisibleWall24, {"enabled":true}, createChannel(channelId, invisibleWall24, channelBus))
script6.spawn(invisibleWall25, {"enabled":true}, createChannel(channelId, invisibleWall25, channelBus))
script6.spawn(invisibleWall26, {"enabled":true}, createChannel(channelId, invisibleWall26, channelBus))
script6.spawn(invisibleWall27, {"enabled":true}, createChannel(channelId, invisibleWall27, channelBus))
script6.spawn(invisibleWall28, {"enabled":true}, createChannel(channelId, invisibleWall28, channelBus))
script6.spawn(invisibleWall29, {"enabled":true}, createChannel(channelId, invisibleWall29, channelBus))
script6.spawn(invisibleWall30, {"enabled":true}, createChannel(channelId, invisibleWall30, channelBus))
script6.spawn(invisibleWall31, {"enabled":true}, createChannel(channelId, invisibleWall31, channelBus))
script6.spawn(invisibleWall32, {"enabled":true}, createChannel(channelId, invisibleWall32, channelBus))
script6.spawn(invisibleWall33, {"enabled":true}, createChannel(channelId, invisibleWall33, channelBus))
script6.spawn(invisibleWall34, {"enabled":true}, createChannel(channelId, invisibleWall34, channelBus))
script6.spawn(invisibleWall35, {"enabled":true}, createChannel(channelId, invisibleWall35, channelBus))
script6.spawn(invisibleWall36, {"enabled":true}, createChannel(channelId, invisibleWall36, channelBus))
script6.spawn(invisibleWall37, {"enabled":true}, createChannel(channelId, invisibleWall37, channelBus))
script6.spawn(invisibleWall38, {"enabled":true}, createChannel(channelId, invisibleWall38, channelBus))
script6.spawn(invisibleWall39, {"enabled":true}, createChannel(channelId, invisibleWall39, channelBus))
script6.spawn(invisibleWall40, {"enabled":true}, createChannel(channelId, invisibleWall40, channelBus))
script7.spawn(invisibleDome, {"enabled":true}, createChannel(channelId, invisibleDome, channelBus))
script6.spawn(invisibleWall41, {"enabled":true}, createChannel(channelId, invisibleWall41, channelBus))
script6.spawn(invisibleWall42, {"enabled":true}, createChannel(channelId, invisibleWall42, channelBus))
script6.spawn(invisibleWall43, {"enabled":true}, createChannel(channelId, invisibleWall43, channelBus))
script6.spawn(invisibleWall44, {"enabled":true}, createChannel(channelId, invisibleWall44, channelBus))
script6.spawn(invisibleWall45, {"enabled":true}, createChannel(channelId, invisibleWall45, channelBus))
script6.spawn(invisibleWall46, {"enabled":true}, createChannel(channelId, invisibleWall46, channelBus))
script6.spawn(invisibleWall47, {"enabled":true}, createChannel(channelId, invisibleWall47, channelBus))
script6.spawn(invisibleWall48, {"enabled":true}, createChannel(channelId, invisibleWall48, channelBus))
script8.spawn(nftPictureFrame, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame, channelBus))