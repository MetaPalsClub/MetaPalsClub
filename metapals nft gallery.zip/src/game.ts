import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script2 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script3 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script4 from "../552af2d3-4de2-4e12-be02-637e97a1e7da/src/item"
import Script5 from "../80116ece-2384-437c-b2e6-c856bb212a61/src/item"
import Script6 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"
import Script7 from "../85cf3207-2792-4349-9938-21fd82ea2168/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("da1fed3c954172146414a66adfa134f7a5e1cb49c902713481bf2fe94180c2cf/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform3)

const valenciaMarbleWall = new Entity('valenciaMarbleWall')
engine.addEntity(valenciaMarbleWall)
valenciaMarbleWall.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(0.42968857288360596, 0, 0.4519140124320984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 242.2186279296875)
})
valenciaMarbleWall.addComponentOrReplace(transform4)
const gltfShape2 = new GLTFShape("874830ba67fdfff68bc5aa202b34ebb45398e4f856be5162566450ca638d55be/Valencia_Marble Wall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
valenciaMarbleWall.addComponentOrReplace(gltfShape2)

const valenciaMarbleWall2 = new Entity('valenciaMarbleWall2')
engine.addEntity(valenciaMarbleWall2)
valenciaMarbleWall2.setParent(_scene)
valenciaMarbleWall2.addComponentOrReplace(gltfShape2)
const transform5 = new Transform({
  position: new Vector3(16, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(160.0126190185547, 0.731249988079071, 6420.3896484375)
})
valenciaMarbleWall2.addComponentOrReplace(transform5)

const valenciaMarbleWall3 = new Entity('valenciaMarbleWall3')
engine.addEntity(valenciaMarbleWall3)
valenciaMarbleWall3.setParent(_scene)
valenciaMarbleWall3.addComponentOrReplace(gltfShape2)
const transform6 = new Transform({
  position: new Vector3(0.4296886920928955, 0.14262008666992188, 0.45191407203674316),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall3.addComponentOrReplace(transform6)

const valenciaMarbleWall4 = new Entity('valenciaMarbleWall4')
engine.addEntity(valenciaMarbleWall4)
valenciaMarbleWall4.setParent(_scene)
valenciaMarbleWall4.addComponentOrReplace(gltfShape2)
const transform7 = new Transform({
  position: new Vector3(0.42968857288360596, 4.5, 0.4519140124320984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 363.32794189453125)
})
valenciaMarbleWall4.addComponentOrReplace(transform7)

const valenciaMarbleWall5 = new Entity('valenciaMarbleWall5')
engine.addEntity(valenciaMarbleWall5)
valenciaMarbleWall5.setParent(_scene)
valenciaMarbleWall5.addComponentOrReplace(gltfShape2)
const transform8 = new Transform({
  position: new Vector3(0.4296884536743164, 4.422621726989746, 0.45191383361816406),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.4841160774230957, 303.09466552734375)
})
valenciaMarbleWall5.addComponentOrReplace(transform8)

const valenciaMarbleWall6 = new Entity('valenciaMarbleWall6')
engine.addEntity(valenciaMarbleWall6)
valenciaMarbleWall6.setParent(_scene)
valenciaMarbleWall6.addComponentOrReplace(gltfShape2)
const transform9 = new Transform({
  position: new Vector3(0.4296884536743164, 4.5, 0.45191383361816406),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.70591163635254, 242.2186279296875)
})
valenciaMarbleWall6.addComponentOrReplace(transform9)

const valenciaMarbleWall8 = new Entity('valenciaMarbleWall8')
engine.addEntity(valenciaMarbleWall8)
valenciaMarbleWall8.setParent(_scene)
valenciaMarbleWall8.addComponentOrReplace(gltfShape2)
const transform10 = new Transform({
  position: new Vector3(4.929689407348633, 9.104865074157715, 2.3367481231689453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall8.addComponentOrReplace(transform10)

const valenciaMarbleWall9 = new Entity('valenciaMarbleWall9')
engine.addEntity(valenciaMarbleWall9)
valenciaMarbleWall9.setParent(_scene)
valenciaMarbleWall9.addComponentOrReplace(gltfShape2)
const transform11 = new Transform({
  position: new Vector3(4.929688930511475, 9, 2.3367481231689453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 181.66397094726562)
})
valenciaMarbleWall9.addComponentOrReplace(transform11)

const valenciaMarbleWall10 = new Entity('valenciaMarbleWall10')
engine.addEntity(valenciaMarbleWall10)
valenciaMarbleWall10.setParent(_scene)
valenciaMarbleWall10.addComponentOrReplace(gltfShape2)
const transform12 = new Transform({
  position: new Vector3(4.929688930511475, 13.5, 2.3367481231689453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 272.4959716796875)
})
valenciaMarbleWall10.addComponentOrReplace(transform12)

const valenciaMarbleWall11 = new Entity('valenciaMarbleWall11')
engine.addEntity(valenciaMarbleWall11)
valenciaMarbleWall11.setParent(_scene)
valenciaMarbleWall11.addComponentOrReplace(gltfShape2)
const transform13 = new Transform({
  position: new Vector3(4.929689407348633, 13.40068531036377, 2.3367481231689453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.654373288154602, 227.3209991455078)
})
valenciaMarbleWall11.addComponentOrReplace(transform13)

const valenciaMarbleWall12 = new Entity('valenciaMarbleWall12')
engine.addEntity(valenciaMarbleWall12)
valenciaMarbleWall12.setParent(_scene)
valenciaMarbleWall12.addComponentOrReplace(gltfShape2)
const transform14 = new Transform({
  position: new Vector3(4.929689407348633, 13.5, 2.3367481231689453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.702905654907227, 181.66397094726562)
})
valenciaMarbleWall12.addComponentOrReplace(transform14)

const valenciaMarbleWall14 = new Entity('valenciaMarbleWall14')
engine.addEntity(valenciaMarbleWall14)
valenciaMarbleWall14.setParent(_scene)
valenciaMarbleWall14.addComponentOrReplace(gltfShape2)
const transform15 = new Transform({
  position: new Vector3(8.929689407348633, 18.142620086669922, 3.751182794570923),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 215.13580322265625)
})
valenciaMarbleWall14.addComponentOrReplace(transform15)

const valenciaMarbleWall15 = new Entity('valenciaMarbleWall15')
engine.addEntity(valenciaMarbleWall15)
valenciaMarbleWall15.setParent(_scene)
valenciaMarbleWall15.addComponentOrReplace(gltfShape2)
const transform16 = new Transform({
  position: new Vector3(8.929689407348633, 18, 3.7503738403320312),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall15.addComponentOrReplace(transform16)

const valenciaMarbleWall16 = new Entity('valenciaMarbleWall16')
engine.addEntity(valenciaMarbleWall16)
valenciaMarbleWall16.setParent(_scene)
valenciaMarbleWall16.addComponentOrReplace(gltfShape2)
const transform17 = new Transform({
  position: new Vector3(8.929689407348633, 22.5, 3.7503738403320312),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 204.37197875976562)
})
valenciaMarbleWall16.addComponentOrReplace(transform17)

const valenciaMarbleWall17 = new Entity('valenciaMarbleWall17')
engine.addEntity(valenciaMarbleWall17)
valenciaMarbleWall17.setParent(_scene)
valenciaMarbleWall17.addComponentOrReplace(gltfShape2)
const transform18 = new Transform({
  position: new Vector3(8.929689407348633, 22.435636520385742, 3.7503738403320312),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.3308451175689697, 170.49075317382812)
})
valenciaMarbleWall17.addComponentOrReplace(transform18)

const valenciaMarbleWall18 = new Entity('valenciaMarbleWall18')
engine.addEntity(valenciaMarbleWall18)
valenciaMarbleWall18.setParent(_scene)
valenciaMarbleWall18.addComponentOrReplace(gltfShape2)
const transform19 = new Transform({
  position: new Vector3(8.929689407348633, 22.5, 3.7503738403320312),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall18.addComponentOrReplace(transform19)

const valenciaMarbleWall20 = new Entity('valenciaMarbleWall20')
engine.addEntity(valenciaMarbleWall20)
valenciaMarbleWall20.setParent(_scene)
valenciaMarbleWall20.addComponentOrReplace(gltfShape2)
const transform20 = new Transform({
  position: new Vector3(8.929689407348633, 27.142620086669922, 3.750680685043335),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 187.41998291015625)
})
valenciaMarbleWall20.addComponentOrReplace(transform20)

const valenciaMarbleWall21 = new Entity('valenciaMarbleWall21')
engine.addEntity(valenciaMarbleWall21)
valenciaMarbleWall21.setParent(_scene)
valenciaMarbleWall21.addComponentOrReplace(gltfShape2)
const transform21 = new Transform({
  position: new Vector3(8.929689407348633, 27, 3.7503738403320312),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 19.5893611907959, 136.24798583984375)
})
valenciaMarbleWall21.addComponentOrReplace(transform21)

const valenciaMarbleWall22 = new Entity('valenciaMarbleWall22')
engine.addEntity(valenciaMarbleWall22)
valenciaMarbleWall22.setParent(_scene)
valenciaMarbleWall22.addComponentOrReplace(gltfShape2)
const transform22 = new Transform({
  position: new Vector3(0.4296894073486328, 0.14262008666992188, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall22.addComponentOrReplace(transform22)

const valenciaMarbleWall23 = new Entity('valenciaMarbleWall23')
engine.addEntity(valenciaMarbleWall23)
valenciaMarbleWall23.setParent(_scene)
valenciaMarbleWall23.addComponentOrReplace(gltfShape2)
const transform23 = new Transform({
  position: new Vector3(0.4296884536743164, 4.5, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 363.32794189453125)
})
valenciaMarbleWall23.addComponentOrReplace(transform23)

const valenciaMarbleWall24 = new Entity('valenciaMarbleWall24')
engine.addEntity(valenciaMarbleWall24)
valenciaMarbleWall24.setParent(_scene)
valenciaMarbleWall24.addComponentOrReplace(gltfShape2)
const transform24 = new Transform({
  position: new Vector3(0.4296894073486328, 4.422621726989746, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.4841160774230957, 303.09466552734375)
})
valenciaMarbleWall24.addComponentOrReplace(transform24)

const valenciaMarbleWall25 = new Entity('valenciaMarbleWall25')
engine.addEntity(valenciaMarbleWall25)
valenciaMarbleWall25.setParent(_scene)
valenciaMarbleWall25.addComponentOrReplace(gltfShape2)
const transform25 = new Transform({
  position: new Vector3(0.4296884536743164, 0, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 242.2186279296875)
})
valenciaMarbleWall25.addComponentOrReplace(transform25)

const valenciaMarbleWall26 = new Entity('valenciaMarbleWall26')
engine.addEntity(valenciaMarbleWall26)
valenciaMarbleWall26.setParent(_scene)
valenciaMarbleWall26.addComponentOrReplace(gltfShape2)
const transform26 = new Transform({
  position: new Vector3(0.4296894073486328, 4.5, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.70591163635254, 242.2186279296875)
})
valenciaMarbleWall26.addComponentOrReplace(transform26)

const valenciaMarbleWall28 = new Entity('valenciaMarbleWall28')
engine.addEntity(valenciaMarbleWall28)
valenciaMarbleWall28.setParent(_scene)
valenciaMarbleWall28.addComponentOrReplace(gltfShape2)
const transform27 = new Transform({
  position: new Vector3(4.929689407348633, 9.104865074157715, 13.645751953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall28.addComponentOrReplace(transform27)

const valenciaMarbleWall29 = new Entity('valenciaMarbleWall29')
engine.addEntity(valenciaMarbleWall29)
valenciaMarbleWall29.setParent(_scene)
valenciaMarbleWall29.addComponentOrReplace(gltfShape2)
const transform28 = new Transform({
  position: new Vector3(4.929688930511475, 9, 13.645751953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 181.66397094726562)
})
valenciaMarbleWall29.addComponentOrReplace(transform28)

const valenciaMarbleWall30 = new Entity('valenciaMarbleWall30')
engine.addEntity(valenciaMarbleWall30)
valenciaMarbleWall30.setParent(_scene)
valenciaMarbleWall30.addComponentOrReplace(gltfShape2)
const transform29 = new Transform({
  position: new Vector3(4.929688930511475, 13.5, 13.645751953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 272.4959716796875)
})
valenciaMarbleWall30.addComponentOrReplace(transform29)

const valenciaMarbleWall31 = new Entity('valenciaMarbleWall31')
engine.addEntity(valenciaMarbleWall31)
valenciaMarbleWall31.setParent(_scene)
valenciaMarbleWall31.addComponentOrReplace(gltfShape2)
const transform30 = new Transform({
  position: new Vector3(4.929689407348633, 13.40068531036377, 13.645751953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.654373288154602, 227.3209991455078)
})
valenciaMarbleWall31.addComponentOrReplace(transform30)

const valenciaMarbleWall32 = new Entity('valenciaMarbleWall32')
engine.addEntity(valenciaMarbleWall32)
valenciaMarbleWall32.setParent(_scene)
valenciaMarbleWall32.addComponentOrReplace(gltfShape2)
const transform31 = new Transform({
  position: new Vector3(4.929689407348633, 13.5, 13.645751953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.702905654907227, 181.66397094726562)
})
valenciaMarbleWall32.addComponentOrReplace(transform31)

const valenciaMarbleWall33 = new Entity('valenciaMarbleWall33')
engine.addEntity(valenciaMarbleWall33)
valenciaMarbleWall33.setParent(_scene)
valenciaMarbleWall33.addComponentOrReplace(gltfShape2)
const transform32 = new Transform({
  position: new Vector3(15.277109146118164, 17.862085342407227, 8.741216659545898),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(129.84271240234375, 1.4434967041015625, 5681.283203125)
})
valenciaMarbleWall33.addComponentOrReplace(transform32)

const valenciaMarbleWall34 = new Entity('valenciaMarbleWall34')
engine.addEntity(valenciaMarbleWall34)
valenciaMarbleWall34.setParent(_scene)
valenciaMarbleWall34.addComponentOrReplace(gltfShape2)
const transform33 = new Transform({
  position: new Vector3(8.929689407348633, 18.142620086669922, 12.23222827911377),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 190.61500549316406)
})
valenciaMarbleWall34.addComponentOrReplace(transform33)

const valenciaMarbleWall35 = new Entity('valenciaMarbleWall35')
engine.addEntity(valenciaMarbleWall35)
valenciaMarbleWall35.setParent(_scene)
valenciaMarbleWall35.addComponentOrReplace(gltfShape2)
const transform34 = new Transform({
  position: new Vector3(8.929689407348633, 18, 12.232126235961914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall35.addComponentOrReplace(transform34)

const valenciaMarbleWall36 = new Entity('valenciaMarbleWall36')
engine.addEntity(valenciaMarbleWall36)
valenciaMarbleWall36.setParent(_scene)
valenciaMarbleWall36.addComponentOrReplace(gltfShape2)
const transform35 = new Transform({
  position: new Vector3(8.929689407348633, 22.5, 12.232126235961914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 204.37197875976562)
})
valenciaMarbleWall36.addComponentOrReplace(transform35)

const valenciaMarbleWall37 = new Entity('valenciaMarbleWall37')
engine.addEntity(valenciaMarbleWall37)
valenciaMarbleWall37.setParent(_scene)
valenciaMarbleWall37.addComponentOrReplace(gltfShape2)
const transform36 = new Transform({
  position: new Vector3(8.929689407348633, 22.435636520385742, 12.232126235961914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.3308451175689697, 170.49075317382812)
})
valenciaMarbleWall37.addComponentOrReplace(transform36)

const valenciaMarbleWall38 = new Entity('valenciaMarbleWall38')
engine.addEntity(valenciaMarbleWall38)
valenciaMarbleWall38.setParent(_scene)
valenciaMarbleWall38.addComponentOrReplace(gltfShape2)
const transform37 = new Transform({
  position: new Vector3(8.929689407348633, 22.5, 12.232126235961914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall38.addComponentOrReplace(transform37)

const valenciaMarbleWall40 = new Entity('valenciaMarbleWall40')
engine.addEntity(valenciaMarbleWall40)
valenciaMarbleWall40.setParent(_scene)
valenciaMarbleWall40.addComponentOrReplace(gltfShape2)
const transform38 = new Transform({
  position: new Vector3(8.929689407348633, 27.142620086669922, 12.232274055480957),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 199.5347137451172)
})
valenciaMarbleWall40.addComponentOrReplace(transform38)

const valenciaMarbleWall41 = new Entity('valenciaMarbleWall41')
engine.addEntity(valenciaMarbleWall41)
valenciaMarbleWall41.setParent(_scene)
valenciaMarbleWall41.addComponentOrReplace(gltfShape2)
const transform39 = new Transform({
  position: new Vector3(8.929689407348633, 27, 12.232126235961914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 19.5893611907959, 136.24798583984375)
})
valenciaMarbleWall41.addComponentOrReplace(transform39)

const valenciaMarbleWall42 = new Entity('valenciaMarbleWall42')
engine.addEntity(valenciaMarbleWall42)
valenciaMarbleWall42.setParent(_scene)
valenciaMarbleWall42.addComponentOrReplace(gltfShape2)
const transform40 = new Transform({
  position: new Vector3(31.587244033813477, 0.14262008666992188, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall42.addComponentOrReplace(transform40)

const valenciaMarbleWall43 = new Entity('valenciaMarbleWall43')
engine.addEntity(valenciaMarbleWall43)
valenciaMarbleWall43.setParent(_scene)
valenciaMarbleWall43.addComponentOrReplace(gltfShape2)
const transform41 = new Transform({
  position: new Vector3(31.587244033813477, 4.5, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 363.32794189453125)
})
valenciaMarbleWall43.addComponentOrReplace(transform41)

const valenciaMarbleWall44 = new Entity('valenciaMarbleWall44')
engine.addEntity(valenciaMarbleWall44)
valenciaMarbleWall44.setParent(_scene)
valenciaMarbleWall44.addComponentOrReplace(gltfShape2)
const transform42 = new Transform({
  position: new Vector3(31.587244033813477, 4.422621726989746, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.4841160774230957, 303.09466552734375)
})
valenciaMarbleWall44.addComponentOrReplace(transform42)

const valenciaMarbleWall45 = new Entity('valenciaMarbleWall45')
engine.addEntity(valenciaMarbleWall45)
valenciaMarbleWall45.setParent(_scene)
valenciaMarbleWall45.addComponentOrReplace(gltfShape2)
const transform43 = new Transform({
  position: new Vector3(31.587244033813477, 0, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 242.2186279296875)
})
valenciaMarbleWall45.addComponentOrReplace(transform43)

const valenciaMarbleWall46 = new Entity('valenciaMarbleWall46')
engine.addEntity(valenciaMarbleWall46)
valenciaMarbleWall46.setParent(_scene)
valenciaMarbleWall46.addComponentOrReplace(gltfShape2)
const transform44 = new Transform({
  position: new Vector3(31.587244033813477, 4.5, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.70591163635254, 242.2186279296875)
})
valenciaMarbleWall46.addComponentOrReplace(transform44)

const valenciaMarbleWall48 = new Entity('valenciaMarbleWall48')
engine.addEntity(valenciaMarbleWall48)
valenciaMarbleWall48.setParent(_scene)
valenciaMarbleWall48.addComponentOrReplace(gltfShape2)
const transform45 = new Transform({
  position: new Vector3(27.587244033813477, 9.104865074157715, 13.644763946533203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall48.addComponentOrReplace(transform45)

const valenciaMarbleWall49 = new Entity('valenciaMarbleWall49')
engine.addEntity(valenciaMarbleWall49)
valenciaMarbleWall49.setParent(_scene)
valenciaMarbleWall49.addComponentOrReplace(gltfShape2)
const transform46 = new Transform({
  position: new Vector3(27.587244033813477, 9, 13.644763946533203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 181.66397094726562)
})
valenciaMarbleWall49.addComponentOrReplace(transform46)

const valenciaMarbleWall50 = new Entity('valenciaMarbleWall50')
engine.addEntity(valenciaMarbleWall50)
valenciaMarbleWall50.setParent(_scene)
valenciaMarbleWall50.addComponentOrReplace(gltfShape2)
const transform47 = new Transform({
  position: new Vector3(27.587244033813477, 13.5, 13.644763946533203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 272.4959716796875)
})
valenciaMarbleWall50.addComponentOrReplace(transform47)

const valenciaMarbleWall51 = new Entity('valenciaMarbleWall51')
engine.addEntity(valenciaMarbleWall51)
valenciaMarbleWall51.setParent(_scene)
valenciaMarbleWall51.addComponentOrReplace(gltfShape2)
const transform48 = new Transform({
  position: new Vector3(27.587244033813477, 13.40068531036377, 13.644763946533203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.654373288154602, 227.3209991455078)
})
valenciaMarbleWall51.addComponentOrReplace(transform48)

const valenciaMarbleWall52 = new Entity('valenciaMarbleWall52')
engine.addEntity(valenciaMarbleWall52)
valenciaMarbleWall52.setParent(_scene)
valenciaMarbleWall52.addComponentOrReplace(gltfShape2)
const transform49 = new Transform({
  position: new Vector3(27.587244033813477, 13.5, 13.644763946533203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.702905654907227, 181.66397094726562)
})
valenciaMarbleWall52.addComponentOrReplace(transform49)

const valenciaMarbleWall54 = new Entity('valenciaMarbleWall54')
engine.addEntity(valenciaMarbleWall54)
valenciaMarbleWall54.setParent(_scene)
valenciaMarbleWall54.addComponentOrReplace(gltfShape2)
const transform50 = new Transform({
  position: new Vector3(23.587244033813477, 18.142620086669922, 12.230294227600098),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 190.61500549316406)
})
valenciaMarbleWall54.addComponentOrReplace(transform50)

const valenciaMarbleWall55 = new Entity('valenciaMarbleWall55')
engine.addEntity(valenciaMarbleWall55)
valenciaMarbleWall55.setParent(_scene)
valenciaMarbleWall55.addComponentOrReplace(gltfShape2)
const transform51 = new Transform({
  position: new Vector3(23.587244033813477, 18, 12.230396270751953),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall55.addComponentOrReplace(transform51)

const valenciaMarbleWall56 = new Entity('valenciaMarbleWall56')
engine.addEntity(valenciaMarbleWall56)
valenciaMarbleWall56.setParent(_scene)
valenciaMarbleWall56.addComponentOrReplace(gltfShape2)
const transform52 = new Transform({
  position: new Vector3(23.587244033813477, 22.5, 12.230396270751953),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 204.37197875976562)
})
valenciaMarbleWall56.addComponentOrReplace(transform52)

const valenciaMarbleWall57 = new Entity('valenciaMarbleWall57')
engine.addEntity(valenciaMarbleWall57)
valenciaMarbleWall57.setParent(_scene)
valenciaMarbleWall57.addComponentOrReplace(gltfShape2)
const transform53 = new Transform({
  position: new Vector3(23.587244033813477, 22.435636520385742, 12.230396270751953),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.3308451175689697, 170.49075317382812)
})
valenciaMarbleWall57.addComponentOrReplace(transform53)

const valenciaMarbleWall58 = new Entity('valenciaMarbleWall58')
engine.addEntity(valenciaMarbleWall58)
valenciaMarbleWall58.setParent(_scene)
valenciaMarbleWall58.addComponentOrReplace(gltfShape2)
const transform54 = new Transform({
  position: new Vector3(23.587244033813477, 22.5, 12.230396270751953),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall58.addComponentOrReplace(transform54)

const valenciaMarbleWall60 = new Entity('valenciaMarbleWall60')
engine.addEntity(valenciaMarbleWall60)
valenciaMarbleWall60.setParent(_scene)
valenciaMarbleWall60.addComponentOrReplace(gltfShape2)
const transform55 = new Transform({
  position: new Vector3(23.587244033813477, 27.142620086669922, 12.23024845123291),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 199.5347137451172)
})
valenciaMarbleWall60.addComponentOrReplace(transform55)

const valenciaMarbleWall61 = new Entity('valenciaMarbleWall61')
engine.addEntity(valenciaMarbleWall61)
valenciaMarbleWall61.setParent(_scene)
valenciaMarbleWall61.addComponentOrReplace(gltfShape2)
const transform56 = new Transform({
  position: new Vector3(23.587244033813477, 27, 12.230396270751953),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 19.5893611907959, 136.24798583984375)
})
valenciaMarbleWall61.addComponentOrReplace(transform56)

const valenciaMarbleWall62 = new Entity('valenciaMarbleWall62')
engine.addEntity(valenciaMarbleWall62)
valenciaMarbleWall62.setParent(_scene)
valenciaMarbleWall62.addComponentOrReplace(gltfShape2)
const transform57 = new Transform({
  position: new Vector3(31.587244033813477, 0.14262008666992188, 0.44400548934936523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall62.addComponentOrReplace(transform57)

const valenciaMarbleWall63 = new Entity('valenciaMarbleWall63')
engine.addEntity(valenciaMarbleWall63)
valenciaMarbleWall63.setParent(_scene)
valenciaMarbleWall63.addComponentOrReplace(gltfShape2)
const transform58 = new Transform({
  position: new Vector3(31.587244033813477, 4.5, 0.44400548934936523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 363.32794189453125)
})
valenciaMarbleWall63.addComponentOrReplace(transform58)

const valenciaMarbleWall64 = new Entity('valenciaMarbleWall64')
engine.addEntity(valenciaMarbleWall64)
valenciaMarbleWall64.setParent(_scene)
valenciaMarbleWall64.addComponentOrReplace(gltfShape2)
const transform59 = new Transform({
  position: new Vector3(31.587244033813477, 4.422621726989746, 0.44400548934936523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.4841160774230957, 303.09466552734375)
})
valenciaMarbleWall64.addComponentOrReplace(transform59)

const valenciaMarbleWall65 = new Entity('valenciaMarbleWall65')
engine.addEntity(valenciaMarbleWall65)
valenciaMarbleWall65.setParent(_scene)
valenciaMarbleWall65.addComponentOrReplace(gltfShape2)
const transform60 = new Transform({
  position: new Vector3(31.587244033813477, 0, 0.44400548934936523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 242.2186279296875)
})
valenciaMarbleWall65.addComponentOrReplace(transform60)

const valenciaMarbleWall66 = new Entity('valenciaMarbleWall66')
engine.addEntity(valenciaMarbleWall66)
valenciaMarbleWall66.setParent(_scene)
valenciaMarbleWall66.addComponentOrReplace(gltfShape2)
const transform61 = new Transform({
  position: new Vector3(31.587244033813477, 4.5, 0.44400548934936523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.70591163635254, 242.2186279296875)
})
valenciaMarbleWall66.addComponentOrReplace(transform61)

const valenciaMarbleWall68 = new Entity('valenciaMarbleWall68')
engine.addEntity(valenciaMarbleWall68)
valenciaMarbleWall68.setParent(_scene)
valenciaMarbleWall68.addComponentOrReplace(gltfShape2)
const transform62 = new Transform({
  position: new Vector3(27.587244033813477, 9.104865074157715, 2.3298277854919434),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall68.addComponentOrReplace(transform62)

const valenciaMarbleWall69 = new Entity('valenciaMarbleWall69')
engine.addEntity(valenciaMarbleWall69)
valenciaMarbleWall69.setParent(_scene)
valenciaMarbleWall69.addComponentOrReplace(gltfShape2)
const transform63 = new Transform({
  position: new Vector3(27.587244033813477, 9, 2.3298277854919434),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 181.66397094726562)
})
valenciaMarbleWall69.addComponentOrReplace(transform63)

const valenciaMarbleWall70 = new Entity('valenciaMarbleWall70')
engine.addEntity(valenciaMarbleWall70)
valenciaMarbleWall70.setParent(_scene)
valenciaMarbleWall70.addComponentOrReplace(gltfShape2)
const transform64 = new Transform({
  position: new Vector3(27.587244033813477, 13.5, 2.3298277854919434),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 272.4959716796875)
})
valenciaMarbleWall70.addComponentOrReplace(transform64)

const valenciaMarbleWall71 = new Entity('valenciaMarbleWall71')
engine.addEntity(valenciaMarbleWall71)
valenciaMarbleWall71.setParent(_scene)
valenciaMarbleWall71.addComponentOrReplace(gltfShape2)
const transform65 = new Transform({
  position: new Vector3(27.587244033813477, 13.40068531036377, 2.3298282623291016),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.654373288154602, 227.3209991455078)
})
valenciaMarbleWall71.addComponentOrReplace(transform65)

const valenciaMarbleWall72 = new Entity('valenciaMarbleWall72')
engine.addEntity(valenciaMarbleWall72)
valenciaMarbleWall72.setParent(_scene)
valenciaMarbleWall72.addComponentOrReplace(gltfShape2)
const transform66 = new Transform({
  position: new Vector3(27.587244033813477, 13.5, 2.3298282623291016),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 22.702905654907227, 181.66397094726562)
})
valenciaMarbleWall72.addComponentOrReplace(transform66)

const valenciaMarbleWall74 = new Entity('valenciaMarbleWall74')
engine.addEntity(valenciaMarbleWall74)
valenciaMarbleWall74.setParent(_scene)
valenciaMarbleWall74.addComponentOrReplace(gltfShape2)
const transform67 = new Transform({
  position: new Vector3(23.587244033813477, 18.142620086669922, 3.7433860301971436),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 215.13580322265625)
})
valenciaMarbleWall74.addComponentOrReplace(transform67)

const valenciaMarbleWall75 = new Entity('valenciaMarbleWall75')
engine.addEntity(valenciaMarbleWall75)
valenciaMarbleWall75.setParent(_scene)
valenciaMarbleWall75.addComponentOrReplace(gltfShape2)
const transform68 = new Transform({
  position: new Vector3(23.587244033813477, 18, 3.744194507598877),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall75.addComponentOrReplace(transform68)

const valenciaMarbleWall76 = new Entity('valenciaMarbleWall76')
engine.addEntity(valenciaMarbleWall76)
valenciaMarbleWall76.setParent(_scene)
valenciaMarbleWall76.addComponentOrReplace(gltfShape2)
const transform69 = new Transform({
  position: new Vector3(23.587244033813477, 22.5, 3.744194507598877),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.218749046325684, 0.731249988079071, 204.37197875976562)
})
valenciaMarbleWall76.addComponentOrReplace(transform69)

const valenciaMarbleWall77 = new Entity('valenciaMarbleWall77')
engine.addEntity(valenciaMarbleWall77)
valenciaMarbleWall77.setParent(_scene)
valenciaMarbleWall77.addComponentOrReplace(gltfShape2)
const transform70 = new Transform({
  position: new Vector3(23.587244033813477, 22.435636520385742, 3.744194507598877),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 1.3308451175689697, 170.49075317382812)
})
valenciaMarbleWall77.addComponentOrReplace(transform70)

const valenciaMarbleWall78 = new Entity('valenciaMarbleWall78')
engine.addEntity(valenciaMarbleWall78)
valenciaMarbleWall78.setParent(_scene)
valenciaMarbleWall78.addComponentOrReplace(gltfShape2)
const transform71 = new Transform({
  position: new Vector3(23.587244033813477, 22.5, 3.744194507598877),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 24.375, 136.24798583984375)
})
valenciaMarbleWall78.addComponentOrReplace(transform71)

const valenciaMarbleWall79 = new Entity('valenciaMarbleWall79')
engine.addEntity(valenciaMarbleWall79)
valenciaMarbleWall79.setParent(_scene)
valenciaMarbleWall79.addComponentOrReplace(gltfShape2)
const transform72 = new Transform({
  position: new Vector3(18.044496536254883, 27, 8.046394348144531),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(95.71021270751953, 0.7522554397583008, 3831.97412109375)
})
valenciaMarbleWall79.addComponentOrReplace(transform72)

const valenciaMarbleWall80 = new Entity('valenciaMarbleWall80')
engine.addEntity(valenciaMarbleWall80)
valenciaMarbleWall80.setParent(_scene)
valenciaMarbleWall80.addComponentOrReplace(gltfShape2)
const transform73 = new Transform({
  position: new Vector3(23.587244033813477, 27.142620086669922, 3.7438876628875732),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 187.41998291015625)
})
valenciaMarbleWall80.addComponentOrReplace(transform73)

const valenciaMarbleWall81 = new Entity('valenciaMarbleWall81')
engine.addEntity(valenciaMarbleWall81)
valenciaMarbleWall81.setParent(_scene)
valenciaMarbleWall81.addComponentOrReplace(gltfShape2)
const transform74 = new Transform({
  position: new Vector3(23.587244033813477, 27, 3.744194507598877),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1208243370056152, 19.5893611907959, 136.24798583984375)
})
valenciaMarbleWall81.addComponentOrReplace(transform74)

const valenciaMarbleWall82 = new Entity('valenciaMarbleWall82')
engine.addEntity(valenciaMarbleWall82)
valenciaMarbleWall82.setParent(_scene)
valenciaMarbleWall82.addComponentOrReplace(gltfShape2)
const transform75 = new Transform({
  position: new Vector3(18.35098648071289, 8.89239501953125, 7.172704696655273),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(136.2034454345703, 1.2944401502609253, 5770.9921875)
})
valenciaMarbleWall82.addComponentOrReplace(transform75)

const valenciaMarbleWall7 = new Entity('valenciaMarbleWall7')
engine.addEntity(valenciaMarbleWall7)
valenciaMarbleWall7.setParent(_scene)
valenciaMarbleWall7.addComponentOrReplace(gltfShape2)
const transform76 = new Transform({
  position: new Vector3(8.929689407348633, 30.697473526000977, 3.750680923461914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 187.41998291015625)
})
valenciaMarbleWall7.addComponentOrReplace(transform76)

const valenciaMarbleWall13 = new Entity('valenciaMarbleWall13')
engine.addEntity(valenciaMarbleWall13)
valenciaMarbleWall13.setParent(_scene)
valenciaMarbleWall13.addComponentOrReplace(gltfShape2)
const transform77 = new Transform({
  position: new Vector3(8.929689407348633, 30.697473526000977, 12.232274055480957),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 199.5347137451172)
})
valenciaMarbleWall13.addComponentOrReplace(transform77)

const valenciaMarbleWall19 = new Entity('valenciaMarbleWall19')
engine.addEntity(valenciaMarbleWall19)
valenciaMarbleWall19.setParent(_scene)
valenciaMarbleWall19.addComponentOrReplace(gltfShape2)
const transform78 = new Transform({
  position: new Vector3(23.587244033813477, 30.697473526000977, 3.7438879013061523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 187.41998291015625)
})
valenciaMarbleWall19.addComponentOrReplace(transform78)

const valenciaMarbleWall27 = new Entity('valenciaMarbleWall27')
engine.addEntity(valenciaMarbleWall27)
valenciaMarbleWall27.setParent(_scene)
valenciaMarbleWall27.addComponentOrReplace(gltfShape2)
const transform79 = new Transform({
  position: new Vector3(23.587244033813477, 30.697473526000977, 12.23024845123291),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 199.5347137451172)
})
valenciaMarbleWall27.addComponentOrReplace(transform79)

const valenciaMarbleWall39 = new Entity('valenciaMarbleWall39')
engine.addEntity(valenciaMarbleWall39)
valenciaMarbleWall39.setParent(_scene)
valenciaMarbleWall39.addComponentOrReplace(gltfShape2)
const transform80 = new Transform({
  position: new Vector3(8.929689407348633, 30.81049919128418, 3.7513437271118164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.6604232788085938, 0.6462713479995728, 223.99176025390625)
})
valenciaMarbleWall39.addComponentOrReplace(transform80)

const valenciaMarbleWall47 = new Entity('valenciaMarbleWall47')
engine.addEntity(valenciaMarbleWall47)
valenciaMarbleWall47.setParent(_scene)
valenciaMarbleWall47.addComponentOrReplace(gltfShape2)
const transform81 = new Transform({
  position: new Vector3(8.929689407348633, 30.81049919128418, 12.232414245605469),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.6604232788085938, 0.6462713479995728, 227.21902465820312)
})
valenciaMarbleWall47.addComponentOrReplace(transform81)

const valenciaMarbleWall53 = new Entity('valenciaMarbleWall53')
engine.addEntity(valenciaMarbleWall53)
valenciaMarbleWall53.setParent(_scene)
valenciaMarbleWall53.addComponentOrReplace(gltfShape2)
const transform82 = new Transform({
  position: new Vector3(23.587244033813477, 30.81049919128418, 3.74322509765625),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.58205246925354, 0.6462713479995728, 223.99176025390625)
})
valenciaMarbleWall53.addComponentOrReplace(transform82)

const valenciaMarbleWall59 = new Entity('valenciaMarbleWall59')
engine.addEntity(valenciaMarbleWall59)
valenciaMarbleWall59.setParent(_scene)
valenciaMarbleWall59.addComponentOrReplace(gltfShape2)
const transform83 = new Transform({
  position: new Vector3(23.587244033813477, 30.81049919128418, 12.230108261108398),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.58205246925354, 0.6462713479995728, 227.21902465820312)
})
valenciaMarbleWall59.addComponentOrReplace(transform83)

const valenciaMarbleWall73 = new Entity('valenciaMarbleWall73')
engine.addEntity(valenciaMarbleWall73)
valenciaMarbleWall73.setParent(_scene)
valenciaMarbleWall73.addComponentOrReplace(gltfShape2)
const transform84 = new Transform({
  position: new Vector3(18.083330154418945, 22.518917083740234, 14.36068058013916),
  rotation: new Quaternion(-0.2185692936182022, -0.9758214354515076, 1.1796473131653329e-7, -1.7180628475443882e-8),
  scale: new Vector3(106.11705017089844, 0.718464195728302, 1194.3289794921875)
})
valenciaMarbleWall73.addComponentOrReplace(transform84)

const valenciaMarbleWall83 = new Entity('valenciaMarbleWall83')
engine.addEntity(valenciaMarbleWall83)
valenciaMarbleWall83.setParent(_scene)
valenciaMarbleWall83.addComponentOrReplace(gltfShape2)
const transform85 = new Transform({
  position: new Vector3(6.162753105163574, 27, 9.569775581359863),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(24.22951316833496, 0.7522554397583008, 5084.54150390625)
})
valenciaMarbleWall83.addComponentOrReplace(transform85)

const valenciaMarbleWall67 = new Entity('valenciaMarbleWall67')
engine.addEntity(valenciaMarbleWall67)
valenciaMarbleWall67.setParent(_scene)
valenciaMarbleWall67.addComponentOrReplace(gltfShape2)
const transform86 = new Transform({
  position: new Vector3(29.803422927856445, 17.862085342407227, 7.960474014282227),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(21.448518753051758, 1.4434967041015625, 6387.14453125)
})
valenciaMarbleWall67.addComponentOrReplace(transform86)

const valenciaMarbleWall84 = new Entity('valenciaMarbleWall84')
engine.addEntity(valenciaMarbleWall84)
valenciaMarbleWall84.setParent(_scene)
valenciaMarbleWall84.addComponentOrReplace(gltfShape2)
const transform87 = new Transform({
  position: new Vector3(16.81102752685547, 13.518916130065918, 0.8925615549087524),
  rotation: new Quaternion(5.220925913818064e-10, 2.8291964326854213e-9, 0.19332878291606903, 0.9811340570449829),
  scale: new Vector3(118.43535614013672, 0.7312500476837158, 719.3863525390625)
})
valenciaMarbleWall84.addComponentOrReplace(transform87)

const valenciaMarbleWall85 = new Entity('valenciaMarbleWall85')
engine.addEntity(valenciaMarbleWall85)
valenciaMarbleWall85.setParent(_scene)
valenciaMarbleWall85.addComponentOrReplace(gltfShape2)
const transform88 = new Transform({
  position: new Vector3(31.587244033813477, 8.888200759887695, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall85.addComponentOrReplace(transform88)

const valenciaMarbleWall86 = new Entity('valenciaMarbleWall86')
engine.addEntity(valenciaMarbleWall86)
valenciaMarbleWall86.setParent(_scene)
valenciaMarbleWall86.addComponentOrReplace(gltfShape2)
const transform89 = new Transform({
  position: new Vector3(31.587244033813477, 8.888200759887695, 0.44400548934936523),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall86.addComponentOrReplace(transform89)

const valenciaMarbleWall87 = new Entity('valenciaMarbleWall87')
engine.addEntity(valenciaMarbleWall87)
valenciaMarbleWall87.setParent(_scene)
valenciaMarbleWall87.addComponentOrReplace(gltfShape2)
const transform90 = new Transform({
  position: new Vector3(0.4296884536743164, 8.888200759887695, 13.290704727172852),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall87.addComponentOrReplace(transform90)

const valenciaMarbleWall88 = new Entity('valenciaMarbleWall88')
engine.addEntity(valenciaMarbleWall88)
valenciaMarbleWall88.setParent(_scene)
valenciaMarbleWall88.addComponentOrReplace(gltfShape2)
const transform91 = new Transform({
  position: new Vector3(0.4296884536743164, 8.888200759887695, 0.45191383361816406),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 303.09466552734375)
})
valenciaMarbleWall88.addComponentOrReplace(transform91)

const valenciaMarbleWall89 = new Entity('valenciaMarbleWall89')
engine.addEntity(valenciaMarbleWall89)
valenciaMarbleWall89.setParent(_scene)
valenciaMarbleWall89.addComponentOrReplace(gltfShape2)
const transform92 = new Transform({
  position: new Vector3(4.929689407348633, 17.899274826049805, 2.3367481231689453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall89.addComponentOrReplace(transform92)

const valenciaMarbleWall90 = new Entity('valenciaMarbleWall90')
engine.addEntity(valenciaMarbleWall90)
valenciaMarbleWall90.setParent(_scene)
valenciaMarbleWall90.addComponentOrReplace(gltfShape2)
const transform93 = new Transform({
  position: new Vector3(4.929689407348633, 17.899274826049805, 13.645751953125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall90.addComponentOrReplace(transform93)

const valenciaMarbleWall91 = new Entity('valenciaMarbleWall91')
engine.addEntity(valenciaMarbleWall91)
valenciaMarbleWall91.setParent(_scene)
valenciaMarbleWall91.addComponentOrReplace(gltfShape2)
const transform94 = new Transform({
  position: new Vector3(27.587244033813477, 17.899274826049805, 13.644763946533203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall91.addComponentOrReplace(transform94)

const valenciaMarbleWall92 = new Entity('valenciaMarbleWall92')
engine.addEntity(valenciaMarbleWall92)
valenciaMarbleWall92.setParent(_scene)
valenciaMarbleWall92.addComponentOrReplace(gltfShape2)
const transform95 = new Transform({
  position: new Vector3(27.587244033813477, 17.899274826049805, 2.3298277854919434),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 227.3209991455078)
})
valenciaMarbleWall92.addComponentOrReplace(transform95)

const valenciaMarbleWall93 = new Entity('valenciaMarbleWall93')
engine.addEntity(valenciaMarbleWall93)
valenciaMarbleWall93.setParent(_scene)
valenciaMarbleWall93.addComponentOrReplace(gltfShape2)
const transform96 = new Transform({
  position: new Vector3(23.587244033813477, 26.892498016357422, 3.7433857917785645),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 215.13580322265625)
})
valenciaMarbleWall93.addComponentOrReplace(transform96)

const valenciaMarbleWall94 = new Entity('valenciaMarbleWall94')
engine.addEntity(valenciaMarbleWall94)
valenciaMarbleWall94.setParent(_scene)
valenciaMarbleWall94.addComponentOrReplace(gltfShape2)
const transform97 = new Transform({
  position: new Vector3(23.587244033813477, 26.892498016357422, 12.230294227600098),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 190.61500549316406)
})
valenciaMarbleWall94.addComponentOrReplace(transform97)

const valenciaMarbleWall95 = new Entity('valenciaMarbleWall95')
engine.addEntity(valenciaMarbleWall95)
valenciaMarbleWall95.setParent(_scene)
valenciaMarbleWall95.addComponentOrReplace(gltfShape2)
const transform98 = new Transform({
  position: new Vector3(8.929689407348633, 26.892498016357422, 3.751183032989502),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 215.13580322265625)
})
valenciaMarbleWall95.addComponentOrReplace(transform98)

const valenciaMarbleWall96 = new Entity('valenciaMarbleWall96')
engine.addEntity(valenciaMarbleWall96)
valenciaMarbleWall96.setParent(_scene)
valenciaMarbleWall96.addComponentOrReplace(gltfShape2)
const transform99 = new Transform({
  position: new Vector3(8.929689407348633, 26.892498016357422, 12.23222827911377),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1640615463256836, 0.5728201270103455, 190.61500549316406)
})
valenciaMarbleWall96.addComponentOrReplace(transform99)

const valenciaMarbleWall97 = new Entity('valenciaMarbleWall97')
engine.addEntity(valenciaMarbleWall97)
valenciaMarbleWall97.setParent(_scene)
valenciaMarbleWall97.addComponentOrReplace(gltfShape2)
const transform100 = new Transform({
  position: new Vector3(16.210309982299805, 13.581438064575195, 2.2125816345214844),
  rotation: new Quaternion(-0.7071068286895752, 4.504429098665355e-16, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(112.54436492919922, 0.7312512397766113, 2155.759033203125)
})
valenciaMarbleWall97.addComponentOrReplace(transform100)

const valenciaMarbleWall98 = new Entity('valenciaMarbleWall98')
engine.addEntity(valenciaMarbleWall98)
valenciaMarbleWall98.setParent(_scene)
valenciaMarbleWall98.addComponentOrReplace(gltfShape2)
const transform101 = new Transform({
  position: new Vector3(16.210309982299805, 22.620141983032227, 12.212581634521484),
  rotation: new Quaternion(-0.7071068286895752, 4.504429098665355e-16, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(72.45064544677734, 0.7312521934509277, 2076.802734375)
})
valenciaMarbleWall98.addComponentOrReplace(transform101)

const valenciaMarbleWall99 = new Entity('valenciaMarbleWall99')
engine.addEntity(valenciaMarbleWall99)
valenciaMarbleWall99.setParent(_scene)
valenciaMarbleWall99.addComponentOrReplace(gltfShape2)
const transform102 = new Transform({
  position: new Vector3(2.5052120685577393, 8.89239501953125, 7.996029853820801),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(23.876638412475586, 1.2944401502609253, 6395.00146484375)
})
valenciaMarbleWall99.addComponentOrReplace(transform102)

const valenciaMarbleWall100 = new Entity('valenciaMarbleWall100')
engine.addEntity(valenciaMarbleWall100)
valenciaMarbleWall100.setParent(_scene)
valenciaMarbleWall100.addComponentOrReplace(gltfShape2)
const transform103 = new Transform({
  position: new Vector3(17.550371170043945, 4.513612270355225, 15.27304744720459),
  rotation: new Quaternion(0, 0, -0.16661907732486725, 0.9860213398933411),
  scale: new Vector3(136.20352172851562, 0.7312500476837158, 584.9547729492188)
})
valenciaMarbleWall100.addComponentOrReplace(transform103)

const valenciaMarbleWall101 = new Entity('valenciaMarbleWall101')
engine.addEntity(valenciaMarbleWall101)
valenciaMarbleWall101.setParent(_scene)
valenciaMarbleWall101.addComponentOrReplace(gltfShape2)
const transform104 = new Transform({
  position: new Vector3(16.009931564331055, 4.39468240737915, 13.18416690826416),
  rotation: new Quaternion(-0.7071068286895752, 4.504429098665355e-16, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(155.9124755859375, 0.7312523126602173, 2022.4837646484375)
})
valenciaMarbleWall101.addComponentOrReplace(transform104)

const valenciaMarbleWall102 = new Entity('valenciaMarbleWall102')
engine.addEntity(valenciaMarbleWall102)
valenciaMarbleWall102.setParent(_scene)
valenciaMarbleWall102.addComponentOrReplace(gltfShape2)
const transform105 = new Transform({
  position: new Vector3(16.786672592163086, 30.84817123413086, 8.046394348144531),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(108.70716094970703, 0.35507258772850037, 3831.97412109375)
})
valenciaMarbleWall102.addComponentOrReplace(transform105)

const valenciaMarbleWall108 = new Entity('valenciaMarbleWall108')
engine.addEntity(valenciaMarbleWall108)
valenciaMarbleWall108.setParent(_scene)
valenciaMarbleWall108.addComponentOrReplace(gltfShape2)
const transform106 = new Transform({
  position: new Vector3(27.594947814941406, 10.065173149108887, 7.949880599975586),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(56.25715637207031, 0.7312532663345337, 766.277587890625)
})
valenciaMarbleWall108.addComponentOrReplace(transform106)

const valenciaMarbleWall109 = new Entity('valenciaMarbleWall109')
engine.addEntity(valenciaMarbleWall109)
valenciaMarbleWall109.setParent(_scene)
valenciaMarbleWall109.addComponentOrReplace(gltfShape2)
const transform107 = new Transform({
  position: new Vector3(8.912654876708984, 19.089670181274414, 8.0005464553833),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(40.742801666259766, 0.7312532663345337, 754.0394897460938)
})
valenciaMarbleWall109.addComponentOrReplace(transform107)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(18.416250228881836, 8.962919235229492, 7.2006120681762695),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(26.935901641845703, 0.14285503327846527, 14.389716148376465)
})
invisibleWall.addComponentOrReplace(transform108)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(2.3225908279418945, 8.962919235229492, 8.023463249206543),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.649331569671631, 0.14285503327846527, 15.529727935791016)
})
invisibleWall2.addComponentOrReplace(transform109)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(18.416250228881836, 8.962919235229492, 7.2006120681762695),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(26.935901641845703, 0.14285503327846527, 14.389716148376465)
})
invisibleWall3.addComponentOrReplace(transform110)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(17.517948150634766, 4.447172164916992, 15.20061206817627),
  rotation: new Quaternion(0, 0, -0.16786304116249084, 0.9858103394508362),
  scale: new Vector3(26.93592071533203, 0.14285515248775482, 1.3490358591079712)
})
invisibleWall4.addComponentOrReplace(transform111)

const invisibleWall5 = new Entity('invisibleWall5')
engine.addEntity(invisibleWall5)
invisibleWall5.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(17.997425079345703, 22.44512367248535, 14.331417083740234),
  rotation: new Quaternion(0, 0, -0.2198612540960312, 0.9755312204360962),
  scale: new Vector3(21.57136344909668, 0.13865020871162415, 3.0361738204956055)
})
invisibleWall5.addComponentOrReplace(transform112)

const invisibleWall6 = new Entity('invisibleWall6')
engine.addEntity(invisibleWall6)
invisibleWall6.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(29.86319923400879, 18.002017974853516, 7.988517761230469),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.242860794067383, 0.14285503327846527, 15.938321113586426)
})
invisibleWall6.addComponentOrReplace(transform113)

const valenciaMarbleWall111 = new Entity('valenciaMarbleWall111')
engine.addEntity(valenciaMarbleWall111)
valenciaMarbleWall111.setParent(_scene)
valenciaMarbleWall111.addComponentOrReplace(gltfShape2)
const transform114 = new Transform({
  position: new Vector3(0.5579509139060974, 1.0248394012451172, 6.784448623657227),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(64.81688690185547, 0.7312532663345337, 748.7380981445312)
})
valenciaMarbleWall111.addComponentOrReplace(transform114)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(16.67733383178711, 13.379175186157227, 0.8446894288063049),
  rotation: new Quaternion(0.19398003816604614, -0.9810055494308472, 1.1800765520320056e-7, 1.6883339171158696e-8),
  scale: new Vector3(24.65478515625, 0.1413668841123581, 1.6560471057891846)
})
invisibleWall7.addComponentOrReplace(transform115)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(18.053112030029297, 27.002017974853516, 7.988517761230469),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(18.96241569519043, 0.14285503327846527, 9.493277549743652)
})
invisibleWall8.addComponentOrReplace(transform116)

const invisibleWall9 = new Entity('invisibleWall9')
engine.addEntity(invisibleWall9)
invisibleWall9.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(6.115876197814941, 27.002017974853516, 9.562631607055664),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.740602970123291, 0.14285503327846527, 12.62314510345459)
})
invisibleWall9.addComponentOrReplace(transform117)

const invisibleWall10 = new Entity('invisibleWall10')
engine.addEntity(invisibleWall10)
invisibleWall10.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(15.134218215942383, 18.002017974853516, 8.757075309753418),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(25.856800079345703, 0.14285503327846527, 14.47760009765625)
})
invisibleWall10.addComponentOrReplace(transform118)

const invisibleWall12 = new Entity('invisibleWall12')
engine.addEntity(invisibleWall12)
invisibleWall12.setParent(_scene)
const transform119 = new Transform({
  position: new Vector3(16.012245178222656, 4.370410919189453, 13.359183311462402),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(31.793113708496094, 0.14285574853420258, 7.275356292724609)
})
invisibleWall12.addComponentOrReplace(transform119)

const invisibleWall14 = new Entity('invisibleWall14')
engine.addEntity(invisibleWall14)
invisibleWall14.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(16.221187591552734, 13.555566787719727, 2.3789234161376953),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(23.13494110107422, 0.14285576343536377, 5.16986608505249)
})
invisibleWall14.addComponentOrReplace(transform120)

const invisibleWall15 = new Entity('invisibleWall15')
engine.addEntity(invisibleWall15)
invisibleWall15.setParent(_scene)
const transform121 = new Transform({
  position: new Vector3(16.275266647338867, 22.46827507019043, 3.847482681274414),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(15.385801315307617, 0.14285606145858765, 7.911473274230957)
})
invisibleWall15.addComponentOrReplace(transform121)

const invisibleWall16 = new Entity('invisibleWall16')
engine.addEntity(invisibleWall16)
invisibleWall16.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(16.275266647338867, 22.460241317749023, 12.347482681274414),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(15.385801315307617, 0.14285621047019958, 7.683147430419922)
})
invisibleWall16.addComponentOrReplace(transform122)

const invisibleWall17 = new Entity('invisibleWall17')
engine.addEntity(invisibleWall17)
invisibleWall17.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(9.004373550415039, 19.085527420043945, 8.091468811035156),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(8.195980072021484, 0.14285597205162048, 1.8103103637695312)
})
invisibleWall17.addComponentOrReplace(transform123)

const invisibleWall18 = new Entity('invisibleWall18')
engine.addEntity(invisibleWall18)
invisibleWall18.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(27.75990104675293, 10.059224128723145, 7.993734359741211),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(10.739264488220215, 0.14285597205162048, 1.8524868488311768)
})
invisibleWall18.addComponentOrReplace(transform124)

const invisibleWall19 = new Entity('invisibleWall19')
engine.addEntity(invisibleWall19)
invisibleWall19.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(0.6572055816650391, 1.0068717002868652, 6.871648788452148),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(13.30737018585205, 0.14285597205162048, 1.699895977973938)
})
invisibleWall19.addComponentOrReplace(transform125)

const invisibleWall20 = new Entity('invisibleWall20')
engine.addEntity(invisibleWall20)
invisibleWall20.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(16.77804946899414, 30.80643081665039, 7.988517761230469),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(21.629682540893555, 0.14285503327846527, 9.493277549743652)
})
invisibleWall20.addComponentOrReplace(transform126)

const invisibleWall21 = new Entity('invisibleWall21')
engine.addEntity(invisibleWall21)
invisibleWall21.setParent(_scene)
const transform127 = new Transform({
  position: new Vector3(29.382347106933594, 27.002017974853516, 7.9698805809021),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.7552456855773926, 0.14285503327846527, 15.607278823852539)
})
invisibleWall21.addComponentOrReplace(transform127)

const valenciaMarbleWall112 = new Entity('valenciaMarbleWall112')
engine.addEntity(valenciaMarbleWall112)
valenciaMarbleWall112.setParent(_scene)
valenciaMarbleWall112.addComponentOrReplace(gltfShape2)
const transform128 = new Transform({
  position: new Vector3(29.65467643737793, 27, 8.065032005310059),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(16.109790802001953, 0.7522554397583008, 6299.89990234375)
})
valenciaMarbleWall112.addComponentOrReplace(transform128)

const invisibleWall22 = new Entity('invisibleWall22')
engine.addEntity(invisibleWall22)
invisibleWall22.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(26.049617767333984, 27.1236515045166, 14.508535385131836),
  rotation: new Quaternion(0, 0, -0.018609821796417236, 0.9998268485069275),
  scale: new Vector3(3.4176270961761475, 0.14285503327846527, 2.9263648986816406)
})
invisibleWall22.addComponentOrReplace(transform129)

const valenciaMarbleWall113 = new Entity('valenciaMarbleWall113')
engine.addEntity(valenciaMarbleWall113)
valenciaMarbleWall113.setParent(_scene)
valenciaMarbleWall113.addComponentOrReplace(gltfShape2)
const transform130 = new Transform({
  position: new Vector3(26.047992706298828, 27.121694564819336, 14.526376724243164),
  rotation: new Quaternion(0, 0, -0.018609821796417236, 0.9998268485069275),
  scale: new Vector3(17.250009536743164, 0.7522553205490112, 1181.231201171875)
})
valenciaMarbleWall113.addComponentOrReplace(transform130)

const invisibleWall23 = new Entity('invisibleWall23')
engine.addEntity(invisibleWall23)
invisibleWall23.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(26.049617767333984, 27.1236515045166, 1.508535385131836),
  rotation: new Quaternion(0, 0, -0.018609821796417236, 0.9998268485069275),
  scale: new Vector3(3.4176270961761475, 0.14285503327846527, 2.9263648986816406)
})
invisibleWall23.addComponentOrReplace(transform131)

const valenciaMarbleWall114 = new Entity('valenciaMarbleWall114')
engine.addEntity(valenciaMarbleWall114)
valenciaMarbleWall114.setParent(_scene)
valenciaMarbleWall114.addComponentOrReplace(gltfShape2)
const transform132 = new Transform({
  position: new Vector3(26.047992706298828, 27.121694564819336, 1.526376724243164),
  rotation: new Quaternion(0, 0, -0.018609821796417236, 0.9998268485069275),
  scale: new Vector3(17.250009536743164, 0.7522553205490112, 1181.231201171875)
})
valenciaMarbleWall114.addComponentOrReplace(transform132)

const invisibleWall24 = new Entity('invisibleWall24')
engine.addEntity(invisibleWall24)
invisibleWall24.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(23.049530029296875, 27.57478904724121, 1.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285501837730408, 2.9263648986816406)
})
invisibleWall24.addComponentOrReplace(transform133)

const valenciaMarbleWall115 = new Entity('valenciaMarbleWall115')
engine.addEntity(valenciaMarbleWall115)
valenciaMarbleWall115.setParent(_scene)
valenciaMarbleWall115.addComponentOrReplace(gltfShape2)
const transform134 = new Transform({
  position: new Vector3(23.048080444335938, 27.57301902770996, 1.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963772773742676, 0.7522554993629456, 1181.231201171875)
})
valenciaMarbleWall115.addComponentOrReplace(transform134)

const invisibleWall25 = new Entity('invisibleWall25')
engine.addEntity(invisibleWall25)
invisibleWall25.setParent(_scene)
const transform135 = new Transform({
  position: new Vector3(23.049530029296875, 27.57478904724121, 14.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285501837730408, 2.9263648986816406)
})
invisibleWall25.addComponentOrReplace(transform135)

const valenciaMarbleWall116 = new Entity('valenciaMarbleWall116')
engine.addEntity(valenciaMarbleWall116)
valenciaMarbleWall116.setParent(_scene)
valenciaMarbleWall116.addComponentOrReplace(gltfShape2)
const transform136 = new Transform({
  position: new Vector3(23.048080444335938, 27.57301902770996, 14.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963772773742676, 0.7522554993629456, 1181.231201171875)
})
valenciaMarbleWall116.addComponentOrReplace(transform136)

const invisibleWall26 = new Entity('invisibleWall26')
engine.addEntity(invisibleWall26)
invisibleWall26.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(20.049530029296875, 28.317834854125977, 1.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285492897033691, 2.9263648986816406)
})
invisibleWall26.addComponentOrReplace(transform137)

const valenciaMarbleWall117 = new Entity('valenciaMarbleWall117')
engine.addEntity(valenciaMarbleWall117)
valenciaMarbleWall117.setParent(_scene)
valenciaMarbleWall117.addComponentOrReplace(gltfShape2)
const transform138 = new Transform({
  position: new Vector3(20.048080444335938, 28.316064834594727, 1.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522558569908142, 1181.231201171875)
})
valenciaMarbleWall117.addComponentOrReplace(transform138)

const invisibleWall27 = new Entity('invisibleWall27')
engine.addEntity(invisibleWall27)
invisibleWall27.setParent(_scene)
const transform139 = new Transform({
  position: new Vector3(20.049530029296875, 28.317834854125977, 14.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285492897033691, 2.9263648986816406)
})
invisibleWall27.addComponentOrReplace(transform139)

const valenciaMarbleWall118 = new Entity('valenciaMarbleWall118')
engine.addEntity(valenciaMarbleWall118)
valenciaMarbleWall118.setParent(_scene)
valenciaMarbleWall118.addComponentOrReplace(gltfShape2)
const transform140 = new Transform({
  position: new Vector3(20.048080444335938, 28.316064834594727, 14.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522558569908142, 1181.231201171875)
})
valenciaMarbleWall118.addComponentOrReplace(transform140)

const invisibleWall28 = new Entity('invisibleWall28')
engine.addEntity(invisibleWall28)
invisibleWall28.setParent(_scene)
const transform141 = new Transform({
  position: new Vector3(17.049530029296875, 29.027803421020508, 1.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall28.addComponentOrReplace(transform141)

const valenciaMarbleWall119 = new Entity('valenciaMarbleWall119')
engine.addEntity(valenciaMarbleWall119)
valenciaMarbleWall119.setParent(_scene)
valenciaMarbleWall119.addComponentOrReplace(gltfShape2)
const transform142 = new Transform({
  position: new Vector3(17.048080444335938, 29.026033401489258, 1.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522560954093933, 1181.231201171875)
})
valenciaMarbleWall119.addComponentOrReplace(transform142)

const invisibleWall29 = new Entity('invisibleWall29')
engine.addEntity(invisibleWall29)
invisibleWall29.setParent(_scene)
const transform143 = new Transform({
  position: new Vector3(17.049530029296875, 29.027803421020508, 14.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall29.addComponentOrReplace(transform143)

const valenciaMarbleWall120 = new Entity('valenciaMarbleWall120')
engine.addEntity(valenciaMarbleWall120)
valenciaMarbleWall120.setParent(_scene)
valenciaMarbleWall120.addComponentOrReplace(gltfShape2)
const transform144 = new Transform({
  position: new Vector3(17.048080444335938, 29.026033401489258, 14.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522560954093933, 1181.231201171875)
})
valenciaMarbleWall120.addComponentOrReplace(transform144)

const invisibleWall30 = new Entity('invisibleWall30')
engine.addEntity(invisibleWall30)
invisibleWall30.setParent(_scene)
const transform145 = new Transform({
  position: new Vector3(14.049530029296875, 29.708072662353516, 1.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall30.addComponentOrReplace(transform145)

const valenciaMarbleWall121 = new Entity('valenciaMarbleWall121')
engine.addEntity(valenciaMarbleWall121)
valenciaMarbleWall121.setParent(_scene)
valenciaMarbleWall121.addComponentOrReplace(gltfShape2)
const transform146 = new Transform({
  position: new Vector3(14.048080444335938, 29.706302642822266, 1.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522562146186829, 1181.231201171875)
})
valenciaMarbleWall121.addComponentOrReplace(transform146)

const invisibleWall31 = new Entity('invisibleWall31')
engine.addEntity(invisibleWall31)
invisibleWall31.setParent(_scene)
const transform147 = new Transform({
  position: new Vector3(14.049530029296875, 29.708072662353516, 14.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall31.addComponentOrReplace(transform147)

const valenciaMarbleWall122 = new Entity('valenciaMarbleWall122')
engine.addEntity(valenciaMarbleWall122)
valenciaMarbleWall122.setParent(_scene)
valenciaMarbleWall122.addComponentOrReplace(gltfShape2)
const transform148 = new Transform({
  position: new Vector3(14.048080444335938, 29.706302642822266, 14.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522562146186829, 1181.231201171875)
})
valenciaMarbleWall122.addComponentOrReplace(transform148)

const invisibleWall32 = new Entity('invisibleWall32')
engine.addEntity(invisibleWall32)
invisibleWall32.setParent(_scene)
const transform149 = new Transform({
  position: new Vector3(11.049530029296875, 30.438661575317383, 1.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall32.addComponentOrReplace(transform149)

const valenciaMarbleWall123 = new Entity('valenciaMarbleWall123')
engine.addEntity(valenciaMarbleWall123)
valenciaMarbleWall123.setParent(_scene)
valenciaMarbleWall123.addComponentOrReplace(gltfShape2)
const transform150 = new Transform({
  position: new Vector3(11.048080444335938, 30.436891555786133, 1.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522563338279724, 1181.231201171875)
})
valenciaMarbleWall123.addComponentOrReplace(transform150)

const invisibleWall33 = new Entity('invisibleWall33')
engine.addEntity(invisibleWall33)
invisibleWall33.setParent(_scene)
const transform151 = new Transform({
  position: new Vector3(11.049530029296875, 30.438661575317383, 14.508535385131836),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(2.3703010082244873, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall33.addComponentOrReplace(transform151)

const valenciaMarbleWall124 = new Entity('valenciaMarbleWall124')
engine.addEntity(valenciaMarbleWall124)
valenciaMarbleWall124.setParent(_scene)
valenciaMarbleWall124.addComponentOrReplace(gltfShape2)
const transform152 = new Transform({
  position: new Vector3(11.048080444335938, 30.436891555786133, 14.526376724243164),
  rotation: new Quaternion(0, 0, -0.0980171412229538, 0.9951847195625305),
  scale: new Vector3(11.963768005371094, 0.7522563338279724, 1181.231201171875)
})
valenciaMarbleWall124.addComponentOrReplace(transform152)

const invisibleWall34 = new Entity('invisibleWall34')
engine.addEntity(invisibleWall34)
invisibleWall34.setParent(_scene)
const transform153 = new Transform({
  position: new Vector3(7.812061786651611, 30.840984344482422, 1.508535385131836),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.6438872814178467, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall34.addComponentOrReplace(transform153)

const valenciaMarbleWall125 = new Entity('valenciaMarbleWall125')
engine.addEntity(valenciaMarbleWall125)
valenciaMarbleWall125.setParent(_scene)
valenciaMarbleWall125.addComponentOrReplace(gltfShape2)
const transform154 = new Transform({
  position: new Vector3(7.810408115386963, 30.838966369628906, 1.526376724243164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(18.39202117919922, 0.7522563934326172, 1181.231201171875)
})
valenciaMarbleWall125.addComponentOrReplace(transform154)

const invisibleWall35 = new Entity('invisibleWall35')
engine.addEntity(invisibleWall35)
invisibleWall35.setParent(_scene)
const transform155 = new Transform({
  position: new Vector3(7.812061786651611, 30.840984344482422, 14.508535385131836),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.6438872814178467, 0.14285486936569214, 2.9263648986816406)
})
invisibleWall35.addComponentOrReplace(transform155)

const valenciaMarbleWall126 = new Entity('valenciaMarbleWall126')
engine.addEntity(valenciaMarbleWall126)
valenciaMarbleWall126.setParent(_scene)
valenciaMarbleWall126.addComponentOrReplace(gltfShape2)
const transform156 = new Transform({
  position: new Vector3(7.810408115386963, 30.838966369628906, 14.526376724243164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(18.39202117919922, 0.7522563934326172, 1181.231201171875)
})
valenciaMarbleWall126.addComponentOrReplace(transform156)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform157 = new Transform({
  position: new Vector3(17.54458999633789, 3.151749849319458, 0.7004127502441406),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame.addComponentOrReplace(transform157)

const invisibleWall36 = new Entity('invisibleWall36')
engine.addEntity(invisibleWall36)
invisibleWall36.setParent(_scene)
const transform158 = new Transform({
  position: new Vector3(31.92051124572754, 9.911849975585938, 7.143158912658691),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(14.18594741821289, 0.14285597205162048, 0.7400825023651123)
})
invisibleWall36.addComponentOrReplace(transform158)

const invisibleWall37 = new Entity('invisibleWall37')
engine.addEntity(invisibleWall37)
invisibleWall37.setParent(_scene)
const transform159 = new Transform({
  position: new Vector3(31.92051124572754, 18.911849975585938, 8.036437034606934),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(15.699723243713379, 0.14285597205162048, 0.7400825023651123)
})
invisibleWall37.addComponentOrReplace(transform159)

const invisibleWall38 = new Entity('invisibleWall38')
engine.addEntity(invisibleWall38)
invisibleWall38.setParent(_scene)
const transform160 = new Transform({
  position: new Vector3(31.92051124572754, 27.911849975585938, 8.036437034606934),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(15.699723243713379, 0.14285597205162048, 0.7400825023651123)
})
invisibleWall38.addComponentOrReplace(transform160)

const invisibleWall39 = new Entity('invisibleWall39')
engine.addEntity(invisibleWall39)
invisibleWall39.setParent(_scene)
const transform161 = new Transform({
  position: new Vector3(3.420511245727539, 27.911849975585938, 9.67863941192627),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(12.451064109802246, 0.14285597205162048, 0.7400825023651123)
})
invisibleWall39.addComponentOrReplace(transform161)

const invisibleWall40 = new Entity('invisibleWall40')
engine.addEntity(invisibleWall40)
invisibleWall40.setParent(_scene)
const transform162 = new Transform({
  position: new Vector3(2.420511245727539, 18.911849975585938, 8.630728721618652),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(14.544236183166504, 0.14285597205162048, 0.7400825023651123)
})
invisibleWall40.addComponentOrReplace(transform162)

const invisibleWall41 = new Entity('invisibleWall41')
engine.addEntity(invisibleWall41)
invisibleWall41.setParent(_scene)
const transform163 = new Transform({
  position: new Vector3(0.1584998518228531, 9.911849975585938, 8.068957328796387),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(15.473494529724121, 0.14285597205162048, 0.7400825023651123)
})
invisibleWall41.addComponentOrReplace(transform163)

const invisibleWall42 = new Entity('invisibleWall42')
engine.addEntity(invisibleWall42)
invisibleWall42.setParent(_scene)
const transform164 = new Transform({
  position: new Vector3(17.517948150634766, 5.947172164916992, 15.968548774719238),
  rotation: new Quaternion(-0.6895908117294312, 0.11981011182069778, -0.12296774983406067, 0.703554630279541),
  scale: new Vector3(26.93531608581543, 0.09619864821434021, 1.3490355014801025)
})
invisibleWall42.addComponentOrReplace(transform164)

const invisibleWall43 = new Entity('invisibleWall43')
engine.addEntity(invisibleWall43)
invisibleWall43.setParent(_scene)
const transform165 = new Transform({
  position: new Vector3(19.31402015686035, 22.57094383239746, 15.968548774719238),
  rotation: new Quaternion(-0.6821731925010681, 0.15661953389644623, -0.1605214923620224, 0.6959475874900818),
  scale: new Vector3(26.935314178466797, 0.09619869291782379, 1.3490378856658936)
})
invisibleWall43.addComponentOrReplace(transform165)

const invisibleWall44 = new Entity('invisibleWall44')
engine.addEntity(invisibleWall44)
invisibleWall44.setParent(_scene)
const transform166 = new Transform({
  position: new Vector3(16.579235076904297, 14.570943832397461, 0.16131067276000977),
  rotation: new Quaternion(-0.6862999796867371, -0.13741259276866913, 0.13951298594474792, 0.7004615068435669),
  scale: new Vector3(26.93532371520996, 0.09619864821434021, 1.3490409851074219)
})
invisibleWall44.addComponentOrReplace(transform166)

const invisibleWall45 = new Entity('invisibleWall45')
engine.addEntity(invisibleWall45)
invisibleWall45.setParent(_scene)
const transform167 = new Transform({
  position: new Vector3(18.399580001831055, 29.434450149536133, 15.881614685058594),
  rotation: new Quaternion(-0.6993103623390198, 0.02923804707825184, -0.03055545687675476, 0.7135661244392395),
  scale: new Vector3(26.924760818481445, 0.09617569297552109, 0.5535658001899719)
})
invisibleWall45.addComponentOrReplace(transform167)

const invisibleWall46 = new Entity('invisibleWall46')
engine.addEntity(invisibleWall46)
invisibleWall46.setParent(_scene)
const transform168 = new Transform({
  position: new Vector3(18.399580001831055, 29.434450149536133, 0.1942143440246582),
  rotation: new Quaternion(-0.6993103623390198, 0.02923804707825184, -0.03055545687675476, 0.7135661244392395),
  scale: new Vector3(26.92477035522461, 0.09617571532726288, 0.5535658597946167)
})
invisibleWall46.addComponentOrReplace(transform168)

const valenciaMarbleWall105 = new Entity('valenciaMarbleWall105')
engine.addEntity(valenciaMarbleWall105)
valenciaMarbleWall105.setParent(_scene)
valenciaMarbleWall105.addComponentOrReplace(gltfShape2)
const transform169 = new Transform({
  position: new Vector3(19.094947814941406, 9.297566413879395, 8.027355194091797),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(57.17897415161133, 4.726050853729248, 146.04087829589844)
})
valenciaMarbleWall105.addComponentOrReplace(transform169)

const valenciaMarbleWall127 = new Entity('valenciaMarbleWall127')
engine.addEntity(valenciaMarbleWall127)
valenciaMarbleWall127.setParent(_scene)
valenciaMarbleWall127.addComponentOrReplace(gltfShape2)
const transform170 = new Transform({
  position: new Vector3(20.094947814941406, 9.633359909057617, 8.027355194091797),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(57.17897415161133, 4.903704643249512, 143.1212615966797)
})
valenciaMarbleWall127.addComponentOrReplace(transform170)

const valenciaMarbleWall128 = new Entity('valenciaMarbleWall128')
engine.addEntity(valenciaMarbleWall128)
valenciaMarbleWall128.setParent(_scene)
valenciaMarbleWall128.addComponentOrReplace(gltfShape2)
const transform171 = new Transform({
  position: new Vector3(21.094947814941406, 9.978374481201172, 8.027355194091797),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(57.17911911010742, 32.490665435791016, 142.7367706298828)
})
valenciaMarbleWall128.addComponentOrReplace(transform171)

const invisibleWall47 = new Entity('invisibleWall47')
engine.addEntity(invisibleWall47)
invisibleWall47.setParent(_scene)
const transform172 = new Transform({
  position: new Vector3(19.56641960144043, 9.453873634338379, 8.038336753845215),
  rotation: new Quaternion(-5.960464477539063e-8, -0.7071068286895752, 0, -0.7071068286895752),
  scale: new Vector3(11.340580940246582, 0.025599343702197075, 0.9372836351394653)
})
invisibleWall47.addComponentOrReplace(transform172)

const invisibleWall48 = new Entity('invisibleWall48')
engine.addEntity(invisibleWall48)
invisibleWall48.setParent(_scene)
const transform173 = new Transform({
  position: new Vector3(20.56641960144043, 9.786542892456055, 8.038336753845215),
  rotation: new Quaternion(-5.960464477539063e-8, -0.7071068286895752, 0, -0.7071068286895752),
  scale: new Vector3(11.340584754943848, 0.025087567046284676, 0.9372845888137817)
})
invisibleWall48.addComponentOrReplace(transform173)

const invisibleWall49 = new Entity('invisibleWall49')
engine.addEntity(invisibleWall49)
invisibleWall49.setParent(_scene)
const transform174 = new Transform({
  position: new Vector3(24.149038314819336, 10.131145477294922, 8.038336753845215),
  rotation: new Quaternion(-5.960464477539063e-8, -0.7071068286895752, 0, -0.7071068286895752),
  scale: new Vector3(11.34057903289795, 0.025020169094204903, 6.0923614501953125)
})
invisibleWall49.addComponentOrReplace(transform174)

const invisibleWall50 = new Entity('invisibleWall50')
engine.addEntity(invisibleWall50)
invisibleWall50.setParent(_scene)
const transform175 = new Transform({
  position: new Vector3(15.983259201049805, 9.948100090026855, 0.15871289372444153),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(31.596269607543945, 0.14285624027252197, 0.6413646340370178)
})
invisibleWall50.addComponentOrReplace(transform175)

const invisibleWall51 = new Entity('invisibleWall51')
engine.addEntity(invisibleWall51)
invisibleWall51.setParent(_scene)
const transform176 = new Transform({
  position: new Vector3(14.764512062072754, 18.948101043701172, 1.4527227878570557),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(25.01418113708496, 0.14285653829574585, 0.6413657069206238)
})
invisibleWall51.addComponentOrReplace(transform176)

const invisibleWall52 = new Entity('invisibleWall52')
engine.addEntity(invisibleWall52)
invisibleWall52.setParent(_scene)
const transform177 = new Transform({
  position: new Vector3(14.764512062072754, 18.948101043701172, 15.952722549438477),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(25.01418113708496, 0.14285656809806824, 0.6413658261299133)
})
invisibleWall52.addComponentOrReplace(transform177)

const invisibleWall53 = new Entity('invisibleWall53')
engine.addEntity(invisibleWall53)
invisibleWall53.setParent(_scene)
const transform178 = new Transform({
  position: new Vector3(19.255531311035156, 9.935796737670898, 14.401180267333984),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(25.01418113708496, 0.14285671710968018, 0.6413664221763611)
})
invisibleWall53.addComponentOrReplace(transform178)

const invisibleWall54 = new Entity('invisibleWall54')
engine.addEntity(invisibleWall54)
invisibleWall54.setParent(_scene)
const transform179 = new Transform({
  position: new Vector3(17.517948150634766, 5.947172164916992, 14.23513126373291),
  rotation: new Quaternion(-0.6895908117294312, 0.11981011182069778, -0.12296774983406067, 0.703554630279541),
  scale: new Vector3(26.93531608581543, 0.09619870781898499, 1.3490363359451294)
})
invisibleWall54.addComponentOrReplace(transform179)

const valenciaMarbleWall129 = new Entity('valenciaMarbleWall129')
engine.addEntity(valenciaMarbleWall129)
valenciaMarbleWall129.setParent(_scene)
valenciaMarbleWall129.addComponentOrReplace(gltfShape2)
const transform180 = new Transform({
  position: new Vector3(9.138011932373047, 0.20305180549621582, 6.886430263519287),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(64.0692138671875, 4.726050853729248, 146.04087829589844)
})
valenciaMarbleWall129.addComponentOrReplace(transform180)

const invisibleWall55 = new Entity('invisibleWall55')
engine.addEntity(invisibleWall55)
invisibleWall55.setParent(_scene)
const transform181 = new Transform({
  position: new Vector3(8.666540145874023, 0.3593590259552002, 6.874125957489014),
  rotation: new Quaternion(0.044329963624477386, 0.7057159543037415, 0.04432973265647888, -0.7057159543037415),
  scale: new Vector3(12.707252502441406, 0.025599343702197075, 0.9372878670692444)
})
invisibleWall55.addComponentOrReplace(transform181)

const valenciaMarbleWall130 = new Entity('valenciaMarbleWall130')
engine.addEntity(valenciaMarbleWall130)
valenciaMarbleWall130.setParent(_scene)
valenciaMarbleWall130.addComponentOrReplace(gltfShape2)
const transform182 = new Transform({
  position: new Vector3(8.138011932373047, 0.5388453006744385, 6.886430263519287),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(64.0692138671875, 4.903704643249512, 143.1212615966797)
})
valenciaMarbleWall130.addComponentOrReplace(transform182)

const invisibleWall56 = new Entity('invisibleWall56')
engine.addEntity(invisibleWall56)
invisibleWall56.setParent(_scene)
const transform183 = new Transform({
  position: new Vector3(7.666540145874023, 0.692028284072876, 6.874125957489014),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(12.70723819732666, 0.025087567046284676, 0.9372884035110474)
})
invisibleWall56.addComponentOrReplace(transform183)

const valenciaMarbleWall131 = new Entity('valenciaMarbleWall131')
engine.addEntity(valenciaMarbleWall131)
valenciaMarbleWall131.setParent(_scene)
valenciaMarbleWall131.addComponentOrReplace(gltfShape2)
const transform184 = new Transform({
  position: new Vector3(7.138011932373047, 0.8838598728179932, 6.886430263519287),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(64.06937408447266, 32.490665435791016, 142.7367706298828)
})
valenciaMarbleWall131.addComponentOrReplace(transform184)

const invisibleWall57 = new Entity('invisibleWall57')
engine.addEntity(invisibleWall57)
invisibleWall57.setParent(_scene)
const transform185 = new Transform({
  position: new Vector3(4.083921432495117, 1.0366308689117432, 6.874125957489014),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(12.707218170166016, 0.025020169094204903, 6.092400074005127)
})
invisibleWall57.addComponentOrReplace(transform185)

const valenciaMarbleWall132 = new Entity('valenciaMarbleWall132')
engine.addEntity(valenciaMarbleWall132)
valenciaMarbleWall132.setParent(_scene)
valenciaMarbleWall132.addComponentOrReplace(gltfShape2)
const transform186 = new Transform({
  position: new Vector3(16.454063415527344, 18.297565460205078, 8.021278381347656),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(41.71883010864258, 4.115778923034668, 146.04087829589844)
})
valenciaMarbleWall132.addComponentOrReplace(transform186)

const invisibleWall58 = new Entity('invisibleWall58')
engine.addEntity(invisibleWall58)
invisibleWall58.setParent(_scene)
const transform187 = new Transform({
  position: new Vector3(16.043472290039062, 18.453872680664062, 8.013265609741211),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(8.274378776550293, 0.025599343702197075, 0.8162595629692078)
})
invisibleWall58.addComponentOrReplace(transform187)

const valenciaMarbleWall133 = new Entity('valenciaMarbleWall133')
engine.addEntity(valenciaMarbleWall133)
valenciaMarbleWall133.setParent(_scene)
valenciaMarbleWall133.addComponentOrReplace(gltfShape2)
const transform188 = new Transform({
  position: new Vector3(15.583192825317383, 18.633359909057617, 8.021278381347656),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(41.71883010864258, 4.270492076873779, 143.1212615966797)
})
valenciaMarbleWall133.addComponentOrReplace(transform188)

const invisibleWall59 = new Entity('invisibleWall59')
engine.addEntity(invisibleWall59)
invisibleWall59.setParent(_scene)
const transform189 = new Transform({
  position: new Vector3(15.172600746154785, 18.786542892456055, 8.013265609741211),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(8.274378776550293, 0.025087567046284676, 0.8162603974342346)
})
invisibleWall59.addComponentOrReplace(transform189)

const valenciaMarbleWall134 = new Entity('valenciaMarbleWall134')
engine.addEntity(valenciaMarbleWall134)
valenciaMarbleWall134.setParent(_scene)
valenciaMarbleWall134.addComponentOrReplace(gltfShape2)
const transform190 = new Transform({
  position: new Vector3(14.712322235107422, 18.978374481201172, 8.021278381347656),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(41.71893310546875, 28.295164108276367, 142.7367706298828)
})
valenciaMarbleWall134.addComponentOrReplace(transform190)

const invisibleWall60 = new Entity('invisibleWall60')
engine.addEntity(invisibleWall60)
invisibleWall60.setParent(_scene)
const transform191 = new Transform({
  position: new Vector3(12.052604675292969, 19.131145477294922, 8.013265609741211),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(8.274371147155762, 0.025020169094204903, 5.305717468261719)
})
invisibleWall60.addComponentOrReplace(transform191)

const invisibleWall61 = new Entity('invisibleWall61')
engine.addEntity(invisibleWall61)
invisibleWall61.setParent(_scene)
const transform192 = new Transform({
  position: new Vector3(0.65720534324646, 7.9005022048950195, 6.871648788452148),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(13.30737018585205, 0.14285597205162048, 1.9553258419036865)
})
invisibleWall61.addComponentOrReplace(transform192)

const valenciaMarbleWall135 = new Entity('valenciaMarbleWall135')
engine.addEntity(valenciaMarbleWall135)
valenciaMarbleWall135.setParent(_scene)
valenciaMarbleWall135.addComponentOrReplace(gltfShape2)
const transform193 = new Transform({
  position: new Vector3(0.5579509139060974, 7.921170234680176, 6.784448623657227),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(64.81688690185547, 0.7312532663345337, 861.2449951171875)
})
valenciaMarbleWall135.addComponentOrReplace(transform193)

const invisibleWall62 = new Entity('invisibleWall62')
engine.addEntity(invisibleWall62)
invisibleWall62.setParent(_scene)
const transform194 = new Transform({
  position: new Vector3(27.75990104675293, 17.059223175048828, 7.993734359741211),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(10.739264488220215, 0.14285597205162048, 1.8524868488311768)
})
invisibleWall62.addComponentOrReplace(transform194)

const valenciaMarbleWall136 = new Entity('valenciaMarbleWall136')
engine.addEntity(valenciaMarbleWall136)
valenciaMarbleWall136.setParent(_scene)
valenciaMarbleWall136.addComponentOrReplace(gltfShape2)
const transform195 = new Transform({
  position: new Vector3(27.594947814941406, 17.065174102783203, 7.949880599975586),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(56.25715637207031, 0.7312532663345337, 766.277587890625)
})
valenciaMarbleWall136.addComponentOrReplace(transform195)

const valenciaMarbleWall137 = new Entity('valenciaMarbleWall137')
engine.addEntity(valenciaMarbleWall137)
valenciaMarbleWall137.setParent(_scene)
valenciaMarbleWall137.addComponentOrReplace(gltfShape2)
const transform196 = new Transform({
  position: new Vector3(8.912654876708984, 26.089670181274414, 8.0005464553833),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(40.742801666259766, 0.7312532663345337, 754.0394897460938)
})
valenciaMarbleWall137.addComponentOrReplace(transform196)

const invisibleWall63 = new Entity('invisibleWall63')
engine.addEntity(invisibleWall63)
invisibleWall63.setParent(_scene)
const transform197 = new Transform({
  position: new Vector3(9.004373550415039, 26.085527420043945, 8.091468811035156),
  rotation: new Quaternion(0.4999999403953552, -0.5000000596046448, -0.5, -0.5),
  scale: new Vector3(8.195980072021484, 0.14285597205162048, 1.8103103637695312)
})
invisibleWall63.addComponentOrReplace(transform197)

const invisibleWall64 = new Entity('invisibleWall64')
engine.addEntity(invisibleWall64)
invisibleWall64.setParent(_scene)
const transform198 = new Transform({
  position: new Vector3(16.012245178222656, 4.370410919189453, 0.3591756820678711),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(31.793113708496094, 0.14285577833652496, 7.275357723236084)
})
invisibleWall64.addComponentOrReplace(transform198)

const valenciaMarbleWall138 = new Entity('valenciaMarbleWall138')
engine.addEntity(valenciaMarbleWall138)
valenciaMarbleWall138.setParent(_scene)
valenciaMarbleWall138.addComponentOrReplace(gltfShape2)
const transform199 = new Transform({
  position: new Vector3(16.009931564331055, 4.39468240737915, 0.18416690826416016),
  rotation: new Quaternion(-0.7071068286895752, 4.504429098665355e-16, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(155.9124755859375, 0.7312524318695068, 2022.4842529296875)
})
valenciaMarbleWall138.addComponentOrReplace(transform199)

const invisibleWall11 = new Entity('invisibleWall11')
engine.addEntity(invisibleWall11)
invisibleWall11.setParent(_scene)
const transform200 = new Transform({
  position: new Vector3(16.221187591552734, 13.555566787719727, 13.729433059692383),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(23.13494110107422, 0.14285582304000854, 5.169865608215332)
})
invisibleWall11.addComponentOrReplace(transform200)

const valenciaMarbleWall110 = new Entity('valenciaMarbleWall110')
engine.addEntity(valenciaMarbleWall110)
valenciaMarbleWall110.setParent(_scene)
valenciaMarbleWall110.addComponentOrReplace(gltfShape2)
const transform201 = new Transform({
  position: new Vector3(16.210309982299805, 13.581438064575195, 13.563091278076172),
  rotation: new Quaternion(-0.7071068286895752, 4.504429098665355e-16, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(112.54436492919922, 0.7312511801719666, 2155.760009765625)
})
valenciaMarbleWall110.addComponentOrReplace(transform201)

const valenciaMarbleWall106 = new Entity('valenciaMarbleWall106')
engine.addEntity(valenciaMarbleWall106)
valenciaMarbleWall106.setParent(_scene)
valenciaMarbleWall106.addComponentOrReplace(gltfShape2)
const transform202 = new Transform({
  position: new Vector3(16.210309982299805, 22.620141983032227, 3.6691112518310547),
  rotation: new Quaternion(-0.7071068286895752, 4.504429098665355e-16, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(72.45064544677734, 0.7312525510787964, 2076.80419921875)
})
valenciaMarbleWall106.addComponentOrReplace(transform202)

const veinedMarbleWall = new Entity('veinedMarbleWall')
engine.addEntity(veinedMarbleWall)
veinedMarbleWall.setParent(_scene)
const transform203 = new Transform({
  position: new Vector3(17.54228973388672, 5.903547763824463, 0.5608224868774414),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall.addComponentOrReplace(transform203)
const gltfShape3 = new GLTFShape("f474e491caaa732f8381aab5fc700b8318ccb5bd6ef999c4a349c772fe27561a/Veined_Marble Wall.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
veinedMarbleWall.addComponentOrReplace(gltfShape3)

const veinedMarbleWall3 = new Entity('veinedMarbleWall3')
engine.addEntity(veinedMarbleWall3)
veinedMarbleWall3.setParent(_scene)
veinedMarbleWall3.addComponentOrReplace(gltfShape3)
const transform204 = new Transform({
  position: new Vector3(7.542289733886719, 2.769845962524414, 0.5608305931091309),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall3.addComponentOrReplace(transform204)

const veinedMarbleWall4 = new Entity('veinedMarbleWall4')
engine.addEntity(veinedMarbleWall4)
veinedMarbleWall4.setParent(_scene)
veinedMarbleWall4.addComponentOrReplace(gltfShape3)
const transform205 = new Transform({
  position: new Vector3(24.142738342285156, 4.364322185516357, 0.5608186721801758),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603309631347656, 15.762733459472656, 59.45534133911133)
})
veinedMarbleWall4.addComponentOrReplace(transform205)

const veinedMarbleWall5 = new Entity('veinedMarbleWall5')
engine.addEntity(veinedMarbleWall5)
veinedMarbleWall5.setParent(_scene)
veinedMarbleWall5.addComponentOrReplace(gltfShape3)
const transform206 = new Transform({
  position: new Vector3(27.54228973388672, 2.769845962524414, 0.5608148574829102),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall5.addComponentOrReplace(transform206)

const veinedMarbleWall11 = new Entity('veinedMarbleWall11')
engine.addEntity(veinedMarbleWall11)
veinedMarbleWall11.setParent(_scene)
veinedMarbleWall11.addComponentOrReplace(gltfShape3)
const transform207 = new Transform({
  position: new Vector3(11.011978149414062, 4.364322185516357, 0.5608201026916504),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.60333251953125, 15.76275634765625, 59.45534133911133)
})
veinedMarbleWall11.addComponentOrReplace(transform207)

const veinedMarbleWall2 = new Entity('veinedMarbleWall2')
engine.addEntity(veinedMarbleWall2)
veinedMarbleWall2.setParent(_scene)
veinedMarbleWall2.addComponentOrReplace(gltfShape3)
const transform208 = new Transform({
  position: new Vector3(27.54228973388672, 2.769845485687256, 13.109566688537598),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall2.addComponentOrReplace(transform208)

const veinedMarbleWall6 = new Entity('veinedMarbleWall6')
engine.addEntity(veinedMarbleWall6)
veinedMarbleWall6.setParent(_scene)
veinedMarbleWall6.addComponentOrReplace(gltfShape3)
const transform209 = new Transform({
  position: new Vector3(24.142738342285156, 4.364322185516357, 13.109570503234863),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603317260742188, 15.762741088867188, 59.45534133911133)
})
veinedMarbleWall6.addComponentOrReplace(transform209)

const veinedMarbleWall7 = new Entity('veinedMarbleWall7')
engine.addEntity(veinedMarbleWall7)
veinedMarbleWall7.setParent(_scene)
veinedMarbleWall7.addComponentOrReplace(gltfShape3)
const transform210 = new Transform({
  position: new Vector3(17.54228973388672, 5.903547763824463, 13.109574317932129),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall7.addComponentOrReplace(transform210)

const veinedMarbleWall8 = new Entity('veinedMarbleWall8')
engine.addEntity(veinedMarbleWall8)
veinedMarbleWall8.setParent(_scene)
veinedMarbleWall8.addComponentOrReplace(gltfShape3)
const transform211 = new Transform({
  position: new Vector3(11.011978149414062, 4.364322185516357, 13.10957145690918),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603340148925781, 15.762763977050781, 59.45534133911133)
})
veinedMarbleWall8.addComponentOrReplace(transform211)

const veinedMarbleWall9 = new Entity('veinedMarbleWall9')
engine.addEntity(veinedMarbleWall9)
veinedMarbleWall9.setParent(_scene)
veinedMarbleWall9.addComponentOrReplace(gltfShape3)
const transform212 = new Transform({
  position: new Vector3(7.542289733886719, 2.769845962524414, 13.10958194732666),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall9.addComponentOrReplace(transform212)

const veinedMarbleWall10 = new Entity('veinedMarbleWall10')
engine.addEntity(veinedMarbleWall10)
veinedMarbleWall10.setParent(_scene)
veinedMarbleWall10.addComponentOrReplace(gltfShape3)
const transform213 = new Transform({
  position: new Vector3(25.247533798217773, 13.494148254394531, 2.426725387573242),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603324890136719, 15.762748718261719, 59.45534133911133)
})
veinedMarbleWall10.addComponentOrReplace(transform213)

const veinedMarbleWall12 = new Entity('veinedMarbleWall12')
engine.addEntity(veinedMarbleWall12)
veinedMarbleWall12.setParent(_scene)
veinedMarbleWall12.addComponentOrReplace(gltfShape3)
const transform214 = new Transform({
  position: new Vector3(18.647085189819336, 15.033373832702637, 2.426729679107666),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall12.addComponentOrReplace(transform214)

const veinedMarbleWall13 = new Entity('veinedMarbleWall13')
engine.addEntity(veinedMarbleWall13)
veinedMarbleWall13.setParent(_scene)
veinedMarbleWall13.addComponentOrReplace(gltfShape3)
const transform215 = new Transform({
  position: new Vector3(12.11677360534668, 13.494148254394531, 2.426726818084717),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603347778320312, 15.762771606445312, 59.45534133911133)
})
veinedMarbleWall13.addComponentOrReplace(transform215)

const veinedMarbleWall14 = new Entity('veinedMarbleWall14')
engine.addEntity(veinedMarbleWall14)
veinedMarbleWall14.setParent(_scene)
veinedMarbleWall14.addComponentOrReplace(gltfShape3)
const transform216 = new Transform({
  position: new Vector3(8.680947303771973, 11.899792671203613, 2.4267373085021973),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall14.addComponentOrReplace(transform216)

const veinedMarbleWall15 = new Entity('veinedMarbleWall15')
engine.addEntity(veinedMarbleWall15)
veinedMarbleWall15.setParent(_scene)
veinedMarbleWall15.addComponentOrReplace(gltfShape3)
const transform217 = new Transform({
  position: new Vector3(25.247533798217773, 13.494148254394531, 13.49727725982666),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603328704833984, 15.762752532958984, 59.45534133911133)
})
veinedMarbleWall15.addComponentOrReplace(transform217)

const veinedMarbleWall16 = new Entity('veinedMarbleWall16')
engine.addEntity(veinedMarbleWall16)
veinedMarbleWall16.setParent(_scene)
veinedMarbleWall16.addComponentOrReplace(gltfShape3)
const transform218 = new Transform({
  position: new Vector3(18.647085189819336, 15.048386573791504, 13.49728012084961),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall16.addComponentOrReplace(transform218)

const veinedMarbleWall17 = new Entity('veinedMarbleWall17')
engine.addEntity(veinedMarbleWall17)
veinedMarbleWall17.setParent(_scene)
veinedMarbleWall17.addComponentOrReplace(gltfShape3)
const transform219 = new Transform({
  position: new Vector3(12.11677360534668, 13.494148254394531, 13.497278213500977),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603351593017578, 15.762775421142578, 59.45534133911133)
})
veinedMarbleWall17.addComponentOrReplace(transform219)

const veinedMarbleWall18 = new Entity('veinedMarbleWall18')
engine.addEntity(veinedMarbleWall18)
veinedMarbleWall18.setParent(_scene)
veinedMarbleWall18.addComponentOrReplace(gltfShape3)
const transform220 = new Transform({
  position: new Vector3(8.647085189819336, 11.899672508239746, 13.497288703918457),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall18.addComponentOrReplace(transform220)

const veinedMarbleWall19 = new Entity('veinedMarbleWall19')
engine.addEntity(veinedMarbleWall19)
veinedMarbleWall19.setParent(_scene)
veinedMarbleWall19.addComponentOrReplace(gltfShape3)
const transform221 = new Transform({
  position: new Vector3(22.8197021484375, 22.618806838989258, 12.129693031311035),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603355407714844, 15.762779235839844, 59.45534133911133)
})
veinedMarbleWall19.addComponentOrReplace(transform221)

const veinedMarbleWall20 = new Entity('veinedMarbleWall20')
engine.addEntity(veinedMarbleWall20)
veinedMarbleWall20.setParent(_scene)
veinedMarbleWall20.addComponentOrReplace(gltfShape3)
const transform222 = new Transform({
  position: new Vector3(16.219253540039062, 24.184093475341797, 12.1296968460083),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall20.addComponentOrReplace(transform222)

const veinedMarbleWall21 = new Entity('veinedMarbleWall21')
engine.addEntity(veinedMarbleWall21)
veinedMarbleWall21.setParent(_scene)
veinedMarbleWall21.addComponentOrReplace(gltfShape3)
const transform223 = new Transform({
  position: new Vector3(9.688941955566406, 22.618806838989258, 12.129693984985352),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603378295898438, 15.762802124023438, 59.45534133911133)
})
veinedMarbleWall21.addComponentOrReplace(transform223)

const veinedMarbleWall22 = new Entity('veinedMarbleWall22')
engine.addEntity(veinedMarbleWall22)
veinedMarbleWall22.setParent(_scene)
veinedMarbleWall22.addComponentOrReplace(gltfShape3)
const transform224 = new Transform({
  position: new Vector3(22.8197021484375, 22.618806838989258, 3.912565231323242),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.603370666503906, 15.762794494628906, 59.45534133911133)
})
veinedMarbleWall22.addComponentOrReplace(transform224)

const veinedMarbleWall23 = new Entity('veinedMarbleWall23')
engine.addEntity(veinedMarbleWall23)
veinedMarbleWall23.setParent(_scene)
veinedMarbleWall23.addComponentOrReplace(gltfShape3)
const transform225 = new Transform({
  position: new Vector3(16.219253540039062, 24.184093475341797, 3.912569046020508),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(15.603271484375, 15.7626953125, 59.45534133911133)
})
veinedMarbleWall23.addComponentOrReplace(transform225)

const veinedMarbleWall24 = new Entity('veinedMarbleWall24')
engine.addEntity(veinedMarbleWall24)
veinedMarbleWall24.setParent(_scene)
veinedMarbleWall24.addComponentOrReplace(gltfShape3)
const transform226 = new Transform({
  position: new Vector3(9.688941955566406, 22.618806838989258, 3.9125661849975586),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(15.6033935546875, 15.7628173828125, 59.45534133911133)
})
veinedMarbleWall24.addComponentOrReplace(transform226)

const cleanGoldWall2 = new Entity('cleanGoldWall2')
engine.addEntity(cleanGoldWall2)
cleanGoldWall2.setParent(_scene)
const transform227 = new Transform({
  position: new Vector3(16.05883026123047, 8.864291191101074, 2.8029308319091797),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(159.3960418701172, 39.52761459350586, 33.7933349609375)
})
cleanGoldWall2.addComponentOrReplace(transform227)
const gltfShape4 = new GLTFShape("008b2ac92b7fbe6bea06d5840cddf3cd392953d5a6b8622b55834f301b319994/Clean_Gold Wall.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
cleanGoldWall2.addComponentOrReplace(gltfShape4)

const cleanGoldWall3 = new Entity('cleanGoldWall3')
engine.addEntity(cleanGoldWall3)
cleanGoldWall3.setParent(_scene)
cleanGoldWall3.addComponentOrReplace(gltfShape4)
const transform228 = new Transform({
  position: new Vector3(18.82655143737793, 0.15945720672607422, 2.8029308319091797),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(131.63954162597656, 39.52758026123047, 14.665427207946777)
})
cleanGoldWall3.addComponentOrReplace(transform228)

const cleanGoldWall4 = new Entity('cleanGoldWall4')
engine.addEntity(cleanGoldWall4)
cleanGoldWall4.setParent(_scene)
cleanGoldWall4.addComponentOrReplace(gltfShape4)
const transform229 = new Transform({
  position: new Vector3(16.047029495239258, 9.024477005004883, 4.80293083190918),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(159.580810546875, 29.645832061767578, 137.0001678466797)
})
cleanGoldWall4.addComponentOrReplace(transform229)

const cleanGoldWall5 = new Entity('cleanGoldWall5')
engine.addEntity(cleanGoldWall5)
cleanGoldWall5.setParent(_scene)
cleanGoldWall5.addComponentOrReplace(gltfShape4)
const transform230 = new Transform({
  position: new Vector3(17.10289764404297, 17.82714080810547, 5.040602684020996),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(149.01893615722656, 29.646055221557617, 58.626060485839844)
})
cleanGoldWall5.addComponentOrReplace(transform230)

const cleanGoldWall6 = new Entity('cleanGoldWall6')
engine.addEntity(cleanGoldWall6)
cleanGoldWall6.setParent(_scene)
cleanGoldWall6.addComponentOrReplace(gltfShape4)
const transform231 = new Transform({
  position: new Vector3(17.052001953125, 18.016094207763672, 5.593941688537598),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(149.57908630371094, 23.791826248168945, 116.01656341552734)
})
cleanGoldWall6.addComponentOrReplace(transform231)

const cleanGoldWall8 = new Entity('cleanGoldWall8')
engine.addEntity(cleanGoldWall8)
cleanGoldWall8.setParent(_scene)
cleanGoldWall8.addComponentOrReplace(gltfShape4)
const transform232 = new Transform({
  position: new Vector3(17.4993896484375, 27.085289001464844, 5.593941688537598),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(137.94796752929688, 23.79194450378418, 81.3458480834961)
})
cleanGoldWall8.addComponentOrReplace(transform232)

const cleanGoldWall9 = new Entity('cleanGoldWall9')
engine.addEntity(cleanGoldWall9)
cleanGoldWall9.setParent(_scene)
cleanGoldWall9.addComponentOrReplace(gltfShape4)
const transform233 = new Transform({
  position: new Vector3(16.782339096069336, 30.891155242919922, 5.593941688537598),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(108.93630981445312, 23.792001724243164, 84.67857360839844)
})
cleanGoldWall9.addComponentOrReplace(transform233)

const barBlack = new Entity('barBlack')
engine.addEntity(barBlack)
barBlack.setParent(_scene)
const transform234 = new Transform({
  position: new Vector3(3.000000238418579, 1, 3.7190160751342773),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000019073486328, 1, 1.0000019073486328)
})
barBlack.addComponentOrReplace(transform234)
const gltfShape5 = new GLTFShape("d1f059f439f98a67c491e5b0bb665b42425d0ad268a6c60dbc22e89f59000f23/Bar_Black.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
barBlack.addComponentOrReplace(gltfShape5)

const barBlack2 = new Entity('barBlack2')
engine.addEntity(barBlack2)
barBlack2.setParent(_scene)
barBlack2.addComponentOrReplace(gltfShape5)
const transform235 = new Transform({
  position: new Vector3(25.000001907348633, 10, 10.839006423950195),
  rotation: new Quaternion(-4.084899820879168e-15, 0.7071068286895752, -8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(1.0000040531158447, 1, 1.0000040531158447)
})
barBlack2.addComponentOrReplace(transform235)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform236 = new Transform({
  position: new Vector3(0.8250251412391663, 7.622277736663818, 6.941629409790039),
  rotation: new Quaternion(4.398226784249631e-16, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1, 1, 0.1168738529086113)
})
radio.addComponentOrReplace(transform236)

const radio2 = new Entity('radio2')
engine.addEntity(radio2)
radio2.setParent(_scene)
const transform237 = new Transform({
  position: new Vector3(27.474220275878906, 16.794361114501953, 8.12045955657959),
  rotation: new Quaternion(2.9778489346414787e-15, 0.7071067690849304, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1, 1, 0.1168738529086113)
})
radio2.addComponentOrReplace(transform237)

const invisibleWall13 = new Entity('invisibleWall13')
engine.addEntity(invisibleWall13)
invisibleWall13.setParent(_scene)
const transform238 = new Transform({
  position: new Vector3(28.755531311035156, 18.9357967376709, 15.99901008605957),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.253543376922607, 0.1428568959236145, 0.6413664221763611)
})
invisibleWall13.addComponentOrReplace(transform238)

const invisibleWall65 = new Entity('invisibleWall65')
engine.addEntity(invisibleWall65)
invisibleWall65.setParent(_scene)
const transform239 = new Transform({
  position: new Vector3(28.755531311035156, 18.9357967376709, 0.15284013748168945),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.253543376922607, 0.14285695552825928, 0.6413664221763611)
})
invisibleWall65.addComponentOrReplace(transform239)

const ceilingLight = new Entity('ceilingLight')
engine.addEntity(ceilingLight)
ceilingLight.setParent(_scene)
const transform240 = new Transform({
  position: new Vector3(27.51921844482422, 3.156644105911255, 1.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight.addComponentOrReplace(transform240)

const ceilingLight2 = new Entity('ceilingLight2')
engine.addEntity(ceilingLight2)
ceilingLight2.setParent(_scene)
const transform241 = new Transform({
  position: new Vector3(22.51921844482422, 3.156644105911255, 1.500000238418579),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight2.addComponentOrReplace(transform241)

const ceilingLight3 = new Entity('ceilingLight3')
engine.addEntity(ceilingLight3)
ceilingLight3.setParent(_scene)
const transform242 = new Transform({
  position: new Vector3(17.51921844482422, 3.156644105911255, 1.500000238418579),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight3.addComponentOrReplace(transform242)

const ceilingLight4 = new Entity('ceilingLight4')
engine.addEntity(ceilingLight4)
ceilingLight4.setParent(_scene)
const transform243 = new Transform({
  position: new Vector3(12.519218444824219, 3.156644105911255, 1.500000238418579),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight4.addComponentOrReplace(transform243)

const ceilingLight5 = new Entity('ceilingLight5')
engine.addEntity(ceilingLight5)
ceilingLight5.setParent(_scene)
const transform244 = new Transform({
  position: new Vector3(7.519218444824219, 3.156644105911255, 1.500000238418579),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight5.addComponentOrReplace(transform244)

const ceilingLight6 = new Entity('ceilingLight6')
engine.addEntity(ceilingLight6)
ceilingLight6.setParent(_scene)
const transform245 = new Transform({
  position: new Vector3(7.519218444824219, 3.156644105911255, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight6.addComponentOrReplace(transform245)

const ceilingLight7 = new Entity('ceilingLight7')
engine.addEntity(ceilingLight7)
ceilingLight7.setParent(_scene)
const transform246 = new Transform({
  position: new Vector3(12.519218444824219, 3.156644105911255, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight7.addComponentOrReplace(transform246)

const ceilingLight8 = new Entity('ceilingLight8')
engine.addEntity(ceilingLight8)
ceilingLight8.setParent(_scene)
const transform247 = new Transform({
  position: new Vector3(17.51921844482422, 3.156644105911255, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight8.addComponentOrReplace(transform247)

const ceilingLight9 = new Entity('ceilingLight9')
engine.addEntity(ceilingLight9)
ceilingLight9.setParent(_scene)
const transform248 = new Transform({
  position: new Vector3(22.51921844482422, 3.156644105911255, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight9.addComponentOrReplace(transform248)

const ceilingLight10 = new Entity('ceilingLight10')
engine.addEntity(ceilingLight10)
ceilingLight10.setParent(_scene)
const transform249 = new Transform({
  position: new Vector3(27.51921844482422, 3.156644105911255, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight10.addComponentOrReplace(transform249)

const ceilingLight11 = new Entity('ceilingLight11')
engine.addEntity(ceilingLight11)
ceilingLight11.setParent(_scene)
const transform250 = new Transform({
  position: new Vector3(8.78742790222168, 12.257770538330078, 12.237671852111816),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight11.addComponentOrReplace(transform250)

const ceilingLight12 = new Entity('ceilingLight12')
engine.addEntity(ceilingLight12)
ceilingLight12.setParent(_scene)
const transform251 = new Transform({
  position: new Vector3(13.78742790222168, 12.257770538330078, 12.237671852111816),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight12.addComponentOrReplace(transform251)

const ceilingLight13 = new Entity('ceilingLight13')
engine.addEntity(ceilingLight13)
ceilingLight13.setParent(_scene)
const transform252 = new Transform({
  position: new Vector3(18.78742790222168, 12.257770538330078, 12.237671852111816),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight13.addComponentOrReplace(transform252)

const ceilingLight14 = new Entity('ceilingLight14')
engine.addEntity(ceilingLight14)
ceilingLight14.setParent(_scene)
const transform253 = new Transform({
  position: new Vector3(23.78742790222168, 12.257770538330078, 12.237671852111816),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight14.addComponentOrReplace(transform253)

const ceilingLight15 = new Entity('ceilingLight15')
engine.addEntity(ceilingLight15)
ceilingLight15.setParent(_scene)
const transform254 = new Transform({
  position: new Vector3(8.78742790222168, 12.257770538330078, 3.77925968170166),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight15.addComponentOrReplace(transform254)

const ceilingLight16 = new Entity('ceilingLight16')
engine.addEntity(ceilingLight16)
ceilingLight16.setParent(_scene)
const transform255 = new Transform({
  position: new Vector3(13.78742790222168, 12.257770538330078, 3.77925968170166),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight16.addComponentOrReplace(transform255)

const ceilingLight17 = new Entity('ceilingLight17')
engine.addEntity(ceilingLight17)
ceilingLight17.setParent(_scene)
const transform256 = new Transform({
  position: new Vector3(18.78742790222168, 12.257770538330078, 3.77925968170166),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight17.addComponentOrReplace(transform256)

const ceilingLight18 = new Entity('ceilingLight18')
engine.addEntity(ceilingLight18)
ceilingLight18.setParent(_scene)
const transform257 = new Transform({
  position: new Vector3(23.78742790222168, 12.257770538330078, 3.77925968170166),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight18.addComponentOrReplace(transform257)

const ceilingLight19 = new Entity('ceilingLight19')
engine.addEntity(ceilingLight19)
ceilingLight19.setParent(_scene)
const transform258 = new Transform({
  position: new Vector3(11.204042434692383, 21.257770538330078, 4.619060039520264),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight19.addComponentOrReplace(transform258)

const ceilingLight20 = new Entity('ceilingLight20')
engine.addEntity(ceilingLight20)
ceilingLight20.setParent(_scene)
const transform259 = new Transform({
  position: new Vector3(16.204042434692383, 21.257770538330078, 4.619060039520264),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight20.addComponentOrReplace(transform259)

const ceilingLight21 = new Entity('ceilingLight21')
engine.addEntity(ceilingLight21)
ceilingLight21.setParent(_scene)
const transform260 = new Transform({
  position: new Vector3(21.204042434692383, 21.257770538330078, 4.619060039520264),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight21.addComponentOrReplace(transform260)

const ceilingLight22 = new Entity('ceilingLight22')
engine.addEntity(ceilingLight22)
ceilingLight22.setParent(_scene)
const transform261 = new Transform({
  position: new Vector3(11.204042434692383, 21.257770538330078, 11.361538887023926),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight22.addComponentOrReplace(transform261)

const ceilingLight23 = new Entity('ceilingLight23')
engine.addEntity(ceilingLight23)
ceilingLight23.setParent(_scene)
const transform262 = new Transform({
  position: new Vector3(16.204042434692383, 21.257770538330078, 11.361538887023926),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight23.addComponentOrReplace(transform262)

const ceilingLight24 = new Entity('ceilingLight24')
engine.addEntity(ceilingLight24)
ceilingLight24.setParent(_scene)
const transform263 = new Transform({
  position: new Vector3(21.204042434692383, 21.257770538330078, 11.361538887023926),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.1871695518493652, 1.4581129550933838, 2.1871695518493652)
})
ceilingLight24.addComponentOrReplace(transform263)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform264 = new Transform({
  position: new Vector3(22.54458999633789, 3.151749849319458, 0.7004121541976929),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame2.addComponentOrReplace(transform264)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform265 = new Transform({
  position: new Vector3(27.54458999633789, 3.151749849319458, 0.7004115581512451),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame3.addComponentOrReplace(transform265)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform266 = new Transform({
  position: new Vector3(12.54458999633789, 3.151749849319458, 0.7004133462905884),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame4.addComponentOrReplace(transform266)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform267 = new Transform({
  position: new Vector3(7.544589996337891, 3.151749849319458, 0.7004139423370361),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame5.addComponentOrReplace(transform267)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform268 = new Transform({
  position: new Vector3(27.54458999633789, 3.151749849319458, 12.996771812438965),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame6.addComponentOrReplace(transform268)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform269 = new Transform({
  position: new Vector3(22.54458999633789, 3.151749849319458, 12.996772766113281),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame7.addComponentOrReplace(transform269)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform270 = new Transform({
  position: new Vector3(17.54458999633789, 3.151749849319458, 12.996772766113281),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame8.addComponentOrReplace(transform270)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform271 = new Transform({
  position: new Vector3(12.54458999633789, 3.151749849319458, 12.996772766113281),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame9.addComponentOrReplace(transform271)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform272 = new Transform({
  position: new Vector3(7.544589996337891, 3.151749849319458, 12.996773719787598),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame10.addComponentOrReplace(transform272)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform273 = new Transform({
  position: new Vector3(8.665891647338867, 12.371891021728516, 13.409215927124023),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame11.addComponentOrReplace(transform273)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform274 = new Transform({
  position: new Vector3(13.665891647338867, 12.371891021728516, 13.409214973449707),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame12.addComponentOrReplace(transform274)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform275 = new Transform({
  position: new Vector3(18.665891647338867, 12.371891021728516, 13.409214973449707),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame13.addComponentOrReplace(transform275)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform276 = new Transform({
  position: new Vector3(23.665891647338867, 12.371891021728516, 13.409214973449707),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame14.addComponentOrReplace(transform276)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform277 = new Transform({
  position: new Vector3(8.706897735595703, 12.371891021728516, 2.4907026290893555),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame15.addComponentOrReplace(transform277)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform278 = new Transform({
  position: new Vector3(13.706897735595703, 12.371891021728516, 2.490701675415039),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame16.addComponentOrReplace(transform278)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform279 = new Transform({
  position: new Vector3(18.706897735595703, 12.371891021728516, 2.490701198577881),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame17.addComponentOrReplace(transform279)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform280 = new Transform({
  position: new Vector3(23.706897735595703, 12.371891021728516, 2.4907007217407227),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame18.addComponentOrReplace(transform280)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform281 = new Transform({
  position: new Vector3(11.218812942504883, 21.485254287719727, 4.015698432922363),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame19.addComponentOrReplace(transform281)

const nftPictureFrame20 = new Entity('nftPictureFrame20')
engine.addEntity(nftPictureFrame20)
nftPictureFrame20.setParent(_scene)
const transform282 = new Transform({
  position: new Vector3(16.218812942504883, 21.485254287719727, 4.015697956085205),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame20.addComponentOrReplace(transform282)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform283 = new Transform({
  position: new Vector3(21.218812942504883, 21.485254287719727, 4.015697479248047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame21.addComponentOrReplace(transform283)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform284 = new Transform({
  position: new Vector3(21.271907806396484, 21.485254287719727, 12.032041549682617),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame22.addComponentOrReplace(transform284)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform285 = new Transform({
  position: new Vector3(16.177806854248047, 21.485254287719727, 12.032041549682617),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame23.addComponentOrReplace(transform285)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform286 = new Transform({
  position: new Vector3(11.177806854248047, 21.485254287719727, 12.032041549682617),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(4.602535247802734, 4.602535247802734, 0.7434821724891663)
})
nftPictureFrame24.addComponentOrReplace(transform286)

const invisibleWall66 = new Entity('invisibleWall66')
engine.addEntity(invisibleWall66)
invisibleWall66.setParent(_scene)
const transform287 = new Transform({
  position: new Vector3(3.1113224029541016, 9.948100090026855, 15.95975112915039),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.207238674163818, 0.14285632967948914, 0.6413649916648865)
})
invisibleWall66.addComponentOrReplace(transform287)

const valenciaMarbleWall107 = new Entity('valenciaMarbleWall107')
engine.addEntity(valenciaMarbleWall107)
valenciaMarbleWall107.setParent(_scene)
valenciaMarbleWall107.addComponentOrReplace(gltfShape2)
const transform288 = new Transform({
  position: new Vector3(0.4296884536743164, 0.14262008666992188, 6.838988304138184),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.2771782875061035, 2.604759931564331, 4819.39599609375)
})
valenciaMarbleWall107.addComponentOrReplace(transform288)

const valenciaMarbleWall139 = new Entity('valenciaMarbleWall139')
engine.addEntity(valenciaMarbleWall139)
valenciaMarbleWall139.setParent(_scene)
valenciaMarbleWall139.addComponentOrReplace(gltfShape2)
const transform289 = new Transform({
  position: new Vector3(27.880573272705078, 9.104865074157715, 7.967694282531738),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.0121045112609863, 2.4955124855041504, 4087.75048828125)
})
valenciaMarbleWall139.addComponentOrReplace(transform289)

const valenciaMarbleWall140 = new Entity('valenciaMarbleWall140')
engine.addEntity(valenciaMarbleWall140)
valenciaMarbleWall140.setParent(_scene)
valenciaMarbleWall140.addComponentOrReplace(gltfShape2)
const transform290 = new Transform({
  position: new Vector3(8.73902702331543, 18.142620086669922, 7.970107078552246),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.796531915664673, 2.7380623817443848, 3011.9013671875)
})
valenciaMarbleWall140.addComponentOrReplace(transform290)

const invisibleWall67 = new Entity('invisibleWall67')
engine.addEntity(invisibleWall67)
invisibleWall67.setParent(_scene)
const transform291 = new Transform({
  position: new Vector3(5.501831531524658, 27.948101043701172, 15.95975112915039),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.478208541870117, 0.14285647869110107, 0.6413649916648865)
})
invisibleWall67.addComponentOrReplace(transform291)

const invisibleWall68 = new Entity('invisibleWall68')
engine.addEntity(invisibleWall68)
invisibleWall68.setParent(_scene)
const transform292 = new Transform({
  position: new Vector3(5.966858386993408, 27.948101043701172, 3.4597511291503906),
  rotation: new Quaternion(-0.7071068286895752, 2.4085271740892887e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(5.108214378356934, 0.14285656809806824, 0.6413649916648865)
})
invisibleWall68.addComponentOrReplace(transform292)

const rainbowAnodizedMetalWall = new Entity('rainbowAnodizedMetalWall')
engine.addEntity(rainbowAnodizedMetalWall)
rainbowAnodizedMetalWall.setParent(_scene)
const transform293 = new Transform({
  position: new Vector3(17.591894149780273, 8.86034870147705, 12.461908340454102),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(107.74652099609375, 4.368704319000244, 37.61054229736328)
})
rainbowAnodizedMetalWall.addComponentOrReplace(transform293)
const gltfShape6 = new GLTFShape("e656adead45a54e5b315094ae9f39732575c8564a978338ab67a55b558fe41f6/Rainbow_Anodized Metal Wall.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
rainbowAnodizedMetalWall.addComponentOrReplace(gltfShape6)

const rainbowAnodizedMetalWall2 = new Entity('rainbowAnodizedMetalWall2')
engine.addEntity(rainbowAnodizedMetalWall2)
rainbowAnodizedMetalWall2.setParent(_scene)
rainbowAnodizedMetalWall2.addComponentOrReplace(gltfShape6)
const transform294 = new Transform({
  position: new Vector3(17.591894149780273, 8.86034870147705, 1.9619083404541016),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(107.74652099609375, 4.3687052726745605, 37.610557556152344)
})
rainbowAnodizedMetalWall2.addComponentOrReplace(transform294)

const rainbowAnodizedMetalWall3 = new Entity('rainbowAnodizedMetalWall3')
engine.addEntity(rainbowAnodizedMetalWall3)
rainbowAnodizedMetalWall3.setParent(_scene)
rainbowAnodizedMetalWall3.addComponentOrReplace(gltfShape6)
const transform295 = new Transform({
  position: new Vector3(16.33354949951172, 17.800004959106445, 12.699580192565918),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(81.89714050292969, 4.368715763092041, 48.64658737182617)
})
rainbowAnodizedMetalWall3.addComponentOrReplace(transform295)

const rainbowAnodizedMetalWall4 = new Entity('rainbowAnodizedMetalWall4')
engine.addEntity(rainbowAnodizedMetalWall4)
rainbowAnodizedMetalWall4.setParent(_scene)
rainbowAnodizedMetalWall4.addComponentOrReplace(gltfShape6)
const transform296 = new Transform({
  position: new Vector3(16.33354949951172, 17.800004959106445, 4.241168022155762),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(81.89714050292969, 4.368717670440674, 48.64671325683594)
})
rainbowAnodizedMetalWall4.addComponentOrReplace(transform296)

const rainbowAnodizedMetalWall5 = new Entity('rainbowAnodizedMetalWall5')
engine.addEntity(rainbowAnodizedMetalWall5)
rainbowAnodizedMetalWall5.setParent(_scene)
rainbowAnodizedMetalWall5.addComponentOrReplace(gltfShape6)
const transform297 = new Transform({
  position: new Vector3(16.17534637451172, 26.972578048706055, 4.87083101272583),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(59.0313606262207, 3.2765438556671143, 24.6435604095459)
})
rainbowAnodizedMetalWall5.addComponentOrReplace(transform297)

const rainbowAnodizedMetalWall6 = new Entity('rainbowAnodizedMetalWall6')
engine.addEntity(rainbowAnodizedMetalWall6)
rainbowAnodizedMetalWall6.setParent(_scene)
rainbowAnodizedMetalWall6.addComponentOrReplace(gltfShape6)
const transform298 = new Transform({
  position: new Vector3(16.17534637451172, 26.972578048706055, 11.704044342041016),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(59.0313606262207, 3.276545763015747, 24.64357566833496)
})
rainbowAnodizedMetalWall6.addComponentOrReplace(transform298)

const floorLampPaperLight = new Entity('floorLampPaperLight')
engine.addEntity(floorLampPaperLight)
floorLampPaperLight.setParent(_scene)
const transform299 = new Transform({
  position: new Vector3(1.5, 1.0350278615951538, 12.594027519226074),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 4.398248195648193, 1)
})
floorLampPaperLight.addComponentOrReplace(transform299)

const floorLampPaperLight2 = new Entity('floorLampPaperLight2')
engine.addEntity(floorLampPaperLight2)
floorLampPaperLight2.setParent(_scene)
const transform300 = new Transform({
  position: new Vector3(1.5, 1.0350278615951538, 1.0940275192260742),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 4.398248195648193, 1)
})
floorLampPaperLight2.addComponentOrReplace(transform300)

const floorLampPaperLight3 = new Entity('floorLampPaperLight3')
engine.addEntity(floorLampPaperLight3)
floorLampPaperLight3.setParent(_scene)
const transform301 = new Transform({
  position: new Vector3(26.5, 10.171631813049316, 13.117587089538574),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 4.398248195648193, 1.0349445343017578)
})
floorLampPaperLight3.addComponentOrReplace(transform301)

const floorLampPaperLight4 = new Entity('floorLampPaperLight4')
engine.addEntity(floorLampPaperLight4)
floorLampPaperLight4.setParent(_scene)
const transform302 = new Transform({
  position: new Vector3(26.5, 10.171631813049316, 2.852254867553711),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 4.398248195648193, 1.0349445343017578)
})
floorLampPaperLight4.addComponentOrReplace(transform302)

const stoolModern = new Entity('stoolModern')
engine.addEntity(stoolModern)
stoolModern.setParent(_scene)
const transform303 = new Transform({
  position: new Vector3(3.5528182983398438, 1.0605543851852417, 4.721270561218262),
  rotation: new Quaternion(-1.9663483411726398e-16, -0.5555702447891235, 6.622912707143769e-8, 0.8314696550369263),
  scale: new Vector3(1.084271788597107, 0.8983447551727295, 1.0144597291946411)
})
stoolModern.addComponentOrReplace(transform303)
const gltfShape7 = new GLTFShape("f229cade1408c7a2889da8d889bf2552a5d049fe199084a1511776a8b72e534e/ModernStool.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
stoolModern.addComponentOrReplace(gltfShape7)

const stoolModern2 = new Entity('stoolModern2')
engine.addEntity(stoolModern2)
stoolModern2.setParent(_scene)
stoolModern2.addComponentOrReplace(gltfShape7)
const transform304 = new Transform({
  position: new Vector3(3.5528182983398438, 1.0605543851852417, 5.819999694824219),
  rotation: new Quaternion(-1.9663483411726398e-16, -0.5555702447891235, 6.622912707143769e-8, 0.8314696550369263),
  scale: new Vector3(1.084271788597107, 0.8983447551727295, 1.0144598484039307)
})
stoolModern2.addComponentOrReplace(transform304)

const stoolModern3 = new Entity('stoolModern3')
engine.addEntity(stoolModern3)
stoolModern3.setParent(_scene)
stoolModern3.addComponentOrReplace(gltfShape7)
const transform305 = new Transform({
  position: new Vector3(3.4511749744415283, 1.0605543851852417, 6.918728351593018),
  rotation: new Quaternion(2.3272704564262364e-15, 0.8314696550369263, -9.911889264913043e-8, -0.5555703043937683),
  scale: new Vector3(1.084272861480713, 0.8983447551727295, 1.014460563659668)
})
stoolModern3.addComponentOrReplace(transform305)

const stoolModern4 = new Entity('stoolModern4')
engine.addEntity(stoolModern4)
stoolModern4.setParent(_scene)
stoolModern4.addComponentOrReplace(gltfShape7)
const transform306 = new Transform({
  position: new Vector3(3.5528182983398438, 1.0605543851852417, 8.017457008361816),
  rotation: new Quaternion(-1.9663483411726398e-16, -0.5555702447891235, 6.622912707143769e-8, 0.8314696550369263),
  scale: new Vector3(1.084272027015686, 0.8983447551727295, 1.0144600868225098)
})
stoolModern4.addComponentOrReplace(transform306)

const stoolModern5 = new Entity('stoolModern5')
engine.addEntity(stoolModern5)
stoolModern5.setParent(_scene)
stoolModern5.addComponentOrReplace(gltfShape7)
const transform307 = new Transform({
  position: new Vector3(3.4511749744415283, 1.0605543851852417, 8.91872787475586),
  rotation: new Quaternion(2.3272704564262364e-15, 0.8314696550369263, -9.911889264913043e-8, -0.5555703043937683),
  scale: new Vector3(1.084273338317871, 0.8983447551727295, 1.0144609212875366)
})
stoolModern5.addComponentOrReplace(transform307)

const stoolModern6 = new Entity('stoolModern6')
engine.addEntity(stoolModern6)
stoolModern6.setParent(_scene)
stoolModern6.addComponentOrReplace(gltfShape7)
const transform308 = new Transform({
  position: new Vector3(24.451175689697266, 10.160213470458984, 9.80742359161377),
  rotation: new Quaternion(-4.853519116557875e-15, 0.8314696550369263, -9.911889975455779e-8, 0.5555702447891235),
  scale: new Vector3(1.0842738151550293, 0.8983447551727295, 1.0144617557525635)
})
stoolModern6.addComponentOrReplace(transform308)

const stoolModern7 = new Entity('stoolModern7')
engine.addEntity(stoolModern7)
stoolModern7.setParent(_scene)
stoolModern7.addComponentOrReplace(gltfShape7)
const transform309 = new Transform({
  position: new Vector3(24.451175689697266, 10.160212516784668, 8.708694458007812),
  rotation: new Quaternion(-4.853519116557875e-15, 0.8314696550369263, -9.911889975455779e-8, 0.5555702447891235),
  scale: new Vector3(1.0842738151550293, 0.8983447551727295, 1.014461874961853)
})
stoolModern7.addComponentOrReplace(transform309)

const stoolModern8 = new Entity('stoolModern8')
engine.addEntity(stoolModern8)
stoolModern8.setParent(_scene)
stoolModern8.addComponentOrReplace(gltfShape7)
const transform310 = new Transform({
  position: new Vector3(24.552818298339844, 10.160212516784668, 7.609965801239014),
  rotation: new Quaternion(1.0348445462094596e-14, -0.5555703043937683, 6.622912707143769e-8, -0.8314696550369263),
  scale: new Vector3(1.0842759609222412, 0.8983447551727295, 1.0144636631011963)
})
stoolModern8.addComponentOrReplace(transform310)

const stoolModern9 = new Entity('stoolModern9')
engine.addEntity(stoolModern9)
stoolModern9.setParent(_scene)
stoolModern9.addComponentOrReplace(gltfShape7)
const transform311 = new Transform({
  position: new Vector3(24.451175689697266, 10.160212516784668, 6.511237144470215),
  rotation: new Quaternion(-4.853519116557875e-15, 0.8314696550369263, -9.911889975455779e-8, 0.5555702447891235),
  scale: new Vector3(1.0842740535736084, 0.8983447551727295, 1.0144619941711426)
})
stoolModern9.addComponentOrReplace(transform311)

const stoolModern10 = new Entity('stoolModern10')
engine.addEntity(stoolModern10)
stoolModern10.setParent(_scene)
stoolModern10.addComponentOrReplace(gltfShape7)
const transform312 = new Transform({
  position: new Vector3(24.552818298339844, 10.160211563110352, 5.609966278076172),
  rotation: new Quaternion(1.0348445462094596e-14, -0.5555703043937683, 6.622912707143769e-8, -0.8314696550369263),
  scale: new Vector3(1.0842763185501099, 0.8983447551727295, 1.0144639015197754)
})
stoolModern10.addComponentOrReplace(transform312)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform313 = new Transform({
  position: new Vector3(29.65564727783203, 27.036521911621094, 7.989132881164551),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.2886895537376404, 1, 468.6632080078125)
})
ropeLight.addComponentOrReplace(transform313)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform314 = new Transform({
  position: new Vector3(26.036182403564453, 27.153888702392578, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.018157409504055977, 0.999835193157196),
  scale: new Vector3(0.30692461133003235, 1.0000827312469482, 87.87435150146484)
})
ropeLight2.addComponentOrReplace(transform314)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform315 = new Transform({
  position: new Vector3(26.036182403564453, 27.153888702392578, 1.5101146697998047),
  rotation: new Quaternion(0, 0, -0.018157409504055977, 0.999835193157196),
  scale: new Vector3(0.30692458152770996, 1.0000826120376587, 87.87435150146484)
})
ropeLight3.addComponentOrReplace(transform315)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform316 = new Transform({
  position: new Vector3(23.0308780670166, 27.609535217285156, 1.5101146697998047),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.21993842720985413, 0.9876928925514221, 87.87435150146484)
})
ropeLight4.addComponentOrReplace(transform316)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform317 = new Transform({
  position: new Vector3(23.0308780670166, 27.609535217285156, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.2199384570121765, 0.9876928925514221, 87.87435150146484)
})
ropeLight5.addComponentOrReplace(transform317)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform318 = new Transform({
  position: new Vector3(20.0308780670166, 28.3613224029541, 1.5101146697998047),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.21993842720985413, 0.9876930117607117, 87.87435150146484)
})
ropeLight6.addComponentOrReplace(transform318)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform319 = new Transform({
  position: new Vector3(20.0308780670166, 28.3613224029541, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.2199384570121765, 0.9876930117607117, 87.87435150146484)
})
ropeLight7.addComponentOrReplace(transform319)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform320 = new Transform({
  position: new Vector3(17.0308780670166, 29.067127227783203, 1.5101146697998047),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.21993842720985413, 0.9876931309700012, 87.87435150146484)
})
ropeLight8.addComponentOrReplace(transform320)

const ropeLight9 = new Entity('ropeLight9')
engine.addEntity(ropeLight9)
ropeLight9.setParent(_scene)
const transform321 = new Transform({
  position: new Vector3(17.0308780670166, 29.067127227783203, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.2199384570121765, 0.9876931309700012, 87.87435150146484)
})
ropeLight9.addComponentOrReplace(transform321)

const ropeLight10 = new Entity('ropeLight10')
engine.addEntity(ropeLight10)
ropeLight10.setParent(_scene)
const transform322 = new Transform({
  position: new Vector3(14.030878067016602, 29.744413375854492, 1.5101146697998047),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.21993842720985413, 0.9876932501792908, 87.87435150146484)
})
ropeLight10.addComponentOrReplace(transform322)

const ropeLight11 = new Entity('ropeLight11')
engine.addEntity(ropeLight11)
ropeLight11.setParent(_scene)
const transform323 = new Transform({
  position: new Vector3(14.030878067016602, 29.744413375854492, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.2199384570121765, 0.9876932501792908, 87.87435150146484)
})
ropeLight11.addComponentOrReplace(transform323)

const ropeLight12 = new Entity('ropeLight12')
engine.addEntity(ropeLight12)
ropeLight12.setParent(_scene)
const transform324 = new Transform({
  position: new Vector3(11.030878067016602, 30.484296798706055, 1.5101146697998047),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.21993842720985413, 0.9876934289932251, 87.87435150146484)
})
ropeLight12.addComponentOrReplace(transform324)

const ropeLight13 = new Entity('ropeLight13')
engine.addEntity(ropeLight13)
ropeLight13.setParent(_scene)
const transform325 = new Transform({
  position: new Vector3(11.030878067016602, 30.484296798706055, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.09854506701231003, 0.9951326251029968),
  scale: new Vector3(0.2199384570121765, 0.9876934289932251, 87.87435150146484)
})
ropeLight13.addComponentOrReplace(transform325)

const ropeLight14 = new Entity('ropeLight14')
engine.addEntity(ropeLight14)
ropeLight14.setParent(_scene)
const transform326 = new Transform({
  position: new Vector3(7.802873611450195, 30.888051986694336, 1.510115146636963),
  rotation: new Quaternion(0, 0, -0.0005304887890815735, 0.9999998807907104),
  scale: new Vector3(0.32602375745773315, 0.9876987338066101, 87.87434387207031)
})
ropeLight14.addComponentOrReplace(transform326)

const ropeLight15 = new Entity('ropeLight15')
engine.addEntity(ropeLight15)
ropeLight15.setParent(_scene)
const transform327 = new Transform({
  position: new Vector3(7.802873611450195, 30.888051986694336, 14.510114669799805),
  rotation: new Quaternion(0, 0, -0.0005304887890815735, 0.9999998807907104),
  scale: new Vector3(0.32602378726005554, 0.9876987338066101, 87.87434387207031)
})
ropeLight15.addComponentOrReplace(transform327)

const ropeLight16 = new Entity('ropeLight16')
engine.addEntity(ropeLight16)
ropeLight16.setParent(_scene)
const transform328 = new Transform({
  position: new Vector3(16.778600692749023, 30.857864379882812, 8.044642448425293),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8989665508270264, 1, 284.77716064453125)
})
ropeLight16.addComponentOrReplace(transform328)

const rainLight = new Entity('rainLight')
engine.addEntity(rainLight)
rainLight.setParent(_scene)
const transform329 = new Transform({
  position: new Vector3(22.871719360351562, 6.801177024841309, 13.461128234863281),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(11.249998092651367, 1.7587621212005615, 0.9999999403953552)
})
rainLight.addComponentOrReplace(transform329)

const rainLight2 = new Entity('rainLight2')
engine.addEntity(rainLight2)
rainLight2.setParent(_scene)
const transform330 = new Transform({
  position: new Vector3(22.871719360351562, 6.801177024841309, 0.6229386329650879),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(11.249998092651367, 1.7587621212005615, 0.9999999403953552)
})
rainLight2.addComponentOrReplace(transform330)

const rainLight3 = new Entity('rainLight3')
engine.addEntity(rainLight3)
rainLight3.setParent(_scene)
const transform331 = new Transform({
  position: new Vector3(15.371719360351562, 15.894546508789062, 2.4267373085021973),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(16.874996185302734, 1.7587621212005615, 0.9999999403953552)
})
rainLight3.addComponentOrReplace(transform331)

const rainLight4 = new Entity('rainLight4')
engine.addEntity(rainLight4)
rainLight4.setParent(_scene)
const transform332 = new Transform({
  position: new Vector3(15.371719360351562, 15.894546508789062, 13.76492691040039),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(16.874996185302734, 1.7587621212005615, 0.9999999403953552)
})
rainLight4.addComponentOrReplace(transform332)

const rainLight5 = new Entity('rainLight5')
engine.addEntity(rainLight5)
rainLight5.setParent(_scene)
const transform333 = new Transform({
  position: new Vector3(8.051142692565918, 6.801177024841309, 13.461129188537598),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(11.249998092651367, 1.7587621212005615, 0.9999999403953552)
})
rainLight5.addComponentOrReplace(transform333)

const rainLight6 = new Entity('rainLight6')
engine.addEntity(rainLight6)
rainLight6.setParent(_scene)
const transform334 = new Transform({
  position: new Vector3(8.051142692565918, 6.801177024841309, 0.6229395866394043),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(11.249998092651367, 1.7587621212005615, 0.9999999403953552)
})
rainLight6.addComponentOrReplace(transform334)

const rainLight7 = new Entity('rainLight7')
engine.addEntity(rainLight7)
rainLight7.setParent(_scene)
const transform335 = new Transform({
  position: new Vector3(15.617622375488281, 24.887802124023438, 3.914134979248047),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(10.597440719604492, 1.7587621212005615, 0.9999999403953552)
})
rainLight7.addComponentOrReplace(transform335)

const rainLight8 = new Entity('rainLight8')
engine.addEntity(rainLight8)
rainLight8.setParent(_scene)
const transform336 = new Transform({
  position: new Vector3(15.617622375488281, 24.887802124023438, 12.315888404846191),
  rotation: new Quaternion(-1, -6.704277212462575e-15, 1.1920928244535389e-7, 1.3861998054886453e-15),
  scale: new Vector3(10.597440719604492, 1.7587621212005615, 0.9999999403953552)
})
rainLight8.addComponentOrReplace(transform336)

const ropeLight17 = new Entity('ropeLight17')
engine.addEntity(ropeLight17)
ropeLight17.setParent(_scene)
const transform337 = new Transform({
  position: new Vector3(15.675220489501953, 27.066987991333008, 8.044642448425293),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.0594656467437744, 1, 284.77752685546875)
})
ropeLight17.addComponentOrReplace(transform337)

const ropeLight18 = new Entity('ropeLight18')
engine.addEntity(ropeLight18)
ropeLight18.setParent(_scene)
const transform338 = new Transform({
  position: new Vector3(6.185117244720459, 27.066877365112305, 14.358261108398438),
  rotation: new Quaternion(0, 0, -0.0005304887890815735, 0.9999998807907104),
  scale: new Vector3(0.4264879524707794, 0.9877021908760071, 87.87434387207031)
})
ropeLight18.addComponentOrReplace(transform338)

const ropeLight19 = new Entity('ropeLight19')
engine.addEntity(ropeLight19)
ropeLight19.setParent(_scene)
const transform339 = new Transform({
  position: new Vector3(17.083271026611328, 17.995758056640625, 8.743292808532715),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.563060998916626, 1, 419.71673583984375)
})
ropeLight19.addComponentOrReplace(transform339)

const ropeLight20 = new Entity('ropeLight20')
engine.addEntity(ropeLight20)
ropeLight20.setParent(_scene)
const transform340 = new Transform({
  position: new Vector3(29.809162139892578, 17.98778533935547, 7.992190361022949),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3738308250904083, 1.4215643405914307, 468.6632080078125)
})
ropeLight20.addComponentOrReplace(transform340)

const ropeLight21 = new Entity('ropeLight21')
engine.addEntity(ropeLight21)
ropeLight21.setParent(_scene)
const transform341 = new Transform({
  position: new Vector3(17.083271026611328, 8.989616394042969, 7.240825653076172),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.563060998916626, 1, 425.9986267089844)
})
ropeLight21.addComponentOrReplace(transform341)

const ropeLight22 = new Entity('ropeLight22')
engine.addEntity(ropeLight22)
ropeLight22.setParent(_scene)
const transform342 = new Transform({
  position: new Vector3(2.40976881980896, 8.990385055541992, 7.989134311676025),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.4133225977420807, 1, 469.9483337402344)
})
ropeLight22.addComponentOrReplace(transform342)

const rainbowAnodizedMetalWall7 = new Entity('rainbowAnodizedMetalWall7')
engine.addEntity(rainbowAnodizedMetalWall7)
rainbowAnodizedMetalWall7.setParent(_scene)
rainbowAnodizedMetalWall7.addComponentOrReplace(gltfShape6)
const transform343 = new Transform({
  position: new Vector3(0.7474591732025146, 8.268448829650879, 6.934941291809082),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 8.940696716308594e-8),
  scale: new Vector3(50.326072692871094, 4.938322067260742, 48.646636962890625)
})
rainbowAnodizedMetalWall7.addComponentOrReplace(transform343)

const rainbowAnodizedMetalWall8 = new Entity('rainbowAnodizedMetalWall8')
engine.addEntity(rainbowAnodizedMetalWall8)
rainbowAnodizedMetalWall8.setParent(_scene)
rainbowAnodizedMetalWall8.addComponentOrReplace(gltfShape6)
const transform344 = new Transform({
  position: new Vector3(27.55619239807129, 17.373811721801758, 8.100362777709961),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 8.940696716308594e-8),
  scale: new Vector3(40.221065521240234, 4.221688270568848, 48.646636962890625)
})
rainbowAnodizedMetalWall8.addComponentOrReplace(transform344)

const rainbowAnodizedMetalWall9 = new Entity('rainbowAnodizedMetalWall9')
engine.addEntity(rainbowAnodizedMetalWall9)
rainbowAnodizedMetalWall9.setParent(_scene)
rainbowAnodizedMetalWall9.addComponentOrReplace(gltfShape6)
const transform345 = new Transform({
  position: new Vector3(9.12043285369873, 26.57402229309082, 7.962472438812256),
  rotation: new Quaternion(-0.70710688829422, 0, -0.7071067094802856, 8.940696716308594e-8),
  scale: new Vector3(33.1152229309082, 4.938325881958008, 48.646636962890625)
})
rainbowAnodizedMetalWall9.addComponentOrReplace(transform345)

const radio3 = new Entity('radio3')
engine.addEntity(radio3)
radio3.setParent(_scene)
const transform346 = new Transform({
  position: new Vector3(9.197999000549316, 25.943904876708984, 7.969380855560303),
  rotation: new Quaternion(4.398226784249631e-16, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.0330047607421875, 1, 0.1168738529086113)
})
radio3.addComponentOrReplace(transform346)

const invisibleWall69 = new Entity('invisibleWall69')
engine.addEntity(invisibleWall69)
invisibleWall69.setParent(_scene)
const transform347 = new Transform({
  position: new Vector3(8.619922637939453, 18.66652488708496, 8.013265609741211),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(8.274392127990723, 0.025087567046284676, 0.6072933077812195)
})
invisibleWall69.addComponentOrReplace(transform347)

const invisibleWall70 = new Entity('invisibleWall70')
engine.addEntity(invisibleWall70)
invisibleWall70.setParent(_scene)
const transform348 = new Transform({
  position: new Vector3(28.007062911987305, 9.575178146362305, 8.013265609741211),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(10.791694641113281, 0.025087567046284676, 0.5150012969970703)
})
invisibleWall70.addComponentOrReplace(transform348)

const invisibleWall71 = new Entity('invisibleWall71')
engine.addEntity(invisibleWall71)
invisibleWall71.setParent(_scene)
const transform349 = new Transform({
  position: new Vector3(0.2718699872493744, 0.6551432609558105, 6.8583879470825195),
  rotation: new Quaternion(8.429369557916289e-8, 0.7071068286895752, -1.4389833324912615e-7, -0.7071068286895752),
  scale: new Vector3(12.587105751037598, 0.025087567046284676, 0.5150023698806763)
})
invisibleWall71.addComponentOrReplace(transform349)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script1.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script1.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script1.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script1.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script1.spawn(invisibleWall5, {"enabled":true}, createChannel(channelId, invisibleWall5, channelBus))
script1.spawn(invisibleWall6, {"enabled":true}, createChannel(channelId, invisibleWall6, channelBus))
script1.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script1.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script1.spawn(invisibleWall9, {"enabled":true}, createChannel(channelId, invisibleWall9, channelBus))
script1.spawn(invisibleWall10, {"enabled":true}, createChannel(channelId, invisibleWall10, channelBus))
script1.spawn(invisibleWall12, {"enabled":true}, createChannel(channelId, invisibleWall12, channelBus))
script1.spawn(invisibleWall14, {"enabled":true}, createChannel(channelId, invisibleWall14, channelBus))
script1.spawn(invisibleWall15, {"enabled":true}, createChannel(channelId, invisibleWall15, channelBus))
script1.spawn(invisibleWall16, {"enabled":true}, createChannel(channelId, invisibleWall16, channelBus))
script1.spawn(invisibleWall17, {"enabled":true}, createChannel(channelId, invisibleWall17, channelBus))
script1.spawn(invisibleWall18, {"enabled":true}, createChannel(channelId, invisibleWall18, channelBus))
script1.spawn(invisibleWall19, {"enabled":true}, createChannel(channelId, invisibleWall19, channelBus))
script1.spawn(invisibleWall20, {"enabled":true}, createChannel(channelId, invisibleWall20, channelBus))
script1.spawn(invisibleWall21, {"enabled":true}, createChannel(channelId, invisibleWall21, channelBus))
script1.spawn(invisibleWall22, {"enabled":true}, createChannel(channelId, invisibleWall22, channelBus))
script1.spawn(invisibleWall23, {"enabled":true}, createChannel(channelId, invisibleWall23, channelBus))
script1.spawn(invisibleWall24, {"enabled":true}, createChannel(channelId, invisibleWall24, channelBus))
script1.spawn(invisibleWall25, {"enabled":true}, createChannel(channelId, invisibleWall25, channelBus))
script1.spawn(invisibleWall26, {"enabled":true}, createChannel(channelId, invisibleWall26, channelBus))
script1.spawn(invisibleWall27, {"enabled":true}, createChannel(channelId, invisibleWall27, channelBus))
script1.spawn(invisibleWall28, {"enabled":true}, createChannel(channelId, invisibleWall28, channelBus))
script1.spawn(invisibleWall29, {"enabled":true}, createChannel(channelId, invisibleWall29, channelBus))
script1.spawn(invisibleWall30, {"enabled":true}, createChannel(channelId, invisibleWall30, channelBus))
script1.spawn(invisibleWall31, {"enabled":true}, createChannel(channelId, invisibleWall31, channelBus))
script1.spawn(invisibleWall32, {"enabled":true}, createChannel(channelId, invisibleWall32, channelBus))
script1.spawn(invisibleWall33, {"enabled":true}, createChannel(channelId, invisibleWall33, channelBus))
script1.spawn(invisibleWall34, {"enabled":true}, createChannel(channelId, invisibleWall34, channelBus))
script1.spawn(invisibleWall35, {"enabled":true}, createChannel(channelId, invisibleWall35, channelBus))
script2.spawn(nftPictureFrame, {"id":"2554","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 14.9898 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script1.spawn(invisibleWall36, {"enabled":true}, createChannel(channelId, invisibleWall36, channelBus))
script1.spawn(invisibleWall37, {"enabled":true}, createChannel(channelId, invisibleWall37, channelBus))
script1.spawn(invisibleWall38, {"enabled":true}, createChannel(channelId, invisibleWall38, channelBus))
script1.spawn(invisibleWall39, {"enabled":true}, createChannel(channelId, invisibleWall39, channelBus))
script1.spawn(invisibleWall40, {"enabled":true}, createChannel(channelId, invisibleWall40, channelBus))
script1.spawn(invisibleWall41, {"enabled":true}, createChannel(channelId, invisibleWall41, channelBus))
script1.spawn(invisibleWall42, {"enabled":true}, createChannel(channelId, invisibleWall42, channelBus))
script1.spawn(invisibleWall43, {"enabled":true}, createChannel(channelId, invisibleWall43, channelBus))
script1.spawn(invisibleWall44, {"enabled":true}, createChannel(channelId, invisibleWall44, channelBus))
script1.spawn(invisibleWall45, {"enabled":true}, createChannel(channelId, invisibleWall45, channelBus))
script1.spawn(invisibleWall46, {"enabled":true}, createChannel(channelId, invisibleWall46, channelBus))
script1.spawn(invisibleWall47, {"enabled":true}, createChannel(channelId, invisibleWall47, channelBus))
script1.spawn(invisibleWall48, {"enabled":true}, createChannel(channelId, invisibleWall48, channelBus))
script1.spawn(invisibleWall49, {"enabled":true}, createChannel(channelId, invisibleWall49, channelBus))
script1.spawn(invisibleWall50, {"enabled":true}, createChannel(channelId, invisibleWall50, channelBus))
script1.spawn(invisibleWall51, {"enabled":true}, createChannel(channelId, invisibleWall51, channelBus))
script1.spawn(invisibleWall52, {"enabled":true}, createChannel(channelId, invisibleWall52, channelBus))
script1.spawn(invisibleWall53, {"enabled":true}, createChannel(channelId, invisibleWall53, channelBus))
script1.spawn(invisibleWall54, {"enabled":true}, createChannel(channelId, invisibleWall54, channelBus))
script1.spawn(invisibleWall55, {"enabled":true}, createChannel(channelId, invisibleWall55, channelBus))
script1.spawn(invisibleWall56, {"enabled":true}, createChannel(channelId, invisibleWall56, channelBus))
script1.spawn(invisibleWall57, {"enabled":true}, createChannel(channelId, invisibleWall57, channelBus))
script1.spawn(invisibleWall58, {"enabled":true}, createChannel(channelId, invisibleWall58, channelBus))
script1.spawn(invisibleWall59, {"enabled":true}, createChannel(channelId, invisibleWall59, channelBus))
script1.spawn(invisibleWall60, {"enabled":true}, createChannel(channelId, invisibleWall60, channelBus))
script1.spawn(invisibleWall61, {"enabled":true}, createChannel(channelId, invisibleWall61, channelBus))
script1.spawn(invisibleWall62, {"enabled":true}, createChannel(channelId, invisibleWall62, channelBus))
script1.spawn(invisibleWall63, {"enabled":true}, createChannel(channelId, invisibleWall63, channelBus))
script1.spawn(invisibleWall64, {"enabled":true}, createChannel(channelId, invisibleWall64, channelBus))
script1.spawn(invisibleWall11, {"enabled":true}, createChannel(channelId, invisibleWall11, channelBus))
script3.spawn(radio, {"startOn":true,"volume":0.38,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmS7rEUHBoTKB2GuCYhBhPc9utv6uZaNjBB4ptouYvuLiW"}, createChannel(channelId, radio, channelBus))
script3.spawn(radio2, {"startOn":false,"volume":1,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio2","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/Qmbvps2kDnrUcAMc7hJq9kJoAfFNEixbFEQkyGQKJdPT6n"}, createChannel(channelId, radio2, channelBus))
script1.spawn(invisibleWall13, {"enabled":true}, createChannel(channelId, invisibleWall13, channelBus))
script1.spawn(invisibleWall65, {"enabled":true}, createChannel(channelId, invisibleWall65, channelBus))
script4.spawn(ceilingLight, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight, channelBus))
script4.spawn(ceilingLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight2, channelBus))
script4.spawn(ceilingLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight3, channelBus))
script4.spawn(ceilingLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight4, channelBus))
script4.spawn(ceilingLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight5, channelBus))
script4.spawn(ceilingLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight6, channelBus))
script4.spawn(ceilingLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight7, channelBus))
script4.spawn(ceilingLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight8, channelBus))
script4.spawn(ceilingLight9, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight9, channelBus))
script4.spawn(ceilingLight10, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight10, channelBus))
script4.spawn(ceilingLight11, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight11, channelBus))
script4.spawn(ceilingLight12, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight12, channelBus))
script4.spawn(ceilingLight13, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight13, channelBus))
script4.spawn(ceilingLight14, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight14, channelBus))
script4.spawn(ceilingLight15, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight15, channelBus))
script4.spawn(ceilingLight16, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight16, channelBus))
script4.spawn(ceilingLight17, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight17, channelBus))
script4.spawn(ceilingLight18, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight18, channelBus))
script4.spawn(ceilingLight19, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight19, channelBus))
script4.spawn(ceilingLight20, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight20, channelBus))
script4.spawn(ceilingLight21, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight21, channelBus))
script4.spawn(ceilingLight22, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight22, channelBus))
script4.spawn(ceilingLight23, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight23, channelBus))
script4.spawn(ceilingLight24, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight24, channelBus))
script2.spawn(nftPictureFrame2, {"id":"3131","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 17.444 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script2.spawn(nftPictureFrame3, {"id":"960","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 16.9898 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script2.spawn(nftPictureFrame4, {"id":"1025","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 15.24\n"}, createChannel(channelId, nftPictureFrame4, channelBus))
script2.spawn(nftPictureFrame5, {"id":"1150","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 16.888\n"}, createChannel(channelId, nftPictureFrame5, channelBus))
script2.spawn(nftPictureFrame6, {"id":"3884","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame6, channelBus))
script2.spawn(nftPictureFrame7, {"id":"4368","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 2.6 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script2.spawn(nftPictureFrame8, {"id":"1150","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 15.9898 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script2.spawn(nftPictureFrame9, {"id":"2103","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 16.2424 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script2.spawn(nftPictureFrame10, {"id":"1758","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: 14.777 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script2.spawn(nftPictureFrame11, {"id":"398","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame11, channelBus))
script2.spawn(nftPictureFrame12, {"id":"432","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame12, channelBus))
script2.spawn(nftPictureFrame13, {"id":"222","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame13, channelBus))
script2.spawn(nftPictureFrame14, {"id":"2866","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: .TBD"}, createChannel(channelId, nftPictureFrame14, channelBus))
script2.spawn(nftPictureFrame15, {"id":"217","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame15, channelBus))
script2.spawn(nftPictureFrame16, {"id":"420","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame16, channelBus))
script2.spawn(nftPictureFrame17, {"id":"332","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame17, channelBus))
script2.spawn(nftPictureFrame18, {"id":"2456","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame18, channelBus))
script2.spawn(nftPictureFrame19, {"id":"117","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame19, channelBus))
script2.spawn(nftPictureFrame20, {"id":"3139","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame20, channelBus))
script2.spawn(nftPictureFrame21, {"id":"368","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Price: TBD"}, createChannel(channelId, nftPictureFrame21, channelBus))
script2.spawn(nftPictureFrame22, {"id":"2210","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame22, channelBus))
script2.spawn(nftPictureFrame23, {"id":"953","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame23, channelBus))
script2.spawn(nftPictureFrame24, {"id":"1907","contract":"0x358f8aC9A5f8891CB98F61cE5f6466Ffc8E28c68","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame24, channelBus))
script1.spawn(invisibleWall66, {"enabled":true}, createChannel(channelId, invisibleWall66, channelBus))
script1.spawn(invisibleWall67, {"enabled":true}, createChannel(channelId, invisibleWall67, channelBus))
script1.spawn(invisibleWall68, {"enabled":true}, createChannel(channelId, invisibleWall68, channelBus))
script5.spawn(floorLampPaperLight, {"startOn":true,"clickable":true}, createChannel(channelId, floorLampPaperLight, channelBus))
script5.spawn(floorLampPaperLight2, {"startOn":true,"clickable":true}, createChannel(channelId, floorLampPaperLight2, channelBus))
script5.spawn(floorLampPaperLight3, {"startOn":true,"clickable":true}, createChannel(channelId, floorLampPaperLight3, channelBus))
script5.spawn(floorLampPaperLight4, {"startOn":true,"clickable":true}, createChannel(channelId, floorLampPaperLight4, channelBus))
script6.spawn(ropeLight, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight, channelBus))
script6.spawn(ropeLight2, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight2, channelBus))
script6.spawn(ropeLight3, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight3, channelBus))
script6.spawn(ropeLight4, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight4, channelBus))
script6.spawn(ropeLight5, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight5, channelBus))
script6.spawn(ropeLight6, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight6, channelBus))
script6.spawn(ropeLight7, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight7, channelBus))
script6.spawn(ropeLight8, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight8, channelBus))
script6.spawn(ropeLight9, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight9, channelBus))
script6.spawn(ropeLight10, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight10, channelBus))
script6.spawn(ropeLight11, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight11, channelBus))
script6.spawn(ropeLight12, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight12, channelBus))
script6.spawn(ropeLight13, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight13, channelBus))
script6.spawn(ropeLight14, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight14, channelBus))
script6.spawn(ropeLight15, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight15, channelBus))
script6.spawn(ropeLight16, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight16, channelBus))
script7.spawn(rainLight, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight, channelBus))
script7.spawn(rainLight2, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight2, channelBus))
script7.spawn(rainLight3, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight3, channelBus))
script7.spawn(rainLight4, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight4, channelBus))
script7.spawn(rainLight5, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight5, channelBus))
script7.spawn(rainLight6, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight6, channelBus))
script7.spawn(rainLight7, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight7, channelBus))
script7.spawn(rainLight8, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight8, channelBus))
script6.spawn(ropeLight17, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight17, channelBus))
script6.spawn(ropeLight18, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight18, channelBus))
script6.spawn(ropeLight19, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight19, channelBus))
script6.spawn(ropeLight20, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight20, channelBus))
script6.spawn(ropeLight21, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight21, channelBus))
script6.spawn(ropeLight22, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight22, channelBus))
script3.spawn(radio3, {"startOn":false,"volume":0.38,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio3","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmdPHXfY297yX8XZumPbxT1P6HxAUsZADn7jRdVhXN7gbD"}, createChannel(channelId, radio3, channelBus))
script1.spawn(invisibleWall69, {"enabled":true}, createChannel(channelId, invisibleWall69, channelBus))
script1.spawn(invisibleWall70, {"enabled":true}, createChannel(channelId, invisibleWall70, channelBus))
script1.spawn(invisibleWall71, {"enabled":true}, createChannel(channelId, invisibleWall71, channelBus))