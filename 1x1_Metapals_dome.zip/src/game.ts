import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script2 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script3 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script4 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script5 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script6 from "../cc309926-283a-4e0f-b0a4-97659437f3bc/src/item"
import Script7 from "../9ca76658-8c9c-43fe-ab17-e4ec05b6ae35/src/item"
import Script8 from "../03829f2d-a9ab-4292-aa97-6f51a02b3ba9/src/item"
import Script9 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script10 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("bfc932843fa883cacaa9d8ffd5fc94069b36c6facc8756ee4768097f7545c2c4/CityTile.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const bevelledVerticesRainbowAno = new Entity('bevelledVerticesRainbowAno')
engine.addEntity(bevelledVerticesRainbowAno)
bevelledVerticesRainbowAno.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(7.5, 5, 7.706107139587402),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.034512519836426, 15.034512519836426, 15.034512519836426)
})
bevelledVerticesRainbowAno.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("bf41185085f70103258ce2257e19098811940a70a44083242b96c32f361c909b/Bevelled_Vertices_-Rainbow_Anodized.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
bevelledVerticesRainbowAno.addComponentOrReplace(gltfShape2)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(7.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
verticalBlackPad.addComponentOrReplace(transform4)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(13, 0, 6.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform5)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(7.5, 0, 7.999999523162842),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 12.044098854064941, 1)
})
triggerArea.addComponentOrReplace(transform6)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(8, 12.423827171325684, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.768038749694824, 0.05898373946547508, 15.17155933380127)
})
invisibleWall.addComponentOrReplace(transform7)

const ringPurpleLight = new Entity('ringPurpleLight')
engine.addEntity(ringPurpleLight)
ringPurpleLight.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(7.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight.addComponentOrReplace(transform8)
const gltfShape3 = new GLTFShape("bfeef52c5e7dc28e46b49de7535ddbb0112817437e0bcf02b3f3d52aa5e44463/Ring_Purple_Light.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
ringPurpleLight.addComponentOrReplace(gltfShape3)

const ringPurpleLight3 = new Entity('ringPurpleLight3')
engine.addEntity(ringPurpleLight3)
ringPurpleLight3.setParent(_scene)
ringPurpleLight3.addComponentOrReplace(gltfShape3)
const transform9 = new Transform({
  position: new Vector3(7.5, 3.147944927215576, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 22.657390594482422, 1)
})
ringPurpleLight3.addComponentOrReplace(transform9)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(2, 13.423827171325684, 7.5),
  rotation: new Quaternion(0, 0, -0.7730104923248291, 0.6343933343887329),
  scale: new Vector3(0.22545789182186127, 0.05898391827940941, 7.5857768058776855)
})
invisibleWall2.addComponentOrReplace(transform10)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(13, 13.423827171325684, 7.5),
  rotation: new Quaternion(0, 0, -0.7730104923248291, 0.6343933343887329),
  scale: new Vector3(0.22545789182186127, 0.05898395553231239, 7.5857768058776855)
})
invisibleWall3.addComponentOrReplace(transform11)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(7.499999523162842, 13.423826217651367, 1.9999995231628418),
  rotation: new Quaternion(-0.5466009378433228, 0.44858381152153015, -0.5466009974479675, 0.4485837519168854),
  scale: new Vector3(0.22545789182186127, 0.05898398160934448, 7.585779666900635)
})
invisibleWall4.addComponentOrReplace(transform12)

const invisibleWall5 = new Entity('invisibleWall5')
engine.addEntity(invisibleWall5)
invisibleWall5.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(7.500000476837158, 13.423828125, 13),
  rotation: new Quaternion(-0.5466009378433228, 0.44858381152153015, -0.5466009974479675, 0.4485837519168854),
  scale: new Vector3(0.22545789182186127, 0.0589839443564415, 7.585779666900635)
})
invisibleWall5.addComponentOrReplace(transform13)

const invisibleWall6 = new Entity('invisibleWall6')
engine.addEntity(invisibleWall6)
invisibleWall6.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(11.389087677001953, 13.423827171325684, 3.6109120845794678),
  rotation: new Quaternion(-0.2958183288574219, 0.24277180433273315, -0.7141686081886292, 0.5861029624938965),
  scale: new Vector3(0.22545796632766724, 0.05898395925760269, 7.585771560668945)
})
invisibleWall6.addComponentOrReplace(transform14)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(3.6109132766723633, 13.423827171325684, 11.389087677001953),
  rotation: new Quaternion(-0.2958183288574219, 0.24277180433273315, -0.7141686081886292, 0.5861029624938965),
  scale: new Vector3(0.22545792162418365, 0.0589839331805706, 7.585776329040527)
})
invisibleWall7.addComponentOrReplace(transform15)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(3.610912322998047, 13.423826217651367, 3.610912799835205),
  rotation: new Quaternion(-0.7141685485839844, 0.5861030220985413, -0.29581838846206665, 0.242771714925766),
  scale: new Vector3(0.2254580706357956, 0.05898398533463478, 7.585784912109375)
})
invisibleWall8.addComponentOrReplace(transform16)

const invisibleWall9 = new Entity('invisibleWall9')
engine.addEntity(invisibleWall9)
invisibleWall9.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(11.389087677001953, 13.423828125, 11.389086723327637),
  rotation: new Quaternion(-0.7141685485839844, 0.5861030220985413, -0.29581838846206665, 0.242771714925766),
  scale: new Vector3(0.22545795142650604, 0.058983951807022095, 7.585784912109375)
})
invisibleWall9.addComponentOrReplace(transform17)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(7.491686820983887, 13.649917602539062, 1.692634105682373),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.574552297592163, 1.574552297592163, 0.18753956258296967)
})
nftPictureFrame.addComponentOrReplace(transform18)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(7.491686820983887, 13.649917602539062, 13.72079849243164),
  rotation: new Quaternion(-5.7086314875795605e-15, 1, -1.1920928244535389e-7, -1.4901161193847656e-8),
  scale: new Vector3(1.574552297592163, 1.574552297592163, 0.18753956258296967)
})
nftPictureFrame2.addComponentOrReplace(transform19)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(13.505767822265625, 13.649917602539062, 7.706716060638428),
  rotation: new Quaternion(-6.431707092233825e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.5745519399642944, 1.574552297592163, 0.18753953278064728)
})
nftPictureFrame3.addComponentOrReplace(transform20)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(1.477604866027832, 13.649917602539062, 7.706716537475586),
  rotation: new Quaternion(-1.9728792828333256e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.5745519399642944, 1.574552297592163, 0.18753953278064728)
})
nftPictureFrame4.addComponentOrReplace(transform21)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(11.744284629821777, 13.649916648864746, 3.454117774963379),
  rotation: new Quaternion(-5.78511348051894e-15, 0.3826834261417389, -4.5619415800501883e-8, -0.9238796234130859),
  scale: new Vector3(1.57455313205719, 1.574552297592163, 0.18753963708877563)
})
nftPictureFrame5.addComponentOrReplace(transform22)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(3.239089012145996, 13.649918556213379, 11.959315299987793),
  rotation: new Quaternion(-1.9797120858605893e-15, 0.9238796234130859, -1.1013501932666259e-7, 0.3826834261417389),
  scale: new Vector3(1.5745561122894287, 1.574552297592163, 0.1875399947166443)
})
nftPictureFrame6.addComponentOrReplace(transform23)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(11.744284629821777, 13.649917602539062, 11.95931339263916),
  rotation: new Quaternion(-5.27408791552858e-15, 0.9238795638084412, -1.1013501932666259e-7, -0.3826834559440613),
  scale: new Vector3(1.5745563507080078, 1.574552297592163, 0.1875399649143219)
})
nftPictureFrame7.addComponentOrReplace(transform24)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(3.239088535308838, 13.649917602539062, 3.454117774963379),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(1.5745518207550049, 1.574552297592163, 0.18753954768180847)
})
nftPictureFrame8.addComponentOrReplace(transform25)

const rainbowAnodizedMetalWall = new Entity('rainbowAnodizedMetalWall')
engine.addEntity(rainbowAnodizedMetalWall)
rainbowAnodizedMetalWall.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(7.5, 15, 13),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 3, 78.7500228881836)
})
rainbowAnodizedMetalWall.addComponentOrReplace(transform26)
const gltfShape4 = new GLTFShape("e656adead45a54e5b315094ae9f39732575c8564a978338ab67a55b558fe41f6/Rainbow_Anodized Metal Wall.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
rainbowAnodizedMetalWall.addComponentOrReplace(gltfShape4)

const rainbowAnodizedMetalWall2 = new Entity('rainbowAnodizedMetalWall2')
engine.addEntity(rainbowAnodizedMetalWall2)
rainbowAnodizedMetalWall2.setParent(_scene)
rainbowAnodizedMetalWall2.addComponentOrReplace(gltfShape4)
const transform27 = new Transform({
  position: new Vector3(7.5, 15, 2.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 3, 78.7500228881836)
})
rainbowAnodizedMetalWall2.addComponentOrReplace(transform27)

const rainbowAnodizedMetalWall3 = new Entity('rainbowAnodizedMetalWall3')
engine.addEntity(rainbowAnodizedMetalWall3)
rainbowAnodizedMetalWall3.setParent(_scene)
rainbowAnodizedMetalWall3.addComponentOrReplace(gltfShape4)
const transform28 = new Transform({
  position: new Vector3(2.249999523162842, 15.000000953674316, 7.750000476837158),
  rotation: new Quaternion(-4.504429098665355e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(22.500003814697266, 3, 78.75003814697266)
})
rainbowAnodizedMetalWall3.addComponentOrReplace(transform28)

const rainbowAnodizedMetalWall4 = new Entity('rainbowAnodizedMetalWall4')
engine.addEntity(rainbowAnodizedMetalWall4)
rainbowAnodizedMetalWall4.setParent(_scene)
rainbowAnodizedMetalWall4.addComponentOrReplace(gltfShape4)
const transform29 = new Transform({
  position: new Vector3(12.75, 14.999999046325684, 7.749999523162842),
  rotation: new Quaternion(-4.504429098665355e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(22.500003814697266, 3, 78.75003814697266)
})
rainbowAnodizedMetalWall4.addComponentOrReplace(transform29)

const rainbowAnodizedMetalWall5 = new Entity('rainbowAnodizedMetalWall5')
engine.addEntity(rainbowAnodizedMetalWall5)
rainbowAnodizedMetalWall5.setParent(_scene)
rainbowAnodizedMetalWall5.addComponentOrReplace(gltfShape4)
const transform30 = new Transform({
  position: new Vector3(3.787688970565796, 15.000000953674316, 11.462310791015625),
  rotation: new Quaternion(3.812615150753642e-15, 0.9238795042037964, -1.1013499090495316e-7, 0.3826834559440613),
  scale: new Vector3(22.500015258789062, 3, 78.75007629394531)
})
rainbowAnodizedMetalWall5.addComponentOrReplace(transform30)

const rainbowAnodizedMetalWall6 = new Entity('rainbowAnodizedMetalWall6')
engine.addEntity(rainbowAnodizedMetalWall6)
rainbowAnodizedMetalWall6.setParent(_scene)
rainbowAnodizedMetalWall6.addComponentOrReplace(gltfShape4)
const transform31 = new Transform({
  position: new Vector3(11.212310791015625, 14.999999046325684, 4.037689208984375),
  rotation: new Quaternion(3.812615150753642e-15, 0.9238795042037964, -1.1013499090495316e-7, 0.3826834559440613),
  scale: new Vector3(22.500015258789062, 3, 78.75007629394531)
})
rainbowAnodizedMetalWall6.addComponentOrReplace(transform31)

const rainbowAnodizedMetalWall7 = new Entity('rainbowAnodizedMetalWall7')
engine.addEntity(rainbowAnodizedMetalWall7)
rainbowAnodizedMetalWall7.setParent(_scene)
rainbowAnodizedMetalWall7.addComponentOrReplace(gltfShape4)
const transform32 = new Transform({
  position: new Vector3(3.787689208984375, 15, 4.037688732147217),
  rotation: new Quaternion(2.2097539788269016e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(22.5, 3, 78.7500228881836)
})
rainbowAnodizedMetalWall7.addComponentOrReplace(transform32)

const rainbowAnodizedMetalWall8 = new Entity('rainbowAnodizedMetalWall8')
engine.addEntity(rainbowAnodizedMetalWall8)
rainbowAnodizedMetalWall8.setParent(_scene)
rainbowAnodizedMetalWall8.addComponentOrReplace(gltfShape4)
const transform33 = new Transform({
  position: new Vector3(11.212310791015625, 15, 11.462310791015625),
  rotation: new Quaternion(2.2097539788269016e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(22.5, 3, 78.7500228881836)
})
rainbowAnodizedMetalWall8.addComponentOrReplace(transform33)

const tripleSpotlight = new Entity('tripleSpotlight')
engine.addEntity(tripleSpotlight)
tripleSpotlight.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(7.696191310882568, 11.315436363220215, 2.4795942306518555),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4, 1, 0.6406177282333374)
})
tripleSpotlight.addComponentOrReplace(transform34)

const tripleSpotlight2 = new Entity('tripleSpotlight2')
engine.addEntity(tripleSpotlight2)
tripleSpotlight2.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(7.3958024978637695, 11.315436363220215, 12.979594230651855),
  rotation: new Quaternion(-4.9053253456778426e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(4.000005722045898, 1, 0.6406186819076538)
})
tripleSpotlight2.addComponentOrReplace(transform35)

const tripleSpotlight3 = new Entity('tripleSpotlight3')
engine.addEntity(tripleSpotlight3)
tripleSpotlight3.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(2.2744460105895996, 11.315437316894531, 7.579400062561035),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.000001907348633, 1, 0.6406177878379822)
})
tripleSpotlight3.addComponentOrReplace(transform36)

const tripleSpotlight4 = new Entity('tripleSpotlight4')
engine.addEntity(tripleSpotlight4)
tripleSpotlight4.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(12.795997619628906, 11.315435409545898, 7.879787921905518),
  rotation: new Quaternion(-3.4685891193362824e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.000006675720215, 1, 0.6406188011169434)
})
tripleSpotlight4.addComponentOrReplace(transform37)

const tripleSpotlight5 = new Entity('tripleSpotlight5')
engine.addEntity(tripleSpotlight5)
tripleSpotlight5.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(3.7059364318847656, 11.315437316894531, 11.351016998291016),
  rotation: new Quaternion(-1.5762229651174382e-15, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(4.000003814697266, 1, 0.6406183838844299)
})
tripleSpotlight5.addComponentOrReplace(transform38)

const tripleSpotlight6 = new Entity('tripleSpotlight6')
engine.addEntity(tripleSpotlight6)
tripleSpotlight6.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(11.364511489868164, 11.315435409545898, 4.123486042022705),
  rotation: new Quaternion(-3.0505698895368126e-15, 0.38268348574638367, -4.561942290592924e-8, -0.9238796234130859),
  scale: new Vector3(4.000007629394531, 1, 0.6406189203262329)
})
tripleSpotlight6.addComponentOrReplace(transform39)

const tripleSpotlight7 = new Entity('tripleSpotlight7')
engine.addEntity(tripleSpotlight7)
tripleSpotlight7.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(11.152104377746582, 11.315436363220215, 11.548108100891113),
  rotation: new Quaternion(-9.792162503215966e-16, 0.9238795638084412, -1.1013501222123523e-7, -0.3826834559440613),
  scale: new Vector3(4.000006198883057, 1, 0.6406188011169434)
})
tripleSpotlight7.addComponentOrReplace(transform40)

const tripleSpotlight8 = new Entity('tripleSpotlight8')
engine.addEntity(tripleSpotlight8)
tripleSpotlight8.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(3.939889669418335, 11.315436363220215, 3.9110803604125977),
  rotation: new Quaternion(-2.1777291189290946e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(4, 1, 0.6406177282333374)
})
tripleSpotlight8.addComponentOrReplace(transform41)

const spotlightLight = new Entity('spotlightLight')
engine.addEntity(spotlightLight)
spotlightLight.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(13.5, 5, 2.499999761581421),
  rotation: new Quaternion(-0.961939811706543, -0.19134174287319183, -0.03806013613939285, 0.19134166836738586),
  scale: new Vector3(2.7616515159606934, 1.227401852607727, 2.761653184890747)
})
spotlightLight.addComponentOrReplace(transform42)

const spotlightLight2 = new Entity('spotlightLight2')
engine.addEntity(spotlightLight2)
spotlightLight2.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(2.5, 5, 13.5),
  rotation: new Quaternion(-0.038060158491134644, 0.19134178757667542, 0.961939811706543, 0.19134174287319183),
  scale: new Vector3(2.761657238006592, 1.2274041175842285, 2.7616546154022217)
})
spotlightLight2.addComponentOrReplace(transform43)

const spotlightLight3 = new Entity('spotlightLight3')
engine.addEntity(spotlightLight3)
spotlightLight3.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(13.500000953674316, 5, 13.5),
  rotation: new Quaternion(0.6532816290855408, 0.2705981433391571, 0.7071067690849304, 4.470348358154297e-8),
  scale: new Vector3(2.7616591453552246, 1.2274049520492554, 2.761655569076538)
})
spotlightLight3.addComponentOrReplace(transform44)

const spotlightLight4 = new Entity('spotlightLight4')
engine.addEntity(spotlightLight4)
spotlightLight4.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(2.4999990463256836, 5, 2.500000476837158),
  rotation: new Quaternion(-0.7071068286895752, 1.4901161193847656e-8, 0.6532816290855408, 0.27059805393218994),
  scale: new Vector3(2.7616524696350098, 1.2274025678634644, 2.7616546154022217)
})
spotlightLight4.addComponentOrReplace(transform45)

const dropChandelier = new Entity('dropChandelier')
engine.addEntity(dropChandelier)
dropChandelier.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(7.500000476837158, 12.17361068725586, 7.706435203552246),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.8945631980896, 1.8829596042633057, 5.8945631980896)
})
dropChandelier.addComponentOrReplace(transform46)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(7.590399265289307, 15.152673721313477, 2.61126971244812),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.689009428024292, 0.16010844707489014)
})
radio.addComponentOrReplace(transform47)

const dclLogo = new Entity('dclLogo')
engine.addEntity(dclLogo)
dclLogo.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(4.81387996673584, 17.78714942932129, 7.709209442138672),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.0000064373016357, 3.3750343322753906, 3.374999523162842)
})
dclLogo.addComponentOrReplace(transform48)
const gltfShape5 = new GLTFShape("096328824448d45480a4e7d7870cf89bb71a3b64c9b253739ebd02ad5607b61f/DecentralandLogo_01/DecentralandLogo_01.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
dclLogo.addComponentOrReplace(gltfShape5)

const discRainbow = new Entity('discRainbow')
engine.addEntity(discRainbow)
discRainbow.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(7.64235782623291, 17.786657333374023, 7.6977643966674805),
  rotation: new Quaternion(1, -6.691670821108589e-15, -1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(0.8359265923500061, 0.8733615875244141, 0.8360017538070679)
})
discRainbow.addComponentOrReplace(transform49)
const gltfShape6 = new GLTFShape("1d628cf69e3a27dae3d50585ccead6fa1dea4afaee256960ebaceee03a6d98d9/Disc_-Rainbow.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
discRainbow.addComponentOrReplace(gltfShape6)

const ringPurpleLight2 = new Entity('ringPurpleLight2')
engine.addEntity(ringPurpleLight2)
ringPurpleLight2.setParent(_scene)
ringPurpleLight2.addComponentOrReplace(gltfShape3)
const transform50 = new Transform({
  position: new Vector3(7.5, 6.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight2.addComponentOrReplace(transform50)

const ringPurpleLight4 = new Entity('ringPurpleLight4')
engine.addEntity(ringPurpleLight4)
ringPurpleLight4.setParent(_scene)
ringPurpleLight4.addComponentOrReplace(gltfShape3)
const transform51 = new Transform({
  position: new Vector3(7.5, 7.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight4.addComponentOrReplace(transform51)

const ringPurpleLight5 = new Entity('ringPurpleLight5')
engine.addEntity(ringPurpleLight5)
ringPurpleLight5.setParent(_scene)
ringPurpleLight5.addComponentOrReplace(gltfShape3)
const transform52 = new Transform({
  position: new Vector3(7.5, 8.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight5.addComponentOrReplace(transform52)

const ringPurpleLight6 = new Entity('ringPurpleLight6')
engine.addEntity(ringPurpleLight6)
ringPurpleLight6.setParent(_scene)
ringPurpleLight6.addComponentOrReplace(gltfShape3)
const transform53 = new Transform({
  position: new Vector3(7.5, 9.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight6.addComponentOrReplace(transform53)

const ringPurpleLight7 = new Entity('ringPurpleLight7')
engine.addEntity(ringPurpleLight7)
ringPurpleLight7.setParent(_scene)
ringPurpleLight7.addComponentOrReplace(gltfShape3)
const transform54 = new Transform({
  position: new Vector3(7.5, 9.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight7.addComponentOrReplace(transform54)

const ringPurpleLight8 = new Entity('ringPurpleLight8')
engine.addEntity(ringPurpleLight8)
ringPurpleLight8.setParent(_scene)
ringPurpleLight8.addComponentOrReplace(gltfShape3)
const transform55 = new Transform({
  position: new Vector3(7.5, 10.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight8.addComponentOrReplace(transform55)

const ringPurpleLight9 = new Entity('ringPurpleLight9')
engine.addEntity(ringPurpleLight9)
ringPurpleLight9.setParent(_scene)
ringPurpleLight9.addComponentOrReplace(gltfShape3)
const transform56 = new Transform({
  position: new Vector3(7.5, 11.5, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight9.addComponentOrReplace(transform56)

const ringPurpleLight10 = new Entity('ringPurpleLight10')
engine.addEntity(ringPurpleLight10)
ringPurpleLight10.setParent(_scene)
ringPurpleLight10.addComponentOrReplace(gltfShape3)
const transform57 = new Transform({
  position: new Vector3(7.5, 12.383048057556152, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ringPurpleLight10.addComponentOrReplace(transform57)

const ringPurpleLight11 = new Entity('ringPurpleLight11')
engine.addEntity(ringPurpleLight11)
ringPurpleLight11.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(3.606375217437744, 4.983725070953369, 11.551440238952637),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(-0.00538723636418581, 0.22126491367816925, 5.052391052246094)
})
ringPurpleLight11.addComponentOrReplace(transform58)
ringPurpleLight11.addComponentOrReplace(gltfShape3)

const ringPurpleLight12 = new Entity('ringPurpleLight12')
engine.addEntity(ringPurpleLight12)
ringPurpleLight12.setParent(_scene)
ringPurpleLight12.addComponentOrReplace(gltfShape3)
const transform59 = new Transform({
  position: new Vector3(11.361480712890625, 4.983725070953369, 3.8417441844940186),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(-0.00538723636418581, 0.22126491367816925, 5.052391052246094)
})
ringPurpleLight12.addComponentOrReplace(transform59)

const ringPurpleLight13 = new Entity('ringPurpleLight13')
engine.addEntity(ringPurpleLight13)
ringPurpleLight13.setParent(_scene)
ringPurpleLight13.addComponentOrReplace(gltfShape3)
const transform60 = new Transform({
  position: new Vector3(3.646627902984619, 4.983725070953369, 3.8190393447875977),
  rotation: new Quaternion(-7.100798428423376e-16, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(-0.0053872400894761086, 0.22126491367816925, 5.052393913269043)
})
ringPurpleLight13.addComponentOrReplace(transform60)

const ringPurpleLight14 = new Entity('ringPurpleLight14')
engine.addEntity(ringPurpleLight14)
ringPurpleLight14.setParent(_scene)
ringPurpleLight14.addComponentOrReplace(gltfShape3)
const transform61 = new Transform({
  position: new Vector3(11.365795135498047, 4.983725070953369, 11.57414436340332),
  rotation: new Quaternion(-7.100798428423376e-16, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(-0.005387241952121258, 0.22126491367816925, 5.052395343780518)
})
ringPurpleLight14.addComponentOrReplace(transform61)

const ringPurpleLight15 = new Entity('ringPurpleLight15')
engine.addEntity(ringPurpleLight15)
ringPurpleLight15.setParent(_scene)
ringPurpleLight15.addComponentOrReplace(gltfShape3)
const transform62 = new Transform({
  position: new Vector3(3.646627902984619, 19.96723747253418, 3.8190393447875977),
  rotation: new Quaternion(-7.100798428423376e-16, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(-0.005387245677411556, 0.22126491367816925, 5.052398204803467)
})
ringPurpleLight15.addComponentOrReplace(transform62)

const ringPurpleLight16 = new Entity('ringPurpleLight16')
engine.addEntity(ringPurpleLight16)
ringPurpleLight16.setParent(_scene)
ringPurpleLight16.addComponentOrReplace(gltfShape3)
const transform63 = new Transform({
  position: new Vector3(3.639557361602783, 19.96723747253418, 11.581911087036133),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(-0.00538723636418581, 0.22126491367816925, 5.052391052246094)
})
ringPurpleLight16.addComponentOrReplace(transform63)

const ringPurpleLight17 = new Entity('ringPurpleLight17')
engine.addEntity(ringPurpleLight17)
ringPurpleLight17.setParent(_scene)
ringPurpleLight17.addComponentOrReplace(gltfShape3)
const transform64 = new Transform({
  position: new Vector3(11.365795135498047, 19.96723747253418, 11.57414436340332),
  rotation: new Quaternion(-7.100798428423376e-16, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(-0.0053872475400567055, 0.22126491367816925, 5.052399635314941)
})
ringPurpleLight17.addComponentOrReplace(transform64)

const ringPurpleLight18 = new Entity('ringPurpleLight18')
engine.addEntity(ringPurpleLight18)
ringPurpleLight18.setParent(_scene)
ringPurpleLight18.addComponentOrReplace(gltfShape3)
const transform65 = new Transform({
  position: new Vector3(11.361480712890625, 19.96723747253418, 3.8417441844940186),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(-0.00538723636418581, 0.22126491367816925, 5.052391052246094)
})
ringPurpleLight18.addComponentOrReplace(transform65)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(11.387320518493652, 8.585188865661621, 15.170673370361328),
  rotation: new Quaternion(0, 0, 0.3826834559440613, 0.9238795638084412),
  scale: new Vector3(0.8788933753967285, 0.8788933753967285, 0.8788935542106628)
})
ropeLight.addComponentOrReplace(transform66)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(3.677412509918213, 8.658280372619629, 15.170673370361328),
  rotation: new Quaternion(0, 0, 0.9238795638084412, 0.3826834559440613),
  scale: new Vector3(0.8788944482803345, 0.8788944482803345, 0.8788935542106628)
})
ropeLight2.addComponentOrReplace(transform67)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(14.986360549926758, 8.658280372619629, 11.525628089904785),
  rotation: new Quaternion(0.6532815098762512, 0.27059805393218994, 0.6532814502716064, 0.2705981433391571),
  scale: new Vector3(0.8788955211639404, 0.8788959980010986, 0.8788939118385315)
})
ropeLight3.addComponentOrReplace(transform68)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(14.986358642578125, 8.585188865661621, 3.815718650817871),
  rotation: new Quaternion(0.27059805393218994, 0.6532815098762512, 0.2705979645252228, 0.653281569480896),
  scale: new Vector3(0.8788938522338867, 0.8788934946060181, 0.8788944482803345)
})
ropeLight4.addComponentOrReplace(transform69)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(0.022125717252492905, 8.658280372619629, 11.525629043579102),
  rotation: new Quaternion(0.6532815098762512, 0.27059805393218994, 0.6532814502716064, 0.2705981433391571),
  scale: new Vector3(0.8788958787918091, 0.8788968324661255, 0.8788939118385315)
})
ropeLight5.addComponentOrReplace(transform70)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(0.022125717252492905, 8.585188865661621, 3.8157191276550293),
  rotation: new Quaternion(0.27059805393218994, 0.6532815098762512, 0.2705979645252228, 0.653281569480896),
  scale: new Vector3(0.8788942098617554, 0.8788934946060181, 0.8788951635360718)
})
ropeLight6.addComponentOrReplace(transform71)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(11.387320518493652, 8.585188865661621, 0.17067337036132812),
  rotation: new Quaternion(0, 0, 0.3826834559440613, 0.9238795638084412),
  scale: new Vector3(0.8788933753967285, 0.8788933753967285, 0.8788935542106628)
})
ropeLight7.addComponentOrReplace(transform72)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(3.677412509918213, 8.658280372619629, 0.17067337036132812),
  rotation: new Quaternion(0, 0, 0.9238795638084412, 0.3826834559440613),
  scale: new Vector3(0.8788949251174927, 0.8788949251174927, 0.8788935542106628)
})
ropeLight8.addComponentOrReplace(transform73)

const ropeLight9 = new Entity('ropeLight9')
engine.addEntity(ropeLight9)
ropeLight9.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(3.6827688217163086, 16.326679229736328, 15.190973281860352),
  rotation: new Quaternion(0, 0, 0.3826834559440613, 0.9238795638084412),
  scale: new Vector3(0.868499755859375, 1, 1)
})
ropeLight9.addComponentOrReplace(transform74)

const ropeLight10 = new Entity('ropeLight10')
engine.addEntity(ropeLight10)
ropeLight10.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(11.41354751586914, 16.326679229736328, 15.190973281860352),
  rotation: new Quaternion(0, 0, 0.9238795638084412, 0.3826834559440613),
  scale: new Vector3(0.8685007095336914, 1.0000007152557373, 1)
})
ropeLight10.addComponentOrReplace(transform75)

const ropeLight11 = new Entity('ropeLight11')
engine.addEntity(ropeLight11)
ropeLight11.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(11.41354751586914, 16.326679229736328, 0.20930099487304688),
  rotation: new Quaternion(0, 0, 0.9238795638084412, 0.3826834559440613),
  scale: new Vector3(0.8685007095336914, 1.0000009536743164, 1)
})
ropeLight11.addComponentOrReplace(transform76)

const ropeLight12 = new Entity('ropeLight12')
engine.addEntity(ropeLight12)
ropeLight12.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(3.6827688217163086, 16.326679229736328, 0.20930099487304688),
  rotation: new Quaternion(0, 0, 0.3826834559440613, 0.9238795638084412),
  scale: new Vector3(0.868499755859375, 1, 1)
})
ropeLight12.addComponentOrReplace(transform77)

const ropeLight13 = new Entity('ropeLight13')
engine.addEntity(ropeLight13)
ropeLight13.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(0.031434059143066406, 16.326679229736328, 3.7981367111206055),
  rotation: new Quaternion(0.6532815098762512, 0.27059805393218994, 0.6532814502716064, 0.2705981433391571),
  scale: new Vector3(0.8685016632080078, 1.0000026226043701, 1.0000003576278687)
})
ropeLight13.addComponentOrReplace(transform78)

const ropeLight14 = new Entity('ropeLight14')
engine.addEntity(ropeLight14)
ropeLight14.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(0.03143495321273804, 16.326679229736328, 11.528916358947754),
  rotation: new Quaternion(0.27059805393218994, 0.6532815098762512, 0.2705979645252228, 0.653281569480896),
  scale: new Vector3(0.8685003519058228, 1.0000001192092896, 1.0000011920928955)
})
ropeLight14.addComponentOrReplace(transform79)

const ropeLight15 = new Entity('ropeLight15')
engine.addEntity(ropeLight15)
ropeLight15.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(14.992671012878418, 16.32378578186035, 3.8064677715301514),
  rotation: new Quaternion(0.6532815098762512, 0.27059805393218994, 0.6532814502716064, 0.2705981433391571),
  scale: new Vector3(0.8685024976730347, 1.0000042915344238, 1.0000003576278687)
})
ropeLight15.addComponentOrReplace(transform80)

const ropeLight16 = new Entity('ropeLight16')
engine.addEntity(ropeLight16)
ropeLight16.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(15.000556945800781, 16.28583335876465, 11.574690818786621),
  rotation: new Quaternion(0.27059805393218994, 0.6532815098762512, 0.2705979645252228, 0.653281569480896),
  scale: new Vector3(0.8685007095336914, 1.0000001192092896, 1.0000019073486328)
})
ropeLight16.addComponentOrReplace(transform81)

const ringPurpleLight19 = new Entity('ringPurpleLight19')
engine.addEntity(ringPurpleLight19)
ringPurpleLight19.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(7.733202934265137, 17.71790885925293, 7.702932357788086),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.734004497528076, 1, 7.70990514755249)
})
ringPurpleLight19.addComponentOrReplace(transform82)
ringPurpleLight19.addComponentOrReplace(gltfShape3)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
const script9 = new Script9()
const script10 = new Script10()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script9.init(options)
script10.init(options)
script1.spawn(verticalBlackPad, {"distance":13,"speed":5,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad, channelBus))
script2.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script3.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script4.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script4.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script4.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script4.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script4.spawn(invisibleWall5, {"enabled":true}, createChannel(channelId, invisibleWall5, channelBus))
script4.spawn(invisibleWall6, {"enabled":true}, createChannel(channelId, invisibleWall6, channelBus))
script4.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script4.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script4.spawn(invisibleWall9, {"enabled":true}, createChannel(channelId, invisibleWall9, channelBus))
script5.spawn(nftPictureFrame, {"id":"69478819454877515899718247009675975988331405547157132439541098673594171392001","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .02 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script5.spawn(nftPictureFrame2, {"id":"69478819454877515899718247009675975988331405547157132439541098661499543486465","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script5.spawn(nftPictureFrame3, {"id":"69478819454877515899718247009675975988331405547157132439541098656001985347585","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script5.spawn(nftPictureFrame4, {"id":"69478819454877515899718247009675975988331405547157132439541098670295636508673","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script5.spawn(nftPictureFrame5, {"id":"69478819454877515899718247009675975988331405547157132439541098674693683019777","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .02 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script5.spawn(nftPictureFrame6, {"id":"69478819454877515899718247009675975988331405547157132439541098675793194647553","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .02 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script5.spawn(nftPictureFrame7, {"id":"69478819454877515899718247009675975988331405547157132439541098662599055114241","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script5.spawn(nftPictureFrame8, {"id":"69478819454877515899718247009675975988331405547157132439541098657101496975361","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .02 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script6.spawn(tripleSpotlight, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight, channelBus))
script6.spawn(tripleSpotlight2, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight2, channelBus))
script6.spawn(tripleSpotlight3, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight3, channelBus))
script6.spawn(tripleSpotlight4, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight4, channelBus))
script6.spawn(tripleSpotlight5, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight5, channelBus))
script6.spawn(tripleSpotlight6, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight6, channelBus))
script6.spawn(tripleSpotlight7, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight7, channelBus))
script6.spawn(tripleSpotlight8, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight8, channelBus))
script7.spawn(spotlightLight, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightLight, channelBus))
script7.spawn(spotlightLight2, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightLight2, channelBus))
script7.spawn(spotlightLight3, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightLight3, channelBus))
script7.spawn(spotlightLight4, {"startOn":true,"clickable":true}, createChannel(channelId, spotlightLight4, channelBus))
script8.spawn(dropChandelier, {"startOn":true,"clickable":true}, createChannel(channelId, dropChandelier, channelBus))
script9.spawn(radio, {"startOn":true,"volume":0.38,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmdPHXfY297yX8XZumPbxT1P6HxAUsZADn7jRdVhXN7gbD"}, createChannel(channelId, radio, channelBus))
script10.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script10.spawn(ropeLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight2, channelBus))
script10.spawn(ropeLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight3, channelBus))
script10.spawn(ropeLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight4, channelBus))
script10.spawn(ropeLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight5, channelBus))
script10.spawn(ropeLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight6, channelBus))
script10.spawn(ropeLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight7, channelBus))
script10.spawn(ropeLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight8, channelBus))
script10.spawn(ropeLight9, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight9, channelBus))
script10.spawn(ropeLight10, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight10, channelBus))
script10.spawn(ropeLight11, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight11, channelBus))
script10.spawn(ropeLight12, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight12, channelBus))
script10.spawn(ropeLight13, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight13, channelBus))
script10.spawn(ropeLight14, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight14, channelBus))
script10.spawn(ropeLight15, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight15, channelBus))
script10.spawn(ropeLight16, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight16, channelBus))