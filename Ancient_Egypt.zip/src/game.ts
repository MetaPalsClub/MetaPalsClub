import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../2263960d-51ff-483a-bd2a-a9d286558620/src/item"
import Script2 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"
import Script3 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script4 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script5 from "../85cf3207-2792-4349-9938-21fd82ea2168/src/item"
import Script6 from "../ef85eb18-f69c-431c-bcfd-dd51d70a604f/src/item"
import Script7 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script8 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script9 from "../cc309926-283a-4e0f-b0a4-97659437f3bc/src/item"
import Script10 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script11 from "../da30258e-3cc1-48a4-bc55-508e923ae977/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("models/FloorBaseSand_01/FloorBaseSand_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const wallPlainYellow3 = new Entity('wallPlainYellow3')
engine.addEntity(wallPlainYellow3)
wallPlainYellow3.setParent(_scene)
const gltfShape2 = new GLTFShape("models/PlainYellowWall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
wallPlainYellow3.addComponentOrReplace(gltfShape2)
const transform3 = new Transform({
  position: new Vector3(0.06186389923095703, 0.008534431457519531, 2.301802635192871),
  rotation: new Quaternion(0.13794969022274017, 0.6935198903083801, -0.13794977962970734, 0.6935199499130249),
  scale: new Vector3(5.554168224334717, 1.000000238418579, 0.06125415489077568)
})
wallPlainYellow3.addComponentOrReplace(transform3)

const wallPlainYellow8 = new Entity('wallPlainYellow8')
engine.addEntity(wallPlainYellow8)
wallPlainYellow8.setParent(_scene)
wallPlainYellow8.addComponentOrReplace(gltfShape2)
const transform4 = new Transform({
  position: new Vector3(1.3668956756591797, 3.170708656311035, 4.226391792297363),
  rotation: new Quaternion(-0.13794974982738495, -0.6935199499130249, 0.13794980943202972, -0.6935199499130249),
  scale: new Vector3(3.8953006267547607, 1.0000003576278687, 0.10706182569265366)
})
wallPlainYellow8.addComponentOrReplace(transform4)

const wallPlainYellow9 = new Entity('wallPlainYellow9')
engine.addEntity(wallPlainYellow9)
wallPlainYellow9.setParent(_scene)
wallPlainYellow9.addComponentOrReplace(gltfShape2)
const transform5 = new Transform({
  position: new Vector3(1.3408660888671875, 3.101006507873535, 4.050985336303711),
  rotation: new Quaternion(-0.13794973492622375, -0.6935199499130249, 0.13794979453086853, -0.6935199499130249),
  scale: new Vector3(4.063999652862549, 1.0000004768371582, 0.061254143714904785)
})
wallPlainYellow9.addComponentOrReplace(transform5)

const wallPlainYellow10 = new Entity('wallPlainYellow10')
engine.addEntity(wallPlainYellow10)
wallPlainYellow10.setParent(_scene)
wallPlainYellow10.addComponentOrReplace(gltfShape2)
const transform6 = new Transform({
  position: new Vector3(2.7909023761749268, 6.601075649261475, 5.5125956535339355),
  rotation: new Quaternion(-0.13794973492622375, -0.6935199499130249, 0.13794979453086853, -0.6935199499130249),
  scale: new Vector3(2.546894073486328, 1.0000004768371582, 0.061254262924194336)
})
wallPlainYellow10.addComponentOrReplace(transform6)

const wallPlainYellow17 = new Entity('wallPlainYellow17')
engine.addEntity(wallPlainYellow17)
wallPlainYellow17.setParent(_scene)
wallPlainYellow17.addComponentOrReplace(gltfShape2)
const transform7 = new Transform({
  position: new Vector3(4.231294631958008, 10.107837677001953, 6.855007648468018),
  rotation: new Quaternion(-0.13794967532157898, -0.6935198903083801, 0.13794982433319092, -0.6935200095176697),
  scale: new Vector3(1.21475350856781, 1.0000027418136597, 0.061254438012838364)
})
wallPlainYellow17.addComponentOrReplace(transform7)

const yellowNeonTubeOn2 = new Entity('yellowNeonTubeOn2')
engine.addEntity(yellowNeonTubeOn2)
yellowNeonTubeOn2.setParent(_scene)
const gltfShape3 = new GLTFShape("models/NeonLightTube_02/NeonLightTube_02.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
yellowNeonTubeOn2.addComponentOrReplace(gltfShape3)
const transform8 = new Transform({
  position: new Vector3(11.41152286529541, 10.869144439697266, 11.1809720993042),
  rotation: new Quaternion(0.09417977929115295, 0.42895010113716125, 0.700806736946106, 0.5621404647827148),
  scale: new Vector3(9.317002296447754, 1.0000038146972656, 1.0000001192092896)
})
yellowNeonTubeOn2.addComponentOrReplace(transform8)

const yellowNeonTubeOn3 = new Entity('yellowNeonTubeOn3')
engine.addEntity(yellowNeonTubeOn3)
yellowNeonTubeOn3.setParent(_scene)
yellowNeonTubeOn3.addComponentOrReplace(gltfShape3)
const transform9 = new Transform({
  position: new Vector3(4.652114391326904, 10.869144439697266, 11.355581283569336),
  rotation: new Quaternion(-0.42895010113716125, -0.09417980909347534, 0.5621404647827148, 0.7008068561553955),
  scale: new Vector3(9.317032814025879, 1.0000077486038208, 1.0000020265579224)
})
yellowNeonTubeOn3.addComponentOrReplace(transform9)

const yellowNeonTubeOn4 = new Entity('yellowNeonTubeOn4')
engine.addEntity(yellowNeonTubeOn4)
yellowNeonTubeOn4.setParent(_scene)
yellowNeonTubeOn4.addComponentOrReplace(gltfShape3)
const transform10 = new Transform({
  position: new Vector3(11.313057899475098, 10.869144439697266, 4.575948715209961),
  rotation: new Quaternion(-0.5621404051780701, -0.7008068561553955, -0.4289499521255493, -0.09417985379695892),
  scale: new Vector3(9.31700325012207, 1.0000040531158447, 1.0000007152557373)
})
yellowNeonTubeOn4.addComponentOrReplace(transform10)

const yellowNeonTubeOn5 = new Entity('yellowNeonTubeOn5')
engine.addEntity(yellowNeonTubeOn5)
yellowNeonTubeOn5.setParent(_scene)
yellowNeonTubeOn5.addComponentOrReplace(gltfShape3)
const transform11 = new Transform({
  position: new Vector3(4.621816635131836, 10.869144439697266, 4.680972099304199),
  rotation: new Quaternion(0.7008067965507507, 0.5621404647827148, -0.09417984634637833, -0.4289500117301941),
  scale: new Vector3(9.31700325012207, 1.0000038146972656, 1.0000001192092896)
})
yellowNeonTubeOn5.addComponentOrReplace(transform11)

const funkyFloorLight = new Entity('funkyFloorLight')
engine.addEntity(funkyFloorLight)
funkyFloorLight.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(7.979918479919434, 17.988475799560547, 7.816535949707031),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
funkyFloorLight.addComponentOrReplace(transform12)

const floorGlass = new Entity('floorGlass')
engine.addEntity(floorGlass)
floorGlass.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(14.360086441040039, 3.698610305786133, 14.347200393676758),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.1743528842926025, 1, 3.169343948364258)
})
floorGlass.addComponentOrReplace(transform13)
const gltfShape4 = new GLTFShape("models/GlassFloor.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
floorGlass.addComponentOrReplace(gltfShape4)

const floorGlass2 = new Entity('floorGlass2')
engine.addEntity(floorGlass2)
floorGlass2.setParent(_scene)
floorGlass2.addComponentOrReplace(gltfShape4)
const transform14 = new Transform({
  position: new Vector3(12.959941864013672, 7.198610782623291, 12.869779586791992),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.464158535003662, 1, 2.4189095497131348)
})
floorGlass2.addComponentOrReplace(transform14)

const floorGlass3 = new Entity('floorGlass3')
engine.addEntity(floorGlass3)
floorGlass3.setParent(_scene)
floorGlass3.addComponentOrReplace(gltfShape4)
const transform15 = new Transform({
  position: new Vector3(11.470767974853516, 10.698610305786133, 11.457549095153809),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.7320603132247925, 1, 1.7240335941314697)
})
floorGlass3.addComponentOrReplace(transform15)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(0.8399311304092407, 1.7303279638290405, 13.432334899902344),
  rotation: new Quaternion(0, 0, 0.5555703043937683, 0.8314696550369263),
  scale: new Vector3(0.35669463872909546, 1.0000004768371582, 0.9999999403953552)
})
ropeLight.addComponentOrReplace(transform16)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(0.8399311304092407, 1.7303279638290405, 2.2686493396759033),
  rotation: new Quaternion(0, 0, 0.5555703043937683, 0.8314696550369263),
  scale: new Vector3(0.356694757938385, 1.0000007152557373, 0.9999999403953552)
})
ropeLight2.addComponentOrReplace(transform17)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(15.204571723937988, 1.7303279638290405, 2.248764753341675),
  rotation: new Quaternion(0, 0, 0.8314696550369263, 0.5555702447891235),
  scale: new Vector3(0.3566949963569641, 1.0000011920928955, 0.9999999403953552)
})
ropeLight3.addComponentOrReplace(transform18)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(15.204571723937988, 1.7303279638290405, 13.489580154418945),
  rotation: new Quaternion(0, 0, 0.8314696550369263, 0.5555702447891235),
  scale: new Vector3(0.3566948473453522, 1.000001072883606, 0.9999999403953552)
})
ropeLight4.addComponentOrReplace(transform19)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(13.58541488647461, 1.7303282022476196, 15.051492691040039),
  rotation: new Quaternion(0.39284756779670715, 0.5879378914833069, 0.3928475081920624, 0.5879379510879517),
  scale: new Vector3(0.3566948175430298, 1.0000008344650269, 1.0000003576278687)
})
ropeLight5.addComponentOrReplace(transform20)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(2.4217286109924316, 1.7303295135498047, 15.051494598388672),
  rotation: new Quaternion(0.39284756779670715, 0.5879378914833069, 0.3928475081920624, 0.5879379510879517),
  scale: new Vector3(0.35669493675231934, 1.0000011920928955, 1.0000003576278687)
})
ropeLight6.addComponentOrReplace(transform21)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(13.403035163879395, 1.7303261756896973, 0.7775633335113525),
  rotation: new Quaternion(0.5879378318786621, 0.3928474485874176, 0.5879377722740173, 0.3928475081920624),
  scale: new Vector3(0.35669490694999695, 1.0000016689300537, 1.000000238418579)
})
ropeLight7.addComponentOrReplace(transform22)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(2.2008543014526367, 1.7303276062011719, 0.777564287185669),
  rotation: new Quaternion(0.5879378318786621, 0.3928474485874176, 0.5879377722740173, 0.3928475081920624),
  scale: new Vector3(0.3566950857639313, 1.0000016689300537, 1.000000238418579)
})
ropeLight8.addComponentOrReplace(transform23)

const ringWhiteLight = new Entity('ringWhiteLight')
engine.addEntity(ringWhiteLight)
ringWhiteLight.setParent(_scene)
const gltfShape5 = new GLTFShape("models/Ring_White_Light.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
ringWhiteLight.addComponentOrReplace(gltfShape5)
const transform24 = new Transform({
  position: new Vector3(8.04497241973877, 10.680224418640137, 7.996932029724121),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.5146563053131104, 0.4356173872947693, 3.5146563053131104)
})
ringWhiteLight.addComponentOrReplace(transform24)

const ringWhiteLight3 = new Entity('ringWhiteLight3')
engine.addEntity(ringWhiteLight3)
ringWhiteLight3.setParent(_scene)
ringWhiteLight3.addComponentOrReplace(gltfShape5)
const transform25 = new Transform({
  position: new Vector3(8.04497241973877, 7.110737323760986, 7.996932029724121),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.934508323669434, 0.6115981936454773, 4.934508323669434)
})
ringWhiteLight3.addComponentOrReplace(transform25)

const ringWhiteLight4 = new Entity('ringWhiteLight4')
engine.addEntity(ringWhiteLight4)
ringWhiteLight4.setParent(_scene)
ringWhiteLight4.addComponentOrReplace(gltfShape5)
const transform26 = new Transform({
  position: new Vector3(8.04497241973877, 3.613776683807373, 7.996932029724121),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.40144681930542, 0.7934151291847229, 6.40144681930542)
})
ringWhiteLight4.addComponentOrReplace(transform26)

const ringWhiteLight5 = new Entity('ringWhiteLight5')
engine.addEntity(ringWhiteLight5)
ringWhiteLight5.setParent(_scene)
ringWhiteLight5.addComponentOrReplace(gltfShape5)
const transform27 = new Transform({
  position: new Vector3(8.04497241973877, 0.007682185620069504, 7.996932029724121),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.932592391967773, 0.9831900596618652, 7.932592391967773)
})
ringWhiteLight5.addComponentOrReplace(transform27)

const ringWhiteLight6 = new Entity('ringWhiteLight6')
engine.addEntity(ringWhiteLight6)
ringWhiteLight6.setParent(_scene)
ringWhiteLight6.addComponentOrReplace(gltfShape5)
const transform28 = new Transform({
  position: new Vector3(8.021251678466797, 17.774961471557617, 7.923958778381348),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.753354549407959, 1.3008509874343872, 0.753354549407959)
})
ringWhiteLight6.addComponentOrReplace(transform28)

const armchairA3 = new Entity('armchairA3')
engine.addEntity(armchairA3)
armchairA3.setParent(_scene)
const gltfShape6 = new GLTFShape("models/Armchair_A.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
armchairA3.addComponentOrReplace(gltfShape6)
const transform29 = new Transform({
  position: new Vector3(14.499552726745605, 0, 7.976435661315918),
  rotation: new Quaternion(1.122618165962097e-14, 0.7071068286895752, -8.429369557916289e-8, -0.7071067690849304),
  scale: new Vector3(5.237331390380859, 1, 1.0000001192092896)
})
armchairA3.addComponentOrReplace(transform29)

const armchairA4 = new Entity('armchairA4')
engine.addEntity(armchairA4)
armchairA4.setParent(_scene)
armchairA4.addComponentOrReplace(gltfShape6)
const transform30 = new Transform({
  position: new Vector3(1.4995527267456055, 0, 7.976435661315918),
  rotation: new Quaternion(-4.731726790171021e-15, 0.7071067094802856, -8.429366715745346e-8, 0.70710688829422),
  scale: new Vector3(5.237331390380859, 1, 1.0000001192092896)
})
armchairA4.addComponentOrReplace(transform30)

const sofaWhite = new Entity('sofaWhite')
engine.addEntity(sofaWhite)
sofaWhite.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(11.18134593963623, 3.732391357421875, 3.3320131301879883),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.9812572002410889, 1, 1)
})
sofaWhite.addComponentOrReplace(transform31)
const gltfShape7 = new GLTFShape("models/Sofa_White.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
sofaWhite.addComponentOrReplace(gltfShape7)

const sofaWhite2 = new Entity('sofaWhite2')
engine.addEntity(sofaWhite2)
sofaWhite2.setParent(_scene)
sofaWhite2.addComponentOrReplace(gltfShape7)
const transform32 = new Transform({
  position: new Vector3(4.933267116546631, 3.732391357421875, 12.588010787963867),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(1.9812572002410889, 1, 1)
})
sofaWhite2.addComponentOrReplace(transform32)

const armchairA7 = new Entity('armchairA7')
engine.addEntity(armchairA7)
armchairA7.setParent(_scene)
armchairA7.addComponentOrReplace(gltfShape6)
const transform33 = new Transform({
  position: new Vector3(11.723447799682617, 7.199822902679443, 7.988994121551514),
  rotation: new Quaternion(3.2001347321982407e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.2363107204437256, 0.7363543510437012, 1.0000004768371582)
})
armchairA7.addComponentOrReplace(transform33)

const armchairA8 = new Entity('armchairA8')
engine.addEntity(armchairA8)
armchairA8.setParent(_scene)
armchairA8.addComponentOrReplace(gltfShape6)
const transform34 = new Transform({
  position: new Vector3(4.373288154602051, 7.19982385635376, 7.98899507522583),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.2363107204437256, 0.7363543510437012, 1.0000004768371582)
})
armchairA8.addComponentOrReplace(transform34)

const floorGlass9 = new Entity('floorGlass9')
engine.addEntity(floorGlass9)
floorGlass9.setParent(_scene)
floorGlass9.addComponentOrReplace(gltfShape4)
const transform35 = new Transform({
  position: new Vector3(15.841970443725586, 15.071178436279297, 15.927896499633789),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.9103546142578125, 1, 3.948115348815918)
})
floorGlass9.addComponentOrReplace(transform35)

const floorGlass10 = new Entity('floorGlass10')
engine.addEntity(floorGlass10)
floorGlass10.setParent(_scene)
floorGlass10.addComponentOrReplace(gltfShape4)
const transform36 = new Transform({
  position: new Vector3(15.991323471069336, 16.071178436279297, 0.023420222103595734),
  rotation: new Quaternion(-0.7071068286895752, 2.412783938165715e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.993804693222046, 1.0000008344650269, 0.06398976594209671)
})
floorGlass10.addComponentOrReplace(transform36)

const floorGlass11 = new Entity('floorGlass11')
engine.addEntity(floorGlass11)
floorGlass11.setParent(_scene)
floorGlass11.addComponentOrReplace(gltfShape4)
const transform37 = new Transform({
  position: new Vector3(15.991323471069336, 16.071178436279297, 16),
  rotation: new Quaternion(-0.7071068286895752, 2.412783938165715e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.993804693222046, 1.0000015497207642, 0.06398981064558029)
})
floorGlass11.addComponentOrReplace(transform37)

const floorGlass12 = new Entity('floorGlass12')
engine.addEntity(floorGlass12)
floorGlass12.setParent(_scene)
floorGlass12.addComponentOrReplace(gltfShape4)
const transform38 = new Transform({
  position: new Vector3(15.963693618774414, 16.071178436279297, 16),
  rotation: new Quaternion(-0.5000000596046448, -0.5000000596046448, -0.49999988079071045, 0.5),
  scale: new Vector3(3.993805170059204, 1.0000022649765015, 0.06398984789848328)
})
floorGlass12.addComponentOrReplace(transform38)

const floorGlass13 = new Entity('floorGlass13')
engine.addEntity(floorGlass13)
floorGlass13.setParent(_scene)
floorGlass13.addComponentOrReplace(gltfShape4)
const transform39 = new Transform({
  position: new Vector3(0.0029417648911476135, 16.071178436279297, 16),
  rotation: new Quaternion(-0.5000000596046448, -0.5000000596046448, -0.49999988079071045, 0.5),
  scale: new Vector3(3.993805170059204, 1.0000022649765015, 0.06398984789848328)
})
floorGlass13.addComponentOrReplace(transform39)

const floorGlass14 = new Entity('floorGlass14')
engine.addEntity(floorGlass14)
floorGlass14.setParent(_scene)
floorGlass14.addComponentOrReplace(gltfShape4)
const transform40 = new Transform({
  position: new Vector3(6.845735549926758, 14.182764053344727, 9.202545166015625),
  rotation: new Quaternion(-0.5000000596046448, -0.5000000596046448, -0.49999988079071045, 0.5),
  scale: new Vector3(0.5725738406181335, 1.0000022649765015, 2.952911615371704)
})
floorGlass14.addComponentOrReplace(transform40)

const floorGlass15 = new Entity('floorGlass15')
engine.addEntity(floorGlass15)
floorGlass15.setParent(_scene)
floorGlass15.addComponentOrReplace(gltfShape4)
const transform41 = new Transform({
  position: new Vector3(9.119122505187988, 14.182764053344727, 9.202545166015625),
  rotation: new Quaternion(-0.5000000596046448, -0.5000000596046448, -0.49999988079071045, 0.5),
  scale: new Vector3(0.5725738406181335, 1.0000022649765015, 2.952911615371704)
})
floorGlass15.addComponentOrReplace(transform41)

const floorGlass16 = new Entity('floorGlass16')
engine.addEntity(floorGlass16)
floorGlass16.setParent(_scene)
floorGlass16.addComponentOrReplace(gltfShape4)
const transform42 = new Transform({
  position: new Vector3(9.147530555725098, 14.182764053344727, 9.22133731842041),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.706243820848613e-8, 0.7071068286895752),
  scale: new Vector3(0.5725739002227783, 1.0000041723251343, 2.9529144763946533)
})
floorGlass16.addComponentOrReplace(transform42)

const floorGlass17 = new Entity('floorGlass17')
engine.addEntity(floorGlass17)
floorGlass17.setParent(_scene)
floorGlass17.addComponentOrReplace(gltfShape4)
const transform43 = new Transform({
  position: new Vector3(9.147530555725098, 14.182764053344727, 6.946937561035156),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.706243820848613e-8, 0.7071068286895752),
  scale: new Vector3(0.5725739002227783, 1.0000046491622925, 2.9529154300689697)
})
floorGlass17.addComponentOrReplace(transform43)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(8.000000953674316, 2.491884708404541, 9.2206392288208),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4504337310791016, 1.7502256631851196, 0.201748788356781)
})
nftPictureFrame9.addComponentOrReplace(transform44)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(8.000000953674316, 2.491884708404541, 6.904630184173584),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.4504337310791016, 1.7502256631851196, 0.201748788356781)
})
nftPictureFrame10.addComponentOrReplace(transform45)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(6.85770845413208, 2.491884708404541, 8.065549850463867),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.4504330158233643, 1.7502256631851196, 0.20174959301948547)
})
nftPictureFrame11.addComponentOrReplace(transform46)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(9.15375804901123, 2.491884708404541, 8.09453010559082),
  rotation: new Quaternion(3.4685891193362824e-15, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.4504344463348389, 1.7502256631851196, 0.20174986124038696)
})
nftPictureFrame12.addComponentOrReplace(transform47)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(9.15375804901123, 4.933501243591309, 8.09453010559082),
  rotation: new Quaternion(3.4685891193362824e-15, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.4504354000091553, 1.750886082649231, 0.2017497420310974)
})
nftPictureFrame13.addComponentOrReplace(transform48)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(8.000000953674316, 4.933501243591309, 6.904630184173584),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.4504337310791016, 1.750886082649231, 0.201748788356781)
})
nftPictureFrame14.addComponentOrReplace(transform49)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(6.85770845413208, 4.933501243591309, 8.065549850463867),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.4504330158233643, 1.750886082649231, 0.20174959301948547)
})
nftPictureFrame15.addComponentOrReplace(transform50)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(8.000000953674316, 4.933501243591309, 9.2206392288208),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4504337310791016, 1.750886082649231, 0.201748788356781)
})
nftPictureFrame16.addComponentOrReplace(transform51)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(9.15375804901123, 8.509129524230957, 8.09453010559082),
  rotation: new Quaternion(3.4685891193362824e-15, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.450434684753418, 1.8684722185134888, 0.20174992084503174)
})
nftPictureFrame17.addComponentOrReplace(transform52)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(8.000000953674316, 8.509129524230957, 6.904630184173584),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.4504337310791016, 1.8684722185134888, 0.201748788356781)
})
nftPictureFrame18.addComponentOrReplace(transform53)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(6.85770845413208, 8.509129524230957, 8.065549850463867),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.450434684753418, 1.8684722185134888, 0.20174947381019592)
})
nftPictureFrame19.addComponentOrReplace(transform54)

const nftPictureFrame20 = new Entity('nftPictureFrame20')
engine.addEntity(nftPictureFrame20)
nftPictureFrame20.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(8.000000953674316, 8.509129524230957, 9.2206392288208),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4504337310791016, 1.8684722185134888, 0.201748788356781)
})
nftPictureFrame20.addComponentOrReplace(transform55)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(9.15375804901123, 12.053340911865234, 8.09453010559082),
  rotation: new Quaternion(3.4685891193362824e-15, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.4504351615905762, 1.6906180381774902, 0.20174995064735413)
})
nftPictureFrame21.addComponentOrReplace(transform56)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(8.000000953674316, 12.053340911865234, 6.904630184173584),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.4504337310791016, 1.6906180381774902, 0.201748788356781)
})
nftPictureFrame22.addComponentOrReplace(transform57)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(6.85770845413208, 12.053340911865234, 8.065549850463867),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.450434684753418, 1.6906180381774902, 0.20174956321716309)
})
nftPictureFrame23.addComponentOrReplace(transform58)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform59 = new Transform({
  position: new Vector3(8.000000953674316, 12.053340911865234, 9.2206392288208),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4504337310791016, 1.6906180381774902, 0.201748788356781)
})
nftPictureFrame24.addComponentOrReplace(transform59)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(8.037463188171387, 18.882173538208008, 0.5722522735595703),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2359554767608643, 1, 0.33528319001197815)
})
radio.addComponentOrReplace(transform60)

const barBlack = new Entity('barBlack')
engine.addEntity(barBlack)
barBlack.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(5.000000953674316, 15.08226203918457, 13.999999046325684),
  rotation: new Quaternion(8.211466039466722e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
barBlack.addComponentOrReplace(transform61)
const gltfShape8 = new GLTFShape("models/Bar_Black.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
barBlack.addComponentOrReplace(gltfShape8)

const lightDecor = new Entity('lightDecor')
engine.addEntity(lightDecor)
lightDecor.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(9.612527847290039, 18.115951538085938, 8.016580581665039),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5761680603027344, 0.1346987783908844, 1.6034797430038452)
})
lightDecor.addComponentOrReplace(transform62)
const gltfShape9 = new GLTFShape("models/Light_Decor5.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
lightDecor.addComponentOrReplace(gltfShape9)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(0.4965245723724365, 1.2878732681274414, 8.088704109191895),
  rotation: new Quaternion(0.13794969022274017, 0.6935199499130249, 0.137949600815773, -0.6935199499130249),
  scale: new Vector3(13.50013256072998, 4.555156707763672, 1.0000061988830566)
})
nftPictureFrame2.addComponentOrReplace(transform63)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(1.4941368103027344, 3.676921844482422, 7.988142967224121),
  rotation: new Quaternion(-0.13794969022274017, -0.6935199499130249, -0.137949600815773, 0.6935199499130249),
  scale: new Vector3(6.330560207366943, 6.330521583557129, 0.7282842397689819)
})
nftPictureFrame3.addComponentOrReplace(transform64)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(2.953619956970215, 7.176921844482422, 8.053140640258789),
  rotation: new Quaternion(-0.13794967532157898, -0.6935199499130249, -0.13794958591461182, 0.6935199499130249),
  scale: new Vector3(8.453228950500488, 6.31178092956543, 0.7261292934417725)
})
nftPictureFrame4.addComponentOrReplace(transform65)

const rainLight2 = new Entity('rainLight2')
engine.addEntity(rainLight2)
rainLight2.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(0.7335729598999023, 0.1411571502685547, 0.6351785659790039),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 3.7602765560150146, 1.4806699752807617)
})
rainLight2.addComponentOrReplace(transform66)

const rainLight3 = new Entity('rainLight3')
engine.addEntity(rainLight3)
rainLight3.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(15.180123329162598, 0.1411571502685547, 0.6351785659790039),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 3.7602765560150146, 1.4806699752807617)
})
rainLight3.addComponentOrReplace(transform67)

const armchairA = new Entity('armchairA')
engine.addEntity(armchairA)
armchairA.setParent(_scene)
armchairA.addComponentOrReplace(gltfShape6)
const transform68 = new Transform({
  position: new Vector3(0.808617115020752, 15.069643020629883, 7.976435661315918),
  rotation: new Quaternion(-4.731726790171021e-15, 0.7071067094802856, -8.429366715745346e-8, 0.70710688829422),
  scale: new Vector3(5.237331390380859, 1, 1.0000001192092896)
})
armchairA.addComponentOrReplace(transform68)

const armchairA2 = new Entity('armchairA2')
engine.addEntity(armchairA2)
armchairA2.setParent(_scene)
armchairA2.addComponentOrReplace(gltfShape6)
const transform69 = new Transform({
  position: new Vector3(15.203239440917969, 15.069643020629883, 7.976435661315918),
  rotation: new Quaternion(1.122618165962097e-14, 0.7071068286895752, -8.429369557916289e-8, -0.7071067690849304),
  scale: new Vector3(5.237331390380859, 1, 1.0000001192092896)
})
armchairA2.addComponentOrReplace(transform69)

const stoolModern = new Entity('stoolModern')
engine.addEntity(stoolModern)
stoolModern.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(10.321306228637695, 15.104275703430176, 13.350895881652832),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3737692832946777, 1, 1)
})
stoolModern.addComponentOrReplace(transform70)
const gltfShape10 = new GLTFShape("models/ModernStool.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
stoolModern.addComponentOrReplace(gltfShape10)

const stoolModern2 = new Entity('stoolModern2')
engine.addEntity(stoolModern2)
stoolModern2.setParent(_scene)
stoolModern2.addComponentOrReplace(gltfShape10)
const transform71 = new Transform({
  position: new Vector3(8.947537422180176, 15.104275703430176, 13.350895881652832),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3737692832946777, 1, 1)
})
stoolModern2.addComponentOrReplace(transform71)

const stoolModern3 = new Entity('stoolModern3')
engine.addEntity(stoolModern3)
stoolModern3.setParent(_scene)
stoolModern3.addComponentOrReplace(gltfShape10)
const transform72 = new Transform({
  position: new Vector3(7.57376766204834, 15.104275703430176, 13.350895881652832),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3737692832946777, 1, 1)
})
stoolModern3.addComponentOrReplace(transform72)

const stoolModern4 = new Entity('stoolModern4')
engine.addEntity(stoolModern4)
stoolModern4.setParent(_scene)
stoolModern4.addComponentOrReplace(gltfShape10)
const transform73 = new Transform({
  position: new Vector3(6.19999885559082, 15.104275703430176, 13.350895881652832),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3737692832946777, 1, 1)
})
stoolModern4.addComponentOrReplace(transform73)

const verticalWhitePad = new Entity('verticalWhitePad')
engine.addEntity(verticalWhitePad)
verticalWhitePad.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.0836068391799927, 1.1736316680908203, 1.0836068391799927)
})
verticalWhitePad.addComponentOrReplace(transform74)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(8.000000953674316, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform75)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(8, 0, 8.000000953674316),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 14.056361198425293, 1)
})
triggerArea.addComponentOrReplace(transform76)

const rainbowAnodizedMetalWall = new Entity('rainbowAnodizedMetalWall')
engine.addEntity(rainbowAnodizedMetalWall)
rainbowAnodizedMetalWall.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(8.092576026916504, 18.603689193725586, 0.35089731216430664),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(29.790172576904297, 4.5690598487854, 186.15374755859375)
})
rainbowAnodizedMetalWall.addComponentOrReplace(transform77)
const gltfShape11 = new GLTFShape("models/Rainbow_Anodized Metal Wall.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
rainbowAnodizedMetalWall.addComponentOrReplace(gltfShape11)

const rainbowAnodizedMetalWall2 = new Entity('rainbowAnodizedMetalWall2')
engine.addEntity(rainbowAnodizedMetalWall2)
rainbowAnodizedMetalWall2.setParent(_scene)
rainbowAnodizedMetalWall2.addComponentOrReplace(gltfShape11)
const transform78 = new Transform({
  position: new Vector3(11.82605266571045, 17.762237548828125, 0.35089588165283203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4697957038879395, 10.876404762268066, 186.15374755859375)
})
rainbowAnodizedMetalWall2.addComponentOrReplace(transform78)

const cleanGoldWall = new Entity('cleanGoldWall')
engine.addEntity(cleanGoldWall)
cleanGoldWall.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(3.112002372741699, 15.13286018371582, 0.29138708114624023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(9.793137550354004, 23.977981567382812, 128.51116943359375)
})
cleanGoldWall.addComponentOrReplace(transform79)
const gltfShape12 = new GLTFShape("models/Clean_Gold Wall.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
cleanGoldWall.addComponentOrReplace(gltfShape12)

const cleanGoldWall2 = new Entity('cleanGoldWall2')
engine.addEntity(cleanGoldWall2)
cleanGoldWall2.setParent(_scene)
cleanGoldWall2.addComponentOrReplace(gltfShape12)
const transform80 = new Transform({
  position: new Vector3(12.798454284667969, 15.13286018371582, 0.29138612747192383),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(9.793137550354004, 23.977981567382812, 128.51116943359375)
})
cleanGoldWall2.addComponentOrReplace(transform80)

const cleanGoldWall3 = new Entity('cleanGoldWall3')
engine.addEntity(cleanGoldWall3)
cleanGoldWall3.setParent(_scene)
cleanGoldWall3.addComponentOrReplace(gltfShape12)
const transform81 = new Transform({
  position: new Vector3(11.723861694335938, 18.93924903869629, 0.29138660430908203),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(9.793156623840332, 37.54008102416992, 128.5111541748047)
})
cleanGoldWall3.addComponentOrReplace(transform81)

const rainbowAnodizedMetalWall3 = new Entity('rainbowAnodizedMetalWall3')
engine.addEntity(rainbowAnodizedMetalWall3)
rainbowAnodizedMetalWall3.setParent(_scene)
rainbowAnodizedMetalWall3.addComponentOrReplace(gltfShape11)
const transform82 = new Transform({
  position: new Vector3(4.111669540405273, 17.762237548828125, 0.35089635848999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4697957038879395, 10.876404762268066, 186.15374755859375)
})
rainbowAnodizedMetalWall3.addComponentOrReplace(transform82)

const rainbowAnodizedMetalWall4 = new Entity('rainbowAnodizedMetalWall4')
engine.addEntity(rainbowAnodizedMetalWall4)
rainbowAnodizedMetalWall4.setParent(_scene)
rainbowAnodizedMetalWall4.addComponentOrReplace(gltfShape11)
const transform83 = new Transform({
  position: new Vector3(12.3604154586792, 17.448219299316406, 0.35089683532714844),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(19.337736129760742, 4.569072246551514, 186.15374755859375)
})
rainbowAnodizedMetalWall4.addComponentOrReplace(transform83)

const rainbowAnodizedMetalWall5 = new Entity('rainbowAnodizedMetalWall5')
engine.addEntity(rainbowAnodizedMetalWall5)
rainbowAnodizedMetalWall5.setParent(_scene)
rainbowAnodizedMetalWall5.addComponentOrReplace(gltfShape11)
const transform84 = new Transform({
  position: new Vector3(2.673964023590088, 17.448219299316406, 0.35089778900146484),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(19.337739944458008, 4.56907320022583, 186.15374755859375)
})
rainbowAnodizedMetalWall5.addComponentOrReplace(transform84)

const rainbowAnodizedMetalWall6 = new Entity('rainbowAnodizedMetalWall6')
engine.addEntity(rainbowAnodizedMetalWall6)
rainbowAnodizedMetalWall6.setParent(_scene)
rainbowAnodizedMetalWall6.addComponentOrReplace(gltfShape11)
const transform85 = new Transform({
  position: new Vector3(3.6120033264160156, 17.448219299316406, 15.687798500061035),
  rotation: new Quaternion(0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(19.337778091430664, 4.569081783294678, 185.62701416015625)
})
rainbowAnodizedMetalWall6.addComponentOrReplace(transform85)

const rainbowAnodizedMetalWall7 = new Entity('rainbowAnodizedMetalWall7')
engine.addEntity(rainbowAnodizedMetalWall7)
rainbowAnodizedMetalWall7.setParent(_scene)
rainbowAnodizedMetalWall7.addComponentOrReplace(gltfShape11)
const transform86 = new Transform({
  position: new Vector3(4.146366119384766, 17.762237548828125, 15.687799453735352),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(1.4697957038879395, 10.876404762268066, 185.6255340576172)
})
rainbowAnodizedMetalWall7.addComponentOrReplace(transform86)

const rainbowAnodizedMetalWall8 = new Entity('rainbowAnodizedMetalWall8')
engine.addEntity(rainbowAnodizedMetalWall8)
rainbowAnodizedMetalWall8.setParent(_scene)
rainbowAnodizedMetalWall8.addComponentOrReplace(gltfShape11)
const transform87 = new Transform({
  position: new Vector3(7.9271440505981445, 18.603689193725586, 15.687797546386719),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(29.790172576904297, 4.5690598487854, 185.6255340576172)
})
rainbowAnodizedMetalWall8.addComponentOrReplace(transform87)

const rainbowAnodizedMetalWall9 = new Entity('rainbowAnodizedMetalWall9')
engine.addEntity(rainbowAnodizedMetalWall9)
rainbowAnodizedMetalWall9.setParent(_scene)
rainbowAnodizedMetalWall9.addComponentOrReplace(gltfShape11)
const transform88 = new Transform({
  position: new Vector3(11.860749244689941, 17.762237548828125, 15.687799453735352),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(1.4697957038879395, 10.876404762268066, 185.6255340576172)
})
rainbowAnodizedMetalWall9.addComponentOrReplace(transform88)

const cleanGoldWall4 = new Entity('cleanGoldWall4')
engine.addEntity(cleanGoldWall4)
cleanGoldWall4.setParent(_scene)
cleanGoldWall4.addComponentOrReplace(gltfShape12)
const transform89 = new Transform({
  position: new Vector3(12.8604154586792, 15.13286018371582, 15.725790977478027),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(9.793137550354004, 23.977981567382812, 128.51116943359375)
})
cleanGoldWall4.addComponentOrReplace(transform89)

const rainbowAnodizedMetalWall10 = new Entity('rainbowAnodizedMetalWall10')
engine.addEntity(rainbowAnodizedMetalWall10)
rainbowAnodizedMetalWall10.setParent(_scene)
rainbowAnodizedMetalWall10.addComponentOrReplace(gltfShape11)
const transform90 = new Transform({
  position: new Vector3(13.298455238342285, 17.448219299316406, 15.687799453735352),
  rotation: new Quaternion(0.7071068286895752, -0.7071068286895752, 1.3697726330974547e-7, 3.1610131401293984e-8),
  scale: new Vector3(19.33778190612793, 4.569082736968994, 185.6268768310547)
})
rainbowAnodizedMetalWall10.addComponentOrReplace(transform90)

const cleanGoldWall5 = new Entity('cleanGoldWall5')
engine.addEntity(cleanGoldWall5)
cleanGoldWall5.setParent(_scene)
cleanGoldWall5.addComponentOrReplace(gltfShape12)
const transform91 = new Transform({
  position: new Vector3(4.292730331420898, 18.93924903869629, 15.725790023803711),
  rotation: new Quaternion(-0.7071068286895752, -0.7071068286895752, 3.1610131401293984e-8, -1.3697726330974547e-7),
  scale: new Vector3(9.793173789978027, 37.540164947509766, 128.51173400878906)
})
cleanGoldWall5.addComponentOrReplace(transform91)

const cleanGoldWall6 = new Entity('cleanGoldWall6')
engine.addEntity(cleanGoldWall6)
cleanGoldWall6.setParent(_scene)
cleanGoldWall6.addComponentOrReplace(gltfShape12)
const transform92 = new Transform({
  position: new Vector3(3.173964500427246, 15.13286018371582, 15.725790977478027),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(9.793137550354004, 23.977981567382812, 128.51116943359375)
})
cleanGoldWall6.addComponentOrReplace(transform92)

const tripleSpotlight = new Entity('tripleSpotlight')
engine.addEntity(tripleSpotlight)
tripleSpotlight.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(9.896744728088379, 16.219770431518555, 3.058661460876465),
  rotation: new Quaternion(-0.35230472683906555, -3.9424230359471475e-18, 4.199799263915338e-8, 0.9358854293823242),
  scale: new Vector3(1.2359554767608643, 1, 1)
})
tripleSpotlight.addComponentOrReplace(transform93)

const tripleSpotlight2 = new Entity('tripleSpotlight2')
engine.addEntity(tripleSpotlight2)
tripleSpotlight2.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(6.2534685134887695, 16.219770431518555, 3.058661460876465),
  rotation: new Quaternion(-0.35230472683906555, -3.9424230359471475e-18, 4.199799263915338e-8, 0.9358854293823242),
  scale: new Vector3(1.2359554767608643, 1, 1)
})
tripleSpotlight2.addComponentOrReplace(transform94)

const pyramidBrass = new Entity('pyramidBrass')
engine.addEntity(pyramidBrass)
pyramidBrass.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(7.989105224609375, 13.823516845703125, 7.986518859863281),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.30491742491722107, 0.483074814081192, 0.30315452814102173)
})
pyramidBrass.addComponentOrReplace(transform95)
const gltfShape13 = new GLTFShape("models/Pyramid_-Brass.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
pyramidBrass.addComponentOrReplace(gltfShape13)

const armchairA5 = new Entity('armchairA5')
engine.addEntity(armchairA5)
armchairA5.setParent(_scene)
armchairA5.addComponentOrReplace(gltfShape6)
const transform96 = new Transform({
  position: new Vector3(8.047664642333984, 15.069643020629883, 0.976435661315918),
  rotation: new Quaternion(-1.5092505899010587e-14, -1.4901159772762185e-7, 2.0227749867891137e-14, 1),
  scale: new Vector3(5.237331867218018, 1, 1.000000238418579)
})
armchairA5.addComponentOrReplace(transform96)

const pillarTraditional = new Entity('pillarTraditional')
engine.addEntity(pillarTraditional)
pillarTraditional.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(1.5250078439712524, 15.030781745910645, 1.502684473991394),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.186615467071533, 1.240671157836914, 2.1303787231445312)
})
pillarTraditional.addComponentOrReplace(transform97)
const gltfShape14 = new GLTFShape("models/TraditionalPillar.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
pillarTraditional.addComponentOrReplace(gltfShape14)

const pillarTraditional2 = new Entity('pillarTraditional2')
engine.addEntity(pillarTraditional2)
pillarTraditional2.setParent(_scene)
pillarTraditional2.addComponentOrReplace(gltfShape14)
const transform98 = new Transform({
  position: new Vector3(16, 15.030781745910645, 1.5026841163635254),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.186615467071533, 1.240671157836914, 2.1303787231445312)
})
pillarTraditional2.addComponentOrReplace(transform98)

const rainLight = new Entity('rainLight')
engine.addEntity(rainLight)
rainLight.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(0.7376537322998047, 0.1411571502685547, 15.135163307189941),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 3.7602765560150146, 1.4806699752807617)
})
rainLight.addComponentOrReplace(transform99)

const pillarTraditional3 = new Entity('pillarTraditional3')
engine.addEntity(pillarTraditional3)
pillarTraditional3.setParent(_scene)
pillarTraditional3.addComponentOrReplace(gltfShape14)
const transform100 = new Transform({
  position: new Vector3(1.5290884971618652, 15.030781745910645, 15.999984741210938),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.186615467071533, 1.240671157836914, 2.1303787231445312)
})
pillarTraditional3.addComponentOrReplace(transform100)

const rainLight4 = new Entity('rainLight4')
engine.addEntity(rainLight4)
rainLight4.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(15.1842041015625, 0.1411571502685547, 15.135163307189941),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 3.7602765560150146, 1.4806699752807617)
})
rainLight4.addComponentOrReplace(transform101)

const pillarTraditional4 = new Entity('pillarTraditional4')
engine.addEntity(pillarTraditional4)
pillarTraditional4.setParent(_scene)
pillarTraditional4.addComponentOrReplace(gltfShape14)
const transform102 = new Transform({
  position: new Vector3(16, 15.030781745910645, 15.999984741210938),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.186615467071533, 1.240671157836914, 2.1303787231445312)
})
pillarTraditional4.addComponentOrReplace(transform102)

const rainbowAnodizedMetalWall11 = new Entity('rainbowAnodizedMetalWall11')
engine.addEntity(rainbowAnodizedMetalWall11)
rainbowAnodizedMetalWall11.setParent(_scene)
rainbowAnodizedMetalWall11.addComponentOrReplace(gltfShape11)
const transform103 = new Transform({
  position: new Vector3(15.580321311950684, 17.448219299316406, 2.715336322784424),
  rotation: new Quaternion(0.5000000596046448, -0.5000000596046448, -0.49999991059303284, 0.5),
  scale: new Vector3(19.337787628173828, 4.569084644317627, 185.6270294189453)
})
rainbowAnodizedMetalWall11.addComponentOrReplace(transform103)

const cleanGoldWall7 = new Entity('cleanGoldWall7')
engine.addEntity(cleanGoldWall7)
cleanGoldWall7.setParent(_scene)
cleanGoldWall7.addComponentOrReplace(gltfShape12)
const transform104 = new Transform({
  position: new Vector3(15.61831283569336, 15.132859230041504, 3.1533761024475098),
  rotation: new Quaternion(4.731725943138074e-15, -0.70710688829422, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(9.7931489944458, 23.977981567382812, 128.5113525390625)
})
cleanGoldWall7.addComponentOrReplace(transform104)

const rainbowAnodizedMetalWall12 = new Entity('rainbowAnodizedMetalWall12')
engine.addEntity(rainbowAnodizedMetalWall12)
rainbowAnodizedMetalWall12.setParent(_scene)
rainbowAnodizedMetalWall12.addComponentOrReplace(gltfShape11)
const transform105 = new Transform({
  position: new Vector3(15.580321311950684, 17.762237548828125, 4.153041839599609),
  rotation: new Quaternion(4.731725943138074e-15, -0.70710688829422, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(1.4697943925857544, 10.876404762268066, 185.6253662109375)
})
rainbowAnodizedMetalWall12.addComponentOrReplace(transform105)

const cleanGoldWall8 = new Entity('cleanGoldWall8')
engine.addEntity(cleanGoldWall8)
cleanGoldWall8.setParent(_scene)
cleanGoldWall8.addComponentOrReplace(gltfShape12)
const transform106 = new Transform({
  position: new Vector3(15.61831283569336, 18.93924903869629, 11.717934608459473),
  rotation: new Quaternion(-0.5000000596046448, -0.5000000596046448, 0.5, 0.49999991059303284),
  scale: new Vector3(9.793174743652344, 37.5401725769043, 128.51177978515625)
})
cleanGoldWall8.addComponentOrReplace(transform106)

const rainbowAnodizedMetalWall13 = new Entity('rainbowAnodizedMetalWall13')
engine.addEntity(rainbowAnodizedMetalWall13)
rainbowAnodizedMetalWall13.setParent(_scene)
rainbowAnodizedMetalWall13.addComponentOrReplace(gltfShape11)
const transform107 = new Transform({
  position: new Vector3(15.580320358276367, 18.603689193725586, 8.086647987365723),
  rotation: new Quaternion(4.731725943138074e-15, -0.70710688829422, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(29.790218353271484, 4.5690598487854, 185.62527465820312)
})
rainbowAnodizedMetalWall13.addComponentOrReplace(transform107)

const rainbowAnodizedMetalWall14 = new Entity('rainbowAnodizedMetalWall14')
engine.addEntity(rainbowAnodizedMetalWall14)
rainbowAnodizedMetalWall14.setParent(_scene)
rainbowAnodizedMetalWall14.addComponentOrReplace(gltfShape11)
const transform108 = new Transform({
  position: new Vector3(15.580322265625, 17.762237548828125, 11.867426872253418),
  rotation: new Quaternion(4.731725943138074e-15, -0.70710688829422, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(1.4697939157485962, 10.876404762268066, 185.62530517578125)
})
rainbowAnodizedMetalWall14.addComponentOrReplace(transform108)

const rainbowAnodizedMetalWall15 = new Entity('rainbowAnodizedMetalWall15')
engine.addEntity(rainbowAnodizedMetalWall15)
rainbowAnodizedMetalWall15.setParent(_scene)
rainbowAnodizedMetalWall15.addComponentOrReplace(gltfShape11)
const transform109 = new Transform({
  position: new Vector3(15.580321311950684, 17.448219299316406, 12.401789665222168),
  rotation: new Quaternion(0.5000000596046448, -0.5000000596046448, -0.49999991059303284, 0.5),
  scale: new Vector3(19.337783813476562, 4.5690836906433105, 185.62716674804688)
})
rainbowAnodizedMetalWall15.addComponentOrReplace(transform109)

const cleanGoldWall9 = new Entity('cleanGoldWall9')
engine.addEntity(cleanGoldWall9)
cleanGoldWall9.setParent(_scene)
cleanGoldWall9.addComponentOrReplace(gltfShape12)
const transform110 = new Transform({
  position: new Vector3(15.618313789367676, 15.13286018371582, 12.839827537536621),
  rotation: new Quaternion(4.731725943138074e-15, -0.70710688829422, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(9.7931489944458, 23.977981567382812, 128.5113525390625)
})
cleanGoldWall9.addComponentOrReplace(transform110)

const rainbowAnodizedMetalWall16 = new Entity('rainbowAnodizedMetalWall16')
engine.addEntity(rainbowAnodizedMetalWall16)
rainbowAnodizedMetalWall16.setParent(_scene)
rainbowAnodizedMetalWall16.addComponentOrReplace(gltfShape11)
const transform111 = new Transform({
  position: new Vector3(0.49839186668395996, 17.44822120666504, 13.338194847106934),
  rotation: new Quaternion(-0.4999999701976776, 0.4999999403953552, -0.5000001192092896, 0.5),
  scale: new Vector3(19.337787628173828, 4.569084644317627, 185.6270294189453)
})
rainbowAnodizedMetalWall16.addComponentOrReplace(transform111)

const cleanGoldWall10 = new Entity('cleanGoldWall10')
engine.addEntity(cleanGoldWall10)
cleanGoldWall10.setParent(_scene)
cleanGoldWall10.addComponentOrReplace(gltfShape12)
const transform112 = new Transform({
  position: new Vector3(0.4604003429412842, 15.13286018371582, 12.900155067443848),
  rotation: new Quaternion(-1.1233005357044051e-14, 0.7071067690849304, -8.429368847373553e-8, 0.70710688829422),
  scale: new Vector3(9.793160438537598, 23.977981567382812, 128.51153564453125)
})
cleanGoldWall10.addComponentOrReplace(transform112)

const rainbowAnodizedMetalWall17 = new Entity('rainbowAnodizedMetalWall17')
engine.addEntity(rainbowAnodizedMetalWall17)
rainbowAnodizedMetalWall17.setParent(_scene)
rainbowAnodizedMetalWall17.addComponentOrReplace(gltfShape11)
const transform113 = new Transform({
  position: new Vector3(0.49839186668395996, 17.762237548828125, 11.900489807128906),
  rotation: new Quaternion(-1.1233005357044051e-14, 0.7071067690849304, -8.429368847373553e-8, 0.70710688829422),
  scale: new Vector3(1.4697924852371216, 10.876404762268066, 185.6251220703125)
})
rainbowAnodizedMetalWall17.addComponentOrReplace(transform113)

const cleanGoldWall11 = new Entity('cleanGoldWall11')
engine.addEntity(cleanGoldWall11)
cleanGoldWall11.setParent(_scene)
cleanGoldWall11.addComponentOrReplace(gltfShape12)
const transform114 = new Transform({
  position: new Vector3(0.4604003429412842, 18.939247131347656, 4.335596561431885),
  rotation: new Quaternion(0.4999999403953552, 0.4999999701976776, 0.5, 0.5000001192092896),
  scale: new Vector3(9.793174743652344, 37.5401725769043, 128.51177978515625)
})
cleanGoldWall11.addComponentOrReplace(transform114)

const rainbowAnodizedMetalWall18 = new Entity('rainbowAnodizedMetalWall18')
engine.addEntity(rainbowAnodizedMetalWall18)
rainbowAnodizedMetalWall18.setParent(_scene)
rainbowAnodizedMetalWall18.addComponentOrReplace(gltfShape11)
const transform115 = new Transform({
  position: new Vector3(0.49839282035827637, 18.603689193725586, 7.966883182525635),
  rotation: new Quaternion(-1.1233005357044051e-14, 0.7071067690849304, -8.429368847373553e-8, 0.70710688829422),
  scale: new Vector3(29.790264129638672, 4.5690598487854, 185.6251220703125)
})
rainbowAnodizedMetalWall18.addComponentOrReplace(transform115)

const rainbowAnodizedMetalWall19 = new Entity('rainbowAnodizedMetalWall19')
engine.addEntity(rainbowAnodizedMetalWall19)
rainbowAnodizedMetalWall19.setParent(_scene)
rainbowAnodizedMetalWall19.addComponentOrReplace(gltfShape11)
const transform116 = new Transform({
  position: new Vector3(0.49839091300964355, 17.762237548828125, 4.186104774475098),
  rotation: new Quaternion(-1.1233005357044051e-14, 0.7071067690849304, -8.429368847373553e-8, 0.70710688829422),
  scale: new Vector3(1.4697924852371216, 10.876404762268066, 185.6251220703125)
})
rainbowAnodizedMetalWall19.addComponentOrReplace(transform116)

const rainbowAnodizedMetalWall20 = new Entity('rainbowAnodizedMetalWall20')
engine.addEntity(rainbowAnodizedMetalWall20)
rainbowAnodizedMetalWall20.setParent(_scene)
rainbowAnodizedMetalWall20.addComponentOrReplace(gltfShape11)
const transform117 = new Transform({
  position: new Vector3(0.49839138984680176, 17.448217391967773, 3.6517419815063477),
  rotation: new Quaternion(-0.4999999701976776, 0.4999999403953552, -0.5000001192092896, 0.5),
  scale: new Vector3(19.337783813476562, 4.5690836906433105, 185.62716674804688)
})
rainbowAnodizedMetalWall20.addComponentOrReplace(transform117)

const cleanGoldWall12 = new Entity('cleanGoldWall12')
engine.addEntity(cleanGoldWall12)
cleanGoldWall12.setParent(_scene)
cleanGoldWall12.addComponentOrReplace(gltfShape12)
const transform118 = new Transform({
  position: new Vector3(0.4603993892669678, 15.132859230041504, 3.2137041091918945),
  rotation: new Quaternion(-1.1233005357044051e-14, 0.7071067690849304, -8.429368847373553e-8, 0.70710688829422),
  scale: new Vector3(9.793160438537598, 23.977981567382812, 128.51153564453125)
})
cleanGoldWall12.addComponentOrReplace(transform118)

const tripleSpotlight3 = new Entity('tripleSpotlight3')
engine.addEntity(tripleSpotlight3)
tripleSpotlight3.setParent(_scene)
const transform119 = new Transform({
  position: new Vector3(9.403002738952637, 16.219770431518555, 12.994894027709961),
  rotation: new Quaternion(5.249748724622805e-8, 0.9358854293823242, 0.352304607629776, -2.7891552178971324e-8),
  scale: new Vector3(1.0825791358947754, 1.000000238418579, 1.0000019073486328)
})
tripleSpotlight3.addComponentOrReplace(transform119)

const tripleSpotlight4 = new Entity('tripleSpotlight4')
engine.addEntity(tripleSpotlight4)
tripleSpotlight4.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(6.211849689483643, 16.219770431518555, 12.994894027709961),
  rotation: new Quaternion(5.249748724622805e-8, 0.9358854293823242, 0.352304607629776, -2.7891552178971324e-8),
  scale: new Vector3(1.0825791358947754, 1.000000238418579, 1.0000019073486328)
})
tripleSpotlight4.addComponentOrReplace(transform120)

const tripleSpotlight5 = new Entity('tripleSpotlight5')
engine.addEntity(tripleSpotlight5)
tripleSpotlight5.setParent(_scene)
const transform121 = new Transform({
  position: new Vector3(12.878740310668945, 16.219770431518555, 6.5478129386901855),
  rotation: new Quaternion(0.24911706149578094, 0.6617709398269653, 0.2491169273853302, -0.6617709398269653),
  scale: new Vector3(1.0825810432434082, 1.0000003576278687, 1.0000038146972656)
})
tripleSpotlight5.addComponentOrReplace(transform121)

const tripleSpotlight6 = new Entity('tripleSpotlight6')
engine.addEntity(tripleSpotlight6)
tripleSpotlight6.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(12.878740310668945, 16.219770431518555, 9.738966941833496),
  rotation: new Quaternion(0.24911706149578094, 0.6617709398269653, 0.2491169273853302, -0.6617709398269653),
  scale: new Vector3(1.0825810432434082, 1.0000003576278687, 1.0000038146972656)
})
tripleSpotlight6.addComponentOrReplace(transform122)

const tripleSpotlight7 = new Entity('tripleSpotlight7')
engine.addEntity(tripleSpotlight7)
tripleSpotlight7.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(3.2102346420288086, 16.219770431518555, 9.633258819580078),
  rotation: new Quaternion(-0.24911700189113617, 0.6617709398269653, 0.24911698698997498, 0.6617709398269653),
  scale: new Vector3(1.0825824737548828, 1.0000003576278687, 1.0000050067901611)
})
tripleSpotlight7.addComponentOrReplace(transform123)

const tripleSpotlight8 = new Entity('tripleSpotlight8')
engine.addEntity(tripleSpotlight8)
tripleSpotlight8.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(3.2102346420288086, 16.219770431518555, 6.442105293273926),
  rotation: new Quaternion(-0.24911700189113617, 0.6617709398269653, 0.24911698698997498, 0.6617709398269653),
  scale: new Vector3(1.0825824737548828, 1.0000003576278687, 1.0000050067901611)
})
tripleSpotlight8.addComponentOrReplace(transform124)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(12.815662384033203, 15.5, 0.4690885543823242),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.947117805480957, 4.415460109710693, 0.2710545063018799)
})
invisibleWall.addComponentOrReplace(transform125)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(3.164788246154785, 15.5, 0.46908968687057495),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.947117805480957, 4.415460109710693, 0.2710545063018799)
})
invisibleWall2.addComponentOrReplace(transform126)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform127 = new Transform({
  position: new Vector3(3.164788246154785, 15.5, 15.583466529846191),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.947117805480957, 4.415460109710693, 0.2710545063018799)
})
invisibleWall3.addComponentOrReplace(transform127)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(12.815662384033203, 15.5, 15.583464622497559),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.947117805480957, 4.415460109710693, 0.2710545063018799)
})
invisibleWall4.addComponentOrReplace(transform128)

const invisibleWall5 = new Entity('invisibleWall5')
engine.addEntity(invisibleWall5)
invisibleWall5.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(15.47096061706543, 15.5, 12.851714134216309),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.9471192359924316, 4.415460109710693, 0.2603965103626251)
})
invisibleWall5.addComponentOrReplace(transform129)

const invisibleWall6 = new Entity('invisibleWall6')
engine.addEntity(invisibleWall6)
invisibleWall6.setParent(_scene)
const transform130 = new Transform({
  position: new Vector3(15.470958709716797, 15.499998092651367, 3.200839042663574),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.9471192359924316, 4.415460109710693, 0.2603965103626251)
})
invisibleWall6.addComponentOrReplace(transform130)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(0.6270829439163208, 15.500001907348633, 12.851716041564941),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.9471197128295898, 4.415460109710693, 0.2603965699672699)
})
invisibleWall7.addComponentOrReplace(transform131)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(0.627081036567688, 15.5, 3.200840950012207),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.9471197128295898, 4.415460109710693, 0.2603965699672699)
})
invisibleWall8.addComponentOrReplace(transform132)

const speakers2 = new Entity('speakers2')
engine.addEntity(speakers2)
speakers2.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(13.046891212463379, 17.489513397216797, 0.6196037530899048),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5953385829925537, 1, 0.22162961959838867)
})
speakers2.addComponentOrReplace(transform133)

const speakers3 = new Entity('speakers3')
engine.addEntity(speakers3)
speakers3.setParent(_scene)
const transform134 = new Transform({
  position: new Vector3(12.580790519714355, 17.33344268798828, 0.6196038126945496),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(0.5953385829925537, 1, 0.22162961959838867)
})
speakers3.addComponentOrReplace(transform134)

const speakers = new Entity('speakers')
engine.addEntity(speakers)
speakers.setParent(_scene)
const transform135 = new Transform({
  position: new Vector3(2.8925139904022217, 17.33344268798828, 0.6196049451828003),
  rotation: new Quaternion(0, 0, -1, 0),
  scale: new Vector3(0.5953385829925537, 1, 0.22162961959838867)
})
speakers.addComponentOrReplace(transform135)

const speakers4 = new Entity('speakers4')
engine.addEntity(speakers4)
speakers4.setParent(_scene)
const transform136 = new Transform({
  position: new Vector3(3.358614683151245, 17.489513397216797, 0.6196048855781555),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5953385829925537, 1, 0.22162961959838867)
})
speakers4.addComponentOrReplace(transform136)

const wallBrass = new Entity('wallBrass')
engine.addEntity(wallBrass)
wallBrass.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(0.03277587890625, 0.03917741775512695, 7.825080871582031),
  rotation: new Quaternion(0.13794969022274017, 0.6935199499130249, -0.13794977962970734, 0.6935199499130249),
  scale: new Vector3(0.34646475315093994, 0.1227225586771965, 0.0691150352358818)
})
wallBrass.addComponentOrReplace(transform137)
const gltfShape15 = new GLTFShape("models/Wall_- Brass.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
wallBrass.addComponentOrReplace(gltfShape15)

const wallBrass2 = new Entity('wallBrass2')
engine.addEntity(wallBrass2)
wallBrass2.setParent(_scene)
wallBrass2.addComponentOrReplace(gltfShape15)
const transform138 = new Transform({
  position: new Vector3(1.555637001991272, 3.715688705444336, 8.12971019744873),
  rotation: new Quaternion(0.13794969022274017, 0.6935199499130249, -0.13794977962970734, 0.6935199499130249),
  scale: new Vector3(0.25116774439811707, 0.10596705973148346, 0.06911519169807434)
})
wallBrass2.addComponentOrReplace(transform138)

const wallBrass3 = new Entity('wallBrass3')
engine.addEntity(wallBrass3)
wallBrass3.setParent(_scene)
wallBrass3.addComponentOrReplace(gltfShape15)
const transform139 = new Transform({
  position: new Vector3(2.871958017349243, 6.893568515777588, 8.12971019744873),
  rotation: new Quaternion(0.13794969022274017, 0.6935199499130249, -0.13794977962970734, 0.6935199499130249),
  scale: new Vector3(0.16829830408096313, 0.1152607724070549, 0.06911525130271912)
})
wallBrass3.addComponentOrReplace(transform139)

const wallBrass4 = new Entity('wallBrass4')
engine.addEntity(wallBrass4)
wallBrass4.setParent(_scene)
wallBrass4.addComponentOrReplace(gltfShape15)
const transform140 = new Transform({
  position: new Vector3(4.300706386566162, 10.34287166595459, 7.950986862182617),
  rotation: new Quaternion(0.13794969022274017, 0.6935199499130249, -0.13794977962970734, 0.6935199499130249),
  scale: new Vector3(0.11063570529222488, 0.11740590631961823, 0.06911541521549225)
})
wallBrass4.addComponentOrReplace(transform140)

const wallBrass5 = new Entity('wallBrass5')
engine.addEntity(wallBrass5)
wallBrass5.setParent(_scene)
wallBrass5.addComponentOrReplace(gltfShape15)
const transform141 = new Transform({
  position: new Vector3(11.683635711669922, 10.34287166595459, 8.003803253173828),
  rotation: new Quaternion(-0.13794969022274017, 0.6935199499130249, -0.13794977962970734, -0.6935199499130249),
  scale: new Vector3(0.11063585430383682, 0.11740590631961823, 0.0691155195236206)
})
wallBrass5.addComponentOrReplace(transform141)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(13.030722618103027, 7.176921844482422, 7.9016499519348145),
  rotation: new Quaternion(-0.13794967532157898, 0.6935199499130249, 0.13794958591461182, 0.6935199499130249),
  scale: new Vector3(8.453238487243652, 6.31178092956543, 0.726130485534668)
})
nftPictureFrame.addComponentOrReplace(transform142)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform143 = new Transform({
  position: new Vector3(14.490205764770508, 3.676921844482422, 7.966648578643799),
  rotation: new Quaternion(-0.13794969022274017, 0.6935199499130249, 0.137949600815773, 0.6935199499130249),
  scale: new Vector3(6.330580711364746, 6.330521583557129, 0.7282846570014954)
})
nftPictureFrame5.addComponentOrReplace(transform143)

const nftPictureFrame25 = new Entity('nftPictureFrame25')
engine.addEntity(nftPictureFrame25)
nftPictureFrame25.setParent(_scene)
const transform144 = new Transform({
  position: new Vector3(15.487817764282227, 1.2878732681274414, 7.866087913513184),
  rotation: new Quaternion(0.13794969022274017, -0.6935199499130249, -0.137949600815773, -0.6935199499130249),
  scale: new Vector3(13.500175476074219, 4.555156707763672, 1.0000067949295044)
})
nftPictureFrame25.addComponentOrReplace(transform144)

const wallBrass6 = new Entity('wallBrass6')
engine.addEntity(wallBrass6)
wallBrass6.setParent(_scene)
wallBrass6.addComponentOrReplace(gltfShape15)
const transform145 = new Transform({
  position: new Vector3(15.951566696166992, 0.03917741775512695, 8.129711151123047),
  rotation: new Quaternion(-0.13794969022274017, 0.6935199499130249, -0.13794977962970734, -0.6935199499130249),
  scale: new Vector3(0.3464643061161041, 0.12272252142429352, 0.06911513209342957)
})
wallBrass6.addComponentOrReplace(transform145)

const wallBrass7 = new Entity('wallBrass7')
engine.addEntity(wallBrass7)
wallBrass7.setParent(_scene)
wallBrass7.addComponentOrReplace(gltfShape15)
const transform146 = new Transform({
  position: new Vector3(14.428705215454102, 3.715688705444336, 7.8250813484191895),
  rotation: new Quaternion(-0.13794969022274017, 0.6935199499130249, -0.13794977962970734, -0.6935199499130249),
  scale: new Vector3(0.25116804242134094, 0.1059669628739357, 0.06911532580852509)
})
wallBrass7.addComponentOrReplace(transform146)

const wallBrass8 = new Entity('wallBrass8')
engine.addEntity(wallBrass8)
wallBrass8.setParent(_scene)
wallBrass8.addComponentOrReplace(gltfShape15)
const transform147 = new Transform({
  position: new Vector3(13.112384796142578, 6.893568515777588, 7.825080394744873),
  rotation: new Quaternion(-0.13794969022274017, 0.6935199499130249, -0.13794977962970734, -0.6935199499130249),
  scale: new Vector3(0.16829831898212433, 0.11526071280241013, 0.06911534070968628)
})
wallBrass8.addComponentOrReplace(transform147)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform148 = new Transform({
  position: new Vector3(8.103148460388184, 1.2878742218017578, 15.472709655761719),
  rotation: new Quaternion(0.19509032368659973, -8.940696716308594e-8, -6.305284294683133e-9, -0.9807852506637573),
  scale: new Vector3(13.500158309936523, 4.555156707763672, 1.0000067949295044)
})
nftPictureFrame6.addComponentOrReplace(transform148)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform149 = new Transform({
  position: new Vector3(8.00258731842041, 3.676922559738159, 14.47509765625),
  rotation: new Quaternion(-0.19509032368659973, 8.940696716308594e-8, 6.305284294683133e-9, 0.9807852506637573),
  scale: new Vector3(6.330574035644531, 6.330521106719971, 0.7282845973968506)
})
nftPictureFrame7.addComponentOrReplace(transform149)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform150 = new Transform({
  position: new Vector3(8.067585945129395, 7.17692232131958, 13.015613555908203),
  rotation: new Quaternion(-0.19509029388427734, 8.940696716308594e-8, 1.3755864891606961e-8, 0.9807852506637573),
  scale: new Vector3(8.45323657989502, 6.31178092956543, 0.7261303663253784)
})
nftPictureFrame8.addComponentOrReplace(transform150)

const wallBrass9 = new Entity('wallBrass9')
engine.addEntity(wallBrass9)
wallBrass9.setParent(_scene)
wallBrass9.addComponentOrReplace(gltfShape15)
const transform151 = new Transform({
  position: new Vector3(7.9654316902160645, 10.342872619628906, 11.668527603149414),
  rotation: new Quaternion(-1.4901160305669237e-8, 0.9807852506637573, -0.19509044289588928, -8.940696716308594e-8),
  scale: new Vector3(0.11063583195209503, 0.11740590631961823, 0.06911550462245941)
})
wallBrass9.addComponentOrReplace(transform151)

const wallBrass10 = new Entity('wallBrass10')
engine.addEntity(wallBrass10)
wallBrass10.setParent(_scene)
wallBrass10.addComponentOrReplace(gltfShape15)
const transform152 = new Transform({
  position: new Vector3(8.144155502319336, 6.893568992614746, 13.09727668762207),
  rotation: new Quaternion(-1.4901160305669237e-8, 0.9807852506637573, -0.19509044289588928, -8.940696716308594e-8),
  scale: new Vector3(0.1682983636856079, 0.11526075005531311, 0.06911532580852509)
})
wallBrass10.addComponentOrReplace(transform152)

const wallBrass11 = new Entity('wallBrass11')
engine.addEntity(wallBrass11)
wallBrass11.setParent(_scene)
wallBrass11.addComponentOrReplace(gltfShape15)
const transform153 = new Transform({
  position: new Vector3(8.14415454864502, 3.7156894207000732, 14.413597106933594),
  rotation: new Quaternion(-1.4901160305669237e-8, 0.9807852506637573, -0.19509044289588928, -8.940696716308594e-8),
  scale: new Vector3(0.25116798281669617, 0.10596701502799988, 0.06911531090736389)
})
wallBrass11.addComponentOrReplace(transform153)

const wallBrass12 = new Entity('wallBrass12')
engine.addEntity(wallBrass12)
wallBrass12.setParent(_scene)
wallBrass12.addComponentOrReplace(gltfShape15)
const transform154 = new Transform({
  position: new Vector3(7.8395256996154785, 0.03917837142944336, 15.936458587646484),
  rotation: new Quaternion(-1.4901160305669237e-8, 0.9807852506637573, -0.19509044289588928, -8.940696716308594e-8),
  scale: new Vector3(0.34646475315093994, 0.12272252887487411, 0.06911511719226837)
})
wallBrass12.addComponentOrReplace(transform154)

const nftPictureFrame26 = new Entity('nftPictureFrame26')
engine.addEntity(nftPictureFrame26)
nftPictureFrame26.setParent(_scene)
const transform155 = new Transform({
  position: new Vector3(7.916093349456787, 7.176921367645264, 2.978649854660034),
  rotation: new Quaternion(-1.4901162970204496e-8, -0.9807853102684021, -0.195090189576149, 8.94069742685133e-8),
  scale: new Vector3(8.453227043151855, 6.311789035797119, 0.7261296510696411)
})
nftPictureFrame26.addComponentOrReplace(transform155)

const nftPictureFrame27 = new Entity('nftPictureFrame27')
engine.addEntity(nftPictureFrame27)
nftPictureFrame27.setParent(_scene)
const transform156 = new Transform({
  position: new Vector3(7.981091022491455, 3.6769211292266846, 1.5191667079925537),
  rotation: new Quaternion(-2.2351743567128324e-8, -0.9807853102684021, -0.19509021937847137, 8.94069742685133e-8),
  scale: new Vector3(6.330559253692627, 6.330522060394287, 0.7282841205596924)
})
nftPictureFrame27.addComponentOrReplace(transform156)

const nftPictureFrame28 = new Entity('nftPictureFrame28')
engine.addEntity(nftPictureFrame28)
nftPictureFrame28.setParent(_scene)
const transform157 = new Transform({
  position: new Vector3(7.880529880523682, 1.287872314453125, 0.521554708480835),
  rotation: new Quaternion(2.2351743567128324e-8, 0.9807853102684021, 0.19509021937847137, -8.94069742685133e-8),
  scale: new Vector3(13.500130653381348, 4.555156230926514, 1.0000059604644775)
})
nftPictureFrame28.addComponentOrReplace(transform157)

const wallBrass13 = new Entity('wallBrass13')
engine.addEntity(wallBrass13)
wallBrass13.setParent(_scene)
wallBrass13.addComponentOrReplace(gltfShape15)
const transform158 = new Transform({
  position: new Vector3(8.144153594970703, 0.03917646408081055, 0.05780625343322754),
  rotation: new Quaternion(0.19509033858776093, 8.94069742685133e-8, -1.604645838426677e-8, 0.9807853102684021),
  scale: new Vector3(0.34646475315093994, 0.1227225512266159, 0.0691150352358818)
})
wallBrass13.addComponentOrReplace(transform158)

const wallBrass14 = new Entity('wallBrass14')
engine.addEntity(wallBrass14)
wallBrass14.setParent(_scene)
wallBrass14.addComponentOrReplace(gltfShape15)
const transform159 = new Transform({
  position: new Vector3(7.839523792266846, 3.7156879901885986, 1.5806667804718018),
  rotation: new Quaternion(0.19509033858776093, 8.94069742685133e-8, -1.604645838426677e-8, 0.9807853102684021),
  scale: new Vector3(0.25116774439811707, 0.10596705973148346, 0.06911519169807434)
})
wallBrass14.addComponentOrReplace(transform159)

const wallBrass15 = new Entity('wallBrass15')
engine.addEntity(wallBrass15)
wallBrass15.setParent(_scene)
wallBrass15.addComponentOrReplace(gltfShape15)
const transform160 = new Transform({
  position: new Vector3(7.839523792266846, 6.89356803894043, 2.8969881534576416),
  rotation: new Quaternion(0.19509033858776093, 8.94069742685133e-8, -1.604645838426677e-8, 0.9807853102684021),
  scale: new Vector3(0.16829830408096313, 0.1152607649564743, 0.06911525130271912)
})
wallBrass15.addComponentOrReplace(transform160)

const wallBrass16 = new Entity('wallBrass16')
engine.addEntity(wallBrass16)
wallBrass16.setParent(_scene)
wallBrass16.addComponentOrReplace(gltfShape15)
const transform161 = new Transform({
  position: new Vector3(8.0182466506958, 10.342870712280273, 4.325735092163086),
  rotation: new Quaternion(0.19509033858776093, 8.94069742685133e-8, -1.604645838426677e-8, 0.9807853102684021),
  scale: new Vector3(0.11063571274280548, 0.11740590631961823, 0.06911541521549225)
})
wallBrass16.addComponentOrReplace(transform161)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
const script9 = new Script9()
const script10 = new Script10()
const script11 = new Script11()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script9.init(options)
script10.init(options)
script11.init(options)
script1.spawn(funkyFloorLight, {"startOn":true,"clickable":true}, createChannel(channelId, funkyFloorLight, channelBus))
script2.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script2.spawn(ropeLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight2, channelBus))
script2.spawn(ropeLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight3, channelBus))
script2.spawn(ropeLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight4, channelBus))
script2.spawn(ropeLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight5, channelBus))
script2.spawn(ropeLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight6, channelBus))
script2.spawn(ropeLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight7, channelBus))
script2.spawn(ropeLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight8, channelBus))
script3.spawn(nftPictureFrame9, {"id":"69478819454877515899718247009675975988331405547157132439541098656001985347585","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script3.spawn(nftPictureFrame10, {"id":"69478819454877515899718247009675975988331405547157132439541098669196124880897","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script3.spawn(nftPictureFrame11, {"id":"69478819454877515899718247009675975988331405547157132439541098657101496975361","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:2\nPrice: .02 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script3.spawn(nftPictureFrame12, {"id":"69478819454877515899718247009675975988331405547157132439541098661499543486465","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script3.spawn(nftPictureFrame13, {"id":"69478819454877515899718247009675975988331405547157132439541098651603938836481","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame13, channelBus))
script3.spawn(nftPictureFrame14, {"id":"69478819454877515899718247009675975988331405547157132439541098654902473719809","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script3.spawn(nftPictureFrame15, {"id":"69478819454877515899718247009675975988331405547157132439541098672494659764225","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame15, channelBus))
script3.spawn(nftPictureFrame16, {"id":"69478819454877515899718247009675975988331405547157132439541098665897589997569","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame16, channelBus))
script3.spawn(nftPictureFrame17, {"id":"69478819454877515899718247009675975988331405547157132439541098653802962092033","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script3.spawn(nftPictureFrame18, {"id":"69478819454877515899718247009675975988331405547157132439541098662599055114241","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script3.spawn(nftPictureFrame19, {"id":"69478819454877515899718247009675975988331405547157132439541098670295636508673","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame19, channelBus))
script3.spawn(nftPictureFrame20, {"id":"69478819454877515899718247009675975988331405547157132439541098671395148136449","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame20, channelBus))
script3.spawn(nftPictureFrame21, {"id":"69478819454877515899718247009675975988331405547157132439541098659300520230913","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame21, channelBus))
script3.spawn(nftPictureFrame22, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: 06 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script3.spawn(nftPictureFrame23, {"id":"69478819454877515899718247009675975988331405547157132439541098663698566742017","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #:1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame23, channelBus))
script3.spawn(nftPictureFrame24, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice:  .06 ETH"}, createChannel(channelId, nftPictureFrame24, channelBus))
script4.spawn(radio, {"startOn":true,"volume":1,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/Qmbvps2kDnrUcAMc7hJq9kJoAfFNEixbFEQkyGQKJdPT6n"}, createChannel(channelId, radio, channelBus))
script3.spawn(nftPictureFrame2, {"id":"69478819454877515899718247009675975988331405547157132439541098668096613253121","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame2, channelBus))
script3.spawn(nftPictureFrame3, {"id":"72405646120007613708465591283795435405784754144165659770746301238301444538369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame3, channelBus))
script3.spawn(nftPictureFrame4, {"id":"69478819454877515899718247009675975988331405547157132439541098666997101625345","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame4, channelBus))
script5.spawn(rainLight2, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight2, channelBus))
script5.spawn(rainLight3, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight3, channelBus))
script6.spawn(verticalWhitePad, {"distance":15,"speed":6,"autoStart":false,"onReachEnd":[{"entityName":"verticalWhitePad","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalWhitePad, channelBus))
script7.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script8.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalWhitePad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalWhitePad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script9.spawn(tripleSpotlight, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight, channelBus))
script9.spawn(tripleSpotlight2, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight2, channelBus))
script5.spawn(rainLight, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight, channelBus))
script5.spawn(rainLight4, {"startOn":true,"clickable":true}, createChannel(channelId, rainLight4, channelBus))
script9.spawn(tripleSpotlight3, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight3, channelBus))
script9.spawn(tripleSpotlight4, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight4, channelBus))
script9.spawn(tripleSpotlight5, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight5, channelBus))
script9.spawn(tripleSpotlight6, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight6, channelBus))
script9.spawn(tripleSpotlight7, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight7, channelBus))
script9.spawn(tripleSpotlight8, {"startOn":true,"clickable":true}, createChannel(channelId, tripleSpotlight8, channelBus))
script10.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script10.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script10.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script10.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script10.spawn(invisibleWall5, {"enabled":true}, createChannel(channelId, invisibleWall5, channelBus))
script10.spawn(invisibleWall6, {"enabled":true}, createChannel(channelId, invisibleWall6, channelBus))
script10.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script10.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script11.spawn(speakers2, {"clickable":false}, createChannel(channelId, speakers2, channelBus))
script11.spawn(speakers3, {"clickable":false}, createChannel(channelId, speakers3, channelBus))
script11.spawn(speakers, {"clickable":false}, createChannel(channelId, speakers, channelBus))
script11.spawn(speakers4, {"clickable":false}, createChannel(channelId, speakers4, channelBus))
script3.spawn(nftPictureFrame, {"id":"69478819454877515899718247009675975988331405547157132439541098666997101625345","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame, channelBus))
script3.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301238301444538369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame5, channelBus))
script3.spawn(nftPictureFrame25, {"id":"69478819454877515899718247009675975988331405547157132439541098668096613253121","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame25, channelBus))
script3.spawn(nftPictureFrame6, {"id":"69478819454877515899718247009675975988331405547157132439541098668096613253121","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame6, channelBus))
script3.spawn(nftPictureFrame7, {"id":"72405646120007613708465591283795435405784754144165659770746301238301444538369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame7, channelBus))
script3.spawn(nftPictureFrame8, {"id":"69478819454877515899718247009675975988331405547157132439541098666997101625345","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame8, channelBus))
script3.spawn(nftPictureFrame26, {"id":"69478819454877515899718247009675975988331405547157132439541098666997101625345","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame26, channelBus))
script3.spawn(nftPictureFrame27, {"id":"72405646120007613708465591283795435405784754144165659770746301238301444538369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame27, channelBus))
script3.spawn(nftPictureFrame28, {"id":"69478819454877515899718247009675975988331405547157132439541098668096613253121","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Gold_Carved","color":"#FFFFFF","ui":false}, createChannel(channelId, nftPictureFrame28, channelBus))