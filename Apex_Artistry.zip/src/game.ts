import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script2 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script3 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script4 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script5 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"
import Script6 from "../7e78cd70-5414-4ec4-be5f-198ec9879a5e/src/item"
import Script7 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(9.89513874053955, 14.104194641113281, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.279308319091797, 5.659231662750244, 0.5635298490524292)
})
nftPictureFrame8.addComponentOrReplace(transform2)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(2.552924394607544, 2.8543660640716553, 2.711696147918701),
  rotation: new Quaternion(-0.2681880593299866, 0.36620521545410156, 0.11108708381652832, 0.8840975761413574),
  scale: new Vector3(3.641407012939453, 4.81561279296875, 0.4795260429382324)
})
nftPictureFrame9.addComponentOrReplace(transform3)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(13.15275764465332, 2.7438066005706787, 13.252943992614746),
  rotation: new Quaternion(0.11108718812465668, 0.8840976357460022, 0.2681879997253418, -0.36620521545410156),
  scale: new Vector3(3.8151721954345703, 4.8663225173950195, 0.502408504486084)
})
nftPictureFrame16.addComponentOrReplace(transform4)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(8.145710945129395, 14.101085662841797, 6.224764823913574),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(4.650711536407471, 5.640412330627441, 0.6124390959739685)
})
nftPictureFrame17.addComponentOrReplace(transform5)

const nftPictureFrame31 = new Entity('nftPictureFrame31')
engine.addEntity(nftPictureFrame31)
nftPictureFrame31.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(0.3867006003856659, 14.876668930053711, 8.042287826538086),
  rotation: new Quaternion(0.1854362040758133, 0.6823587417602539, -0.18543629348278046, 0.6823586821556091),
  scale: new Vector3(3.7968974113464355, 5.128882884979248, 0.5000028014183044)
})
nftPictureFrame31.addComponentOrReplace(transform6)

const nftPictureFrame34 = new Entity('nftPictureFrame34')
engine.addEntity(nftPictureFrame34)
nftPictureFrame34.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(0.3900691270828247, 14.86113452911377, 10.355381965637207),
  rotation: new Quaternion(0.1854361742734909, 0.6823587417602539, -0.18543626368045807, 0.6823586821556091),
  scale: new Vector3(3.7969276905059814, 5.12888240814209, 0.5000064373016357)
})
nftPictureFrame34.addComponentOrReplace(transform7)

const nftPictureFrame35 = new Entity('nftPictureFrame35')
engine.addEntity(nftPictureFrame35)
nftPictureFrame35.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(8.096426963806152, 14.079950332641602, 9.674392700195312),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.456194877624512, 5.55093240737915, 0.6876867413520813)
})
nftPictureFrame35.addComponentOrReplace(transform8)

const nftPictureFrame37 = new Entity('nftPictureFrame37')
engine.addEntity(nftPictureFrame37)
nftPictureFrame37.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(14.209321022033691, 14.454115867614746, 1.7628791332244873),
  rotation: new Quaternion(-0.1802399754524231, 0.3753302991390228, -0.0746578648686409, -0.9061274528503418),
  scale: new Vector3(4.683954238891602, 4.743311405181885, 0.662612795829773)
})
nftPictureFrame37.addComponentOrReplace(transform9)

const nftPictureFrame38 = new Entity('nftPictureFrame38')
engine.addEntity(nftPictureFrame38)
nftPictureFrame38.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(6.286441802978516, 14.099328994750977, 7.9477763175964355),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.686256408691406, 5.7428388595581055, 0.6629368662834167)
})
nftPictureFrame38.addComponentOrReplace(transform10)

const nftPictureFrame64 = new Entity('nftPictureFrame64')
engine.addEntity(nftPictureFrame64)
nftPictureFrame64.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(15.391226768493652, 14.827062606811523, 10.59438419342041),
  rotation: new Quaternion(-0.18628856539726257, 0.682126522064209, -0.18628865480422974, -0.682126522064209),
  scale: new Vector3(4.111861705780029, 5.241394519805908, 0.5000054836273193)
})
nftPictureFrame64.addComponentOrReplace(transform11)

const nftPictureFrame65 = new Entity('nftPictureFrame65')
engine.addEntity(nftPictureFrame65)
nftPictureFrame65.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(15.375831604003906, 14.83890151977539, 8.006430625915527),
  rotation: new Quaternion(-0.18628856539726257, 0.682126522064209, -0.18628865480422974, -0.682126522064209),
  scale: new Vector3(4.111857891082764, 5.259215831756592, 0.5000052452087402)
})
nftPictureFrame65.addComponentOrReplace(transform12)

const nftPictureFrame68 = new Entity('nftPictureFrame68')
engine.addEntity(nftPictureFrame68)
nftPictureFrame68.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(15.383830070495605, 14.831608772277832, 5.407448768615723),
  rotation: new Quaternion(-0.18628856539726257, 0.682126522064209, -0.18628865480422974, -0.682126522064209),
  scale: new Vector3(4.111857891082764, 5.259215831756592, 0.5000052452087402)
})
nftPictureFrame68.addComponentOrReplace(transform13)

const nftPictureFrame69 = new Entity('nftPictureFrame69')
engine.addEntity(nftPictureFrame69)
nftPictureFrame69.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(5.405656814575195, 14.88347053527832, 0.35474300384521484),
  rotation: new Quaternion(-0.2629100978374481, 9.126193436349113e-16, 3.134131887350122e-8, -0.964820384979248),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000020265579224)
})
nftPictureFrame69.addComponentOrReplace(transform14)

const nftPictureFrame72 = new Entity('nftPictureFrame72')
engine.addEntity(nftPictureFrame72)
nftPictureFrame72.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(10.417661666870117, 14.875046730041504, 0.34240442514419556),
  rotation: new Quaternion(-0.2629100978374481, 9.126193436349113e-16, 3.134131887350122e-8, -0.964820384979248),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000020265579224)
})
nftPictureFrame72.addComponentOrReplace(transform15)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("models/CityTile.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform16 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform16)

const nftPictureFrame41 = new Entity('nftPictureFrame41')
engine.addEntity(nftPictureFrame41)
nftPictureFrame41.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(7.901618003845215, 14.9183349609375, 0.3660026788711548),
  rotation: new Quaternion(0.2629100978374481, -3.594236019921482e-8, -4.113547547035523e-8, 0.964820384979248),
  scale: new Vector3(3.79689359664917, 5.128885269165039, 0.5000020265579224)
})
nftPictureFrame41.addComponentOrReplace(transform17)

const nftPictureFrame42 = new Entity('nftPictureFrame42')
engine.addEntity(nftPictureFrame42)
nftPictureFrame42.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(0.4096366763114929, 14.8645658493042, 5.613411903381348),
  rotation: new Quaternion(0.1854361742734909, 0.6823587417602539, -0.18543626368045807, 0.6823586821556091),
  scale: new Vector3(3.796931505203247, 5.12888240814209, 0.500006914138794)
})
nftPictureFrame42.addComponentOrReplace(transform18)

const wallPlainGlass19 = new Entity('wallPlainGlass19')
engine.addEntity(wallPlainGlass19)
wallPlainGlass19.setParent(_scene)
const gltfShape2 = new GLTFShape("models/PlainGlassWall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
wallPlainGlass19.addComponentOrReplace(gltfShape2)
const transform19 = new Transform({
  position: new Vector3(9.818069458007812, 13.782939910888672, 6.255527019500732),
  rotation: new Quaternion(0.70710688829422, -0.7071067690849304, 0, 1.2344522737350871e-8),
  scale: new Vector3(3.0296452045440674, 0.8449563980102539, 0.14495888352394104)
})
wallPlainGlass19.addComponentOrReplace(transform19)

const wallPlainGlass20 = new Entity('wallPlainGlass20')
engine.addEntity(wallPlainGlass20)
wallPlainGlass20.setParent(_scene)
wallPlainGlass20.addComponentOrReplace(gltfShape2)
const transform20 = new Transform({
  position: new Vector3(9.818069458007812, 13.782939910888672, 9.633153915405273),
  rotation: new Quaternion(0.70710688829422, -0.7071067690849304, 0, 1.2344522737350871e-8),
  scale: new Vector3(3.0296506881713867, 0.8449566960334778, 0.14495916664600372)
})
wallPlainGlass20.addComponentOrReplace(transform20)

const wallPlainGlass21 = new Entity('wallPlainGlass21')
engine.addEntity(wallPlainGlass21)
wallPlainGlass21.setParent(_scene)
wallPlainGlass21.addComponentOrReplace(gltfShape2)
const transform21 = new Transform({
  position: new Vector3(9.818069458007812, 13.782939910888672, 6.301930904388428),
  rotation: new Quaternion(0.5, -0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(3.02962327003479, 0.8449410200119019, 0.14495877921581268)
})
wallPlainGlass21.addComponentOrReplace(transform21)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.460805892944336, 0.12048319727182388, 1.460805892944336)
})
verticalBlackPad.addComponentOrReplace(transform22)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(9.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform23)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(8, 0, 8.041803359985352),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.473411798477173, 10.190823554992676, 2.4700629711151123)
})
triggerArea.addComponentOrReplace(transform24)

const nftPictureFrame50 = new Entity('nftPictureFrame50')
engine.addEntity(nftPictureFrame50)
nftPictureFrame50.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(14.384993553161621, 10.845839500427246, 1.5249147415161133),
  rotation: new Quaternion(3.795361513134546e-15, 0.3826833963394165, -4.5619415800501883e-8, -0.9238796234130859),
  scale: new Vector3(4.0000152587890625, 4.632970333099365, 0.5658560991287231)
})
nftPictureFrame50.addComponentOrReplace(transform25)

const nftPictureFrame52 = new Entity('nftPictureFrame52')
engine.addEntity(nftPictureFrame52)
nftPictureFrame52.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(13.25960636138916, 2.750180721282959, 2.5073957443237305),
  rotation: new Quaternion(0.1110871210694313, 0.8840975761413574, -0.2681882083415985, 0.36620521545410156),
  scale: new Vector3(3.815157890319824, 4.866322994232178, 0.5024076104164124)
})
nftPictureFrame52.addComponentOrReplace(transform26)

const nftPictureFrame53 = new Entity('nftPictureFrame53')
engine.addEntity(nftPictureFrame53)
nftPictureFrame53.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(1.5322222709655762, 14.501944541931152, 1.6454417705535889),
  rotation: new Quaternion(-0.1802399605512619, -0.3753302991390228, 0.07465790957212448, -0.9061274528503418),
  scale: new Vector3(4.57501220703125, 4.63297176361084, 0.6472004652023315)
})
nftPictureFrame53.addComponentOrReplace(transform27)

const nftPictureFrame55 = new Entity('nftPictureFrame55')
engine.addEntity(nftPictureFrame55)
nftPictureFrame55.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(2.650930643081665, 2.958951234817505, 13.419707298278809),
  rotation: new Quaternion(-0.11108711361885071, 0.8840975761413574, 0.2681879699230194, 0.36620524525642395),
  scale: new Vector3(3.641413688659668, 4.815615653991699, 0.4795265793800354)
})
nftPictureFrame55.addComponentOrReplace(transform28)

const nftPictureFrame67 = new Entity('nftPictureFrame67')
engine.addEntity(nftPictureFrame67)
nftPictureFrame67.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(2.5589077472686768, 2.7318639755249023, 2.6916871070861816),
  rotation: new Quaternion(-0.1110871285200119, 0.8840975761413574, -0.2681881785392761, -0.3662051856517792),
  scale: new Vector3(3.815157413482666, 4.8663225173950195, 0.5024073123931885)
})
nftPictureFrame67.addComponentOrReplace(transform29)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(13.235013961791992, 2.7106919288635254, 13.380800247192383),
  rotation: new Quaternion(-0.2681880593299866, -0.3662051856517792, 0.11108723282814026, -0.8840976357460022),
  scale: new Vector3(3.6414051055908203, 4.815615177154541, 0.47952592372894287)
})
nftPictureFrame5.addComponentOrReplace(transform30)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(13.049517631530762, 2.8021366596221924, 2.657184362411499),
  rotation: new Quaternion(0.26818808913230896, 0.36620524525642395, 0.11108707636594772, -0.8840976357460022),
  scale: new Vector3(3.641397476196289, 4.815614223480225, 0.4795253872871399)
})
nftPictureFrame10.addComponentOrReplace(transform31)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(14.2642183303833, 14.424153327941895, 14.397565841674805),
  rotation: new Quaternion(0.07465782761573792, -0.9061274528503418, 0.18024007976055145, 0.3753302991390228),
  scale: new Vector3(4.683967113494873, 4.743311882019043, 0.6626150608062744)
})
nftPictureFrame12.addComponentOrReplace(transform32)

const nftPictureFrame47 = new Entity('nftPictureFrame47')
engine.addEntity(nftPictureFrame47)
nftPictureFrame47.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(1.4599790573120117, 14.495033264160156, 14.485396385192871),
  rotation: new Quaternion(-0.07465782761573792, -0.9061274528503418, 0.18024009466171265, -0.3753302991390228),
  scale: new Vector3(4.683962345123291, 4.743314743041992, 0.6626156568527222)
})
nftPictureFrame47.addComponentOrReplace(transform33)

const nftPictureFrame61 = new Entity('nftPictureFrame61')
engine.addEntity(nftPictureFrame61)
nftPictureFrame61.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(2.5209646224975586, 2.930299758911133, 13.504075050354004),
  rotation: new Quaternion(-0.26818808913230896, 0.36620524525642395, -0.11108716577291489, -0.8840976357460022),
  scale: new Vector3(3.815157413482666, 4.866323471069336, 0.5024071931838989)
})
nftPictureFrame61.addComponentOrReplace(transform34)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(10.327800750732422, 14.851425170898438, 15.757018089294434),
  rotation: new Quaternion(-2.4052690505982355e-8, 0.9631332159042358, -0.26902493834495544, -2.8703601273605273e-8),
  scale: new Vector3(4.111849308013916, 5.241393089294434, 0.5000027418136597)
})
nftPictureFrame.addComponentOrReplace(transform35)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(7.831839561462402, 14.878342628479004, 15.732442855834961),
  rotation: new Quaternion(3.407464532756421e-8, -0.9631332159042358, 0.26902493834495544, -7.1759052033826265e-9),
  scale: new Vector3(3.7968993186950684, 5.1288862228393555, 0.5000027418136597)
})
nftPictureFrame2.addComponentOrReplace(transform36)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(5.3157958984375, 14.855942726135254, 15.784278869628906),
  rotation: new Quaternion(-2.4052690505982355e-8, 0.9631332159042358, -0.26902493834495544, -2.8703601273605273e-8),
  scale: new Vector3(4.111849308013916, 5.241393089294434, 0.5000027418136597)
})
nftPictureFrame3.addComponentOrReplace(transform37)

const wallPlainGlass14 = new Entity('wallPlainGlass14')
engine.addEntity(wallPlainGlass14)
wallPlainGlass14.setParent(_scene)
wallPlainGlass14.addComponentOrReplace(gltfShape2)
const transform38 = new Transform({
  position: new Vector3(6.408136367797852, 13.782939910888672, 6.301930904388428),
  rotation: new Quaternion(0.5, -0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(3.02962327003479, 0.8449410200119019, 0.14495877921581268)
})
wallPlainGlass14.addComponentOrReplace(transform38)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(0.33355140686035156, 12.656850814819336, 7.993919372558594),
  rotation: new Quaternion(2.5926168679225653e-15, 0.7137430906295776, -8.508479254487611e-8, 0.7004076838493347),
  scale: new Vector3(1.0000064373016357, 1, 1.0000064373016357)
})
radio.addComponentOrReplace(transform39)

const signpostTree5 = new Entity('signpostTree5')
engine.addEntity(signpostTree5)
signpostTree5.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(8.023031234741211, 4.845696449279785, 9.464295387268066),
  rotation: new Quaternion(0, 1.483675757074845e-21, 1.2445975172237049e-14, 1),
  scale: new Vector3(1.3049815893173218, 0.85685133934021, 1)
})
signpostTree5.addComponentOrReplace(transform40)

const wallPlainBlack5 = new Entity('wallPlainBlack5')
engine.addEntity(wallPlainBlack5)
wallPlainBlack5.setParent(_scene)
const gltfShape3 = new GLTFShape("models/PlainBlackWall.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
wallPlainBlack5.addComponentOrReplace(gltfShape3)
const transform41 = new Transform({
  position: new Vector3(9.211030006408691, 4.8765668869018555, 9.470000267028809),
  rotation: new Quaternion(-3.552713678800501e-15, 4.331258849253477e-22, 3.633324110324798e-15, 1),
  scale: new Vector3(1.190567970275879, 0.21347105503082275, 0.3330826163291931)
})
wallPlainBlack5.addComponentOrReplace(transform41)

const wallPlainBlack6 = new Entity('wallPlainBlack6')
engine.addEntity(wallPlainBlack6)
wallPlainBlack6.setParent(_scene)
wallPlainBlack6.addComponentOrReplace(gltfShape3)
const transform42 = new Transform({
  position: new Vector3(6.754734039306641, 4.8765668869018555, 6.789850234985352),
  rotation: new Quaternion(-2.2039534707343246e-15, 1, -1.1920927533992653e-7, 1.262177448353619e-29),
  scale: new Vector3(1.190567970275879, 0.21347105503082275, 0.3330826163291931)
})
wallPlainBlack6.addComponentOrReplace(transform42)

const signpostTree6 = new Entity('signpostTree6')
engine.addEntity(signpostTree6)
signpostTree6.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(7.942732810974121, 4.845696449279785, 6.795555114746094),
  rotation: new Quaternion(6.608697591177926e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.3049815893173218, 0.85685133934021, 1)
})
signpostTree6.addComponentOrReplace(transform43)

const wallPlainBlack7 = new Entity('wallPlainBlack7')
engine.addEntity(wallPlainBlack7)
wallPlainBlack7.setParent(_scene)
wallPlainBlack7.addComponentOrReplace(gltfShape3)
const transform44 = new Transform({
  position: new Vector3(6.710696220397949, 4.8765668869018555, 9.23653793334961),
  rotation: new Quaternion(-1.5584305086647696e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1905689239501953, 0.21347105503082275, 0.3330828547477722)
})
wallPlainBlack7.addComponentOrReplace(transform44)

const signpostTree7 = new Entity('signpostTree7')
engine.addEntity(signpostTree7)
signpostTree7.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(6.716401100158691, 4.845696449279785, 8.048540115356445),
  rotation: new Quaternion(4.673055359013557e-15, 0.7071068286895752, -8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(1.3049825429916382, 0.85685133934021, 1.0000009536743164)
})
signpostTree7.addComponentOrReplace(transform45)

const wallPlainBlack8 = new Entity('wallPlainBlack8')
engine.addEntity(wallPlainBlack8)
wallPlainBlack8.setParent(_scene)
wallPlainBlack8.addComponentOrReplace(gltfShape3)
const transform46 = new Transform({
  position: new Vector3(9.38228988647461, 4.8765668869018555, 6.890681266784668),
  rotation: new Quaternion(4.3797422489394965e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.1905696392059326, 0.21347105503082275, 0.33308303356170654)
})
wallPlainBlack8.addComponentOrReplace(transform46)

const signpostTree8 = new Entity('signpostTree8')
engine.addEntity(signpostTree8)
signpostTree8.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(9.376585006713867, 4.845696449279785, 8.078679084777832),
  rotation: new Quaternion(-2.7256851086615054e-15, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.3049832582473755, 0.85685133934021, 1.0000016689300537)
})
signpostTree8.addComponentOrReplace(transform47)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(15.757591247558594, 7.919834136962891, 8.066052436828613),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(6.366151809692383, 8.142498016357422, 0.7741274237632751)
})
nftPictureFrame7.addComponentOrReplace(transform48)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(7.953104019165039, 7.982729911804199, 0.30860424041748047),
  rotation: new Quaternion(-3.552713678800501e-15, -3.725290298461914e-8, 8.374730793017041e-15, 1),
  scale: new Vector3(9.23898696899414, 8.266758918762207, 0.805905818939209)
})
nftPictureFrame11.addComponentOrReplace(transform49)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(0.11496925354003906, 8.076419830322266, 8.001660346984863),
  rotation: new Quaternion(-1.9739713200605732e-15, 0.7071068286895752, -8.429368136830817e-8, 0.7071067690849304),
  scale: new Vector3(6.565490245819092, 7.907368183135986, 0.7708697319030762)
})
nftPictureFrame14.addComponentOrReplace(transform50)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(7.79766845703125, 7.915465354919434, 15.625429153442383),
  rotation: new Quaternion(3.475808169387494e-16, -1, 1.1920928244535389e-7, -7.450580596923828e-9),
  scale: new Vector3(8.972309112548828, 8.448015213012695, 0.823576033115387)
})
nftPictureFrame19.addComponentOrReplace(transform51)

const ringBlueLight = new Entity('ringBlueLight')
engine.addEntity(ringBlueLight)
ringBlueLight.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8842449188232422, 0.25108602643013, 1.8842449188232422)
})
ringBlueLight.addComponentOrReplace(transform52)
const gltfShape4 = new GLTFShape("models/Ring_Blue_Light.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
ringBlueLight.addComponentOrReplace(gltfShape4)

const ringBlueLight2 = new Entity('ringBlueLight2')
engine.addEntity(ringBlueLight2)
ringBlueLight2.setParent(_scene)
ringBlueLight2.addComponentOrReplace(gltfShape4)
const transform53 = new Transform({
  position: new Vector3(8, 6.590167999267578, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8842449188232422, 0.25108602643013, 1.8842449188232422)
})
ringBlueLight2.addComponentOrReplace(transform53)

const ringBlueLight3 = new Entity('ringBlueLight3')
engine.addEntity(ringBlueLight3)
ringBlueLight3.setParent(_scene)
ringBlueLight3.addComponentOrReplace(gltfShape4)
const transform54 = new Transform({
  position: new Vector3(8, 3.378354072570801, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8842449188232422, 0.25108602643013, 1.8842449188232422)
})
ringBlueLight3.addComponentOrReplace(transform54)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(9.89513874053955, 17.366601943969727, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.2793121337890625, 4.149393558502197, 0.5635303258895874)
})
nftPictureFrame22.addComponentOrReplace(transform55)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(8.096426963806152, 17.348825454711914, 9.674392700195312),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.456194877624512, 4.069988250732422, 0.6876867413520813)
})
nftPictureFrame23.addComponentOrReplace(transform56)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(6.286441802978516, 17.363035202026367, 7.9477763175964355),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.686260223388672, 4.210695266723633, 0.662937343120575)
})
nftPictureFrame24.addComponentOrReplace(transform57)

const nftPictureFrame25 = new Entity('nftPictureFrame25')
engine.addEntity(nftPictureFrame25)
nftPictureFrame25.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(8.145710945129395, 17.36432456970215, 6.224764823913574),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(4.650711536407471, 4.135595321655273, 0.6124390959739685)
})
nftPictureFrame25.addComponentOrReplace(transform58)

const armchairD5 = new Entity('armchairD5')
engine.addEntity(armchairD5)
armchairD5.setParent(_scene)
const gltfShape5 = new GLTFShape("models/Armchair_D.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
armchairD5.addComponentOrReplace(gltfShape5)
const transform59 = new Transform({
  position: new Vector3(1.7063791751861572, 10.1961030960083, 5.218828201293945),
  rotation: new Quaternion(-6.65064594497863e-16, 0.4713967442512512, -5.6194867426029305e-8, 0.8819212913513184),
  scale: new Vector3(1, 1, 1)
})
armchairD5.addComponentOrReplace(transform59)

const armchairD6 = new Entity('armchairD6')
engine.addEntity(armchairD6)
armchairD6.setParent(_scene)
armchairD6.addComponentOrReplace(gltfShape5)
const transform60 = new Transform({
  position: new Vector3(1.707350730895996, 10.1961030960083, 10.71483039855957),
  rotation: new Quaternion(-1.5283430513453496e-15, 0.8819212913513184, -1.0513319637084351e-7, 0.47139671444892883),
  scale: new Vector3(1.0000017881393433, 1, 1.0000017881393433)
})
armchairD6.addComponentOrReplace(transform60)

const armchairD7 = new Entity('armchairD7')
engine.addEntity(armchairD7)
armchairD7.setParent(_scene)
armchairD7.addComponentOrReplace(gltfShape5)
const transform61 = new Transform({
  position: new Vector3(14.418876647949219, 10.184867858886719, 10.808110237121582),
  rotation: new Quaternion(-5.148019343307513e-15, 0.8819212913513184, -1.0513320347627086e-7, -0.4713967442512512),
  scale: new Vector3(1.0000030994415283, 1, 1.0000030994415283)
})
armchairD7.addComponentOrReplace(transform61)

const armchairD8 = new Entity('armchairD8')
engine.addEntity(armchairD8)
armchairD8.setParent(_scene)
armchairD8.addComponentOrReplace(gltfShape5)
const transform62 = new Transform({
  position: new Vector3(14.42638874053955, 10.184866905212402, 5.48838472366333),
  rotation: new Quaternion(4.35375358405184e-15, 0.47139671444892883, -5.6194867426029305e-8, -0.8819212913513184),
  scale: new Vector3(1.0000005960464478, 1, 1.0000005960464478)
})
armchairD8.addComponentOrReplace(transform62)

const coffeeTable4 = new Entity('coffeeTable4')
engine.addEntity(coffeeTable4)
coffeeTable4.setParent(_scene)
const gltfShape6 = new GLTFShape("models/Coffee_Table.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
coffeeTable4.addComponentOrReplace(gltfShape6)
const transform63 = new Transform({
  position: new Vector3(15.495584487915039, 10.146903038024902, 8.028848648071289),
  rotation: new Quaternion(1.1250501669602536e-14, -0.7101039290428162, 8.465097067755778e-8, -0.7040969729423523),
  scale: new Vector3(4.066239356994629, 5.477626323699951, 0.290917307138443)
})
coffeeTable4.addComponentOrReplace(transform63)

const wallPlainGlass4 = new Entity('wallPlainGlass4')
engine.addEntity(wallPlainGlass4)
wallPlainGlass4.setParent(_scene)
wallPlainGlass4.addComponentOrReplace(gltfShape2)
const transform64 = new Transform({
  position: new Vector3(12.86147403717041, 10.203889846801758, 0.999760627746582),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(4.523913860321045, 3.516906261444092, 0.1881696730852127)
})
wallPlainGlass4.addComponentOrReplace(transform64)

const wallHexagonGrid = new Entity('wallHexagonGrid')
engine.addEntity(wallHexagonGrid)
wallHexagonGrid.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(12.085265159606934, 6.215203285217285, 0.024163246154785156),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.208616256713867, 1.8572133779525757, 0.06551527231931686)
})
wallHexagonGrid.addComponentOrReplace(transform65)
const gltfShape7 = new GLTFShape("models/HexagonGridWall.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
wallHexagonGrid.addComponentOrReplace(gltfShape7)

const wallHexagonGrid2 = new Entity('wallHexagonGrid2')
engine.addEntity(wallHexagonGrid2)
wallHexagonGrid2.setParent(_scene)
wallHexagonGrid2.addComponentOrReplace(gltfShape7)
const transform66 = new Transform({
  position: new Vector3(12.085265159606934, 6.215203285217285, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(4.208616256713867, 1.8572133779525757, 0.06551527231931686)
})
wallHexagonGrid2.addComponentOrReplace(transform66)

const wallHexagonGrid3 = new Entity('wallHexagonGrid3')
engine.addEntity(wallHexagonGrid3)
wallHexagonGrid3.setParent(_scene)
wallHexagonGrid3.addComponentOrReplace(gltfShape7)
const transform67 = new Transform({
  position: new Vector3(15.996781349182129, 6.215203285217285, 3.8100876808166504),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.208621978759766, 1.8572133779525757, 0.06551536172628403)
})
wallHexagonGrid3.addComponentOrReplace(transform67)

const wallHexagonGrid4 = new Entity('wallHexagonGrid4')
engine.addEntity(wallHexagonGrid4)
wallHexagonGrid4.setParent(_scene)
wallHexagonGrid4.addComponentOrReplace(gltfShape7)
const transform68 = new Transform({
  position: new Vector3(0.07641315460205078, 6.215203285217285, 3.8100876808166504),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.208623886108398, 1.8572133779525757, 0.06551539152860641)
})
wallHexagonGrid4.addComponentOrReplace(transform68)

const wallPlainGlass = new Entity('wallPlainGlass')
engine.addEntity(wallPlainGlass)
wallPlainGlass.setParent(_scene)
wallPlainGlass.addComponentOrReplace(gltfShape2)
const transform69 = new Transform({
  position: new Vector3(15.717037200927734, 10.203889846801758, 2.4694008827209473),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.4266836643218994, 2.7406113147735596, 0.1881696730852127)
})
wallPlainGlass.addComponentOrReplace(transform69)

const wallPlainGlass2 = new Entity('wallPlainGlass2')
engine.addEntity(wallPlainGlass2)
wallPlainGlass2.setParent(_scene)
wallPlainGlass2.addComponentOrReplace(gltfShape2)
const transform70 = new Transform({
  position: new Vector3(3.818892002105713, 10.203889846801758, 2.812556266784668),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.6428046226501465, 2.765995502471924, 0.1881696730852127)
})
wallPlainGlass2.addComponentOrReplace(transform70)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(4.140608787536621, 18.56723403930664, 5),
  rotation: new Quaternion(-0.12562504410743713, -0.2976500391960144, 0.15632812678813934, 0.9333725571632385),
  scale: new Vector3(0.5000001788139343, 1.0000001192092896, 1.0000001192092896)
})
ropeLight.addComponentOrReplace(transform71)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(5.041098117828369, 18.56723403930664, 4.128238677978516),
  rotation: new Quaternion(-0.15306755900382996, -0.4697582721710205, 0.12957800924777985, 0.8597134351730347),
  scale: new Vector3(0.5000004172325134, 1.0000007152557373, 1.0000009536743164)
})
ropeLight2.addComponentOrReplace(transform72)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(10.955591201782227, 18.56723403930664, 11.919440269470215),
  rotation: new Quaternion(0.12957796454429626, 0.8597134351730347, 0.1530674397945404, 0.46975821256637573),
  scale: new Vector3(0.5000008344650269, 1.0000008344650269, 1.0000015497207642)
})
ropeLight3.addComponentOrReplace(transform73)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(11.856080055236816, 18.56723403930664, 11.04767894744873),
  rotation: new Quaternion(0.15632811188697815, 0.9333726167678833, 0.12562492489814758, 0.297650009393692),
  scale: new Vector3(0.5000011920928955, 1.0000001192092896, 1.0000026226043701)
})
ropeLight4.addComponentOrReplace(transform74)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(11.841716766357422, 18.56723403930664, 4.933804035186768),
  rotation: new Quaternion(0.1998605579137802, 0.9400784373283386, 0.016609525308012962, -0.27573996782302856),
  scale: new Vector3(0.5000014305114746, 1.000001072883606, 1.0000029802322388)
})
ropeLight5.addComponentOrReplace(transform75)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(10.969955444335938, 18.56723403930664, 4.033316135406494),
  rotation: new Quaternion(0.19937095046043396, 0.8704643845558167, -0.021710455417633057, -0.4495237171649933),
  scale: new Vector3(0.5000025033950806, 0.9999998211860657, 1.0000054836273193)
})
ropeLight6.addComponentOrReplace(transform76)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(4.006162643432617, 18.56723403930664, 11.033316612243652),
  rotation: new Quaternion(0.016609635204076767, -0.27573999762535095, -0.19986052811145782, -0.9400784373283386),
  scale: new Vector3(0.5000019073486328, 1.0000011920928955, 1.0000038146972656)
})
ropeLight7.addComponentOrReplace(transform77)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(4.877923488616943, 18.56723403930664, 11.933804512023926),
  rotation: new Quaternion(-0.0217103511095047, -0.4495237469673157, -0.19937089085578918, -0.8704645037651062),
  scale: new Vector3(0.5000033378601074, 1, 1.0000070333480835)
})
ropeLight8.addComponentOrReplace(transform78)

const ropeLight9 = new Entity('ropeLight9')
engine.addEntity(ropeLight9)
ropeLight9.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(4.452199935913086, 18.56723403930664, 7.356975555419922),
  rotation: new Quaternion(0.09182862937450409, 0.10500191152095795, -0.17829084396362305, -0.9740402698516846),
  scale: new Vector3(0.5000019073486328, 1.0000011920928955, 1.0000038146972656)
})
ropeLight9.addComponentOrReplace(transform79)

const ropeLight10 = new Entity('ropeLight10')
engine.addEntity(ropeLight10)
ropeLight10.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(4.431886672973633, 18.56723403930664, 8.61014461517334),
  rotation: new Quaternion(0.05623820796608925, -0.08219342678785324, -0.19250290095806122, -0.9762295484542847),
  scale: new Vector3(0.5000033974647522, 0.9999999403953552, 1.0000070333480835)
})
ropeLight10.addComponentOrReplace(transform80)

const ropeLight11 = new Entity('ropeLight11')
engine.addEntity(ropeLight11)
ropeLight11.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(11.284163475036621, 18.56723403930664, 8.61014461517334),
  rotation: new Quaternion(-0.17829084396362305, -0.9740403294563293, -0.09182851761579514, -0.10500194132328033),
  scale: new Vector3(0.5000021457672119, 1.0000011920928955, 1.000004768371582)
})
ropeLight11.addComponentOrReplace(transform81)

const ropeLight12 = new Entity('ropeLight12')
engine.addEntity(ropeLight12)
ropeLight12.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(11.304476737976074, 18.56723403930664, 7.356975555419922),
  rotation: new Quaternion(-0.1925029158592224, -0.9762295484542847, -0.056238092482089996, 0.08219340443611145),
  scale: new Vector3(0.5000035762786865, 1.000000238418579, 1.0000075101852417)
})
ropeLight12.addComponentOrReplace(transform82)

const ropeLight13 = new Entity('ropeLight13')
engine.addEntity(ropeLight13)
ropeLight13.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(7.4686384201049805, 18.56723403930664, 11.71138858795166),
  rotation: new Quaternion(-0.06113802269101143, -0.6145029664039612, -0.1910032480955124, -0.762998104095459),
  scale: new Vector3(0.5000024437904358, 1.0000019073486328, 1.0000053644180298)
})
ropeLight13.addComponentOrReplace(transform83)

const ropeLight14 = new Entity('ropeLight14')
engine.addEntity(ropeLight14)
ropeLight14.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(8.721808433532715, 18.56723403930664, 11.731701850891113),
  rotation: new Quaternion(-0.09635370969772339, -0.7484180927276611, -0.17588646709918976, -0.6321790218353271),
  scale: new Vector3(0.5000037550926208, 1.000000238418579, 1.0000081062316895)
})
ropeLight14.addComponentOrReplace(transform84)

const ropeLight15 = new Entity('ropeLight15')
engine.addEntity(ropeLight15)
ropeLight15.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(8.721808433532715, 18.56723403930664, 4.3643951416015625),
  rotation: new Quaternion(-0.19100329279899597, -0.7629979848861694, 0.061138104647397995, 0.6145029067993164),
  scale: new Vector3(0.5000023245811462, 1.0000011920928955, 1.0000051259994507)
})
ropeLight15.addComponentOrReplace(transform85)

const ropeLight16 = new Entity('ropeLight16')
engine.addEntity(ropeLight16)
ropeLight16.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(7.4686384201049805, 18.56723403930664, 4.344081878662109),
  rotation: new Quaternion(-0.17588655650615692, -0.6321790218353271, 0.09635378420352936, 0.7484180927276611),
  scale: new Vector3(0.5000038743019104, 1.000000238418579, 1.000008225440979)
})
ropeLight16.addComponentOrReplace(transform86)

const ropeLight17 = new Entity('ropeLight17')
engine.addEntity(ropeLight17)
ropeLight17.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(8, 17.486385345458984, 1.8178977966308594),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7684885263442993, 1, 8.000417709350586)
})
ropeLight17.addComponentOrReplace(transform87)

const ropeLight18 = new Entity('ropeLight18')
engine.addEntity(ropeLight18)
ropeLight18.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(7.939006805419922, 17.486385345458984, 14.329544067382812),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7819982767105103, 1, 7.412299633026123)
})
ropeLight18.addComponentOrReplace(transform88)

const ropeLight19 = new Entity('ropeLight19')
engine.addEntity(ropeLight19)
ropeLight19.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(1.8738923072814941, 17.486385345458984, 8.035276412963867),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.7819994688034058, 1, 7.412309169769287)
})
ropeLight19.addComponentOrReplace(transform89)

const ropeLight20 = new Entity('ropeLight20')
engine.addEntity(ropeLight20)
ropeLight20.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(13.913094520568848, 17.486385345458984, 8.035276412963867),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.7820001840591431, 1, 7.4123148918151855)
})
ropeLight20.addComponentOrReplace(transform90)

const ropeLight21 = new Entity('ropeLight21')
engine.addEntity(ropeLight21)
ropeLight21.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(2.8418307304382324, 17.486385345458984, 2.781761884689331),
  rotation: new Quaternion(-4.008848120676993e-18, -0.3784223794937134, 4.51114630095617e-8, -0.9256330728530884),
  scale: new Vector3(0.2356879711151123, 1, 7.412309169769287)
})
ropeLight21.addComponentOrReplace(transform91)

const ropeLight22 = new Entity('ropeLight22')
engine.addEntity(ropeLight22)
ropeLight22.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(13.160564422607422, 17.486385345458984, 13.438575744628906),
  rotation: new Quaternion(2.1518320130090805e-16, -0.3897239863872528, 4.645871953812275e-8, -0.9209318161010742),
  scale: new Vector3(0.23568803071975708, 1, 7.412310600280762)
})
ropeLight22.addComponentOrReplace(transform92)

const ropeLight23 = new Entity('ropeLight23')
engine.addEntity(ropeLight23)
ropeLight23.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(12.95888614654541, 17.486385345458984, 2.8772947788238525),
  rotation: new Quaternion(1.534225801043149e-15, 0.41112953424453735, -4.901045258520753e-8, -0.9115769863128662),
  scale: new Vector3(0.2356880009174347, 1, 7.412310600280762)
})
ropeLight23.addComponentOrReplace(transform93)

const ropeLight24 = new Entity('ropeLight24')
engine.addEntity(ropeLight24)
ropeLight24.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(2.7659902572631836, 17.486385345458984, 13.330239295959473),
  rotation: new Quaternion(1.534225801043149e-15, 0.41112953424453735, -4.901045258520753e-8, -0.9115769863128662),
  scale: new Vector3(0.2356880009174347, 1, 7.412310600280762)
})
ropeLight24.addComponentOrReplace(transform94)

const ropeLight25 = new Entity('ropeLight25')
engine.addEntity(ropeLight25)
ropeLight25.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(0.26256489753723145, 9.847129821777344, 2.9972281455993652),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788704991340637, 1.8473496437072754, 2.0984013080596924)
})
ropeLight25.addComponentOrReplace(transform95)

const ropeLight26 = new Entity('ropeLight26')
engine.addEntity(ropeLight26)
ropeLight26.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(12.952972412109375, 9.847129821777344, 0.3525320887565613),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788715720176697, 1.8473520278930664, 2.0984013080596924)
})
ropeLight26.addComponentOrReplace(transform96)

const ropeLight27 = new Entity('ropeLight27')
engine.addEntity(ropeLight27)
ropeLight27.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(15.732499122619629, 9.847129821777344, 13.106722831726074),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788709759712219, 1.8473505973815918, 2.0984013080596924)
})
ropeLight27.addComponentOrReplace(transform97)

const ropeLight28 = new Entity('ropeLight28')
engine.addEntity(ropeLight28)
ropeLight28.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(2.8802173137664795, 9.847129821777344, 15.78670597076416),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788714528083801, 1.8473515510559082, 2.0984013080596924)
})
ropeLight28.addComponentOrReplace(transform98)

const ropeLight29 = new Entity('ropeLight29')
engine.addEntity(ropeLight29)
ropeLight29.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(8, 5.079182147979736, 0.8178977966308594),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7684885263442993, 1, 8.000417709350586)
})
ropeLight29.addComponentOrReplace(transform99)

const ropeLight30 = new Entity('ropeLight30')
engine.addEntity(ropeLight30)
ropeLight30.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(8, 5.079182147979736, 15.242786407470703),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7684885263442993, 1, 8.000417709350586)
})
ropeLight30.addComponentOrReplace(transform100)

const ropeLight31 = new Entity('ropeLight31')
engine.addEntity(ropeLight31)
ropeLight31.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(15, 5.079182147979736, 7.817897796630859),
  rotation: new Quaternion(-7.781870092739773e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(0.76848965883255, 1, 8.000425338745117)
})
ropeLight31.addComponentOrReplace(transform101)

const ropeLight32 = new Entity('ropeLight32')
engine.addEntity(ropeLight32)
ropeLight32.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(0.6929459571838379, 5.079182147979736, 7.817897796630859),
  rotation: new Quaternion(-7.781870092739773e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(0.7684898972511292, 1, 8.00042724609375)
})
ropeLight32.addComponentOrReplace(transform102)

const wallPlainGlass6 = new Entity('wallPlainGlass6')
engine.addEntity(wallPlainGlass6)
wallPlainGlass6.setParent(_scene)
wallPlainGlass6.addComponentOrReplace(gltfShape2)
const transform103 = new Transform({
  position: new Vector3(1.4081363677978516, 11.027326583862305, 12.301931381225586),
  rotation: new Quaternion(-0.27059799432754517, 0.2705981135368347, 0.653281569480896, -0.6532813906669617),
  scale: new Vector3(0.13235273957252502, 0.8449410200119019, 0.14495877921581268)
})
wallPlainGlass6.addComponentOrReplace(transform103)

const wallPlainGlass7 = new Entity('wallPlainGlass7')
engine.addEntity(wallPlainGlass7)
wallPlainGlass7.setParent(_scene)
wallPlainGlass7.addComponentOrReplace(gltfShape2)
const transform104 = new Transform({
  position: new Vector3(11.908136367797852, 11.027326583862305, 1.5444457530975342),
  rotation: new Quaternion(-0.27059799432754517, 0.2705981135368347, 0.653281569480896, -0.6532813906669617),
  scale: new Vector3(0.13235273957252502, 0.8449410200119019, 0.14495877921581268)
})
wallPlainGlass7.addComponentOrReplace(transform104)

const wallPlainGlass8 = new Entity('wallPlainGlass8')
engine.addEntity(wallPlainGlass8)
wallPlainGlass8.setParent(_scene)
wallPlainGlass8.addComponentOrReplace(gltfShape2)
const transform105 = new Transform({
  position: new Vector3(3.8358283042907715, 11.027326583862305, 1.7779417037963867),
  rotation: new Quaternion(-0.653281569480896, 0.6532814502716064, 0.2705981135368347, -0.27059799432754517),
  scale: new Vector3(0.13235287368297577, 0.8449416756629944, 0.14495886862277985)
})
wallPlainGlass8.addComponentOrReplace(transform105)

const wallPlainGlass9 = new Entity('wallPlainGlass9')
engine.addEntity(wallPlainGlass9)
wallPlainGlass9.setParent(_scene)
wallPlainGlass9.addComponentOrReplace(gltfShape2)
const transform106 = new Transform({
  position: new Vector3(14.538959503173828, 11.027326583862305, 12.277941703796387),
  rotation: new Quaternion(-0.653281569480896, 0.6532814502716064, 0.2705981135368347, -0.27059799432754517),
  scale: new Vector3(0.13235299289226532, 0.8449420928955078, 0.14495894312858582)
})
wallPlainGlass9.addComponentOrReplace(transform106)

const wallHexagonGrid5 = new Entity('wallHexagonGrid5')
engine.addEntity(wallHexagonGrid5)
wallHexagonGrid5.setParent(_scene)
wallHexagonGrid5.addComponentOrReplace(gltfShape7)
const transform107 = new Transform({
  position: new Vector3(13.703689575195312, 6.215203285217285, 0.6624575257301331),
  rotation: new Quaternion(-2.382198213715073e-15, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.1281304359436035, 1.8572133779525757, 0.06551553308963776)
})
wallHexagonGrid5.addComponentOrReplace(transform107)

const wallHexagonGrid6 = new Entity('wallHexagonGrid6')
engine.addEntity(wallHexagonGrid6)
wallHexagonGrid6.setParent(_scene)
wallHexagonGrid6.addComponentOrReplace(gltfShape7)
const transform108 = new Transform({
  position: new Vector3(0.3560822010040283, 6.215203285217285, 13.956121444702148),
  rotation: new Quaternion(-2.382198213715073e-15, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.1281311511993408, 1.8572133779525757, 0.06551556289196014)
})
wallHexagonGrid6.addComponentOrReplace(transform108)

const wallHexagonGrid7 = new Entity('wallHexagonGrid7')
engine.addEntity(wallHexagonGrid7)
wallHexagonGrid7.setParent(_scene)
wallHexagonGrid7.addComponentOrReplace(gltfShape7)
const transform109 = new Transform({
  position: new Vector3(13.665406227111816, 6.215203285217285, 15.449700355529785),
  rotation: new Quaternion(1.7710661657325817e-15, -0.9238795638084412, 1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.128131628036499, 1.8572133779525757, 0.06551557779312134)
})
wallHexagonGrid7.addComponentOrReplace(transform109)

const wallHexagonGrid8 = new Entity('wallHexagonGrid8')
engine.addEntity(wallHexagonGrid8)
wallHexagonGrid8.setParent(_scene)
wallHexagonGrid8.addComponentOrReplace(gltfShape7)
const transform110 = new Transform({
  position: new Vector3(0.3711308240890503, 6.215203285217285, 2.120954990386963),
  rotation: new Quaternion(1.7710661657325817e-15, -0.9238795638084412, 1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.1281335353851318, 1.8572133779525757, 0.0655156821012497)
})
wallHexagonGrid8.addComponentOrReplace(transform110)

const ropeLight33 = new Entity('ropeLight33')
engine.addEntity(ropeLight33)
ropeLight33.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(15.732499122619629, 9.847129821777344, 2.9769978523254395),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788711547851562, 1.8473496437072754, 2.0984013080596924)
})
ropeLight33.addComponentOrReplace(transform111)

const ropeLight34 = new Entity('ropeLight34')
engine.addEntity(ropeLight34)
ropeLight34.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(12.915316581726074, 9.847129821777344, 15.780800819396973),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788715124130249, 1.84735107421875, 2.0984013080596924)
})
ropeLight34.addComponentOrReplace(transform112)

const ropeLight35 = new Entity('ropeLight35')
engine.addEntity(ropeLight35)
ropeLight35.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(0.23249900341033936, 9.847129821777344, 13.049262046813965),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788718700408936, 1.8473525047302246, 2.0984013080596924)
})
ropeLight35.addComponentOrReplace(transform113)

const ropeLight36 = new Entity('ropeLight36')
engine.addEntity(ropeLight36)
ropeLight36.setParent(_scene)
const transform114 = new Transform({
  position: new Vector3(2.860182046890259, 9.847129821777344, 0.2737441062927246),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.6788709163665771, 1.847348690032959, 2.0984013080596924)
})
ropeLight36.addComponentOrReplace(transform114)

const nftPictureFrame20 = new Entity('nftPictureFrame20')
engine.addEntity(nftPictureFrame20)
nftPictureFrame20.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(13.26959228515625, 2.016827344894409, 8.09152889251709),
  rotation: new Quaternion(0.20526228845119476, 0.6766590476036072, -0.20526234805583954, 0.6766589879989624),
  scale: new Vector3(12.480159759521484, 9.634262084960938, 1.1856876611709595)
})
nftPictureFrame20.addComponentOrReplace(transform115)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(2.871155261993408, 2.016827344894409, 8.09152889251709),
  rotation: new Quaternion(0.20526225864887238, -0.6766589879989624, 0.20526237785816193, 0.6766590476036072),
  scale: new Vector3(12.480171203613281, 9.634262084960938, 1.1856880187988281)
})
nftPictureFrame21.addComponentOrReplace(transform116)

const nftPictureFrame26 = new Entity('nftPictureFrame26')
engine.addEntity(nftPictureFrame26)
nftPictureFrame26.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(7.937840461730957, 2.016827344894409, 2.799532890319824),
  rotation: new Quaternion(-2.9802318834981634e-8, -0.9569402933120728, 0.29028481245040894, 2.9802318834981634e-8),
  scale: new Vector3(12.480184555053711, 9.634263038635254, 1.185688853263855)
})
nftPictureFrame26.addComponentOrReplace(transform117)

const nftPictureFrame28 = new Entity('nftPictureFrame28')
engine.addEntity(nftPictureFrame28)
nftPictureFrame28.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(7.937840461730957, 2.016827344894409, 13.272254943847656),
  rotation: new Quaternion(0.2902846932411194, 2.9802322387695312e-8, 2.9802320611338473e-8, 0.9569403529167175),
  scale: new Vector3(12.480184555053711, 9.63426399230957, 1.185688853263855)
})
nftPictureFrame28.addComponentOrReplace(transform118)

const coffeeTable = new Entity('coffeeTable')
engine.addEntity(coffeeTable)
coffeeTable.setParent(_scene)
coffeeTable.addComponentOrReplace(gltfShape6)
const transform119 = new Transform({
  position: new Vector3(0.3393821716308594, 10.146903038024902, 7.976534843444824),
  rotation: new Quaternion(1.1250501669602536e-14, -0.7101039290428162, 8.465097067755778e-8, -0.7040969729423523),
  scale: new Vector3(4.066239356994629, 5.477626323699951, 0.29091742634773254)
})
coffeeTable.addComponentOrReplace(transform119)

const wallHexagonGrid9 = new Entity('wallHexagonGrid9')
engine.addEntity(wallHexagonGrid9)
wallHexagonGrid9.setParent(_scene)
wallHexagonGrid9.addComponentOrReplace(gltfShape7)
const transform120 = new Transform({
  position: new Vector3(15.590381622314453, 14.711639404296875, 3.8100876808166504),
  rotation: new Quaternion(-0.18343335390090942, 0.6828998923301697, 0.18343329429626465, 0.6828998923301697),
  scale: new Vector3(4.208630561828613, 0.7969920039176941, 0.06663988530635834)
})
wallHexagonGrid9.addComponentOrReplace(transform120)

const wallHexagonGrid10 = new Entity('wallHexagonGrid10')
engine.addEntity(wallHexagonGrid10)
wallHexagonGrid10.setParent(_scene)
wallHexagonGrid10.addComponentOrReplace(gltfShape7)
const transform121 = new Transform({
  position: new Vector3(0.17286378145217896, 14.711639404296875, 12.310087203979492),
  rotation: new Quaternion(-0.18343336880207062, -0.6828998923301697, -0.18343327939510345, 0.6828998923301697),
  scale: new Vector3(4.208635330200195, 0.7969930171966553, 0.0666399598121643)
})
wallHexagonGrid10.addComponentOrReplace(transform121)

const wallHexagonGrid11 = new Entity('wallHexagonGrid11')
engine.addEntity(wallHexagonGrid11)
wallHexagonGrid11.setParent(_scene)
wallHexagonGrid11.addComponentOrReplace(gltfShape7)
const transform122 = new Transform({
  position: new Vector3(12.090381622314453, 14.711639404296875, 15.974437713623047),
  rotation: new Quaternion(-0.2594139575958252, -2.9802322387695312e-8, 1.2860669862391205e-8, 0.9657663106918335),
  scale: new Vector3(4.208632469177246, 0.7969921827316284, 0.06663991510868073)
})
wallHexagonGrid11.addComponentOrReplace(transform122)

const wallHexagonGrid12 = new Entity('wallHexagonGrid12')
engine.addEntity(wallHexagonGrid12)
wallHexagonGrid12.setParent(_scene)
wallHexagonGrid12.addComponentOrReplace(gltfShape7)
const transform123 = new Transform({
  position: new Vector3(3.590381622314453, 14.711639404296875, 0.13601058721542358),
  rotation: new Quaternion(-1.2860669862391205e-8, -0.9657662510871887, -0.25941380858421326, -2.9802322387695312e-8),
  scale: new Vector3(4.208632469177246, 0.7969921231269836, 0.06663987785577774)
})
wallHexagonGrid12.addComponentOrReplace(transform123)

const wallHexagonGrid13 = new Entity('wallHexagonGrid13')
engine.addEntity(wallHexagonGrid13)
wallHexagonGrid13.setParent(_scene)
wallHexagonGrid13.addComponentOrReplace(gltfShape7)
const transform124 = new Transform({
  position: new Vector3(13.663531303405762, 14.208303451538086, 0.7227678298950195),
  rotation: new Quaternion(-0.07973547279834747, 0.9036027193069458, 0.19249838590621948, 0.3742845058441162),
  scale: new Vector3(1.1303751468658447, 0.7969921827316284, 0.06664018332958221)
})
wallHexagonGrid13.addComponentOrReplace(transform124)

const wallHexagonGrid14 = new Entity('wallHexagonGrid14')
engine.addEntity(wallHexagonGrid14)
wallHexagonGrid14.setParent(_scene)
wallHexagonGrid14.addComponentOrReplace(gltfShape7)
const transform125 = new Transform({
  position: new Vector3(2.0145106315612793, 14.208303451538086, 15.503531455993652),
  rotation: new Quaternion(-0.19249849021434784, -0.3742844760417938, -0.0797354131937027, 0.9036027193069458),
  scale: new Vector3(1.1303781270980835, 0.7969924211502075, 0.06664039194583893)
})
wallHexagonGrid14.addComponentOrReplace(transform125)

const wallHexagonGrid15 = new Entity('wallHexagonGrid15')
engine.addEntity(wallHexagonGrid15)
wallHexagonGrid15.setParent(_scene)
wallHexagonGrid15.addComponentOrReplace(gltfShape7)
const transform126 = new Transform({
  position: new Vector3(0.5145105719566345, 14.208303451538086, 2.277918815612793),
  rotation: new Quaternion(-0.07973551005125046, -0.9036027193069458, -0.1924983710050583, 0.3742845058441162),
  scale: new Vector3(1.1303809881210327, 0.796992301940918, 0.06664050370454788)
})
wallHexagonGrid15.addComponentOrReplace(transform126)

const wallHexagonGrid16 = new Entity('wallHexagonGrid16')
engine.addEntity(wallHexagonGrid16)
wallHexagonGrid16.setParent(_scene)
wallHexagonGrid16.addComponentOrReplace(gltfShape7)
const transform127 = new Transform({
  position: new Vector3(15.237356185913086, 14.208303451538086, 13.793784141540527),
  rotation: new Quaternion(-0.19249847531318665, 0.3742845058441162, 0.07973546534776688, 0.9036027193069458),
  scale: new Vector3(1.1303834915161133, 0.7969918251037598, 0.06664071977138519)
})
wallHexagonGrid16.addComponentOrReplace(transform127)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(14.384993553161621, 7.096432209014893, 1.5249147415161133),
  rotation: new Quaternion(3.795361513134546e-15, 0.3826833963394165, -4.5619415800501883e-8, -0.9238796234130859),
  scale: new Vector3(4.0000152587890625, 4.632970333099365, 0.5658560991287231)
})
nftPictureFrame4.addComponentOrReplace(transform128)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(1.3849937915802002, 10.845839500427246, 1.5249145030975342),
  rotation: new Quaternion(5.532468222187571e-16, -0.3826834559440613, 4.5619412247788205e-8, -0.9238795042037964),
  scale: new Vector3(4.000015735626221, 4.632970333099365, 0.5658562183380127)
})
nftPictureFrame6.addComponentOrReplace(transform129)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform130 = new Transform({
  position: new Vector3(1.384993314743042, 7.096432209014893, 1.5249149799346924),
  rotation: new Quaternion(5.532468222187571e-16, -0.3826834559440613, 4.5619412247788205e-8, -0.9238795042037964),
  scale: new Vector3(4.000015735626221, 4.632970333099365, 0.5658562183380127)
})
nftPictureFrame15.addComponentOrReplace(transform130)

const nftPictureFrame27 = new Entity('nftPictureFrame27')
engine.addEntity(nftPictureFrame27)
nftPictureFrame27.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(1.2045495510101318, 7.096432209014893, 14.720295906066895),
  rotation: new Quaternion(-1.7392746898815229e-15, -0.9238796234130859, 1.1013501932666259e-7, -0.3826834261417389),
  scale: new Vector3(4.000024795532227, 4.632970333099365, 0.565857470035553)
})
nftPictureFrame27.addComponentOrReplace(transform131)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(1.20455002784729, 10.845839500427246, 14.720295906066895),
  rotation: new Quaternion(-1.7392746898815229e-15, -0.9238796234130859, 1.1013501932666259e-7, -0.3826834261417389),
  scale: new Vector3(4.000024795532227, 4.632970333099365, 0.565857470035553)
})
nftPictureFrame30.addComponentOrReplace(transform132)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(14.417023658752441, 10.845839500427246, 14.622970581054688),
  rotation: new Quaternion(-5.582271959541111e-15, 0.9238795042037964, -1.1013500511580787e-7, -0.3826834559440613),
  scale: new Vector3(4.000033378601074, 4.632970333099365, 0.5658586025238037)
})
nftPictureFrame18.addComponentOrReplace(transform133)

const nftPictureFrame32 = new Entity('nftPictureFrame32')
engine.addEntity(nftPictureFrame32)
nftPictureFrame32.setParent(_scene)
const transform134 = new Transform({
  position: new Vector3(14.437300682067871, 7.096432209014893, 14.622970581054688),
  rotation: new Quaternion(-5.582271959541111e-15, 0.9238795042037964, -1.1013500511580787e-7, -0.3826834559440613),
  scale: new Vector3(4.000033378601074, 4.632970333099365, 0.5658586025238037)
})
nftPictureFrame32.addComponentOrReplace(transform134)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script1.spawn(nftPictureFrame8, {"id":"72405646120007613708465591283795435405784754144165659770746301100862491066369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script1.spawn(nftPictureFrame9, {"id":"72405646120007613708465591283795435405784754144165659770746301131648816644097","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script1.spawn(nftPictureFrame16, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame16, channelBus))
script1.spawn(nftPictureFrame17, {"id":"72405646120007613708465591283795435405784754144165659770746301134947351527425","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script1.spawn(nftPictureFrame31, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame31, channelBus))
script1.spawn(nftPictureFrame34, {"id":"72405646120007613708465591283795435405784754144165659770746301149241002688513","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame34, channelBus))
script1.spawn(nftPictureFrame35, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame35, channelBus))
script1.spawn(nftPictureFrame37, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame37, channelBus))
script1.spawn(nftPictureFrame38, {"id":"72405646120007613708465591283795435405784754144165659770746301119554188738561","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame38, channelBus))
script1.spawn(nftPictureFrame64, {"id":"72405646120007613708465591283795435405784754144165659770746301172330746871809","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .08 ETH"}, createChannel(channelId, nftPictureFrame64, channelBus))
script1.spawn(nftPictureFrame65, {"id":"72405646120007613708465591283795435405784754144165659770746301163534653849601","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame65, channelBus))
script1.spawn(nftPictureFrame68, {"id":"72405646120007613708465591283795435405784754144165659770746301123952235249665","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame68, channelBus))
script1.spawn(nftPictureFrame69, {"id":"72405646120007613708465591283795435405784754144165659770746301089867374788609","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame69, channelBus))
script1.spawn(nftPictureFrame72, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame72, channelBus))
script1.spawn(nftPictureFrame41, {"id":"72405646120007613708465591283795435405784754144165659770746301063479095721985","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame41, channelBus))
script1.spawn(nftPictureFrame42, {"id":"72405646120007613708465591283795435405784754144165659770746301062379584094209","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame42, channelBus))
script2.spawn(verticalBlackPad, {"distance":85,"speed":10,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad, channelBus))
script3.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script4.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script1.spawn(nftPictureFrame50, {"id":"72405646120007613708465591283795435405784754144165659770746301143743444549633","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame50, channelBus))
script1.spawn(nftPictureFrame52, {"id":"72405646120007613708465591283795435405784754144165659770746301171231235244033","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame52, channelBus))
script1.spawn(nftPictureFrame53, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame53, channelBus))
script1.spawn(nftPictureFrame55, {"id":"72405646120007613708465591283795435405784754144165659770746301144842956177409","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame55, channelBus))
script1.spawn(nftPictureFrame67, {"id":"72405646120007613708465591283795435405784754144165659770746301166833188732929","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame67, channelBus))
script1.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script1.spawn(nftPictureFrame10, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script1.spawn(nftPictureFrame12, {"id":"72405646120007613708465591283795435405784754144165659770746301121753211994113","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script1.spawn(nftPictureFrame47, {"id":"72405646120007613708465591283795435405784754144165659770746301142643932921857","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame47, channelBus))
script1.spawn(nftPictureFrame61, {"id":"72405646120007613708465591283795435405784754144165659770746301144842956177409","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame61, channelBus))
script1.spawn(nftPictureFrame, {"id":"72405646120007613708465591283795435405784754144165659770746301126151258505217","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script1.spawn(nftPictureFrame2, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script1.spawn(nftPictureFrame3, {"id":"72405646120007613708465591283795435405784754144165659770746301166833188732929","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script5.spawn(radio, {"startOn":true,"volume":1,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmWiz4AbpLH4JL8WPUsc6JQ4VQGb8TUvYigkPzEpsnLavD"}, createChannel(channelId, radio, channelBus))
script6.spawn(signpostTree5, {"text":"Up","fontSize":40}, createChannel(channelId, signpostTree5, channelBus))
script6.spawn(signpostTree6, {"text":"Up","fontSize":40}, createChannel(channelId, signpostTree6, channelBus))
script6.spawn(signpostTree7, {"text":"Up","fontSize":40}, createChannel(channelId, signpostTree7, channelBus))
script6.spawn(signpostTree8, {"text":"Up","fontSize":40}, createChannel(channelId, signpostTree8, channelBus))
script1.spawn(nftPictureFrame7, {"id":"72405646120007613708465591283795435405784754144165659770746301158037095710721","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script1.spawn(nftPictureFrame11, {"id":"72405646120007613708465591283795435405784754144165659770746301155838072455169","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script1.spawn(nftPictureFrame14, {"id":"72405646120007613708465591283795435405784754144165659770746301156937584082945","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script1.spawn(nftPictureFrame19, {"id":"72405646120007613708465591283795435405784754144165659770746301152539537571841","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame19, channelBus))
script1.spawn(nftPictureFrame22, {"id":"72405646120007613708465591283795435405784754144165659770746301164634165477377","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script1.spawn(nftPictureFrame23, {"id":"72405646120007613708465591283795435405784754144165659770746301156937584082945","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame23, channelBus))
script1.spawn(nftPictureFrame24, {"id":"72405646120007613708465591283795435405784754144165659770746301160236118966273","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame24, channelBus))
script1.spawn(nftPictureFrame25, {"id":"72405646120007613708465591283795435405784754144165659770746301159136607338497","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame25, channelBus))
script7.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script7.spawn(ropeLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight2, channelBus))
script7.spawn(ropeLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight3, channelBus))
script7.spawn(ropeLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight4, channelBus))
script7.spawn(ropeLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight5, channelBus))
script7.spawn(ropeLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight6, channelBus))
script7.spawn(ropeLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight7, channelBus))
script7.spawn(ropeLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight8, channelBus))
script7.spawn(ropeLight9, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight9, channelBus))
script7.spawn(ropeLight10, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight10, channelBus))
script7.spawn(ropeLight11, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight11, channelBus))
script7.spawn(ropeLight12, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight12, channelBus))
script7.spawn(ropeLight13, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight13, channelBus))
script7.spawn(ropeLight14, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight14, channelBus))
script7.spawn(ropeLight15, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight15, channelBus))
script7.spawn(ropeLight16, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight16, channelBus))
script7.spawn(ropeLight17, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight17, channelBus))
script7.spawn(ropeLight18, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight18, channelBus))
script7.spawn(ropeLight19, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight19, channelBus))
script7.spawn(ropeLight20, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight20, channelBus))
script7.spawn(ropeLight21, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight21, channelBus))
script7.spawn(ropeLight22, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight22, channelBus))
script7.spawn(ropeLight23, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight23, channelBus))
script7.spawn(ropeLight24, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight24, channelBus))
script7.spawn(ropeLight25, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight25, channelBus))
script7.spawn(ropeLight26, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight26, channelBus))
script7.spawn(ropeLight27, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight27, channelBus))
script7.spawn(ropeLight28, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight28, channelBus))
script7.spawn(ropeLight29, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight29, channelBus))
script7.spawn(ropeLight30, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight30, channelBus))
script7.spawn(ropeLight31, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight31, channelBus))
script7.spawn(ropeLight32, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight32, channelBus))
script7.spawn(ropeLight33, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight33, channelBus))
script7.spawn(ropeLight34, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight34, channelBus))
script7.spawn(ropeLight35, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight35, channelBus))
script7.spawn(ropeLight36, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight36, channelBus))
script1.spawn(nftPictureFrame20, {"id":"72405646120007613708465591283795435405784754144165659770746301165733677105153","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame20, channelBus))
script1.spawn(nftPictureFrame21, {"id":"72405646120007613708465591283795435405784754144165659770746301165733677105153","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame21, channelBus))
script1.spawn(nftPictureFrame26, {"id":"72405646120007613708465591283795435405784754144165659770746301165733677105153","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame26, channelBus))
script1.spawn(nftPictureFrame28, {"id":"72405646120007613708465591283795435405784754144165659770746301165733677105153","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":""}, createChannel(channelId, nftPictureFrame28, channelBus))
script1.spawn(nftPictureFrame4, {"id":"72405646120007613708465591283795435405784754144165659770746301145942467805185","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script1.spawn(nftPictureFrame6, {"id":"72405646120007613708465591283795435405784754144165659770746301150340514316289","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script1.spawn(nftPictureFrame15, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame15, channelBus))
script1.spawn(nftPictureFrame27, {"id":"72405646120007613708465591283795435405784754144165659770746301128350281760769","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame27, channelBus))
script1.spawn(nftPictureFrame30, {"id":"72405646120007613708465591283795435405784754144165659770746301127250770132993","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script1.spawn(nftPictureFrame18, {"id":"72405646120007613708465591283795435405784754144165659770746301147041979432961","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script1.spawn(nftPictureFrame32, {"id":"72405646120007613708465591283795435405784754144165659770746301133847839899649","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame32, channelBus))