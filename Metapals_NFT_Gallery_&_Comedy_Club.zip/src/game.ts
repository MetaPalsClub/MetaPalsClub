import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../58dc566a-2add-4326-b61c-0fdf46903195/src/item"
import Script2 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script3 from "../7e78cd70-5414-4ec4-be5f-198ec9879a5e/src/item"
import Script4 from "../a747f104-5434-42a8-a543-8739c24cf253/src/item"
import Script5 from "../94d40c0a-759a-4210-bb23-7a87d9e143f1/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const wallFuturistic = new Entity('wallFuturistic')
engine.addEntity(wallFuturistic)
wallFuturistic.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(7.274981498718262, 0, 15.958828926086426),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.565148115158081, 4.908885955810547, 0.2674713134765625)
})
wallFuturistic.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("bf2b6c7948d0922d7105a79f519db233b1bb3dad2321bbcbdb097de62c0dab11/FuturisticWall.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
wallFuturistic.addComponentOrReplace(gltfShape)

const wallFuturistic2 = new Entity('wallFuturistic2')
engine.addEntity(wallFuturistic2)
wallFuturistic2.setParent(_scene)
wallFuturistic2.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(0.14782071113586426, 0, 10.150323867797852),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.807488441467285, 4.900798320770264, 0.2674722671508789)
})
wallFuturistic2.addComponentOrReplace(transform3)

const verticalPlatform = new Entity('verticalPlatform')
engine.addEntity(verticalPlatform)
verticalPlatform.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(1.1922025680541992, 1.4868388175964355, 2.641437530517578),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.8540468215942383, 1, 2.3253750801086426)
})
verticalPlatform.addComponentOrReplace(transform4)

const verticalPlatform2 = new Entity('verticalPlatform2')
engine.addEntity(verticalPlatform2)
verticalPlatform2.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(13.336196899414062, 1.4868388175964355, 14.81934928894043),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.2555882930755615, 1, 0.9440109729766846)
})
verticalPlatform2.addComponentOrReplace(transform5)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(15.963220596313477, 0.977658748626709, 13),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.59379768371582, 9.265453338623047, 1.0000057220458984)
})
nftPictureFrame2.addComponentOrReplace(transform6)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(15.963220596313477, 1.0005183219909668, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.5937957763671875, 9.265938758850098, 1.0000054836273193)
})
nftPictureFrame4.addComponentOrReplace(transform7)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(15.963220596313477, 7.200077533721924, 13),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593791961669922, 10.0425386428833, 1.0000050067901611)
})
nftPictureFrame.addComponentOrReplace(transform8)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(15.963220596313477, 7.200077533721924, 3),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593793869018555, 10.0425386428833, 1.0000052452087402)
})
nftPictureFrame6.addComponentOrReplace(transform9)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(15.963220596313477, 14.020363807678223, 13),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593793869018555, 10.0425386428833, 1.0000052452087402)
})
nftPictureFrame7.addComponentOrReplace(transform10)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(15.963220596313477, 14.020363807678223, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593793869018555, 10.0425386428833, 1.0000052452087402)
})
nftPictureFrame8.addComponentOrReplace(transform11)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(15.963220596313477, 14.020363807678223, 3),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.5937957763671875, 10.0425386428833, 1.0000054836273193)
})
nftPictureFrame9.addComponentOrReplace(transform12)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(12.963220596313477, 0.7444839477539062, 0.05216026306152344),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593784332275391, 10.443582534790039, 1.0000040531158447)
})
nftPictureFrame10.addComponentOrReplace(transform13)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(7.96321964263916, 0.8440937995910645, 0.052161216735839844),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593784332275391, 10.0425386428833, 1.0000040531158447)
})
nftPictureFrame11.addComponentOrReplace(transform14)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(2.9632186889648438, 0.7444829940795898, 0.05216217041015625),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593786239624023, 10.443582534790039, 1.0000042915344238)
})
nftPictureFrame12.addComponentOrReplace(transform15)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(2.9632205963134766, 7.261369228363037, 0.03762531280517578),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593788146972656, 10.0425386428833, 1.000004529953003)
})
nftPictureFrame13.addComponentOrReplace(transform16)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(12.963220596313477, 7.261368751525879, 0.032343387603759766),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593786239624023, 10.0425386428833, 1.0000042915344238)
})
nftPictureFrame15.addComponentOrReplace(transform17)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(12.96322250366211, 14.036521911621094, 0.05216026306152344),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593788146972656, 9.686063766479492, 1.000004529953003)
})
nftPictureFrame16.addComponentOrReplace(transform18)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(7.963221549987793, 14.020363807678223, 0.05216026306152344),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593788146972656, 10.0425386428833, 1.000004529953003)
})
nftPictureFrame17.addComponentOrReplace(transform19)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(2.9632205963134766, 14.020364761352539, 0.05216026306152344),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.593790054321289, 10.0425386428833, 1.000004768371582)
})
nftPictureFrame18.addComponentOrReplace(transform20)

const nftPictureFrame20 = new Entity('nftPictureFrame20')
engine.addEntity(nftPictureFrame20)
nftPictureFrame20.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(3.711301326751709, 7.3709001541137695, 15.956565856933594),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, -1.088531040241566e-15, 1),
  scale: new Vector3(7.593786239624023, 9.652515411376953, 1.0000042915344238)
})
nftPictureFrame20.addComponentOrReplace(transform21)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(3.711300849914551, 14.0492582321167, 15.956564903259277),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, -1.088531040241566e-15, 1),
  scale: new Vector3(7.593788146972656, 9.652515411376953, 1.000004529953003)
})
nftPictureFrame21.addComponentOrReplace(transform22)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(0.04844093322753906, 0.9125480651855469, 12.843570709228516),
  rotation: new Quaternion(-2.743679053076502e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593807220458984, 9.652515411376953, 1.000006914138794)
})
nftPictureFrame22.addComponentOrReplace(transform23)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(0.04844045639038086, 6.947059631347656, 12.843568801879883),
  rotation: new Quaternion(-2.743679053076502e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593799591064453, 11.390625, 1.0000059604644775)
})
nftPictureFrame23.addComponentOrReplace(transform24)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(0.04844045639038086, 13.715314865112305, 12.84356689453125),
  rotation: new Quaternion(-2.743679053076502e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593801498413086, 11.390625, 1.0000061988830566)
})
nftPictureFrame24.addComponentOrReplace(transform25)

const signpostTree = new Entity('signpostTree')
engine.addEntity(signpostTree)
signpostTree.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(7.965038299560547, 7.293859481811523, 0.01829027757048607),
  rotation: new Quaternion(6.635589193187356e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(2.5668981075286865, 4.721567630767822, 1)
})
signpostTree.addComponentOrReplace(transform26)

const signpostTree2 = new Entity('signpostTree2')
engine.addEntity(signpostTree2)
signpostTree2.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(15.973556518554688, 7.38093376159668, 8.057090759277344),
  rotation: new Quaternion(1.0747230267727816e-14, 0.7071067690849304, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.4547324180603027, 4.630883693695068, 1)
})
signpostTree2.addComponentOrReplace(transform27)

const signpostTree3 = new Entity('signpostTree3')
engine.addEntity(signpostTree3)
signpostTree3.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(0.01338958740234375, 7.3901214599609375, 2.667842149734497),
  rotation: new Quaternion(-4.127578846475997e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.785750150680542, 4.490051746368408, 1.0000085830688477)
})
signpostTree3.addComponentOrReplace(transform28)

const signpostTree4 = new Entity('signpostTree4')
engine.addEntity(signpostTree4)
signpostTree4.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(13.369629859924316, 7.404770851135254, 15.977176666259766),
  rotation: new Quaternion(-3.552713678800501e-15, -2.2351741790771484e-8, 7.935584020414208e-15, 1),
  scale: new Vector3(1.8130700588226318, 4.529245853424072, 1.000002384185791)
})
signpostTree4.addComponentOrReplace(transform29)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(0.1739521026611328, 15.06531810760498, 2.6118555068969727),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.7969110012054443, 5.6953125, 0.5000043511390686)
})
nftPictureFrame5.addComponentOrReplace(transform30)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(13.504712104797363, 8.611555099487305, 15.871301651000977),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame14.addComponentOrReplace(transform31)

const nftPictureFrame25 = new Entity('nftPictureFrame25')
engine.addEntity(nftPictureFrame25)
nftPictureFrame25.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(13.51201343536377, 15.145454406738281, 15.828689575195312),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame25.addComponentOrReplace(transform32)

const nftPictureFrame26 = new Entity('nftPictureFrame26')
engine.addEntity(nftPictureFrame26)
nftPictureFrame26.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(0.2637367248535156, 9.248017311096191, 2.6363182067871094),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.7969157695770264, 5.128884315490723, 0.5000049471855164)
})
nftPictureFrame26.addComponentOrReplace(transform33)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(3.711301803588867, 0.976902961730957, 15.956565856933594),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, -1.088531040241566e-15, 1),
  scale: new Vector3(7.593786239624023, 9.652515411376953, 1.0000042915344238)
})
nftPictureFrame3.addComponentOrReplace(transform34)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(13.392844200134277, 0.8353047370910645, 15.956565856933594),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, -1.088531040241566e-15, 1),
  scale: new Vector3(7.593786239624023, 10.040206909179688, 1.0000042915344238)
})
nftPictureFrame19.addComponentOrReplace(transform35)

const nftPictureFrame27 = new Entity('nftPictureFrame27')
engine.addEntity(nftPictureFrame27)
nftPictureFrame27.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(15.963220596313477, 0.9615230560302734, 3),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593790054321289, 9.238396644592285, 1.000004768371582)
})
nftPictureFrame27.addComponentOrReplace(transform36)

const glass = new Entity('glass')
engine.addEntity(glass)
glass.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(3.6012306213378906, 0, 12.845247268676758),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.079696178436279, 0.4160313606262207, 6.000001430511475)
})
glass.addComponentOrReplace(transform37)
const gltfShape2 = new GLTFShape("50131923e14ed26cca4626faee6609c4107eb684dce0443c71378c2cfdf8d1dd/glass.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
glass.addComponentOrReplace(gltfShape2)

const glassBlack = new Entity('glassBlack')
engine.addEntity(glassBlack)
glassBlack.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(3.1018803119659424, 0.5, 13.387984275817871),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(6, 1, 5.000000953674316)
})
glassBlack.addComponentOrReplace(transform38)
const gltfShape3 = new GLTFShape("32a02ed355bdd5a2491e66bdc8a9e5a1e8b7430200d954af4e4bb19de06d4d09/glass_black.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
glassBlack.addComponentOrReplace(gltfShape3)

const nftPictureFrame28 = new Entity('nftPictureFrame28')
engine.addEntity(nftPictureFrame28)
nftPictureFrame28.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(13.392845153808594, 14.07422924041748, 15.956565856933594),
  rotation: new Quaternion(-2.7916168827263593e-15, 0, -1.088531040241566e-15, 1),
  scale: new Vector3(7.593786239624023, 9.652515411376953, 1.0000042915344238)
})
nftPictureFrame28.addComponentOrReplace(transform39)

const nftPictureFrame29 = new Entity('nftPictureFrame29')
engine.addEntity(nftPictureFrame29)
nftPictureFrame29.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(0.04844093322753906, 0.9125485420227051, 2.6137123107910156),
  rotation: new Quaternion(-2.743679053076502e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593809127807617, 9.652515411376953, 1.000007152557373)
})
nftPictureFrame29.addComponentOrReplace(transform40)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(0.04844093322753906, 14.049959182739258, 2.6137123107910156),
  rotation: new Quaternion(-2.743679053076502e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.593812942504883, 9.652515411376953, 1.0000076293945312)
})
nftPictureFrame30.addComponentOrReplace(transform41)

const signpostTree5 = new Entity('signpostTree5')
engine.addEntity(signpostTree5)
signpostTree5.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(3.630859375, 2.42220139503479, 15.796663284301758),
  rotation: new Quaternion(6.635589193187356e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(2.4935755729675293, 3.323535442352295, 1)
})
signpostTree5.addComponentOrReplace(transform42)

const signpostTree6 = new Entity('signpostTree6')
engine.addEntity(signpostTree6)
signpostTree6.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(0.21242523193359375, 2.3756210803985596, 12.842644691467285),
  rotation: new Quaternion(1.0747230267727816e-14, 0.7071067690849304, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.310276985168457, 3.407674789428711, 1)
})
signpostTree6.addComponentOrReplace(transform43)

const wallPlainBlack = new Entity('wallPlainBlack')
engine.addEntity(wallPlainBlack)
wallPlainBlack.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(15.019939422607422, 7.529757976531982, 15.98727035522461),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6606100797653198, 1.1292099952697754, 0.33308255672454834)
})
wallPlainBlack.addComponentOrReplace(transform44)
const gltfShape4 = new GLTFShape("06ece3735838040700ce75b8efcd993dba4c332b271fffa3ee76507512f4e0fc/PlainBlackWall.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
wallPlainBlack.addComponentOrReplace(gltfShape4)

const wallPlainBlack2 = new Entity('wallPlainBlack2')
engine.addEntity(wallPlainBlack2)
wallPlainBlack2.setParent(_scene)
wallPlainBlack2.addComponentOrReplace(gltfShape4)
const transform45 = new Transform({
  position: new Vector3(0.11448675394058228, 6.391359806060791, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.965818881988525, 0.09845852106809616, 0.3330821096897125)
})
wallPlainBlack2.addComponentOrReplace(transform45)

const wallPlainBlack3 = new Entity('wallPlainBlack3')
engine.addEntity(wallPlainBlack3)
wallPlainBlack3.setParent(_scene)
wallPlainBlack3.addComponentOrReplace(gltfShape4)
const transform46 = new Transform({
  position: new Vector3(5.628243923187256, 7.463967800140381, 0.01258540153503418),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(2.341846466064453, 1.1763044595718384, 0.3330826163291931)
})
wallPlainBlack3.addComponentOrReplace(transform46)

const wallPlainBlack4 = new Entity('wallPlainBlack4')
engine.addEntity(wallPlainBlack4)
wallPlainBlack4.setParent(_scene)
wallPlainBlack4.addComponentOrReplace(gltfShape4)
const transform47 = new Transform({
  position: new Vector3(0.005781050771474838, 7.529757976531982, 4.3158087730407715),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.660612940788269, 1.1292099952697754, 0.33308255672454834)
})
wallPlainBlack4.addComponentOrReplace(transform47)

const wallPlainBlack5 = new Entity('wallPlainBlack5')
engine.addEntity(wallPlainBlack5)
wallPlainBlack5.setParent(_scene)
wallPlainBlack5.addComponentOrReplace(gltfShape4)
const transform48 = new Transform({
  position: new Vector3(15.981100082397461, 7.463967800140381, 5.711318016052246),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.3418450355529785, 1.1763044595718384, 0.33308255672454834)
})
wallPlainBlack5.addComponentOrReplace(transform48)

const wallPlainBlack6 = new Entity('wallPlainBlack6')
engine.addEntity(wallPlainBlack6)
wallPlainBlack6.setParent(_scene)
wallPlainBlack6.addComponentOrReplace(gltfShape4)
const transform49 = new Transform({
  position: new Vector3(1.3119640350341797, 2.6619045734405518, 15.779041290283203),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(2.3119120597839355, 0.762809157371521, 0.3330826163291931)
})
wallPlainBlack6.addComponentOrReplace(transform49)

const wallPlainBlack7 = new Entity('wallPlainBlack7')
engine.addEntity(wallPlainBlack7)
wallPlainBlack7.setParent(_scene)
wallPlainBlack7.addComponentOrReplace(gltfShape4)
const transform50 = new Transform({
  position: new Vector3(0.11985397338867188, 2.5105018615722656, 15.001419067382812),
  rotation: new Quaternion(-8.64484282363286e-15, 0.7071067690849304, -8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(2.1413657665252686, 0.8278048634529114, 0.3330826163291931)
})
wallPlainBlack7.addComponentOrReplace(transform50)

const wallPlainBlack8 = new Entity('wallPlainBlack8')
engine.addEntity(wallPlainBlack8)
wallPlainBlack8.setParent(_scene)
wallPlainBlack8.addComponentOrReplace(gltfShape4)
const transform51 = new Transform({
  position: new Vector3(15.981100082397461, 7.463967800140381, 5.711318016052246),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.3418450355529785, 1.1763044595718384, 0.33308255672454834)
})
wallPlainBlack8.addComponentOrReplace(transform51)

const wallPlainBlack9 = new Entity('wallPlainBlack9')
engine.addEntity(wallPlainBlack9)
wallPlainBlack9.setParent(_scene)
wallPlainBlack9.addComponentOrReplace(gltfShape4)
const transform52 = new Transform({
  position: new Vector3(0.1144866943359375, 13.04508113861084, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.616304874420166, 0.09845852106809616, 0.3330819308757782)
})
wallPlainBlack9.addComponentOrReplace(transform52)

const wallPlainBlack10 = new Entity('wallPlainBlack10')
engine.addEntity(wallPlainBlack10)
wallPlainBlack10.setParent(_scene)
wallPlainBlack10.addComponentOrReplace(gltfShape4)
const transform53 = new Transform({
  position: new Vector3(0.11448675394058228, 13.068408012390137, 0.03870880603790283),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.936089515686035, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack10.addComponentOrReplace(transform53)

const wallPlainBlack11 = new Entity('wallPlainBlack11')
engine.addEntity(wallPlainBlack11)
wallPlainBlack11.setParent(_scene)
wallPlainBlack11.addComponentOrReplace(gltfShape4)
const transform54 = new Transform({
  position: new Vector3(0.11448675394058228, 6.4295148849487305, 0.03870880603790283),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.936089515686035, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack11.addComponentOrReplace(transform54)

const wallPlainBlack12 = new Entity('wallPlainBlack12')
engine.addEntity(wallPlainBlack12)
wallPlainBlack12.setParent(_scene)
wallPlainBlack12.addComponentOrReplace(gltfShape4)
const transform55 = new Transform({
  position: new Vector3(0.05230432003736496, 0, 0.03870869427919388),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.936089515686035, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack12.addComponentOrReplace(transform55)

const wallPlainBlack13 = new Entity('wallPlainBlack13')
engine.addEntity(wallPlainBlack13)
wallPlainBlack13.setParent(_scene)
wallPlainBlack13.addComponentOrReplace(gltfShape4)
const transform56 = new Transform({
  position: new Vector3(15.998268127441406, 13.070622444152832, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.965824604034424, 0.09845852106809616, 0.333081990480423)
})
wallPlainBlack13.addComponentOrReplace(transform56)

const wallPlainBlack14 = new Entity('wallPlainBlack14')
engine.addEntity(wallPlainBlack14)
wallPlainBlack14.setParent(_scene)
wallPlainBlack14.addComponentOrReplace(gltfShape4)
const transform57 = new Transform({
  position: new Vector3(15.998268127441406, 6.389320373535156, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.965826511383057, 0.09845852106809616, 0.333081990480423)
})
wallPlainBlack14.addComponentOrReplace(transform57)

const wallPlainBlack15 = new Entity('wallPlainBlack15')
engine.addEntity(wallPlainBlack15)
wallPlainBlack15.setParent(_scene)
wallPlainBlack15.addComponentOrReplace(gltfShape4)
const transform58 = new Transform({
  position: new Vector3(0.11448675394058228, 13.068408012390137, 15.894967079162598),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.601691961288452, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack15.addComponentOrReplace(transform58)

const wallPlainBlack16 = new Entity('wallPlainBlack16')
engine.addEntity(wallPlainBlack16)
wallPlainBlack16.setParent(_scene)
wallPlainBlack16.addComponentOrReplace(gltfShape4)
const transform59 = new Transform({
  position: new Vector3(0.11448675394058228, 6.403277397155762, 15.894967079162598),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.936089515686035, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack16.addComponentOrReplace(transform59)

const wallPlainGlass = new Entity('wallPlainGlass')
engine.addEntity(wallPlainGlass)
wallPlainGlass.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(10.824103355407715, 7.043292045593262, 15.961666107177734),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.7907058000564575, 0.1518286168575287, 0.14495790004730225)
})
wallPlainGlass.addComponentOrReplace(transform60)
const gltfShape5 = new GLTFShape("ceed966710028a407635a309e91f31236a72714a515035e8330211b84c9b8445/PlainGlassWall.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
wallPlainGlass.addComponentOrReplace(gltfShape5)

const wallPlainGlass2 = new Entity('wallPlainGlass2')
engine.addEntity(wallPlainGlass2)
wallPlainGlass2.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(0.00102996826171875, 7.064826011657715, 9.825395584106445),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.2552483081817627, 0.15574190020561218, 0.39199742674827576)
})
wallPlainGlass2.addComponentOrReplace(transform61)
wallPlainGlass2.addComponentOrReplace(gltfShape5)

const doorframeGlass = new Entity('doorframeGlass')
engine.addEntity(doorframeGlass)
doorframeGlass.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(10.878403663635254, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6999362707138062, 1.603243112564087, 0.10084214061498642)
})
doorframeGlass.addComponentOrReplace(transform62)
const gltfShape6 = new GLTFShape("4c81b76bffb97cfe01d313e95d626c9963b9a0840341a0d44cf958064e0c8172/GlassDoorframe.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
doorframeGlass.addComponentOrReplace(gltfShape6)

const doorframeGlass2 = new Entity('doorframeGlass2')
engine.addEntity(doorframeGlass2)
doorframeGlass2.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(0.09369885921478271, 0, 5.291280746459961),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.2577321529388428, 1.6006245613098145, 0.07209040224552155)
})
doorframeGlass2.addComponentOrReplace(transform63)
doorframeGlass2.addComponentOrReplace(gltfShape6)

const wallPlainBlack17 = new Entity('wallPlainBlack17')
engine.addEntity(wallPlainBlack17)
wallPlainBlack17.setParent(_scene)
wallPlainBlack17.addComponentOrReplace(gltfShape4)
const transform64 = new Transform({
  position: new Vector3(0.11448675394058228, 0, 0.033069610595703125),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.6400718688964844, 0.09845852106809616, 0.333081990480423)
})
wallPlainBlack17.addComponentOrReplace(transform64)

const wallPlainBlack18 = new Entity('wallPlainBlack18')
engine.addEntity(wallPlainBlack18)
wallPlainBlack18.setParent(_scene)
wallPlainBlack18.addComponentOrReplace(gltfShape4)
const transform65 = new Transform({
  position: new Vector3(0.11448675394058228, 0, 9.734774589538574),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.134972333908081, 0.09845852106809616, 0.33308175206184387)
})
wallPlainBlack18.addComponentOrReplace(transform65)

const wallPlainBlack19 = new Entity('wallPlainBlack19')
engine.addEntity(wallPlainBlack19)
wallPlainBlack19.setParent(_scene)
wallPlainBlack19.addComponentOrReplace(gltfShape4)
const transform66 = new Transform({
  position: new Vector3(0.14765578508377075, 0, 15.894967079162598),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.570309638977051, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack19.addComponentOrReplace(transform66)

const wallPlainBlack20 = new Entity('wallPlainBlack20')
engine.addEntity(wallPlainBlack20)
wallPlainBlack20.setParent(_scene)
wallPlainBlack20.addComponentOrReplace(gltfShape4)
const transform67 = new Transform({
  position: new Vector3(10.781586647033691, 0, 15.894967079162598),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(2.5846259593963623, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack20.addComponentOrReplace(transform67)

const wallPlainBlack21 = new Entity('wallPlainBlack21')
engine.addEntity(wallPlainBlack21)
wallPlainBlack21.setParent(_scene)
wallPlainBlack21.addComponentOrReplace(gltfShape4)
const transform68 = new Transform({
  position: new Vector3(15.998268127441406, 0, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.9658284187316895, 0.09845852106809616, 0.333081990480423)
})
wallPlainBlack21.addComponentOrReplace(transform68)

const wallPlainBlack22 = new Entity('wallPlainBlack22')
engine.addEntity(wallPlainBlack22)
wallPlainBlack22.setParent(_scene)
wallPlainBlack22.addComponentOrReplace(gltfShape4)
const transform69 = new Transform({
  position: new Vector3(0.1144866943359375, 19.568578720092773, 0.03870880603790283),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.936089515686035, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack22.addComponentOrReplace(transform69)

const wallPlainBlack23 = new Entity('wallPlainBlack23')
engine.addEntity(wallPlainBlack23)
wallPlainBlack23.setParent(_scene)
wallPlainBlack23.addComponentOrReplace(gltfShape4)
const transform70 = new Transform({
  position: new Vector3(15.998268127441406, 19.570791244506836, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.9658284187316895, 0.09845852106809616, 0.33308181166648865)
})
wallPlainBlack23.addComponentOrReplace(transform70)

const wallPlainBlack24 = new Entity('wallPlainBlack24')
engine.addEntity(wallPlainBlack24)
wallPlainBlack24.setParent(_scene)
wallPlainBlack24.addComponentOrReplace(gltfShape4)
const transform71 = new Transform({
  position: new Vector3(0.11448675394058228, 19.568408966064453, 15.894967079162598),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(7.936089515686035, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack24.addComponentOrReplace(transform71)

const wallPlainBlack25 = new Entity('wallPlainBlack25')
engine.addEntity(wallPlainBlack25)
wallPlainBlack25.setParent(_scene)
wallPlainBlack25.addComponentOrReplace(gltfShape4)
const transform72 = new Transform({
  position: new Vector3(0.11448675394058228, 19.545082092285156, 0),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.965824604034424, 0.09845852106809616, 0.33308202028274536)
})
wallPlainBlack25.addComponentOrReplace(transform72)

const wallPlainBlack26 = new Entity('wallPlainBlack26')
engine.addEntity(wallPlainBlack26)
wallPlainBlack26.setParent(_scene)
wallPlainBlack26.addComponentOrReplace(gltfShape4)
const transform73 = new Transform({
  position: new Vector3(15.998268127441406, 19.955711364746094, 0),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(9.97726821899414, 0.09845853596925735, 0.33308202028274536)
})
wallPlainBlack26.addComponentOrReplace(transform73)

const wallPlainBlack27 = new Entity('wallPlainBlack27')
engine.addEntity(wallPlainBlack27)
wallPlainBlack27.setParent(_scene)
wallPlainBlack27.addComponentOrReplace(gltfShape4)
const transform74 = new Transform({
  position: new Vector3(15.998268127441406, 19.955711364746094, 15.5),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(9.97726821899414, 0.09845853596925735, 0.33308202028274536)
})
wallPlainBlack27.addComponentOrReplace(transform74)

const wallPlainBlack28 = new Entity('wallPlainBlack28')
engine.addEntity(wallPlainBlack28)
wallPlainBlack28.setParent(_scene)
wallPlainBlack28.addComponentOrReplace(gltfShape4)
const transform75 = new Transform({
  position: new Vector3(0.099761962890625, 19.955711364746094, 15.611383438110352),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(9.97726821899414, 0.09845853596925735, 0.33308202028274536)
})
wallPlainBlack28.addComponentOrReplace(transform75)

const wallPlainBlack29 = new Entity('wallPlainBlack29')
engine.addEntity(wallPlainBlack29)
wallPlainBlack29.setParent(_scene)
wallPlainBlack29.addComponentOrReplace(gltfShape4)
const transform76 = new Transform({
  position: new Vector3(0.0997619554400444, 19.955711364746094, 0.06366729736328125),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(9.97726821899414, 0.09845853596925735, 0.33308202028274536)
})
wallPlainBlack29.addComponentOrReplace(transform76)

const wallPlainBlack30 = new Entity('wallPlainBlack30')
engine.addEntity(wallPlainBlack30)
wallPlainBlack30.setParent(_scene)
wallPlainBlack30.addComponentOrReplace(gltfShape4)
const transform77 = new Transform({
  position: new Vector3(0.0997619554400444, 19.955711364746094, 9.796586036682129),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(9.97726821899414, 0.09845853596925735, 0.33308202028274536)
})
wallPlainBlack30.addComponentOrReplace(transform77)

const wallPlainBlack31 = new Entity('wallPlainBlack31')
engine.addEntity(wallPlainBlack31)
wallPlainBlack31.setParent(_scene)
wallPlainBlack31.addComponentOrReplace(gltfShape4)
const transform78 = new Transform({
  position: new Vector3(0.0997619554400444, 19.955711364746094, 4.914857864379883),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999988079071045, 0.5),
  scale: new Vector3(9.97726821899414, 0.09845853596925735, 0.33308202028274536)
})
wallPlainBlack31.addComponentOrReplace(transform78)

const wallPlainBlack32 = new Entity('wallPlainBlack32')
engine.addEntity(wallPlainBlack32)
wallPlainBlack32.setParent(_scene)
wallPlainBlack32.addComponentOrReplace(gltfShape4)
const transform79 = new Transform({
  position: new Vector3(15.59791374206543, 19.955711364746094, 15.902372360229492),
  rotation: new Quaternion(0.7071068286895752, 0.7071068286895752, -1.6135614089307637e-7, 0),
  scale: new Vector3(9.977272987365723, 0.0984586700797081, 0.3330826759338379)
})
wallPlainBlack32.addComponentOrReplace(transform79)

const wallPlainBlack33 = new Entity('wallPlainBlack33')
engine.addEntity(wallPlainBlack33)
wallPlainBlack33.setParent(_scene)
wallPlainBlack33.addComponentOrReplace(gltfShape4)
const transform80 = new Transform({
  position: new Vector3(15.59791374206543, 19.955711364746094, 0),
  rotation: new Quaternion(0.7071068286895752, 0.7071068286895752, -1.6135614089307637e-7, 0),
  scale: new Vector3(9.977274894714355, 0.09845871478319168, 0.333082914352417)
})
wallPlainBlack33.addComponentOrReplace(transform80)

const wallPlainBlack34 = new Entity('wallPlainBlack34')
engine.addEntity(wallPlainBlack34)
wallPlainBlack34.setParent(_scene)
wallPlainBlack34.addComponentOrReplace(gltfShape4)
const transform81 = new Transform({
  position: new Vector3(0.09791362285614014, 19.955711364746094, 0.0000018477439880371094),
  rotation: new Quaternion(0.7071068286895752, 0.7071068286895752, -1.6135614089307637e-7, 0),
  scale: new Vector3(9.977278709411621, 0.09845880419015884, 0.3330833911895752)
})
wallPlainBlack34.addComponentOrReplace(transform81)

const wallPlainBlack35 = new Entity('wallPlainBlack35')
engine.addEntity(wallPlainBlack35)
wallPlainBlack35.setParent(_scene)
wallPlainBlack35.addComponentOrReplace(gltfShape4)
const transform82 = new Transform({
  position: new Vector3(10.81637191772461, 19.955711364746094, 15.906949996948242),
  rotation: new Quaternion(0.7071068286895752, 0.7071068286895752, -1.6135614089307637e-7, 0),
  scale: new Vector3(9.977288246154785, 0.09845905005931854, 0.33308467268943787)
})
wallPlainBlack35.addComponentOrReplace(transform82)

const wallPlainBlack36 = new Entity('wallPlainBlack36')
engine.addEntity(wallPlainBlack36)
wallPlainBlack36.setParent(_scene)
wallPlainBlack36.addComponentOrReplace(gltfShape4)
const transform83 = new Transform({
  position: new Vector3(7.09791374206543, 19.955711364746094, 15.906949996948242),
  rotation: new Quaternion(0.7071068286895752, 0.7071068286895752, -1.6135614089307637e-7, 0),
  scale: new Vector3(9.977286338806152, 0.09845898300409317, 0.3330843448638916)
})
wallPlainBlack36.addComponentOrReplace(transform83)

const wallPlainBlack37 = new Entity('wallPlainBlack37')
engine.addEntity(wallPlainBlack37)
wallPlainBlack37.setParent(_scene)
wallPlainBlack37.addComponentOrReplace(gltfShape4)
const transform84 = new Transform({
  position: new Vector3(0.04585862159729004, 19.955711364746094, 15.906949996948242),
  rotation: new Quaternion(0.7071068286895752, 0.7071068286895752, -1.6135614089307637e-7, 0),
  scale: new Vector3(9.977293968200684, 0.09845924377441406, 0.3330856263637543)
})
wallPlainBlack37.addComponentOrReplace(transform84)

const wallPlainGlass7 = new Entity('wallPlainGlass7')
engine.addEntity(wallPlainGlass7)
wallPlainGlass7.setParent(_scene)
wallPlainGlass7.addComponentOrReplace(gltfShape5)
const transform85 = new Transform({
  position: new Vector3(15.880594253540039, 13.170878410339355, 0.15453004837036133),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(6.8100266456604, 3.364389419555664, 0.1881696730852127)
})
wallPlainGlass7.addComponentOrReplace(transform85)

const wallPlainGlass14 = new Entity('wallPlainGlass14')
engine.addEntity(wallPlainGlass14)
wallPlainGlass14.setParent(_scene)
wallPlainGlass14.addComponentOrReplace(gltfShape5)
const transform86 = new Transform({
  position: new Vector3(10.815423011779785, 1.5003461837768555, 0.1258092224597931),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(5.335572242736816, 1.2799559831619263, 0.1881696730852127)
})
wallPlainGlass14.addComponentOrReplace(transform86)

const wallPlainGlass15 = new Entity('wallPlainGlass15')
engine.addEntity(wallPlainGlass15)
wallPlainGlass15.setParent(_scene)
wallPlainGlass15.addComponentOrReplace(gltfShape5)
const transform87 = new Transform({
  position: new Vector3(15.892654418945312, 1.5003461837768555, 15.873411178588867),
  rotation: new Quaternion(0.5000001192092896, -0.4999999403953552, 0.5000000596046448, 0.5),
  scale: new Vector3(7.846922397613525, 1.2706642150878906, 0.1881723254919052)
})
wallPlainGlass15.addComponentOrReplace(transform87)

const wallPlainGlass13 = new Entity('wallPlainGlass13')
engine.addEntity(wallPlainGlass13)
wallPlainGlass13.setParent(_scene)
wallPlainGlass13.addComponentOrReplace(gltfShape5)
const transform88 = new Transform({
  position: new Vector3(10.791725158691406, 6.525995254516602, 13.616251945495605),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1214356422424316, 2.1337978839874268, 0.14495840668678284)
})
wallPlainGlass13.addComponentOrReplace(transform88)

const wallPlainGlass16 = new Entity('wallPlainGlass16')
engine.addEntity(wallPlainGlass16)
wallPlainGlass16.setParent(_scene)
wallPlainGlass16.addComponentOrReplace(gltfShape5)
const transform89 = new Transform({
  position: new Vector3(2.257134437561035, 6.502294540405273, 5.334196090698242),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.088750958442688, 2.6379661560058594, 0.14495813846588135)
})
wallPlainGlass16.addComponentOrReplace(transform89)

const wallPlainGlass17 = new Entity('wallPlainGlass17')
engine.addEntity(wallPlainGlass17)
wallPlainGlass17.setParent(_scene)
wallPlainGlass17.addComponentOrReplace(gltfShape5)
const transform90 = new Transform({
  position: new Vector3(10.791725158691406, 13.222801208496094, 13.616252899169922),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1214356422424316, 2.1337978839874268, 0.14495840668678284)
})
wallPlainGlass17.addComponentOrReplace(transform90)

const wallPlainGlass18 = new Entity('wallPlainGlass18')
engine.addEntity(wallPlainGlass18)
wallPlainGlass18.setParent(_scene)
wallPlainGlass18.addComponentOrReplace(gltfShape5)
const transform91 = new Transform({
  position: new Vector3(2.257134437561035, 13.199100494384766, 5.334196090698242),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.088750958442688, 2.637965440750122, 0.1449582874774933)
})
wallPlainGlass18.addComponentOrReplace(transform91)

const wallPlainGlass3 = new Entity('wallPlainGlass3')
engine.addEntity(wallPlainGlass3)
wallPlainGlass3.setParent(_scene)
wallPlainGlass3.addComponentOrReplace(gltfShape5)
const transform92 = new Transform({
  position: new Vector3(2.257134437561035, 19.939699172973633, 5.334196090698242),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.088750958442688, 2.637970447540283, 0.14495840668678284)
})
wallPlainGlass3.addComponentOrReplace(transform92)

const wallPlainGlass8 = new Entity('wallPlainGlass8')
engine.addEntity(wallPlainGlass8)
wallPlainGlass8.setParent(_scene)
wallPlainGlass8.addComponentOrReplace(gltfShape5)
const transform93 = new Transform({
  position: new Vector3(10.791725158691406, 19.96339988708496, 13.616251945495605),
  rotation: new Quaternion(0.5, -0.5, -0.4999999403953552, -0.5000000596046448),
  scale: new Vector3(1.1214356422424316, 2.1337978839874268, 0.14495840668678284)
})
wallPlainGlass8.addComponentOrReplace(transform93)

const wallPlainGlass11 = new Entity('wallPlainGlass11')
engine.addEntity(wallPlainGlass11)
wallPlainGlass11.setParent(_scene)
wallPlainGlass11.addComponentOrReplace(gltfShape5)
const transform94 = new Transform({
  position: new Vector3(15.880594253540039, 19.930240631103516, 0.15453290939331055),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(6.8100266456604, 3.364389419555664, 0.1881696730852127)
})
wallPlainGlass11.addComponentOrReplace(transform94)

const nftPictureFrame31 = new Entity('nftPictureFrame31')
engine.addEntity(nftPictureFrame31)
nftPictureFrame31.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(5.504712104797363, 8.375499725341797, 15.87130069732666),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame31.addComponentOrReplace(transform95)

const nftPictureFrame32 = new Entity('nftPictureFrame32')
engine.addEntity(nftPictureFrame32)
nftPictureFrame32.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(2.2249839305877686, 8.40939998626709, 15.828689575195312),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame32.addComponentOrReplace(transform96)

const nftPictureFrame33 = new Entity('nftPictureFrame33')
engine.addEntity(nftPictureFrame33)
nftPictureFrame33.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(0.2637364864349365, 8.384114265441895, 14.077117919921875),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.7969138622283936, 5.128884315490723, 0.5000047087669373)
})
nftPictureFrame33.addComponentOrReplace(transform97)

const nftPictureFrame34 = new Entity('nftPictureFrame34')
engine.addEntity(nftPictureFrame34)
nftPictureFrame34.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(0.17395257949829102, 8.375499725341797, 11.380400657653809),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.796912908554077, 5.128884315490723, 0.5000045895576477)
})
nftPictureFrame34.addComponentOrReplace(transform98)

const videoStream3 = new Entity('videoStream3')
engine.addEntity(videoStream3)
videoStream3.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(3.751833915710449, 13.224461555480957, 12.801398277282715),
  rotation: new Quaternion(-2.7951699621553416e-8, -0.9379037618637085, 1.01468536684024e-7, -0.3468957245349884),
  scale: new Vector3(3.2191853523254395, 2.9523916244506836, 0.9228478670120239)
})
videoStream3.addComponentOrReplace(transform99)

const wallPlainGlass4 = new Entity('wallPlainGlass4')
engine.addEntity(wallPlainGlass4)
wallPlainGlass4.setParent(_scene)
wallPlainGlass4.addComponentOrReplace(gltfShape5)
const transform100 = new Transform({
  position: new Vector3(15.880594253540039, 6.487863540649414, 0.15452957153320312),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(6.8100266456604, 3.364389419555664, 0.1881696730852127)
})
wallPlainGlass4.addComponentOrReplace(transform100)

const nftPictureFrame35 = new Entity('nftPictureFrame35')
engine.addEntity(nftPictureFrame35)
nftPictureFrame35.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(7.963222503662109, 14.823307037353516, 0.17352008819580078),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(7.068943977355957, 7.158529281616211, 1.000004529953003)
})
nftPictureFrame35.addComponentOrReplace(transform101)

const nftPictureFrame36 = new Entity('nftPictureFrame36')
engine.addEntity(nftPictureFrame36)
nftPictureFrame36.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(3.308795928955078, 14.8233060836792, 0.17352008819580078),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(7.068943977355957, 7.158529281616211, 1.000004529953003)
})
nftPictureFrame36.addComponentOrReplace(transform102)

const nftPictureFrame37 = new Entity('nftPictureFrame37')
engine.addEntity(nftPictureFrame37)
nftPictureFrame37.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(12.617647171020508, 14.823307991027832, 0.17352008819580078),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(7.06894588470459, 7.158529281616211, 1.000004768371582)
})
nftPictureFrame37.addComponentOrReplace(transform103)

const nftPictureFrame38 = new Entity('nftPictureFrame38')
engine.addEntity(nftPictureFrame38)
nftPictureFrame38.setParent(_scene)
const transform104 = new Transform({
  position: new Vector3(15.852396965026855, 14.823307037353516, 7.9477763175964355),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(7.068961143493652, 7.158529281616211, 1.0000066757202148)
})
nftPictureFrame38.addComponentOrReplace(transform104)

const nftPictureFrame39 = new Entity('nftPictureFrame39')
engine.addEntity(nftPictureFrame39)
nftPictureFrame39.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(15.852397918701172, 14.823305130004883, 3.2933497428894043),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(7.068961143493652, 7.158529281616211, 1.0000066757202148)
})
nftPictureFrame39.addComponentOrReplace(transform105)

const nftPictureFrame40 = new Entity('nftPictureFrame40')
engine.addEntity(nftPictureFrame40)
nftPictureFrame40.setParent(_scene)
const transform106 = new Transform({
  position: new Vector3(15.852396011352539, 14.823308944702148, 12.602201461791992),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(7.068963050842285, 7.158529281616211, 1.000006914138794)
})
nftPictureFrame40.addComponentOrReplace(transform106)

const nftPictureFrame45 = new Entity('nftPictureFrame45')
engine.addEntity(nftPictureFrame45)
nftPictureFrame45.setParent(_scene)
const transform107 = new Transform({
  position: new Vector3(13.130834579467773, 8.747620582580566, 0.2718377113342285),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.668906211853027, 0.5000022053718567)
})
nftPictureFrame45.addComponentOrReplace(transform107)

const nftPictureFrame46 = new Entity('nftPictureFrame46')
engine.addEntity(nftPictureFrame46)
nftPictureFrame46.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(9.579055786132812, 8.710151672363281, 0.22922658920288086),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.668906211853027, 0.5000022053718567)
})
nftPictureFrame46.addComponentOrReplace(transform108)

const nftPictureFrame47 = new Entity('nftPictureFrame47')
engine.addEntity(nftPictureFrame47)
nftPictureFrame47.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(2.3105907440185547, 8.710151672363281, 0.22922754287719727),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.668906211853027, 0.5000022053718567)
})
nftPictureFrame47.addComponentOrReplace(transform109)

const nftPictureFrame48 = new Entity('nftPictureFrame48')
engine.addEntity(nftPictureFrame48)
nftPictureFrame48.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(5.86237096786499, 8.747620582580566, 0.2718386650085449),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.668906211853027, 0.5000022053718567)
})
nftPictureFrame48.addComponentOrReplace(transform110)

const nftPictureFrame61 = new Entity('nftPictureFrame61')
engine.addEntity(nftPictureFrame61)
nftPictureFrame61.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(15.74041748046875, 8.737577438354492, 2.463104248046875),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111853122711182, 5.688185691833496, 0.5000033974647522)
})
nftPictureFrame61.addComponentOrReplace(transform111)

const nftPictureFrame62 = new Entity('nftPictureFrame62')
engine.addEntity(nftPictureFrame62)
nftPictureFrame62.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(15.697806358337402, 8.775175094604492, 6.014884948730469),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111853122711182, 5.688185691833496, 0.5000033974647522)
})
nftPictureFrame62.addComponentOrReplace(transform112)

const nftPictureFrame63 = new Entity('nftPictureFrame63')
engine.addEntity(nftPictureFrame63)
nftPictureFrame63.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(15.740418434143066, 8.737578392028809, 9.73157024383545),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111853122711182, 5.688185691833496, 0.5000033974647522)
})
nftPictureFrame63.addComponentOrReplace(transform113)

const nftPictureFrame64 = new Entity('nftPictureFrame64')
engine.addEntity(nftPictureFrame64)
nftPictureFrame64.setParent(_scene)
const transform114 = new Transform({
  position: new Vector3(15.697807312011719, 8.775176048278809, 13.283349990844727),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111853122711182, 5.688185691833496, 0.5000033974647522)
})
nftPictureFrame64.addComponentOrReplace(transform114)

const nftPictureFrame65 = new Entity('nftPictureFrame65')
engine.addEntity(nftPictureFrame65)
nftPictureFrame65.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(15.74041748046875, 2.6531455516815186, 2.463104248046875),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111852169036865, 5.259216785430908, 0.5000032782554626)
})
nftPictureFrame65.addComponentOrReplace(transform115)

const nftPictureFrame68 = new Entity('nftPictureFrame68')
engine.addEntity(nftPictureFrame68)
nftPictureFrame68.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(15.697807312011719, 2.6497159004211426, 13.283349990844727),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111853122711182, 5.259216785430908, 0.5000033974647522)
})
nftPictureFrame68.addComponentOrReplace(transform116)

const nftPictureFrame69 = new Entity('nftPictureFrame69')
engine.addEntity(nftPictureFrame69)
nftPictureFrame69.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(2.3105907440185547, 2.663205623626709, 0.22922754287719727),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000022053718567)
})
nftPictureFrame69.addComponentOrReplace(transform117)

const nftPictureFrame72 = new Entity('nftPictureFrame72')
engine.addEntity(nftPictureFrame72)
nftPictureFrame72.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(13.130834579467773, 2.697849750518799, 0.2718377113342285),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000022053718567)
})
nftPictureFrame72.addComponentOrReplace(transform118)

const wallPlainGlass23 = new Entity('wallPlainGlass23')
engine.addEntity(wallPlainGlass23)
wallPlainGlass23.setParent(_scene)
wallPlainGlass23.addComponentOrReplace(gltfShape5)
const transform119 = new Transform({
  position: new Vector3(0.00102996826171875, 13.75582218170166, 9.825395584106445),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.255248785018921, 0.13248126208782196, 0.391997754573822)
})
wallPlainGlass23.addComponentOrReplace(transform119)

const wallPlainBlack38 = new Entity('wallPlainBlack38')
engine.addEntity(wallPlainBlack38)
wallPlainBlack38.setParent(_scene)
wallPlainBlack38.addComponentOrReplace(gltfShape4)
const transform120 = new Transform({
  position: new Vector3(0.1144866943359375, 13.04508113861084, 10),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.8308262825012207, 0.09845852106809616, 0.3330819308757782)
})
wallPlainBlack38.addComponentOrReplace(transform120)

const wallPlainBlack39 = new Entity('wallPlainBlack39')
engine.addEntity(wallPlainBlack39)
wallPlainBlack39.setParent(_scene)
wallPlainBlack39.addComponentOrReplace(gltfShape4)
const transform121 = new Transform({
  position: new Vector3(11.069341659545898, 13.068408012390137, 15.894967079162598),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(2.3590331077575684, 0.09845852106809616, 0.33308252692222595)
})
wallPlainBlack39.addComponentOrReplace(transform121)

const wallPlainBlack40 = new Entity('wallPlainBlack40')
engine.addEntity(wallPlainBlack40)
wallPlainBlack40.setParent(_scene)
wallPlainBlack40.addComponentOrReplace(gltfShape4)
const transform122 = new Transform({
  position: new Vector3(10.195789337158203, 1.7854652404785156, 0.21559810638427734),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.5371062755584717, 1.1292099952697754, 0.33308255672454834)
})
wallPlainBlack40.addComponentOrReplace(transform122)

const signpostTree7 = new Entity('signpostTree7')
engine.addEntity(signpostTree7)
signpostTree7.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(7.674420356750488, 1.660478115081787, 0.2055048942565918),
  rotation: new Quaternion(-3.552713678800501e-15, -2.2351741790771484e-8, 7.935584020414208e-15, 1),
  scale: new Vector3(2.7700371742248535, 4.529245853424072, 1.000002384185791)
})
signpostTree7.addComponentOrReplace(transform123)

const wallPlainBlack41 = new Entity('wallPlainBlack41')
engine.addEntity(wallPlainBlack41)
wallPlainBlack41.setParent(_scene)
wallPlainBlack41.addComponentOrReplace(gltfShape4)
const transform124 = new Transform({
  position: new Vector3(15.712030410766602, 1.8427505493164062, 10.715961456298828),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.8892970085144043, 1.1292099952697754, 0.3330824375152588)
})
wallPlainBlack41.addComponentOrReplace(transform124)

const signpostTree8 = new Entity('signpostTree8')
engine.addEntity(signpostTree8)
signpostTree8.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(15.71963882446289, 1.7031135559082031, 7.848673343658447),
  rotation: new Quaternion(-4.127578846475997e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(3.1070291996002197, 4.490051746368408, 1.0000109672546387)
})
signpostTree8.addComponentOrReplace(transform125)

const galleryInfoWhite = new Entity('galleryInfoWhite')
engine.addEntity(galleryInfoWhite)
galleryInfoWhite.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(7.457619667053223, 13.261543273925781, 15.284799575805664),
  rotation: new Quaternion(-2.9153193636943797e-8, -0.969635546207428, -0.24455468356609344, 5.974465578295271e-15),
  scale: new Vector3(1.6990418434143066, 0.3424391746520996, 0.17705613374710083)
})
galleryInfoWhite.addComponentOrReplace(transform126)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape7 = new GLTFShape("bfc932843fa883cacaa9d8ffd5fc94069b36c6facc8756ee4768097f7545c2c4/CityTile.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
entity.addComponentOrReplace(gltfShape7)
const transform127 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform127)

const nftPictureFrame41 = new Entity('nftPictureFrame41')
engine.addEntity(nftPictureFrame41)
nftPictureFrame41.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(13.504712104797363, 2.6865029335021973, 15.871301651000977),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame41.addComponentOrReplace(transform128)

const nftPictureFrame42 = new Entity('nftPictureFrame42')
engine.addEntity(nftPictureFrame42)
nftPictureFrame42.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(0.2637367248535156, 2.822965145111084, 2.6363182067871094),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.796917676925659, 5.128884315490723, 0.5000051856040955)
})
nftPictureFrame42.addComponentOrReplace(transform129)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script1.spawn(verticalPlatform, {"distance":17,"speed":4,"autoStart":true,"onReachEnd":[{"entityName":"verticalPlatform","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalPlatform","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalPlatform, channelBus))
script1.spawn(verticalPlatform2, {"distance":17,"speed":4,"autoStart":true,"onReachEnd":[{"entityName":"verticalPlatform2","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalPlatform2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalPlatform2, channelBus))
script2.spawn(nftPictureFrame2, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script2.spawn(nftPictureFrame4, {"id":"72405646120007613708465591283795435405784754144165659770746301114056630599681","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script2.spawn(nftPictureFrame, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script2.spawn(nftPictureFrame6, {"id":"72405646120007613708465591283795435405784754144165659770746301133847839899649","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script2.spawn(nftPictureFrame7, {"id":"72405646120007613708465591283795435405784754144165659770746301112957118971905","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script2.spawn(nftPictureFrame8, {"id":"72405646120007613708465591283795435405784754144165659770746301100862491066369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script2.spawn(nftPictureFrame9, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script2.spawn(nftPictureFrame10, {"id":"72405646120007613708465591283795435405784754144165659770746301101962002694145","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script2.spawn(nftPictureFrame11, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script2.spawn(nftPictureFrame12, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script2.spawn(nftPictureFrame13, {"id":"72405646120007613708465591283795435405784754144165659770746301139345398038529","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame13, channelBus))
script2.spawn(nftPictureFrame15, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame15, channelBus))
script2.spawn(nftPictureFrame16, {"id":"72405646120007613708465591283795435405784754144165659770746301144842956177409","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame16, channelBus))
script2.spawn(nftPictureFrame17, {"id":"72405646120007613708465591283795435405784754144165659770746301134947351527425","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script2.spawn(nftPictureFrame18, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script2.spawn(nftPictureFrame20, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame20, channelBus))
script2.spawn(nftPictureFrame21, {"id":"72405646120007613708465591283795435405784754144165659770746301101962002694145","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame21, channelBus))
script2.spawn(nftPictureFrame22, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script2.spawn(nftPictureFrame23, {"id":"72405646120007613708465591283795435405784754144165659770746301133847839899649","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame23, channelBus))
script2.spawn(nftPictureFrame24, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame24, channelBus))
script3.spawn(signpostTree, {"text":"Snatch Up These\nCrypto Collectibles For\nSale Now At OpenSea!","fontSize":35}, createChannel(channelId, signpostTree, channelBus))
script3.spawn(signpostTree2, {"text":"Get Yours Now!\nPrices Double With\nEach New Mint!","fontSize":40}, createChannel(channelId, signpostTree2, channelBus))
script3.spawn(signpostTree3, {"text":"Ignore “NOT \nFOR SALE” \nText In UI","fontSize":45}, createChannel(channelId, signpostTree3, channelBus))
script3.spawn(signpostTree4, {"text":"Ignore “NOT \nFOR SALE” \nText In UI","fontSize":45}, createChannel(channelId, signpostTree4, channelBus))
script2.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301131648816644097","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script2.spawn(nftPictureFrame14, {"id":"72405646120007613708465591283795435405784754144165659770746301061280072466433","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script2.spawn(nftPictureFrame25, {"id":"72405646120007613708465591283795435405784754144165659770746301138245886410753","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame25, channelBus))
script2.spawn(nftPictureFrame26, {"id":"72405646120007613708465591283795435405784754144165659770746301089867374788609","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame26, channelBus))
script2.spawn(nftPictureFrame3, {"id":"72405646120007613708465591283795435405784754144165659770746301144842956177409","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script2.spawn(nftPictureFrame19, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame19, channelBus))
script2.spawn(nftPictureFrame27, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame27, channelBus))
script2.spawn(nftPictureFrame28, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame28, channelBus))
script2.spawn(nftPictureFrame29, {"id":"72405646120007613708465591283795435405784754144165659770746301112957118971905","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame29, channelBus))
script2.spawn(nftPictureFrame30, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script3.spawn(signpostTree5, {"text":"Snatch Up These\nCrypto Collectibles For\nSale Now At OpenSea!","fontSize":30}, createChannel(channelId, signpostTree5, channelBus))
script3.spawn(signpostTree6, {"text":"Get Yours Now!\nPrices Double With\nEach New Mint!","fontSize":37}, createChannel(channelId, signpostTree6, channelBus))
script2.spawn(nftPictureFrame31, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame31, channelBus))
script2.spawn(nftPictureFrame32, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame32, channelBus))
script2.spawn(nftPictureFrame33, {"id":"72405646120007613708465591283795435405784754144165659770746301127250770132993","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame33, channelBus))
script2.spawn(nftPictureFrame34, {"id":"72405646120007613708465591283795435405784754144165659770746301128350281760769","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame34, channelBus))
script4.spawn(videoStream3, {"startOn":"false","onClickText":"Play video","volume":0.13,"onClick":[{"entityName":"videoStream3","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/Qmd3eMnYQsgXjuhad1fdUCBnCQvzpoLKwRkMUrBDjedGtT/Cozumel%20Diving.mp4"}, createChannel(channelId, videoStream3, channelBus))
script2.spawn(nftPictureFrame35, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame35, channelBus))
script2.spawn(nftPictureFrame36, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame36, channelBus))
script2.spawn(nftPictureFrame37, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame37, channelBus))
script2.spawn(nftPictureFrame38, {"id":"72405646120007613708465591283795435405784754144165659770746301119554188738561","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame38, channelBus))
script2.spawn(nftPictureFrame39, {"id":"72405646120007613708465591283795435405784754144165659770746301117355165483009","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame39, channelBus))
script2.spawn(nftPictureFrame40, {"id":"72405646120007613708465591283795435405784754144165659770746301121753211994113","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame40, channelBus))
script2.spawn(nftPictureFrame45, {"id":"72405646120007613708465591283795435405784754144165659770746301143743444549633","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame45, channelBus))
script2.spawn(nftPictureFrame46, {"id":"72405646120007613708465591283795435405784754144165659770746301142643932921857","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame46, channelBus))
script2.spawn(nftPictureFrame47, {"id":"72405646120007613708465591283795435405784754144165659770746301150340514316289","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame47, channelBus))
script2.spawn(nftPictureFrame48, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame48, channelBus))
script2.spawn(nftPictureFrame61, {"id":"72405646120007613708465591283795435405784754144165659770746301145942467805185","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame61, channelBus))
script2.spawn(nftPictureFrame62, {"id":"72405646120007613708465591283795435405784754144165659770746301147041979432961","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame62, channelBus))
script2.spawn(nftPictureFrame63, {"id":"72405646120007613708465591283795435405784754144165659770746301149241002688513","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame63, channelBus))
script2.spawn(nftPictureFrame64, {"id":"72405646120007613708465591283795435405784754144165659770746301154738560827393","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .04 ETH"}, createChannel(channelId, nftPictureFrame64, channelBus))
script2.spawn(nftPictureFrame65, {"id":"72405646120007613708465591283795435405784754144165659770746301110758095716353","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame65, channelBus))
script2.spawn(nftPictureFrame68, {"id":"72405646120007613708465591283795435405784754144165659770746301123952235249665","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame68, channelBus))
script2.spawn(nftPictureFrame69, {"id":"72405646120007613708465591283795435405784754144165659770746301126151258505217","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame69, channelBus))
script2.spawn(nftPictureFrame72, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame72, channelBus))
script3.spawn(signpostTree7, {"text":"Ignore “NOT \nFOR SALE” \nText In UI","fontSize":45}, createChannel(channelId, signpostTree7, channelBus))
script3.spawn(signpostTree8, {"text":"Enjoy The Comedy & Show \nYour Support With Emotes!\nAlso Feel Free To Support \nMy Starving Artist Friends!\nStand-Up Schedule TBD","fontSize":25}, createChannel(channelId, signpostTree8, channelBus))
script5.spawn(galleryInfoWhite, {"text":"Video & Editing \nby Phergyson\n\nMusic by Pink Floyd","fontSize":7.5,"font":"SF_Heavy","color":"#000000"}, createChannel(channelId, galleryInfoWhite, channelBus))
script2.spawn(nftPictureFrame41, {"id":"72405646120007613708465591283795435405784754144165659770746301063479095721985","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame41, channelBus))
script2.spawn(nftPictureFrame42, {"id":"72405646120007613708465591283795435405784754144165659770746301062379584094209","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame42, channelBus))