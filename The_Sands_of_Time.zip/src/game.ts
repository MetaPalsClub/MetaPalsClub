import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script2 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script3 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script4 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"
import Script5 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script6 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const teardropMetal = new Entity('teardropMetal')
engine.addEntity(teardropMetal)
teardropMetal.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(16, 1, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(8.72417163848877, 4.362085819244385, 8.72417163848877)
})
teardropMetal.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("3428c606d1f72f253a18e80a6e9befcf0daaaa3f0c79ea1ab36e3bb8c353f1cb/Teardrop_- Metal.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
teardropMetal.addComponentOrReplace(gltfShape)

const teardropMetal2 = new Entity('teardropMetal2')
engine.addEntity(teardropMetal2)
teardropMetal2.setParent(_scene)
teardropMetal2.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(16, 45, 16),
  rotation: new Quaternion(0, 0, 1, 0),
  scale: new Vector3(8.72417163848877, 4.362085819244385, 8.72417163848877)
})
teardropMetal2.addComponentOrReplace(transform3)

const chocolateBrownBeechwoodWall = new Entity('chocolateBrownBeechwoodWall')
engine.addEntity(chocolateBrownBeechwoodWall)
chocolateBrownBeechwoodWall.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(29.5, 0, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall.addComponentOrReplace(transform4)
const gltfShape2 = new GLTFShape("57a8e083638837fb0c6424dc9388b343ae4f9deae4b0d29ac16507caabcee365/Chocolate_Brown Beechwood Wall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
chocolateBrownBeechwoodWall.addComponentOrReplace(gltfShape2)

const chocolateBrownBeechwoodWall2 = new Entity('chocolateBrownBeechwoodWall2')
engine.addEntity(chocolateBrownBeechwoodWall2)
chocolateBrownBeechwoodWall2.setParent(_scene)
chocolateBrownBeechwoodWall2.addComponentOrReplace(gltfShape2)
const transform5 = new Transform({
  position: new Vector3(15.952980041503906, 1, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(115.7126693725586, 11.25, 1068.7498779296875)
})
chocolateBrownBeechwoodWall2.addComponentOrReplace(transform5)

const chocolateBrownBeechwoodWall3 = new Entity('chocolateBrownBeechwoodWall3')
engine.addEntity(chocolateBrownBeechwoodWall3)
chocolateBrownBeechwoodWall3.setParent(_scene)
chocolateBrownBeechwoodWall3.addComponentOrReplace(gltfShape2)
const transform6 = new Transform({
  position: new Vector3(16.019411087036133, 1, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(113.75857543945312, 11.25, 1068.7501220703125)
})
chocolateBrownBeechwoodWall3.addComponentOrReplace(transform6)

const chocolateBrownBeechwoodWall4 = new Entity('chocolateBrownBeechwoodWall4')
engine.addEntity(chocolateBrownBeechwoodWall4)
chocolateBrownBeechwoodWall4.setParent(_scene)
chocolateBrownBeechwoodWall4.addComponentOrReplace(gltfShape2)
const transform7 = new Transform({
  position: new Vector3(29.5, 0, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall4.addComponentOrReplace(transform7)

const chocolateBrownBeechwoodWall5 = new Entity('chocolateBrownBeechwoodWall5')
engine.addEntity(chocolateBrownBeechwoodWall5)
chocolateBrownBeechwoodWall5.setParent(_scene)
chocolateBrownBeechwoodWall5.addComponentOrReplace(gltfShape2)
const transform8 = new Transform({
  position: new Vector3(2.5, 0, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall5.addComponentOrReplace(transform8)

const chocolateBrownBeechwoodWall6 = new Entity('chocolateBrownBeechwoodWall6')
engine.addEntity(chocolateBrownBeechwoodWall6)
chocolateBrownBeechwoodWall6.setParent(_scene)
chocolateBrownBeechwoodWall6.addComponentOrReplace(gltfShape2)
const transform9 = new Transform({
  position: new Vector3(2.5, 0, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall6.addComponentOrReplace(transform9)

const chocolateBrownBeechwoodWall7 = new Entity('chocolateBrownBeechwoodWall7')
engine.addEntity(chocolateBrownBeechwoodWall7)
chocolateBrownBeechwoodWall7.setParent(_scene)
chocolateBrownBeechwoodWall7.addComponentOrReplace(gltfShape2)
const transform10 = new Transform({
  position: new Vector3(29.500001907348633, 0.9999984502792358, 15.999998092651367),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(103.85262298583984, 11.25, 1068.7503662109375)
})
chocolateBrownBeechwoodWall7.addComponentOrReplace(transform10)

const chocolateBrownBeechwoodWall8 = new Entity('chocolateBrownBeechwoodWall8')
engine.addEntity(chocolateBrownBeechwoodWall8)
chocolateBrownBeechwoodWall8.setParent(_scene)
chocolateBrownBeechwoodWall8.addComponentOrReplace(gltfShape2)
const transform11 = new Transform({
  position: new Vector3(2.499998092651367, 1.0000015497207642, 16.000001907348633),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(106.50802612304688, 11.25, 1068.7508544921875)
})
chocolateBrownBeechwoodWall8.addComponentOrReplace(transform11)

const chocolateBrownBeechwoodWall10 = new Entity('chocolateBrownBeechwoodWall10')
engine.addEntity(chocolateBrownBeechwoodWall10)
chocolateBrownBeechwoodWall10.setParent(_scene)
chocolateBrownBeechwoodWall10.addComponentOrReplace(gltfShape2)
const transform12 = new Transform({
  position: new Vector3(2.5282444953918457, 42.5, 16.000001907348633),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(108.51404571533203, 11.25, 1068.7510986328125)
})
chocolateBrownBeechwoodWall10.addComponentOrReplace(transform12)

const chocolateBrownBeechwoodWall12 = new Entity('chocolateBrownBeechwoodWall12')
engine.addEntity(chocolateBrownBeechwoodWall12)
chocolateBrownBeechwoodWall12.setParent(_scene)
chocolateBrownBeechwoodWall12.addComponentOrReplace(gltfShape2)
const transform13 = new Transform({
  position: new Vector3(29.5, 41.5, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall12.addComponentOrReplace(transform13)

const chocolateBrownBeechwoodWall13 = new Entity('chocolateBrownBeechwoodWall13')
engine.addEntity(chocolateBrownBeechwoodWall13)
chocolateBrownBeechwoodWall13.setParent(_scene)
chocolateBrownBeechwoodWall13.addComponentOrReplace(gltfShape2)
const transform14 = new Transform({
  position: new Vector3(29.5, 41.5, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall13.addComponentOrReplace(transform14)

const chocolateBrownBeechwoodWall14 = new Entity('chocolateBrownBeechwoodWall14')
engine.addEntity(chocolateBrownBeechwoodWall14)
chocolateBrownBeechwoodWall14.setParent(_scene)
chocolateBrownBeechwoodWall14.addComponentOrReplace(gltfShape2)
const transform15 = new Transform({
  position: new Vector3(16.04862403869629, 42.5, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(113.50477600097656, 11.25, 1068.7498779296875)
})
chocolateBrownBeechwoodWall14.addComponentOrReplace(transform15)

const chocolateBrownBeechwoodWall15 = new Entity('chocolateBrownBeechwoodWall15')
engine.addEntity(chocolateBrownBeechwoodWall15)
chocolateBrownBeechwoodWall15.setParent(_scene)
chocolateBrownBeechwoodWall15.addComponentOrReplace(gltfShape2)
const transform16 = new Transform({
  position: new Vector3(2.5, 41.5, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall15.addComponentOrReplace(transform16)

const chocolateBrownBeechwoodWall16 = new Entity('chocolateBrownBeechwoodWall16')
engine.addEntity(chocolateBrownBeechwoodWall16)
chocolateBrownBeechwoodWall16.setParent(_scene)
chocolateBrownBeechwoodWall16.addComponentOrReplace(gltfShape2)
const transform17 = new Transform({
  position: new Vector3(2.5, 41.5, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(22.5, 22.5, 2137.5)
})
chocolateBrownBeechwoodWall16.addComponentOrReplace(transform17)

const chocolateBrownBeechwoodWall17 = new Entity('chocolateBrownBeechwoodWall17')
engine.addEntity(chocolateBrownBeechwoodWall17)
chocolateBrownBeechwoodWall17.setParent(_scene)
chocolateBrownBeechwoodWall17.addComponentOrReplace(gltfShape2)
const transform18 = new Transform({
  position: new Vector3(3.5, 23.21255874633789, 3.000000238418579),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(188.0427703857422, -11.25002384185791, 1068.7498779296875)
})
chocolateBrownBeechwoodWall17.addComponentOrReplace(transform18)

const chocolateBrownBeechwoodWall18 = new Entity('chocolateBrownBeechwoodWall18')
engine.addEntity(chocolateBrownBeechwoodWall18)
chocolateBrownBeechwoodWall18.setParent(_scene)
chocolateBrownBeechwoodWall18.addComponentOrReplace(gltfShape2)
const transform19 = new Transform({
  position: new Vector3(30.5, 23.20209503173828, 2.999998092651367),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(188.1335906982422, 11.250020027160645, 1068.7498779296875)
})
chocolateBrownBeechwoodWall18.addComponentOrReplace(transform19)

const chocolateBrownBeechwoodWall19 = new Entity('chocolateBrownBeechwoodWall19')
engine.addEntity(chocolateBrownBeechwoodWall19)
chocolateBrownBeechwoodWall19.setParent(_scene)
chocolateBrownBeechwoodWall19.addComponentOrReplace(gltfShape2)
const transform20 = new Transform({
  position: new Vector3(30.5, 23.255889892578125, 28.999998092651367),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(189.0626678466797, 11.250021934509277, 1068.7498779296875)
})
chocolateBrownBeechwoodWall19.addComponentOrReplace(transform20)

const chocolateBrownBeechwoodWall20 = new Entity('chocolateBrownBeechwoodWall20')
engine.addEntity(chocolateBrownBeechwoodWall20)
chocolateBrownBeechwoodWall20.setParent(_scene)
chocolateBrownBeechwoodWall20.addComponentOrReplace(gltfShape2)
const transform21 = new Transform({
  position: new Vector3(3.5, 23.319189071655273, 28.999998092651367),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(187.90078735351562, 11.250018119812012, 1068.7498779296875)
})
chocolateBrownBeechwoodWall20.addComponentOrReplace(transform21)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape3 = new GLTFShape("eb05a4210af1d91dfa0cb5e8b2ee43339deecd35f112c0753f47c1d6739ac50c/FloorBaseSand_01/FloorBaseSand_01.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
entity.addComponentOrReplace(gltfShape3)
const transform22 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform22)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape3)
const transform23 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform23)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape3)
const transform24 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform24)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape3)
const transform25 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform25)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(16.01994514465332, 0.9302082061767578, 16.014753341674805),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(28.387441635131836, 0.12999999523162842, 28.991371154785156)
})
invisibleWall.addComponentOrReplace(transform26)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(3.4182217121124268, 42.36964797973633, 7.9689459800720215),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.7166945934295654, 0.12999999523162842, 12.230731010437012)
})
invisibleWall2.addComponentOrReplace(transform27)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(30.940649032592773, 43.420379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 1.3352904319763184)
})
invisibleWall7.addComponentOrReplace(transform28)

const chocolateBrownBeechwoodWall9 = new Entity('chocolateBrownBeechwoodWall9')
engine.addEntity(chocolateBrownBeechwoodWall9)
chocolateBrownBeechwoodWall9.setParent(_scene)
chocolateBrownBeechwoodWall9.addComponentOrReplace(gltfShape2)
const transform29 = new Transform({
  position: new Vector3(16.04862403869629, 42.5, 28.8107967376709),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(113.50477600097656, 11.25, 1068.7498779296875)
})
chocolateBrownBeechwoodWall9.addComponentOrReplace(transform29)

const chocolateBrownBeechwoodWall11 = new Entity('chocolateBrownBeechwoodWall11')
engine.addEntity(chocolateBrownBeechwoodWall11)
chocolateBrownBeechwoodWall11.setParent(_scene)
chocolateBrownBeechwoodWall11.addComponentOrReplace(gltfShape2)
const transform30 = new Transform({
  position: new Vector3(29.52824592590332, 42.5, 16.000001907348633),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(108.51409149169922, 11.25, 1068.7513427734375)
})
chocolateBrownBeechwoodWall11.addComponentOrReplace(transform30)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(15.992109298706055, 43.40484619140625, 27.430604934692383),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(24.19318962097168, 0.130000501871109, 2.6705806255340576)
})
invisibleWall8.addComponentOrReplace(transform31)

const invisibleWall9 = new Entity('invisibleWall9')
engine.addEntity(invisibleWall9)
invisibleWall9.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(15.992109298706055, 43.40484619140625, 4.274677276611328),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(24.19318962097168, 0.13000056147575378, 2.6705806255340576)
})
invisibleWall9.addComponentOrReplace(transform32)

const invisibleWall10 = new Entity('invisibleWall10')
engine.addEntity(invisibleWall10)
invisibleWall10.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(15.992109298706055, 2.40484619140625, 4.321319580078125),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(24.19318962097168, 0.13000071048736572, 2.6705799102783203)
})
invisibleWall10.addComponentOrReplace(transform33)

const invisibleWall11 = new Entity('invisibleWall11')
engine.addEntity(invisibleWall11)
invisibleWall11.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(15.992109298706055, 2.40484619140625, 27.542627334594727),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(24.19318962097168, 0.13000062108039856, 2.6705806255340576)
})
invisibleWall11.addComponentOrReplace(transform34)

const invisibleWall5 = new Entity('invisibleWall5')
engine.addEntity(invisibleWall5)
invisibleWall5.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(3.825277328491211, 2.062070846557617, 15.859289169311523),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(22.3846435546875, 0.1300007700920105, 2.6705801486968994)
})
invisibleWall5.addComponentOrReplace(transform35)

const invisibleWall12 = new Entity('invisibleWall12')
engine.addEntity(invisibleWall12)
invisibleWall12.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(28.09247398376465, 2.062070846557617, 15.859289169311523),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(22.3846435546875, 0.1300007700920105, 2.6705801486968994)
})
invisibleWall12.addComponentOrReplace(transform36)

const invisibleWall13 = new Entity('invisibleWall13')
engine.addEntity(invisibleWall13)
invisibleWall13.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(28.09247398376465, 43.56207275390625, 9.359289169311523),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(9.443521499633789, 0.1300007700920105, 2.6705801486968994)
})
invisibleWall13.addComponentOrReplace(transform37)

const invisibleWall14 = new Entity('invisibleWall14')
engine.addEntity(invisibleWall14)
invisibleWall14.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(3.825277328491211, 43.56207275390625, 9.359289169311523),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(9.443521499633789, 0.1300007700920105, 2.6705801486968994)
})
invisibleWall14.addComponentOrReplace(transform38)

const invisibleWall15 = new Entity('invisibleWall15')
engine.addEntity(invisibleWall15)
invisibleWall15.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(28.09247398376465, 43.56207275390625, 22.359289169311523),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(9.443521499633789, 0.1300007700920105, 2.6705801486968994)
})
invisibleWall15.addComponentOrReplace(transform39)

const invisibleWall16 = new Entity('invisibleWall16')
engine.addEntity(invisibleWall16)
invisibleWall16.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(3.825277328491211, 43.56207275390625, 22.359289169311523),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(9.443521499633789, 0.1300007700920105, 2.6705801486968994)
})
invisibleWall16.addComponentOrReplace(transform40)

const invisibleWall17 = new Entity('invisibleWall17')
engine.addEntity(invisibleWall17)
invisibleWall17.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(3.418222427368164, 42.36964797973633, 23.721954345703125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.7166945934295654, 0.12999999523162842, 12.230731010437012)
})
invisibleWall17.addComponentOrReplace(transform41)

const invisibleWall18 = new Entity('invisibleWall18')
engine.addEntity(invisibleWall18)
invisibleWall18.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(4.823851585388184, 42.36964797973633, 15.792013168334961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.347599029541016, 0.12999999523162842, 3.343811511993408)
})
invisibleWall18.addComponentOrReplace(transform42)

const invisibleWall19 = new Entity('invisibleWall19')
engine.addEntity(invisibleWall19)
invisibleWall19.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(26.839717864990234, 42.36964797973633, 15.87013053894043),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(8.162768363952637, 0.12999999523162842, 3.420315980911255)
})
invisibleWall19.addComponentOrReplace(transform43)

const invisibleWall20 = new Entity('invisibleWall20')
engine.addEntity(invisibleWall20)
invisibleWall20.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(0.9331299066543579, 0.5927716493606567, 28.990312576293945),
  rotation: new Quaternion(0.6863870024681091, 0.16991965472698212, -0.686387300491333, 0.16991962492465973),
  scale: new Vector3(2.519596815109253, 0.12921573221683502, 1.9398796558380127)
})
invisibleWall20.addComponentOrReplace(transform44)

const invisibleWall21 = new Entity('invisibleWall21')
engine.addEntity(invisibleWall21)
invisibleWall21.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(30.603342056274414, 24.244951248168945, 2.957712173461914),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(2.3491029739379883, 0.1300002932548523, 39.97101974487305)
})
invisibleWall21.addComponentOrReplace(transform45)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(29.33237075805664, 0, 28.95164680480957),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
verticalBlackPad.addComponentOrReplace(transform46)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(29.35416030883789, 0, 29),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 42.00499725341797, 1.5)
})
triggerArea.addComponentOrReplace(transform47)

const invisibleWall6 = new Entity('invisibleWall6')
engine.addEntity(invisibleWall6)
invisibleWall6.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(1.242159366607666, 24.244953155517578, 28.913654327392578),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(2.3491029739379883, 0.1300002932548523, 39.97101974487305)
})
invisibleWall6.addComponentOrReplace(transform48)

const invisibleWall22 = new Entity('invisibleWall22')
engine.addEntity(invisibleWall22)
invisibleWall22.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(1.1458446979522705, 43.420379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 1.3352904319763184)
})
invisibleWall22.addComponentOrReplace(transform49)

const invisibleWall23 = new Entity('invisibleWall23')
engine.addEntity(invisibleWall23)
invisibleWall23.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(31.14558982849121, 0.5832477807998657, 3),
  rotation: new Quaternion(-0.6866714358329773, 0.1687677502632141, -0.6866711378097534, -0.16876794397830963),
  scale: new Vector3(2.519598960876465, 0.12921589612960815, 1.9398813247680664)
})
invisibleWall23.addComponentOrReplace(transform50)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(15.92219352722168, 43.420379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.13000068068504333, 1.3352904319763184)
})
invisibleWall3.addComponentOrReplace(transform51)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(2.5064315795898438, 24.244951248168945, 1.6657202243804932),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(2.425445795059204, 0.13000041246414185, 39.971046447753906)
})
invisibleWall4.addComponentOrReplace(transform52)

const invisibleWall24 = new Entity('invisibleWall24')
engine.addEntity(invisibleWall24)
invisibleWall24.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(29.180419921875, 24.244953155517578, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(2.425586462020874, 0.13000033795833588, 39.97102737426758)
})
invisibleWall24.addComponentOrReplace(transform53)

const invisibleWall25 = new Entity('invisibleWall25')
engine.addEntity(invisibleWall25)
invisibleWall25.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(15.844953536987305, 43.420379638671875, 30.202667236328125),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.42671775817871, 0.13000033795833588, 1.335290789604187)
})
invisibleWall25.addComponentOrReplace(transform54)

const invisibleWall26 = new Entity('invisibleWall26')
engine.addEntity(invisibleWall26)
invisibleWall26.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(29.079986572265625, 0.620762288570404, 31.07160758972168),
  rotation: new Quaternion(-2.086162567138672e-7, 0.2773982882499695, -0.9607551097869873, -8.940696716308594e-8),
  scale: new Vector3(2.5195977687835693, 0.1292155385017395, 1.9398777484893799)
})
invisibleWall26.addComponentOrReplace(transform55)

const invisibleWall27 = new Entity('invisibleWall27')
engine.addEntity(invisibleWall27)
invisibleWall27.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(2.5906982421875, 0.6207618117332458, 0.81165611743927),
  rotation: new Quaternion(-0.9607549905776978, -8.940696005765858e-8, 2.549527948758623e-7, -0.27739837765693665),
  scale: new Vector3(2.519598960876465, 0.12921589612960815, 1.9398815631866455)
})
invisibleWall27.addComponentOrReplace(transform56)

const invisibleWall28 = new Entity('invisibleWall28')
engine.addEntity(invisibleWall28)
invisibleWall28.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(9.296048164367676, 38.36964797973633, 15.845450401306152),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(29.733591079711914, 0.12999999523162842, 11.021014213562012)
})
invisibleWall28.addComponentOrReplace(transform57)

const invisibleWall29 = new Entity('invisibleWall29')
engine.addEntity(invisibleWall29)
invisibleWall29.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(23.490942001342773, 38.36964797973633, 15.84544849395752),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(29.733591079711914, 0.12999999523162842, 11.021024703979492)
})
invisibleWall29.addComponentOrReplace(transform58)

const invisibleWall30 = new Entity('invisibleWall30')
engine.addEntity(invisibleWall30)
invisibleWall30.setParent(_scene)
const transform59 = new Transform({
  position: new Vector3(16.393497467041016, 33.86964797973633, 23.721954345703125),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(26.792686462402344, 0.12999999523162842, 12.230754852294922)
})
invisibleWall30.addComponentOrReplace(transform59)

const invisibleWall31 = new Entity('invisibleWall31')
engine.addEntity(invisibleWall31)
invisibleWall31.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(16.376705169677734, 33.86964797973633, 8.82654857635498),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(24.79603385925293, 0.12999999523162842, 10.622279167175293)
})
invisibleWall31.addComponentOrReplace(transform60)

const invisibleWall32 = new Entity('invisibleWall32')
engine.addEntity(invisibleWall32)
invisibleWall32.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(23.040395736694336, 28.869647979736328, 15.845446586608887),
  rotation: new Quaternion(-1.5394154660318578e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(29.733627319335938, 0.12999999523162842, 11.02104377746582)
})
invisibleWall32.addComponentOrReplace(transform61)

const invisibleWall33 = new Entity('invisibleWall33')
engine.addEntity(invisibleWall33)
invisibleWall33.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(8.845500946044922, 28.869647979736328, 15.845452308654785),
  rotation: new Quaternion(-1.5394154660318578e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(29.733627319335938, 0.12999999523162842, 11.021031379699707)
})
invisibleWall33.addComponentOrReplace(transform62)

const invisibleWall34 = new Entity('invisibleWall34')
engine.addEntity(invisibleWall34)
invisibleWall34.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(15.959734916687012, 22.869647979736328, 9.26079273223877),
  rotation: new Quaternion(1.0587911840678754e-22, -5.960464477539063e-8, 4.6412446131629485e-15, 1),
  scale: new Vector3(24.79605484008789, 0.12999999523162842, 10.62229061126709)
})
invisibleWall34.addComponentOrReplace(transform63)

const invisibleWall35 = new Entity('invisibleWall35')
engine.addEntity(invisibleWall35)
invisibleWall35.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(15.942949295043945, 22.869647979736328, 24.221954345703125),
  rotation: new Quaternion(1.0587911840678754e-22, -5.960464477539063e-8, 4.6412446131629485e-15, 1),
  scale: new Vector3(25.017990112304688, 0.12999999523162842, 12.230768203735352)
})
invisibleWall35.addComponentOrReplace(transform64)

const invisibleWall36 = new Entity('invisibleWall36')
engine.addEntity(invisibleWall36)
invisibleWall36.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(8.845500946044922, 17.369647979736328, 16.34545135498047),
  rotation: new Quaternion(-3.2818552003999147e-15, 0.7071067690849304, -8.429369557916289e-8, 0.70710688829422),
  scale: new Vector3(29.733654022216797, 0.12999999523162842, 11.021045684814453)
})
invisibleWall36.addComponentOrReplace(transform65)

const invisibleWall37 = new Entity('invisibleWall37')
engine.addEntity(invisibleWall37)
invisibleWall37.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(23.040395736694336, 17.369647979736328, 16.345447540283203),
  rotation: new Quaternion(-3.2818552003999147e-15, 0.7071067690849304, -8.429369557916289e-8, 0.70710688829422),
  scale: new Vector3(29.733654022216797, 0.12999999523162842, 11.021050453186035)
})
invisibleWall37.addComponentOrReplace(transform66)

const invisibleWall38 = new Entity('invisibleWall38')
engine.addEntity(invisibleWall38)
invisibleWall38.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(15.942950248718262, 11.869647979736328, 24.221956253051758),
  rotation: new Quaternion(-6.961866284469712e-15, 1, -1.1920927533992653e-7, 1.1920927533992653e-7),
  scale: new Vector3(25.018022537231445, 0.12999999523162842, 12.230785369873047)
})
invisibleWall38.addComponentOrReplace(transform67)

const invisibleWall39 = new Entity('invisibleWall39')
engine.addEntity(invisibleWall39)
invisibleWall39.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(15.959733009338379, 11.869647026062012, 9.260791778564453),
  rotation: new Quaternion(-6.961866284469712e-15, 1, -1.1920927533992653e-7, 1.1920927533992653e-7),
  scale: new Vector3(24.796085357666016, 0.12999999523162842, 10.622305870056152)
})
invisibleWall39.addComponentOrReplace(transform68)

const invisibleWall41 = new Entity('invisibleWall41')
engine.addEntity(invisibleWall41)
invisibleWall41.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(15.94294548034668, 6.369647979736328, 15.968941688537598),
  rotation: new Quaternion(-6.961866284469712e-15, 1, -1.1920927533992653e-7, 1.1920927533992653e-7),
  scale: new Vector3(26.03366470336914, 0.12999999523162842, 25.25582504272461)
})
invisibleWall41.addComponentOrReplace(transform69)

const invisibleWall40 = new Entity('invisibleWall40')
engine.addEntity(invisibleWall40)
invisibleWall40.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(30.624048233032227, 39.420379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall40.addComponentOrReplace(transform70)

const invisibleWall42 = new Entity('invisibleWall42')
engine.addEntity(invisibleWall42)
invisibleWall42.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(15.92219352722168, 39.420379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.13000071048736572, 0.6676454544067383)
})
invisibleWall42.addComponentOrReplace(transform71)

const invisibleWall43 = new Entity('invisibleWall43')
engine.addEntity(invisibleWall43)
invisibleWall43.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(1.1458446979522705, 39.420379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall43.addComponentOrReplace(transform72)

const invisibleWall44 = new Entity('invisibleWall44')
engine.addEntity(invisibleWall44)
invisibleWall44.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(15.844953536987305, 39.420379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.426721572875977, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall44.addComponentOrReplace(transform73)

const invisibleWall45 = new Entity('invisibleWall45')
engine.addEntity(invisibleWall45)
invisibleWall45.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(30.624048233032227, 34.920379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall45.addComponentOrReplace(transform74)

const invisibleWall46 = new Entity('invisibleWall46')
engine.addEntity(invisibleWall46)
invisibleWall46.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(15.92219352722168, 34.920379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.1300007402896881, 0.6676456928253174)
})
invisibleWall46.addComponentOrReplace(transform75)

const invisibleWall47 = new Entity('invisibleWall47')
engine.addEntity(invisibleWall47)
invisibleWall47.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(1.1458446979522705, 34.920379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall47.addComponentOrReplace(transform76)

const invisibleWall48 = new Entity('invisibleWall48')
engine.addEntity(invisibleWall48)
invisibleWall48.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(15.844953536987305, 34.920379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.42673683166504, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall48.addComponentOrReplace(transform77)

const invisibleWall49 = new Entity('invisibleWall49')
engine.addEntity(invisibleWall49)
invisibleWall49.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(30.624048233032227, 29.920379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall49.addComponentOrReplace(transform78)

const invisibleWall50 = new Entity('invisibleWall50')
engine.addEntity(invisibleWall50)
invisibleWall50.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(15.92219352722168, 29.920379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.1300007700920105, 0.6676459312438965)
})
invisibleWall50.addComponentOrReplace(transform79)

const invisibleWall51 = new Entity('invisibleWall51')
engine.addEntity(invisibleWall51)
invisibleWall51.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(1.1458446979522705, 29.920379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall51.addComponentOrReplace(transform80)

const invisibleWall52 = new Entity('invisibleWall52')
engine.addEntity(invisibleWall52)
invisibleWall52.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(15.844953536987305, 29.920379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.426753997802734, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall52.addComponentOrReplace(transform81)

const invisibleWall53 = new Entity('invisibleWall53')
engine.addEntity(invisibleWall53)
invisibleWall53.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(30.624048233032227, 23.920379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall53.addComponentOrReplace(transform82)

const invisibleWall55 = new Entity('invisibleWall55')
engine.addEntity(invisibleWall55)
invisibleWall55.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(1.1458446979522705, 23.920379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall55.addComponentOrReplace(transform83)

const invisibleWall57 = new Entity('invisibleWall57')
engine.addEntity(invisibleWall57)
invisibleWall57.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(30.624048233032227, 18.420379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall57.addComponentOrReplace(transform84)

const invisibleWall58 = new Entity('invisibleWall58')
engine.addEntity(invisibleWall58)
invisibleWall58.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(15.92219352722168, 18.420379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.13000082969665527, 0.6676464080810547)
})
invisibleWall58.addComponentOrReplace(transform85)

const invisibleWall59 = new Entity('invisibleWall59')
engine.addEntity(invisibleWall59)
invisibleWall59.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(1.1458446979522705, 18.420379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall59.addComponentOrReplace(transform86)

const invisibleWall60 = new Entity('invisibleWall60')
engine.addEntity(invisibleWall60)
invisibleWall60.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(15.844953536987305, 18.420379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.426788330078125, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall60.addComponentOrReplace(transform87)

const invisibleWall61 = new Entity('invisibleWall61')
engine.addEntity(invisibleWall61)
invisibleWall61.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(30.624048233032227, 12.920379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall61.addComponentOrReplace(transform88)

const invisibleWall62 = new Entity('invisibleWall62')
engine.addEntity(invisibleWall62)
invisibleWall62.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(15.92219352722168, 12.920379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.13000085949897766, 0.6676466464996338)
})
invisibleWall62.addComponentOrReplace(transform89)

const invisibleWall63 = new Entity('invisibleWall63')
engine.addEntity(invisibleWall63)
invisibleWall63.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(1.1458446979522705, 12.920379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall63.addComponentOrReplace(transform90)

const invisibleWall64 = new Entity('invisibleWall64')
engine.addEntity(invisibleWall64)
invisibleWall64.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(15.844953536987305, 12.920379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.426803588867188, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall64.addComponentOrReplace(transform91)

const invisibleWall65 = new Entity('invisibleWall65')
engine.addEntity(invisibleWall65)
invisibleWall65.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(30.624048233032227, 6.920379638671875, 15.914789199829102),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(29.366304397583008, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall65.addComponentOrReplace(transform92)

const invisibleWall66 = new Entity('invisibleWall66')
engine.addEntity(invisibleWall66)
invisibleWall66.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(15.92219352722168, 6.920379638671875, 1.614530086517334),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.13000091910362244, 0.6676470041275024)
})
invisibleWall66.addComponentOrReplace(transform93)

const invisibleWall67 = new Entity('invisibleWall67')
engine.addEntity(invisibleWall67)
invisibleWall67.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(1.1458446979522705, 6.920379638671875, 15.85494327545166),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(28.289522171020508, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall67.addComponentOrReplace(transform94)

const invisibleWall68 = new Entity('invisibleWall68')
engine.addEntity(invisibleWall68)
invisibleWall68.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(15.844953536987305, 6.920379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.426834106445312, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall68.addComponentOrReplace(transform95)

const invisibleWall69 = new Entity('invisibleWall69')
engine.addEntity(invisibleWall69)
invisibleWall69.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(30.947385787963867, 1.920379638671875, 17.186012268066406),
  rotation: new Quaternion(-0.5000000596046448, 0.4999999403953552, -0.5, -0.5),
  scale: new Vector3(25.87432861328125, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall69.addComponentOrReplace(transform96)

const invisibleWall70 = new Entity('invisibleWall70')
engine.addEntity(invisibleWall70)
invisibleWall70.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(17.197132110595703, 1.920379638671875, 1.665719985961914),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(26.715211868286133, 0.13000085949897766, 0.6676469445228577)
})
invisibleWall70.addComponentOrReplace(transform97)

const invisibleWall71 = new Entity('invisibleWall71')
engine.addEntity(invisibleWall71)
invisibleWall71.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(1.2421588897705078, 1.920379638671875, 14.68535327911377),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(25.87432861328125, 0.1300002932548523, 0.6676452159881592)
})
invisibleWall71.addComponentOrReplace(transform98)

const invisibleWall72 = new Entity('invisibleWall72')
engine.addEntity(invisibleWall72)
invisibleWall72.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(14.488882064819336, 1.920379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(26.71695327758789, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall72.addComponentOrReplace(transform99)

const invisibleWall81 = new Entity('invisibleWall81')
engine.addEntity(invisibleWall81)
invisibleWall81.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(14.389037132263184, 39.420379638671875, 16.368762969970703),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(3.078185558319092, 0.01625014841556549, 0.6676474213600159)
})
invisibleWall81.addComponentOrReplace(transform100)

const triggerArea3 = new Entity('triggerArea3')
engine.addEntity(triggerArea3)
triggerArea3.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(2.3541603088378906, 0, 3.0000009536743164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 42.00499725341797, 1.5)
})
triggerArea3.addComponentOrReplace(transform101)

const verticalBlackPad2 = new Entity('verticalBlackPad2')
engine.addEntity(verticalBlackPad2)
verticalBlackPad2.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(2.2679178714752197, 0, 2.946953773498535),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
verticalBlackPad2.addComponentOrReplace(transform102)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(28.24195671081543, 43.62815475463867, 15.850725173950195),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.185526505112648, 0.802521288394928, 102.17676544189453)
})
ropeLight.addComponentOrReplace(transform103)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform104 = new Transform({
  position: new Vector3(3.8829898834228516, 43.62815475463867, 15.850725173950195),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552662432193756, 0.5488288402557373, 102.17676544189453)
})
ropeLight2.addComponentOrReplace(transform104)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(27.466691970825195, 43.62815475463867, 2.9753353595733643),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.1855269819498062, 3.9086060523986816, 71.4645767211914)
})
ropeLight3.addComponentOrReplace(transform105)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform106 = new Transform({
  position: new Vector3(4.915863990783691, 43.62815475463867, 2.9753365516662598),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.185527041554451, 3.9086079597473145, 71.4645767211914)
})
ropeLight4.addComponentOrReplace(transform106)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform107 = new Transform({
  position: new Vector3(4.915863990783691, 43.62815475463867, 28.855314254760742),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552716076374054, 3.90861177444458, 71.4645767211914)
})
ropeLight5.addComponentOrReplace(transform107)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(27.466691970825195, 43.62815475463867, 28.855314254760742),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552710115909576, 3.9086098670959473, 71.4645767211914)
})
ropeLight6.addComponentOrReplace(transform108)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(2.527418375015259, 43.62815475463867, 26.109331130981445),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.18552745878696442, 13.315666198730469, 71.4647216796875)
})
ropeLight7.addComponentOrReplace(transform109)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(29.527420043945312, 43.62815475463867, 26.109329223632812),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.1855274885892868, 13.315670013427734, 71.46473693847656)
})
ropeLight8.addComponentOrReplace(transform110)

const ropeLight9 = new Entity('ropeLight9')
engine.addEntity(ropeLight9)
ropeLight9.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(29.527420043945312, 43.62815475463867, 4.921122074127197),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.18552757799625397, 13.315681457519531, 71.46478271484375)
})
ropeLight9.addComponentOrReplace(transform111)

const ropeLight10 = new Entity('ropeLight10')
engine.addEntity(ropeLight10)
ropeLight10.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(2.5274181365966797, 43.62815475463867, 4.92112398147583),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.18552754819393158, 13.315677642822266, 71.46476745605469)
})
ropeLight10.addComponentOrReplace(transform112)

const ropeLight11 = new Entity('ropeLight11')
engine.addEntity(ropeLight11)
ropeLight11.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(29.527420043945312, 2.128154754638672, 5.555665016174316),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.1855277419090271, 3.328927755355835, 71.46488952636719)
})
ropeLight11.addComponentOrReplace(transform113)

const ropeLight12 = new Entity('ropeLight12')
engine.addEntity(ropeLight12)
ropeLight12.setParent(_scene)
const transform114 = new Transform({
  position: new Vector3(27.466691970825195, 2.128154754638672, 2.975335121154785),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552707135677338, 3.908608913421631, 71.4645767211914)
})
ropeLight12.addComponentOrReplace(transform114)

const ropeLight13 = new Entity('ropeLight13')
engine.addEntity(ropeLight13)
ropeLight13.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(27.65852165222168, 2.128154754638672, 28.967605590820312),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552711606025696, 7.753355979919434, 71.4645767211914)
})
ropeLight13.addComponentOrReplace(transform115)

const ropeLight14 = new Entity('ropeLight14')
engine.addEntity(ropeLight14)
ropeLight14.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(29.527420043945312, 2.128154754638672, 26.279708862304688),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.18552763760089874, 2.5694620609283447, 71.46481323242188)
})
ropeLight14.addComponentOrReplace(transform116)

const ropeLight15 = new Entity('ropeLight15')
engine.addEntity(ropeLight15)
ropeLight15.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(2.5274181365966797, 2.128154754638672, 26.109329223632812),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.18552753329277039, 10.299592018127441, 71.46478271484375)
})
ropeLight15.addComponentOrReplace(transform117)

const ropeLight16 = new Entity('ropeLight16')
engine.addEntity(ropeLight16)
ropeLight16.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(4.915863990783691, 2.128154754638672, 28.967605590820312),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552717566490173, 9.671303749084473, 71.4645767211914)
})
ropeLight16.addComponentOrReplace(transform118)

const ropeLight17 = new Entity('ropeLight17')
engine.addEntity(ropeLight17)
ropeLight17.setParent(_scene)
const transform119 = new Transform({
  position: new Vector3(4.830386161804199, 2.128154754638672, 2.975337028503418),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.18552711606025696, 3.90861177444458, 71.4645767211914)
})
ropeLight17.addComponentOrReplace(transform119)

const ropeLight18 = new Entity('ropeLight18')
engine.addEntity(ropeLight18)
ropeLight18.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(2.496206283569336, 2.128154754638672, 5.177582740783691),
  rotation: new Quaternion(-0.5, -0.5, -0.5, -0.5000001192092896),
  scale: new Vector3(0.1855277419090271, 9.207524299621582, 71.46488952636719)
})
ropeLight18.addComponentOrReplace(transform120)

const discRainbow = new Entity('discRainbow')
engine.addEntity(discRainbow)
discRainbow.setParent(_scene)
const transform121 = new Transform({
  position: new Vector3(16.08563232421875, 38.5, 15.93038558959961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.384753704071045, 1, 1.3769208192825317)
})
discRainbow.addComponentOrReplace(transform121)
const gltfShape4 = new GLTFShape("1d628cf69e3a27dae3d50585ccead6fa1dea4afaee256960ebaceee03a6d98d9/Disc_-Rainbow.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
discRainbow.addComponentOrReplace(gltfShape4)

const ropeLight19 = new Entity('ropeLight19')
engine.addEntity(ropeLight19)
ropeLight19.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(16.104705810546875, 38.4631233215332, 15.955110549926758),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.2870623469352722, 0.8025217652320862, 810.178955078125)
})
ropeLight19.addComponentOrReplace(transform122)

const ropeLight20 = new Entity('ropeLight20')
engine.addEntity(ropeLight20)
ropeLight20.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(15.951557159423828, 28.956941604614258, 15.955110549926758),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.2870623469352722, 0.8025217652320862, 374.4844665527344)
})
ropeLight20.addComponentOrReplace(transform123)

const ropeLight22 = new Entity('ropeLight22')
engine.addEntity(ropeLight22)
ropeLight22.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(0.33374178409576416, 1.8779644966125488, 28.99116325378418),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.3213149905204773, 1.758768081665039, 64.75537109375)
})
ropeLight22.addComponentOrReplace(transform124)

const ropeLight23 = new Entity('ropeLight23')
engine.addEntity(ropeLight23)
ropeLight23.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(31.813125610351562, 1.902637004852295, 2.946887969970703),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.3216511011123657, 1.7587699890136719, 64.75537109375)
})
ropeLight23.addComponentOrReplace(transform125)

const ropeLight24 = new Entity('ropeLight24')
engine.addEntity(ropeLight24)
ropeLight24.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(29.379806518554688, 1.674048900604248, 31.74844741821289),
  rotation: new Quaternion(-0.5, -0.5, 0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.2844555377960205, 1.7587676048278809, 64.75537872314453)
})
ropeLight24.addComponentOrReplace(transform126)

const ropeLight25 = new Entity('ropeLight25')
engine.addEntity(ropeLight25)
ropeLight25.setParent(_scene)
const transform127 = new Transform({
  position: new Vector3(2.510744094848633, 1.6846548318862915, 0.4182713031768799),
  rotation: new Quaternion(-0.5, -0.5, 0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(0.2844553589820862, 1.7587661743164062, 64.75537872314453)
})
ropeLight25.addComponentOrReplace(transform127)

const ropeLight26 = new Entity('ropeLight26')
engine.addEntity(ropeLight26)
ropeLight26.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(15.951557159423828, 17.456941604614258, 15.955110549926758),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.2870623469352722, 0.8025217652320862, 337.6112365722656)
})
ropeLight26.addComponentOrReplace(transform128)

const ropeLight27 = new Entity('ropeLight27')
engine.addEntity(ropeLight27)
ropeLight27.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(15.986900329589844, 11.956941604614258, 16.073001861572266),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.28041329979896545, 0.8025217652320862, 675.222900390625)
})
ropeLight27.addComponentOrReplace(transform129)

const ropeLight28 = new Entity('ropeLight28')
engine.addEntity(ropeLight28)
ropeLight28.setParent(_scene)
const transform130 = new Transform({
  position: new Vector3(15.951557159423828, 33.956939697265625, 15.893489837646484),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.2804134786128998, 0.8025217652320862, 675.2244262695312)
})
ropeLight28.addComponentOrReplace(transform130)

const discRainbow2 = new Entity('discRainbow2')
engine.addEntity(discRainbow2)
discRainbow2.setParent(_scene)
discRainbow2.addComponentOrReplace(gltfShape4)
const transform131 = new Transform({
  position: new Vector3(16.08563232421875, 33.99641036987305, 15.93038558959961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.223038911819458, 1, 1.2488528490066528)
})
discRainbow2.addComponentOrReplace(transform131)

const discRainbow3 = new Entity('discRainbow3')
engine.addEntity(discRainbow3)
discRainbow3.setParent(_scene)
discRainbow3.addComponentOrReplace(gltfShape4)
const transform132 = new Transform({
  position: new Vector3(16.08563232421875, 28.996410369873047, 15.93038558959961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7140929102897644, 1, 0.6921584606170654)
})
discRainbow3.addComponentOrReplace(transform132)

const discRainbow4 = new Entity('discRainbow4')
engine.addEntity(discRainbow4)
discRainbow4.setParent(_scene)
discRainbow4.addComponentOrReplace(gltfShape4)
const transform133 = new Transform({
  position: new Vector3(16.08563232421875, 17.496410369873047, 15.93038558959961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6676967740058899, 1, 0.6520227789878845)
})
discRainbow4.addComponentOrReplace(transform133)

const discRainbow5 = new Entity('discRainbow5')
engine.addEntity(discRainbow5)
discRainbow5.setParent(_scene)
discRainbow5.addComponentOrReplace(gltfShape4)
const transform134 = new Transform({
  position: new Vector3(16.08563232421875, 11.996410369873047, 15.93038558959961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2538517713546753, 1, 1.2643214464187622)
})
discRainbow5.addComponentOrReplace(transform134)

const discRainbow6 = new Entity('discRainbow6')
engine.addEntity(discRainbow6)
discRainbow6.setParent(_scene)
discRainbow6.addComponentOrReplace(gltfShape4)
const transform135 = new Transform({
  position: new Vector3(16.08563232421875, 6.505760192871094, 15.93038558959961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4171228408813477, 1, 1.4294419288635254)
})
discRainbow6.addComponentOrReplace(transform135)

const doorframeWoodenBoard = new Entity('doorframeWoodenBoard')
engine.addEntity(doorframeWoodenBoard)
doorframeWoodenBoard.setParent(_scene)
const transform136 = new Transform({
  position: new Vector3(30.622758865356445, 0, 31.778606414794922),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2329585552215576, 1, 1)
})
doorframeWoodenBoard.addComponentOrReplace(transform136)
const gltfShape5 = new GLTFShape("480f8ce2a31cc7491baddf53b368f16be4d8989b09e2af8f738e1081ce0607da/WoodenBoardDoorframe.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
doorframeWoodenBoard.addComponentOrReplace(gltfShape5)

const doorframeArrowBoard = new Entity('doorframeArrowBoard')
engine.addEntity(doorframeArrowBoard)
doorframeArrowBoard.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(3.7253241539001465, 0, 0.4645986557006836),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2022188901901245, 1, 0.6002073287963867)
})
doorframeArrowBoard.addComponentOrReplace(transform137)
const gltfShape6 = new GLTFShape("381be534bc05626e714a07abd4ea213ba4cdc450fbd2011f23e61b3b8248cb15/ArrowBoardDoorframe.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
doorframeArrowBoard.addComponentOrReplace(gltfShape6)

const doorframeWoodenBoard2 = new Entity('doorframeWoodenBoard2')
engine.addEntity(doorframeWoodenBoard2)
doorframeWoodenBoard2.setParent(_scene)
doorframeWoodenBoard2.addComponentOrReplace(gltfShape5)
const transform138 = new Transform({
  position: new Vector3(31.883018493652344, 0, 1.7203569412231445),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.2329597473144531, 1, 1.0000011920928955)
})
doorframeWoodenBoard2.addComponentOrReplace(transform138)

const doorframeArrowBoard2 = new Entity('doorframeArrowBoard2')
engine.addEntity(doorframeArrowBoard2)
doorframeArrowBoard2.setParent(_scene)
doorframeArrowBoard2.addComponentOrReplace(gltfShape6)
const transform139 = new Transform({
  position: new Vector3(0.40005671977996826, 0.0000034570693969726562, 27.782962799072266),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.2022205591201782, 1, 1.0000016689300537)
})
doorframeArrowBoard2.addComponentOrReplace(transform139)

const doorframeArrowBoard3 = new Entity('doorframeArrowBoard3')
engine.addEntity(doorframeArrowBoard3)
doorframeArrowBoard3.setParent(_scene)
doorframeArrowBoard3.addComponentOrReplace(gltfShape6)
const transform140 = new Transform({
  position: new Vector3(28.264751434326172, 42.553611755371094, 14.055557250976562),
  rotation: new Quaternion(-6.692902301134779e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.7969493865966797, 0.5543136596679688, 0.3688713014125824)
})
doorframeArrowBoard3.addComponentOrReplace(transform140)

const doorframeWoodenBoard3 = new Entity('doorframeWoodenBoard3')
engine.addEntity(doorframeWoodenBoard3)
doorframeWoodenBoard3.setParent(_scene)
doorframeWoodenBoard3.addComponentOrReplace(gltfShape5)
const transform141 = new Transform({
  position: new Vector3(3.8880128860473633, 42.53028106689453, 13.846936225891113),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.964176058769226, 0.5514587759971619, 0.37390777468681335)
})
doorframeWoodenBoard3.addComponentOrReplace(transform141)

const invisibleWall85 = new Entity('invisibleWall85')
engine.addEntity(invisibleWall85)
invisibleWall85.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(28.918222427368164, 42.36964797973633, 23.721954345703125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.7166945934295654, 0.12999999523162842, 12.230731010437012)
})
invisibleWall85.addComponentOrReplace(transform142)

const invisibleWall86 = new Entity('invisibleWall86')
engine.addEntity(invisibleWall86)
invisibleWall86.setParent(_scene)
const transform143 = new Transform({
  position: new Vector3(28.418222427368164, 42.36964797973633, 7.968945503234863),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.7166945934295654, 0.12999999523162842, 12.230731010437012)
})
invisibleWall86.addComponentOrReplace(transform143)

const invisibleWall87 = new Entity('invisibleWall87')
engine.addEntity(invisibleWall87)
invisibleWall87.setParent(_scene)
const transform144 = new Transform({
  position: new Vector3(16.534936904907227, 42.36964797973633, 3.468944549560547),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.7167012691497803, 0.12999999523162842, 24.97036361694336)
})
invisibleWall87.addComponentOrReplace(transform144)

const invisibleWall88 = new Entity('invisibleWall88')
engine.addEntity(invisibleWall88)
invisibleWall88.setParent(_scene)
const transform145 = new Transform({
  position: new Vector3(16.534936904907227, 42.36964797973633, 28.468944549560547),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.7167022228240967, 0.12999999523162842, 25.617374420166016)
})
invisibleWall88.addComponentOrReplace(transform145)

const invisibleWall84 = new Entity('invisibleWall84')
engine.addEntity(invisibleWall84)
invisibleWall84.setParent(_scene)
const transform146 = new Transform({
  position: new Vector3(16.191579818725586, 39.420379638671875, 14.574337005615234),
  rotation: new Quaternion(-0.7071068286895752, -2.9802322387695312e-8, 7.194915951913572e-8, -0.7071068286895752),
  scale: new Vector3(3.093294858932495, 0.01625005528330803, 0.6676452159881592)
})
invisibleWall84.addComponentOrReplace(transform146)

const invisibleWall98 = new Entity('invisibleWall98')
engine.addEntity(invisibleWall98)
invisibleWall98.setParent(_scene)
const transform147 = new Transform({
  position: new Vector3(16.387632369995117, 23.920379638671875, 14.574337005615234),
  rotation: new Quaternion(-0.7071068286895752, -2.9802322387695312e-8, 7.194915951913572e-8, -0.7071068286895752),
  scale: new Vector3(3.093294858932495, 0.016250066459178925, 0.6676455140113831)
})
invisibleWall98.addComponentOrReplace(transform147)

const invisibleWall99 = new Entity('invisibleWall99')
engine.addEntity(invisibleWall99)
invisibleWall99.setParent(_scene)
const transform148 = new Transform({
  position: new Vector3(14.585089683532715, 23.920379638671875, 16.368762969970703),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(3.078185558319092, 0.01625014841556549, 0.6676474213600159)
})
invisibleWall99.addComponentOrReplace(transform148)

const discMetal = new Entity('discMetal')
engine.addEntity(discMetal)
discMetal.setParent(_scene)
const transform149 = new Transform({
  position: new Vector3(16.10434913635254, 38.5147705078125, 16.16668128967285),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.18749994039535522, 18436322, 0.17578120529651642)
})
discMetal.addComponentOrReplace(transform149)
const gltfShape7 = new GLTFShape("70ea51483e09d83c1772c470a7f846e5988f4d7637ead9ae77d4b07487498cc4/Disc_- Metal.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
discMetal.addComponentOrReplace(gltfShape7)

const scratchedCopperWall = new Entity('scratchedCopperWall')
engine.addEntity(scratchedCopperWall)
scratchedCopperWall.setParent(_scene)
const transform150 = new Transform({
  position: new Vector3(16.09163475036621, 38.5, 28.934541702270508),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(11.714152336120605, 53.529212951660156, 22.578760147094727)
})
scratchedCopperWall.addComponentOrReplace(transform150)
const gltfShape8 = new GLTFShape("f12e00a9d389813851f95f67c34bf812da5192ec58ca5740d76f14dcf0cbfa68/Scratched_Copper Wall.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
scratchedCopperWall.addComponentOrReplace(gltfShape8)

const scratchedCopperWall2 = new Entity('scratchedCopperWall2')
engine.addEntity(scratchedCopperWall2)
scratchedCopperWall2.setParent(_scene)
scratchedCopperWall2.addComponentOrReplace(gltfShape8)
const transform151 = new Transform({
  position: new Vector3(16.09163475036621, 38.5, 14.194920539855957),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(11.714152336120605, 56.00022888183594, 22.57874298095703)
})
scratchedCopperWall2.addComponentOrReplace(transform151)

const scratchedCopperWall4 = new Entity('scratchedCopperWall4')
engine.addEntity(scratchedCopperWall4)
scratchedCopperWall4.setParent(_scene)
scratchedCopperWall4.addComponentOrReplace(gltfShape8)
const transform152 = new Transform({
  position: new Vector3(16.196502685546875, 39.591251373291016, 14.63949203491211),
  rotation: new Quaternion(-1, 2.177062080483132e-15, 1.1920927533992653e-7, -7.105426087051581e-15),
  scale: new Vector3(15.76338005065918, 2.776186943054199, 22.578771591186523)
})
scratchedCopperWall4.addComponentOrReplace(transform152)

const scratchedCopperWall5 = new Entity('scratchedCopperWall5')
engine.addEntity(scratchedCopperWall5)
scratchedCopperWall5.setParent(_scene)
scratchedCopperWall5.addComponentOrReplace(gltfShape8)
const transform153 = new Transform({
  position: new Vector3(14.446502685546875, 39.591251373291016, 16.38949203491211),
  rotation: new Quaternion(0.7071067690849304, -8.429367426288081e-8, -0.70710688829422, -3.93532100217411e-15),
  scale: new Vector3(15.763391494750977, 2.776186466217041, 22.578744888305664)
})
scratchedCopperWall5.addComponentOrReplace(transform153)

const invisibleWall54 = new Entity('invisibleWall54')
engine.addEntity(invisibleWall54)
invisibleWall54.setParent(_scene)
const transform154 = new Transform({
  position: new Vector3(16.13524627685547, 38.5315055847168, 7.791130065917969),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(13.652054786682129, 0.01625004969537258, 2.628863573074341)
})
invisibleWall54.addComponentOrReplace(transform154)

const invisibleWall56 = new Entity('invisibleWall56')
engine.addEntity(invisibleWall56)
invisibleWall56.setParent(_scene)
const transform155 = new Transform({
  position: new Vector3(16.143112182617188, 38.5315055847168, 24.544021606445312),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(13.663427352905273, 0.01625004969537258, 2.6288628578186035)
})
invisibleWall56.addComponentOrReplace(transform155)

const stairsSpiral = new Entity('stairsSpiral')
engine.addEntity(stairsSpiral)
stairsSpiral.setParent(_scene)
const transform156 = new Transform({
  position: new Vector3(16.14089584350586, 34.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral.addComponentOrReplace(transform156)
const gltfShape9 = new GLTFShape("7ad467d63d496decec898c7fce7b617d49f13761363e9374f11e0f75d440814d/SpiralStairs.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
stairsSpiral.addComponentOrReplace(gltfShape9)

const discMetal2 = new Entity('discMetal2')
engine.addEntity(discMetal2)
discMetal2.setParent(_scene)
discMetal2.addComponentOrReplace(gltfShape7)
const transform157 = new Transform({
  position: new Vector3(15.98307991027832, 29.0147705078125, 16.127826690673828),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.18749994039535522, 18436322, 0.17578120529651642)
})
discMetal2.addComponentOrReplace(transform157)

const stairsSpiral2 = new Entity('stairsSpiral2')
engine.addEntity(stairsSpiral2)
stairsSpiral2.setParent(_scene)
stairsSpiral2.addComponentOrReplace(gltfShape9)
const transform158 = new Transform({
  position: new Vector3(16.14089584350586, 30.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral2.addComponentOrReplace(transform158)

const stairsSpiral3 = new Entity('stairsSpiral3')
engine.addEntity(stairsSpiral3)
stairsSpiral3.setParent(_scene)
stairsSpiral3.addComponentOrReplace(gltfShape9)
const transform159 = new Transform({
  position: new Vector3(16.14089584350586, 26.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral3.addComponentOrReplace(transform159)

const discMetal3 = new Entity('discMetal3')
engine.addEntity(discMetal3)
discMetal3.setParent(_scene)
discMetal3.addComponentOrReplace(gltfShape7)
const transform160 = new Transform({
  position: new Vector3(16.185277938842773, 34.0147705078125, 15.924158096313477),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.18749994039535522, 18436322, 0.17578120529651642)
})
discMetal3.addComponentOrReplace(transform160)

const invisibleWall73 = new Entity('invisibleWall73')
engine.addEntity(invisibleWall73)
invisibleWall73.setParent(_scene)
const transform161 = new Transform({
  position: new Vector3(15.928528785705566, 29.031505584716797, 11.66289234161377),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(4.965062618255615, 0.01625004969537258, 2.62886118888855)
})
invisibleWall73.addComponentOrReplace(transform161)

const invisibleWall74 = new Entity('invisibleWall74')
engine.addEntity(invisibleWall74)
invisibleWall74.setParent(_scene)
const transform162 = new Transform({
  position: new Vector3(15.996854782104492, 29.031505584716797, 21.08519172668457),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(5.408010482788086, 0.01625004969537258, 2.6288626194000244)
})
invisibleWall74.addComponentOrReplace(transform162)

const scratchedCopperWall3 = new Entity('scratchedCopperWall3')
engine.addEntity(scratchedCopperWall3)
scratchedCopperWall3.setParent(_scene)
scratchedCopperWall3.addComponentOrReplace(gltfShape8)
const transform163 = new Transform({
  position: new Vector3(15.990596771240234, 29, 22.0462703704834),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(11.714152336120605, 18.04478645324707, 22.57875633239746)
})
scratchedCopperWall3.addComponentOrReplace(transform163)

const scratchedCopperWall7 = new Entity('scratchedCopperWall7')
engine.addEntity(scratchedCopperWall7)
scratchedCopperWall7.setParent(_scene)
scratchedCopperWall7.addComponentOrReplace(gltfShape8)
const transform164 = new Transform({
  position: new Vector3(16.03236198425293, 29, 14.054656028747559),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(11.714152336120605, 20.119932174682617, 22.578737258911133)
})
scratchedCopperWall7.addComponentOrReplace(transform164)

const scratchedCopperWall8 = new Entity('scratchedCopperWall8')
engine.addEntity(scratchedCopperWall8)
scratchedCopperWall8.setParent(_scene)
scratchedCopperWall8.addComponentOrReplace(gltfShape8)
const transform165 = new Transform({
  position: new Vector3(13.906840324401855, 34, 15.95616340637207),
  rotation: new Quaternion(-0.4999999403953552, 0.5000000596046448, 0.5, 0.5),
  scale: new Vector3(11.714152336120605, 42.00016784667969, 22.57875633239746)
})
scratchedCopperWall8.addComponentOrReplace(transform165)

const scratchedCopperWall9 = new Entity('scratchedCopperWall9')
engine.addEntity(scratchedCopperWall9)
scratchedCopperWall9.setParent(_scene)
scratchedCopperWall9.addComponentOrReplace(gltfShape8)
const transform166 = new Transform({
  position: new Vector3(26.932422637939453, 34, 15.95616340637207),
  rotation: new Quaternion(-0.4999999403953552, 0.5000000596046448, 0.5, 0.5),
  scale: new Vector3(11.714152336120605, 42.000144958496094, 22.57876968383789)
})
scratchedCopperWall9.addComponentOrReplace(transform166)

const invisibleWall75 = new Entity('invisibleWall75')
engine.addEntity(invisibleWall75)
invisibleWall75.setParent(_scene)
const transform167 = new Transform({
  position: new Vector3(24.103004455566406, 34.0315055847168, 15.964754104614258),
  rotation: new Quaternion(3.6156306837398233e-9, 0, -1.2282491468340595e-7, 1),
  scale: new Vector3(13.663419723510742, 0.01625004969537258, 2.6288647651672363)
})
invisibleWall75.addComponentOrReplace(transform167)

const invisibleWall76 = new Entity('invisibleWall76')
engine.addEntity(invisibleWall76)
invisibleWall76.setParent(_scene)
const transform168 = new Transform({
  position: new Vector3(7.241461753845215, 34.0315055847168, 15.972620010375977),
  rotation: new Quaternion(3.6156306837398233e-9, 0, -1.2282491468340595e-7, 1),
  scale: new Vector3(13.652059555053711, 0.01625004969537258, 2.62886381149292)
})
invisibleWall76.addComponentOrReplace(transform168)

const stairsSpiral4 = new Entity('stairsSpiral4')
engine.addEntity(stairsSpiral4)
stairsSpiral4.setParent(_scene)
stairsSpiral4.addComponentOrReplace(gltfShape9)
const transform169 = new Transform({
  position: new Vector3(16.14089584350586, 22.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral4.addComponentOrReplace(transform169)

const stairsSpiral5 = new Entity('stairsSpiral5')
engine.addEntity(stairsSpiral5)
stairsSpiral5.setParent(_scene)
stairsSpiral5.addComponentOrReplace(gltfShape9)
const transform170 = new Transform({
  position: new Vector3(16.14089584350586, 18.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral5.addComponentOrReplace(transform170)

const stairsSpiral6 = new Entity('stairsSpiral6')
engine.addEntity(stairsSpiral6)
stairsSpiral6.setParent(_scene)
stairsSpiral6.addComponentOrReplace(gltfShape9)
const transform171 = new Transform({
  position: new Vector3(16.14089584350586, 14.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral6.addComponentOrReplace(transform171)

const stairsSpiral7 = new Entity('stairsSpiral7')
engine.addEntity(stairsSpiral7)
stairsSpiral7.setParent(_scene)
stairsSpiral7.addComponentOrReplace(gltfShape9)
const transform172 = new Transform({
  position: new Vector3(16.14089584350586, 10.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral7.addComponentOrReplace(transform172)

const stairsSpiral8 = new Entity('stairsSpiral8')
engine.addEntity(stairsSpiral8)
stairsSpiral8.setParent(_scene)
stairsSpiral8.addComponentOrReplace(gltfShape9)
const transform173 = new Transform({
  position: new Vector3(16.14089584350586, 6.5, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral8.addComponentOrReplace(transform173)

const pipe = new Entity('pipe')
engine.addEntity(pipe)
pipe.setParent(_scene)
const transform174 = new Transform({
  position: new Vector3(16.000001907348633, 21, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(28.741436004638672, 20.530427932739258, 27.52897071838379)
})
pipe.addComponentOrReplace(transform174)
const gltfShape10 = new GLTFShape("87bfe7b0caa5da225967ea550c32f0bf3f851f2bbf5b7b5df6e030d5540d26c0/Pipe.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
pipe.addComponentOrReplace(gltfShape10)

const scratchedCopperWall10 = new Entity('scratchedCopperWall10')
engine.addEntity(scratchedCopperWall10)
scratchedCopperWall10.setParent(_scene)
scratchedCopperWall10.addComponentOrReplace(gltfShape8)
const transform175 = new Transform({
  position: new Vector3(16.04692268371582, 17.481321334838867, 21.343175888061523),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(11.714152336120605, 16.91176986694336, 22.578765869140625)
})
scratchedCopperWall10.addComponentOrReplace(transform175)

const invisibleWall77 = new Entity('invisibleWall77')
engine.addEntity(invisibleWall77)
invisibleWall77.setParent(_scene)
const transform176 = new Transform({
  position: new Vector3(16.05318260192871, 17.48139190673828, 20.73105812072754),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(5.408018112182617, 0.01625004969537258, 2.62886643409729)
})
invisibleWall77.addComponentOrReplace(transform176)

const scratchedCopperWall11 = new Entity('scratchedCopperWall11')
engine.addEntity(scratchedCopperWall11)
scratchedCopperWall11.setParent(_scene)
scratchedCopperWall11.addComponentOrReplace(gltfShape8)
const transform177 = new Transform({
  position: new Vector3(16.04692268371582, 17.481321334838867, 14.260213851928711),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(11.714152336120605, 18.80416488647461, 22.57878303527832)
})
scratchedCopperWall11.addComponentOrReplace(transform177)

const invisibleWall78 = new Entity('invisibleWall78')
engine.addEntity(invisibleWall78)
invisibleWall78.setParent(_scene)
const transform178 = new Transform({
  position: new Vector3(16.05318260192871, 17.491912841796875, 12.578802108764648),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(4.381103038787842, 0.01625004969537258, 2.6288671493530273)
})
invisibleWall78.addComponentOrReplace(transform178)

const scratchedCopperWall12 = new Entity('scratchedCopperWall12')
engine.addEntity(scratchedCopperWall12)
scratchedCopperWall12.setParent(_scene)
scratchedCopperWall12.addComponentOrReplace(gltfShape8)
const transform179 = new Transform({
  position: new Vector3(13.691617965698242, 11.98911190032959, 16.096923828125),
  rotation: new Quaternion(-0.4999999403953552, 0.5000000596046448, 0.5, 0.5),
  scale: new Vector3(13.964284896850586, 40.261173248291016, 22.57879638671875)
})
scratchedCopperWall12.addComponentOrReplace(transform179)

const invisibleWall79 = new Entity('invisibleWall79')
engine.addEntity(invisibleWall79)
invisibleWall79.setParent(_scene)
const transform180 = new Transform({
  position: new Vector3(9.334026336669922, 12.020617485046387, 16.06609344482422),
  rotation: new Quaternion(3.6156306837398233e-9, 0, -1.2282491468340595e-7, 1),
  scale: new Vector3(9.967808723449707, 0.01625004969537258, 3.133836507797241)
})
invisibleWall79.addComponentOrReplace(transform180)

const scratchedCopperWall13 = new Entity('scratchedCopperWall13')
engine.addEntity(scratchedCopperWall13)
scratchedCopperWall13.setParent(_scene)
scratchedCopperWall13.addComponentOrReplace(gltfShape8)
const transform181 = new Transform({
  position: new Vector3(26.968284606933594, 11.98911190032959, 16.096923828125),
  rotation: new Quaternion(-0.4999999403953552, 0.5000000596046448, 0.5, 0.5),
  scale: new Vector3(13.964284896850586, 43.4792594909668, 22.57879638671875)
})
scratchedCopperWall13.addComponentOrReplace(transform181)

const invisibleWall80 = new Entity('invisibleWall80')
engine.addEntity(invisibleWall80)
invisibleWall80.setParent(_scene)
const transform182 = new Transform({
  position: new Vector3(23.098039627075195, 12.020617485046387, 16.331281661987305),
  rotation: new Quaternion(3.6156306837398233e-9, 0, -1.2282491468340595e-7, 1),
  scale: new Vector3(9.967808723449707, 0.01625004969537258, 3.133836507797241)
})
invisibleWall80.addComponentOrReplace(transform182)

const invisibleWall83 = new Entity('invisibleWall83')
engine.addEntity(invisibleWall83)
invisibleWall83.setParent(_scene)
const transform183 = new Transform({
  position: new Vector3(16.43653106689453, 29.031505584716797, 5.448484420776367),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(8.858479499816895, 0.01625004969537258, 2.628866195678711)
})
invisibleWall83.addComponentOrReplace(transform183)

const invisibleWall89 = new Entity('invisibleWall89')
engine.addEntity(invisibleWall89)
invisibleWall89.setParent(_scene)
const transform184 = new Transform({
  position: new Vector3(16.43653106689453, 29.031505584716797, 26.448484420776367),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(8.858485221862793, 0.01625004969537258, 2.6288676261901855)
})
invisibleWall89.addComponentOrReplace(transform184)

const invisibleWall90 = new Entity('invisibleWall90')
engine.addEntity(invisibleWall90)
invisibleWall90.setParent(_scene)
const transform185 = new Transform({
  position: new Vector3(15.936531066894531, 17.48239517211914, 26.805856704711914),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(8.858492851257324, 0.01625004969537258, 2.628868818283081)
})
invisibleWall90.addComponentOrReplace(transform185)

const invisibleWall91 = new Entity('invisibleWall91')
engine.addEntity(invisibleWall91)
invisibleWall91.setParent(_scene)
const transform186 = new Transform({
  position: new Vector3(15.936531066894531, 17.48239517211914, 5.805856704711914),
  rotation: new Quaternion(8.940696716308594e-8, -0.7071068286895752, 0, 0.7071068286895752),
  scale: new Vector3(8.858494758605957, 0.01625004969537258, 2.628868579864502)
})
invisibleWall91.addComponentOrReplace(transform186)

const invisibleWall92 = new Entity('invisibleWall92')
engine.addEntity(invisibleWall92)
invisibleWall92.setParent(_scene)
const transform187 = new Transform({
  position: new Vector3(8.436531066894531, 22.982397079467773, 16.305858612060547),
  rotation: new Quaternion(3.6156300176060086e-9, 0, -1.2282491468340595e-7, 1),
  scale: new Vector3(9.965810775756836, 0.01625004969537258, 2.6288697719573975)
})
invisibleWall92.addComponentOrReplace(transform187)

const invisibleWall93 = new Entity('invisibleWall93')
engine.addEntity(invisibleWall93)
invisibleWall93.setParent(_scene)
const transform188 = new Transform({
  position: new Vector3(23.43653106689453, 22.982393264770508, 16.30585479736328),
  rotation: new Quaternion(3.6156300176060086e-9, 0, -1.2282491468340595e-7, 1),
  scale: new Vector3(9.96580982208252, 0.01625004969537258, 2.6288700103759766)
})
invisibleWall93.addComponentOrReplace(transform188)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform189 = new Transform({
  position: new Vector3(16.105772018432617, 39.8106689453125, 3.5741119384765625),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.497091293334961, 2.497091293334961, 0.18657515943050385)
})
nftPictureFrame.addComponentOrReplace(transform189)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform190 = new Transform({
  position: new Vector3(16.105772018432617, 39.8106689453125, 28.516239166259766),
  rotation: new Quaternion(7.20454122385807e-15, -1, 1.1920928244535389e-7, -2.2351741790771484e-8),
  scale: new Vector3(2.497091293334961, 2.497091293334961, 0.18657515943050385)
})
nftPictureFrame2.addComponentOrReplace(transform190)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform191 = new Transform({
  position: new Vector3(3.634706497192383, 39.8106689453125, 16.045177459716797),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.4970922470092773, 2.497091293334961, 0.18657512962818146)
})
nftPictureFrame3.addComponentOrReplace(transform191)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform192 = new Transform({
  position: new Vector3(28.57683753967285, 39.8106689453125, 16.04517364501953),
  rotation: new Quaternion(5.094380134889687e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(2.4970922470092773, 2.497091293334961, 0.18657508492469788)
})
nftPictureFrame4.addComponentOrReplace(transform192)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform193 = new Transform({
  position: new Vector3(24.924144744873047, 39.8106689453125, 24.863548278808594),
  rotation: new Quaternion(-1.0208842573925826e-14, 0.9238795638084412, -1.1013501932666259e-7, -0.3826833963394165),
  scale: new Vector3(2.49709153175354, 2.497091293334961, 0.18657517433166504)
})
nftPictureFrame5.addComponentOrReplace(transform193)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform194 = new Transform({
  position: new Vector3(24.924144744873047, 39.8106689453125, 7.226799964904785),
  rotation: new Quaternion(-4.392575221606873e-15, 0.38268351554870605, -4.561941935321556e-8, -0.9238796234130859),
  scale: new Vector3(2.4970927238464355, 2.497091293334961, 0.18657511472702026)
})
nftPictureFrame6.addComponentOrReplace(transform194)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform195 = new Transform({
  position: new Vector3(7.287398338317871, 39.8106689453125, 7.226801872253418),
  rotation: new Quaternion(4.440892098500626e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(2.497091293334961, 2.497091293334961, 0.18657517433166504)
})
nftPictureFrame7.addComponentOrReplace(transform195)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform196 = new Transform({
  position: new Vector3(7.287398338317871, 39.8106689453125, 24.86355209350586),
  rotation: new Quaternion(5.288966472763576e-15, -0.9238796234130859, 1.1013501932666259e-7, -0.38268351554870605),
  scale: new Vector3(2.497093439102173, 2.497091293334961, 0.18657521903514862)
})
nftPictureFrame8.addComponentOrReplace(transform196)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform197 = new Transform({
  position: new Vector3(24.924144744873047, 35.265159606933594, 24.863548278808594),
  rotation: new Quaternion(-1.0208842573925826e-14, 0.9238795638084412, -1.1013501932666259e-7, -0.3826833963394165),
  scale: new Vector3(2.4970927238464355, 2.497091293334961, 0.186575248837471)
})
nftPictureFrame9.addComponentOrReplace(transform197)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform198 = new Transform({
  position: new Vector3(7.287398338317871, 35.265159606933594, 7.226801872253418),
  rotation: new Quaternion(2.220446049250313e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(2.497091293334961, 2.497091293334961, 0.18657517433166504)
})
nftPictureFrame10.addComponentOrReplace(transform198)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform199 = new Transform({
  position: new Vector3(7.287398338317871, 35.265159606933594, 24.86355209350586),
  rotation: new Quaternion(5.288966049247102e-15, -0.9238795042037964, 1.1013500511580787e-7, -0.3826834559440613),
  scale: new Vector3(2.4970932006835938, 2.497091293334961, 0.18657520413398743)
})
nftPictureFrame11.addComponentOrReplace(transform199)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform200 = new Transform({
  position: new Vector3(16.105772018432617, 35.265159606933594, 3.5741119384765625),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.497091293334961, 2.497091293334961, 0.18657515943050385)
})
nftPictureFrame12.addComponentOrReplace(transform200)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform201 = new Transform({
  position: new Vector3(24.924144744873047, 35.265159606933594, 7.226799964904785),
  rotation: new Quaternion(-4.392574798090399e-15, 0.3826834559440613, -4.5619412247788205e-8, -0.9238795042037964),
  scale: new Vector3(2.4970927238464355, 2.497091293334961, 0.18657511472702026)
})
nftPictureFrame13.addComponentOrReplace(transform201)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform202 = new Transform({
  position: new Vector3(28.57683753967285, 35.265159606933594, 16.04517364501953),
  rotation: new Quaternion(5.094380134889687e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(2.497093677520752, 2.497091293334961, 0.18657517433166504)
})
nftPictureFrame14.addComponentOrReplace(transform202)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform203 = new Transform({
  position: new Vector3(16.105772018432617, 35.265159606933594, 28.516239166259766),
  rotation: new Quaternion(7.20454122385807e-15, -1, 1.1920928244535389e-7, -2.2351741790771484e-8),
  scale: new Vector3(2.497091293334961, 2.497091293334961, 0.18657515943050385)
})
nftPictureFrame15.addComponentOrReplace(transform203)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform204 = new Transform({
  position: new Vector3(3.634706497192383, 35.265159606933594, 16.045177459716797),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.497093677520752, 2.497091293334961, 0.18657521903514862)
})
nftPictureFrame16.addComponentOrReplace(transform204)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform205 = new Transform({
  position: new Vector3(22.774433135986328, 12.765159606933594, 22.646713256835938),
  rotation: new Quaternion(-1.0208842573925826e-14, 0.9238795638084412, -1.1013501932666259e-7, -0.3826833963394165),
  scale: new Vector3(2.0575523376464844, 2.497091293334961, 0.15373405814170837)
})
nftPictureFrame17.addComponentOrReplace(transform205)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform206 = new Transform({
  position: new Vector3(9.437110900878906, 12.765159606933594, 9.443639755249023),
  rotation: new Quaternion(2.220446049250313e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(2.0575499534606934, 2.497091293334961, 0.15373393893241882)
})
nftPictureFrame18.addComponentOrReplace(transform206)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform207 = new Transform({
  position: new Vector3(9.437110900878906, 12.765159606933594, 22.64671516418457),
  rotation: new Quaternion(5.288966049247102e-15, -0.9238795042037964, 1.1013500511580787e-7, -0.3826834559440613),
  scale: new Vector3(2.0575504302978516, 2.497091293334961, 0.15373390913009644)
})
nftPictureFrame19.addComponentOrReplace(transform207)

const nftPictureFrame20 = new Entity('nftPictureFrame20')
engine.addEntity(nftPictureFrame20)
nftPictureFrame20.setParent(_scene)
const transform208 = new Transform({
  position: new Vector3(16.105772018432617, 12.765159606933594, 6.709192276000977),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8883590698242188, 2.497091293334961, 0.13967233896255493)
})
nftPictureFrame20.addComponentOrReplace(transform208)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform209 = new Transform({
  position: new Vector3(22.774433135986328, 12.765159606933594, 9.44363784790039),
  rotation: new Quaternion(-4.392574798090399e-15, 0.3826834559440613, -4.5619412247788205e-8, -0.9238795042037964),
  scale: new Vector3(2.0575499534606934, 2.497091293334961, 0.15373381972312927)
})
nftPictureFrame21.addComponentOrReplace(transform209)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform210 = new Transform({
  position: new Vector3(25.536685943603516, 12.765159606933594, 16.045175552368164),
  rotation: new Quaternion(5.094380134889687e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.8693556785583496, 2.497091293334961, 0.1410926878452301)
})
nftPictureFrame22.addComponentOrReplace(transform210)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform211 = new Transform({
  position: new Vector3(16.105772018432617, 12.765159606933594, 25.381160736083984),
  rotation: new Quaternion(7.20454122385807e-15, -1, 1.1920928244535389e-7, -2.2351741790771484e-8),
  scale: new Vector3(1.8883590698242188, 2.497091293334961, 0.13967233896255493)
})
nftPictureFrame23.addComponentOrReplace(transform211)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform212 = new Transform({
  position: new Vector3(6.674860000610352, 12.765159606933594, 16.045177459716797),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.8693556785583496, 2.497091293334961, 0.1410927176475525)
})
nftPictureFrame24.addComponentOrReplace(transform212)

const nftPictureFrame25 = new Entity('nftPictureFrame25')
engine.addEntity(nftPictureFrame25)
nftPictureFrame25.setParent(_scene)
const transform213 = new Transform({
  position: new Vector3(16.105772018432617, 7.265159606933594, 2.436408042907715),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.7508597373962402, 2.497091293334961, 0.20359593629837036)
})
nftPictureFrame25.addComponentOrReplace(transform213)

const nftPictureFrame26 = new Entity('nftPictureFrame26')
engine.addEntity(nftPictureFrame26)
nftPictureFrame26.setParent(_scene)
const transform214 = new Transform({
  position: new Vector3(6.391225814819336, 7.265159606933594, 6.422325134277344),
  rotation: new Quaternion(2.220446049250313e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(3.0810790061950684, 2.497091293334961, 0.23020896315574646)
})
nftPictureFrame26.addComponentOrReplace(transform214)

const nftPictureFrame27 = new Entity('nftPictureFrame27')
engine.addEntity(nftPictureFrame27)
nftPictureFrame27.setParent(_scene)
const transform215 = new Transform({
  position: new Vector3(25.820316314697266, 7.265159606933594, 6.4223222732543945),
  rotation: new Quaternion(-4.392574798090399e-15, 0.3826834559440613, -4.5619412247788205e-8, -0.9238795042037964),
  scale: new Vector3(3.0810770988464355, 2.497091293334961, 0.2302086353302002)
})
nftPictureFrame27.addComponentOrReplace(transform215)

const nftPictureFrame28 = new Entity('nftPictureFrame28')
engine.addEntity(nftPictureFrame28)
nftPictureFrame28.setParent(_scene)
const transform216 = new Transform({
  position: new Vector3(25.820316314697266, 7.265159606933594, 25.668025970458984),
  rotation: new Quaternion(-1.0208842573925826e-14, 0.9238795638084412, -1.1013501932666259e-7, -0.3826833963394165),
  scale: new Vector3(3.0810837745666504, 2.497091293334961, 0.23020923137664795)
})
nftPictureFrame28.addComponentOrReplace(transform216)

const nftPictureFrame29 = new Entity('nftPictureFrame29')
engine.addEntity(nftPictureFrame29)
nftPictureFrame29.setParent(_scene)
const transform217 = new Transform({
  position: new Vector3(16.105772018432617, 7.265159606933594, 29.65394401550293),
  rotation: new Quaternion(7.20454122385807e-15, -1, 1.1920928244535389e-7, -2.2351741790771484e-8),
  scale: new Vector3(2.7508597373962402, 2.497091293334961, 0.20359593629837036)
})
nftPictureFrame29.addComponentOrReplace(transform217)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform218 = new Transform({
  position: new Vector3(6.391225814819336, 7.265159606933594, 25.66802978515625),
  rotation: new Quaternion(5.288966049247102e-15, -0.9238795042037964, 1.1013500511580787e-7, -0.3826834559440613),
  scale: new Vector3(3.081078052520752, 2.497091293334961, 0.23020878434181213)
})
nftPictureFrame30.addComponentOrReplace(transform218)

const nftPictureFrame31 = new Entity('nftPictureFrame31')
engine.addEntity(nftPictureFrame31)
nftPictureFrame31.setParent(_scene)
const transform219 = new Transform({
  position: new Vector3(29.844219207763672, 7.265159606933594, 16.045175552368164),
  rotation: new Quaternion(5.094380134889687e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(2.7249019145965576, 2.497091293334961, 0.20553651452064514)
})
nftPictureFrame31.addComponentOrReplace(transform219)

const nftPictureFrame32 = new Entity('nftPictureFrame32')
engine.addEntity(nftPictureFrame32)
nftPictureFrame32.setParent(_scene)
const transform220 = new Transform({
  position: new Vector3(2.3673267364501953, 7.265159606933594, 16.045177459716797),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.7249019145965576, 2.497091293334961, 0.20553657412528992)
})
nftPictureFrame32.addComponentOrReplace(transform220)

const discMetal4 = new Entity('discMetal4')
engine.addEntity(discMetal4)
discMetal4.setParent(_scene)
discMetal4.addComponentOrReplace(gltfShape7)
const transform221 = new Transform({
  position: new Vector3(15.98307991027832, 17.518497467041016, 16.127826690673828),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.18749994039535522, 18436322, 0.17578120529651642)
})
discMetal4.addComponentOrReplace(transform221)

const discMetal5 = new Entity('discMetal5')
engine.addEntity(discMetal5)
discMetal5.setParent(_scene)
discMetal5.addComponentOrReplace(gltfShape7)
const transform222 = new Transform({
  position: new Vector3(15.98307991027832, 12.018497467041016, 16.092458724975586),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.18749994039535522, 18436322, 0.17578120529651642)
})
discMetal5.addComponentOrReplace(transform222)

const discMetal6 = new Entity('discMetal6')
engine.addEntity(discMetal6)
discMetal6.setParent(_scene)
discMetal6.addComponentOrReplace(gltfShape7)
const transform223 = new Transform({
  position: new Vector3(16.13207244873047, 6.518497467041016, 16.481428146362305),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.22257141768932343, 21884798, 0.20866072177886963)
})
discMetal6.addComponentOrReplace(transform223)

const ringWhiteLight = new Entity('ringWhiteLight')
engine.addEntity(ringWhiteLight)
ringWhiteLight.setParent(_scene)
const transform224 = new Transform({
  position: new Vector3(16.000001907348633, 42.2300910949707, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(10.629400253295898, 0.435609370470047, 10.629400253295898)
})
ringWhiteLight.addComponentOrReplace(transform224)
const gltfShape11 = new GLTFShape("0ce3c5ab4ebd2c3c6c33ec979ada6edb7f45313200399fbbe7778335d446b5b4/Ring_White_Light.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
ringWhiteLight.addComponentOrReplace(gltfShape11)

const ringWhiteLight2 = new Entity('ringWhiteLight2')
engine.addEntity(ringWhiteLight2)
ringWhiteLight2.setParent(_scene)
ringWhiteLight2.addComponentOrReplace(gltfShape11)
const transform225 = new Transform({
  position: new Vector3(16.000001907348633, 38.44716262817383, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(13.951086044311523, 0.9443962574005127, 13.951086044311523)
})
ringWhiteLight2.addComponentOrReplace(transform225)

const ringWhiteLight3 = new Entity('ringWhiteLight3')
engine.addEntity(ringWhiteLight3)
ringWhiteLight3.setParent(_scene)
ringWhiteLight3.addComponentOrReplace(gltfShape11)
const transform226 = new Transform({
  position: new Vector3(16.000001907348633, 33.93343734741211, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(11.597677230834961, 0.7850860953330994, 11.597677230834961)
})
ringWhiteLight3.addComponentOrReplace(transform226)

const ringWhiteLight4 = new Entity('ringWhiteLight4')
engine.addEntity(ringWhiteLight4)
ringWhiteLight4.setParent(_scene)
ringWhiteLight4.addComponentOrReplace(gltfShape11)
const transform227 = new Transform({
  position: new Vector3(16.000001907348633, 28.9480037689209, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.628026485443115, 0.4486736059188843, 6.628026485443115)
})
ringWhiteLight4.addComponentOrReplace(transform227)

const ringWhiteLight5 = new Entity('ringWhiteLight5')
engine.addEntity(ringWhiteLight5)
ringWhiteLight5.setParent(_scene)
ringWhiteLight5.addComponentOrReplace(gltfShape11)
const transform228 = new Transform({
  position: new Vector3(16.000001907348633, 25.1085262298584, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.69407320022583, 0.18237096071243286, 2.69407320022583)
})
ringWhiteLight5.addComponentOrReplace(transform228)

const ringWhiteLight6 = new Entity('ringWhiteLight6')
engine.addEntity(ringWhiteLight6)
ringWhiteLight6.setParent(_scene)
ringWhiteLight6.addComponentOrReplace(gltfShape11)
const transform229 = new Transform({
  position: new Vector3(16.000001907348633, 17.475717544555664, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.122979164123535, 0.45293936133384705, 6.122979164123535)
})
ringWhiteLight6.addComponentOrReplace(transform229)

const invisibleWall82 = new Entity('invisibleWall82')
engine.addEntity(invisibleWall82)
invisibleWall82.setParent(_scene)
const transform230 = new Transform({
  position: new Vector3(3.8890371322631836, 39.420379638671875, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(12.312742233276367, 0.01625014841556549, 0.6676474213600159)
})
invisibleWall82.addComponentOrReplace(transform230)

const invisibleWall94 = new Entity('invisibleWall94')
engine.addEntity(invisibleWall94)
invisibleWall94.setParent(_scene)
const transform231 = new Transform({
  position: new Vector3(28.17086410522461, 39.420379638671875, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(12.312742233276367, 0.01625014841556549, 0.6676474213600159)
})
invisibleWall94.addComponentOrReplace(transform231)

const invisibleWall95 = new Entity('invisibleWall95')
engine.addEntity(invisibleWall95)
invisibleWall95.setParent(_scene)
const transform232 = new Transform({
  position: new Vector3(16.02994728088379, 39.420379638671875, 3.8630409240722656),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(12.312755584716797, 0.01625015400350094, 0.6676476001739502)
})
invisibleWall95.addComponentOrReplace(transform232)

const invisibleWall96 = new Entity('invisibleWall96')
engine.addEntity(invisibleWall96)
invisibleWall96.setParent(_scene)
const transform233 = new Transform({
  position: new Vector3(16.029951095581055, 39.420379638671875, 28.14487075805664),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(12.312755584716797, 0.01625015400350094, 0.6676476001739502)
})
invisibleWall96.addComponentOrReplace(transform233)

const invisibleWall97 = new Entity('invisibleWall97')
engine.addEntity(invisibleWall97)
invisibleWall97.setParent(_scene)
const transform234 = new Transform({
  position: new Vector3(7.445024490356445, 39.420379638671875, 7.419034004211426),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(12.312760353088379, 0.016250163316726685, 0.667646586894989)
})
invisibleWall97.addComponentOrReplace(transform234)

const invisibleWall100 = new Entity('invisibleWall100')
engine.addEntity(invisibleWall100)
invisibleWall100.setParent(_scene)
const transform235 = new Transform({
  position: new Vector3(24.6148738861084, 39.420379638671875, 24.588878631591797),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(12.312760353088379, 0.016250163316726685, 0.667646586894989)
})
invisibleWall100.addComponentOrReplace(transform235)

const invisibleWall101 = new Entity('invisibleWall101')
engine.addEntity(invisibleWall101)
invisibleWall101.setParent(_scene)
const transform236 = new Transform({
  position: new Vector3(24.614871978759766, 39.420379638671875, 7.419033050537109),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(12.312742233276367, 0.01625014841556549, 0.6676474213600159)
})
invisibleWall101.addComponentOrReplace(transform236)

const invisibleWall102 = new Entity('invisibleWall102')
engine.addEntity(invisibleWall102)
invisibleWall102.setParent(_scene)
const transform237 = new Transform({
  position: new Vector3(7.445029258728027, 39.420379638671875, 24.588878631591797),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(12.312742233276367, 0.01625014841556549, 0.6676474213600159)
})
invisibleWall102.addComponentOrReplace(transform237)

const invisibleWall103 = new Entity('invisibleWall103')
engine.addEntity(invisibleWall103)
invisibleWall103.setParent(_scene)
const transform238 = new Transform({
  position: new Vector3(24.211185455322266, 34.920379638671875, 24.18518829345703),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(11.733789443969727, 0.015486042015254498, 0.6362521052360535)
})
invisibleWall103.addComponentOrReplace(transform238)

const invisibleWall104 = new Entity('invisibleWall104')
engine.addEntity(invisibleWall104)
invisibleWall104.setParent(_scene)
const transform239 = new Transform({
  position: new Vector3(24.211181640625, 34.920379638671875, 7.822722434997559),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(11.733757972717285, 0.015486017800867558, 0.6362525224685669)
})
invisibleWall104.addComponentOrReplace(transform239)

const invisibleWall105 = new Entity('invisibleWall105')
engine.addEntity(invisibleWall105)
invisibleWall105.setParent(_scene)
const transform240 = new Transform({
  position: new Vector3(16.029951095581055, 34.920379638671875, 27.57396697998047),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(11.73378849029541, 0.015486020594835281, 0.6362527012825012)
})
invisibleWall105.addComponentOrReplace(transform240)

const invisibleWall106 = new Entity('invisibleWall106')
engine.addEntity(invisibleWall106)
invisibleWall106.setParent(_scene)
const transform241 = new Transform({
  position: new Vector3(27.599960327148438, 34.920379638671875, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(11.733757972717285, 0.015486015938222408, 0.6362525224685669)
})
invisibleWall106.addComponentOrReplace(transform241)

const invisibleWall107 = new Entity('invisibleWall107')
engine.addEntity(invisibleWall107)
invisibleWall107.setParent(_scene)
const transform242 = new Transform({
  position: new Vector3(7.848719596862793, 34.920379638671875, 24.18518829345703),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(11.733757972717285, 0.015486017800867558, 0.6362525224685669)
})
invisibleWall107.addComponentOrReplace(transform242)

const invisibleWall108 = new Entity('invisibleWall108')
engine.addEntity(invisibleWall108)
invisibleWall108.setParent(_scene)
const transform243 = new Transform({
  position: new Vector3(4.4599409103393555, 34.920379638671875, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(11.733757972717285, 0.015486015938222408, 0.6362525224685669)
})
invisibleWall108.addComponentOrReplace(transform243)

const invisibleWall109 = new Entity('invisibleWall109')
engine.addEntity(invisibleWall109)
invisibleWall109.setParent(_scene)
const transform244 = new Transform({
  position: new Vector3(7.8487138748168945, 34.920379638671875, 7.822724342346191),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(11.733789443969727, 0.015486042015254498, 0.6362521052360535)
})
invisibleWall109.addComponentOrReplace(transform244)

const invisibleWall110 = new Entity('invisibleWall110')
engine.addEntity(invisibleWall110)
invisibleWall110.setParent(_scene)
const transform245 = new Transform({
  position: new Vector3(16.02994728088379, 34.920379638671875, 4.4339447021484375),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(11.73378849029541, 0.015486020594835281, 0.6362527012825012)
})
invisibleWall110.addComponentOrReplace(transform245)

const invisibleWall111 = new Entity('invisibleWall111')
engine.addEntity(invisibleWall111)
invisibleWall111.setParent(_scene)
const transform246 = new Transform({
  position: new Vector3(22.67690658569336, 12.874065399169922, 22.650911331176758),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(9.53329849243164, 0.012581868097186089, 0.5169323086738586)
})
invisibleWall111.addComponentOrReplace(transform246)

const invisibleWall112 = new Entity('invisibleWall112')
engine.addEntity(invisibleWall112)
invisibleWall112.setParent(_scene)
const transform247 = new Transform({
  position: new Vector3(22.676904678344727, 12.874065399169922, 9.357000350952148),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(9.53325080871582, 0.01258182991296053, 0.5169321298599243)
})
invisibleWall112.addComponentOrReplace(transform247)

const invisibleWall113 = new Entity('invisibleWall113')
engine.addEntity(invisibleWall113)
invisibleWall113.setParent(_scene)
const transform248 = new Transform({
  position: new Vector3(16.029951095581055, 12.874065399169922, 25.404170989990234),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(9.533299446105957, 0.012581830844283104, 0.5169322490692139)
})
invisibleWall113.addComponentOrReplace(transform248)

const invisibleWall114 = new Entity('invisibleWall114')
engine.addEntity(invisibleWall114)
invisibleWall114.setParent(_scene)
const transform249 = new Transform({
  position: new Vector3(25.430164337158203, 12.874065399169922, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(9.533252716064453, 0.012581827118992805, 0.5169321298599243)
})
invisibleWall114.addComponentOrReplace(transform249)

const invisibleWall115 = new Entity('invisibleWall115')
engine.addEntity(invisibleWall115)
invisibleWall115.setParent(_scene)
const transform250 = new Transform({
  position: new Vector3(9.382996559143066, 12.874065399169922, 22.650911331176758),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(9.53325080871582, 0.01258182991296053, 0.5169321298599243)
})
invisibleWall115.addComponentOrReplace(transform250)

const invisibleWall116 = new Entity('invisibleWall116')
engine.addEntity(invisibleWall116)
invisibleWall116.setParent(_scene)
const transform251 = new Transform({
  position: new Vector3(6.62973690032959, 12.874065399169922, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(9.533252716064453, 0.012581827118992805, 0.5169321298599243)
})
invisibleWall116.addComponentOrReplace(transform251)

const invisibleWall117 = new Entity('invisibleWall117')
engine.addEntity(invisibleWall117)
invisibleWall117.setParent(_scene)
const transform252 = new Transform({
  position: new Vector3(9.382991790771484, 12.874065399169922, 9.357002258300781),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(9.53329849243164, 0.012581868097186089, 0.5169323086738586)
})
invisibleWall117.addComponentOrReplace(transform252)

const invisibleWall118 = new Entity('invisibleWall118')
engine.addEntity(invisibleWall118)
invisibleWall118.setParent(_scene)
const transform253 = new Transform({
  position: new Vector3(16.02994728088379, 12.874065399169922, 6.603740692138672),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(9.533299446105957, 0.012581830844283104, 0.5169322490692139)
})
invisibleWall118.addComponentOrReplace(transform253)

const invisibleWall119 = new Entity('invisibleWall119')
engine.addEntity(invisibleWall119)
invisibleWall119.setParent(_scene)
const transform254 = new Transform({
  position: new Vector3(25.128158569335938, 6.837318420410156, 25.10216522216797),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(13.048996925354004, 0.017221812158823013, 0.7075664401054382)
})
invisibleWall119.addComponentOrReplace(transform254)

const invisibleWall120 = new Entity('invisibleWall120')
engine.addEntity(invisibleWall120)
invisibleWall120.setParent(_scene)
const transform255 = new Transform({
  position: new Vector3(25.128158569335938, 6.837318420410156, 6.905747413635254),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(13.048906326293945, 0.017221741378307343, 0.707565426826477)
})
invisibleWall120.addComponentOrReplace(transform255)

const invisibleWall121 = new Entity('invisibleWall121')
engine.addEntity(invisibleWall121)
invisibleWall121.setParent(_scene)
const transform256 = new Transform({
  position: new Vector3(16.029951095581055, 6.837318420410156, 28.870765686035156),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(13.048999786376953, 0.017221735790371895, 0.7075656056404114)
})
invisibleWall121.addComponentOrReplace(transform256)

const invisibleWall122 = new Entity('invisibleWall122')
engine.addEntity(invisibleWall122)
invisibleWall122.setParent(_scene)
const transform257 = new Transform({
  position: new Vector3(28.896759033203125, 6.837318420410156, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(13.048909187316895, 0.017221730202436447, 0.707565426826477)
})
invisibleWall122.addComponentOrReplace(transform257)

const invisibleWall123 = new Entity('invisibleWall123')
engine.addEntity(invisibleWall123)
invisibleWall123.setParent(_scene)
const transform258 = new Transform({
  position: new Vector3(6.931745529174805, 6.837318420410156, 25.10216522216797),
  rotation: new Quaternion(-0.27059799432754517, -0.6532814502716064, 0.653281569480896, -0.27059805393218994),
  scale: new Vector3(13.048906326293945, 0.017221741378307343, 0.707565426826477)
})
invisibleWall123.addComponentOrReplace(transform258)

const invisibleWall124 = new Entity('invisibleWall124')
engine.addEntity(invisibleWall124)
invisibleWall124.setParent(_scene)
const transform259 = new Transform({
  position: new Vector3(3.1631431579589844, 6.837318420410156, 16.003957748413086),
  rotation: new Quaternion(-0.4999999403953552, -0.4999999403953552, 0.5000001192092896, -0.5),
  scale: new Vector3(13.048909187316895, 0.017221730202436447, 0.707565426826477)
})
invisibleWall124.addComponentOrReplace(transform259)

const invisibleWall125 = new Entity('invisibleWall125')
engine.addEntity(invisibleWall125)
invisibleWall125.setParent(_scene)
const transform260 = new Transform({
  position: new Vector3(6.93173885345459, 6.837318420410156, 6.905750274658203),
  rotation: new Quaternion(0.2705981731414795, -0.6532814502716064, 0.653281569480896, 0.27059808373451233),
  scale: new Vector3(13.048996925354004, 0.017221812158823013, 0.7075664401054382)
})
invisibleWall125.addComponentOrReplace(transform260)

const invisibleWall126 = new Entity('invisibleWall126')
engine.addEntity(invisibleWall126)
invisibleWall126.setParent(_scene)
const transform261 = new Transform({
  position: new Vector3(16.02994728088379, 6.837318420410156, 3.13714599609375),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(13.048999786376953, 0.017221735790371895, 0.7075656056404114)
})
invisibleWall126.addComponentOrReplace(transform261)

const invisibleWall127 = new Entity('invisibleWall127')
engine.addEntity(invisibleWall127)
invisibleWall127.setParent(_scene)
const transform262 = new Transform({
  position: new Vector3(15.844953536987305, 23.920379638671875, 30.390274047851562),
  rotation: new Quaternion(8.940696005765858e-8, -0.7071067094802856, 0.70710688829422, 0),
  scale: new Vector3(29.426803588867188, 0.13000033795833588, 0.6676453948020935)
})
invisibleWall127.addComponentOrReplace(transform262)

const invisibleWall128 = new Entity('invisibleWall128')
engine.addEntity(invisibleWall128)
invisibleWall128.setParent(_scene)
const transform263 = new Transform({
  position: new Vector3(15.92219352722168, 23.920379638671875, 1.6145305633544922),
  rotation: new Quaternion(-0.7071068286895752, 0, 7.194917372999043e-8, -0.7071068286895752),
  scale: new Vector3(29.283222198486328, 0.13000085949897766, 0.6676465272903442)
})
invisibleWall128.addComponentOrReplace(transform263)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform264 = new Transform({
  position: new Vector3(16.194868087768555, 39.129032135009766, 14.682097434997559),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.579780340194702, 0.8929768800735474, 0.1625930517911911)
})
radio.addComponentOrReplace(transform264)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script1.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script1.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script1.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script1.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script1.spawn(invisibleWall9, {"enabled":true}, createChannel(channelId, invisibleWall9, channelBus))
script1.spawn(invisibleWall10, {"enabled":true}, createChannel(channelId, invisibleWall10, channelBus))
script1.spawn(invisibleWall11, {"enabled":true}, createChannel(channelId, invisibleWall11, channelBus))
script1.spawn(invisibleWall5, {"enabled":true}, createChannel(channelId, invisibleWall5, channelBus))
script1.spawn(invisibleWall12, {"enabled":true}, createChannel(channelId, invisibleWall12, channelBus))
script1.spawn(invisibleWall13, {"enabled":true}, createChannel(channelId, invisibleWall13, channelBus))
script1.spawn(invisibleWall14, {"enabled":true}, createChannel(channelId, invisibleWall14, channelBus))
script1.spawn(invisibleWall15, {"enabled":true}, createChannel(channelId, invisibleWall15, channelBus))
script1.spawn(invisibleWall16, {"enabled":true}, createChannel(channelId, invisibleWall16, channelBus))
script1.spawn(invisibleWall17, {"enabled":true}, createChannel(channelId, invisibleWall17, channelBus))
script1.spawn(invisibleWall18, {"enabled":true}, createChannel(channelId, invisibleWall18, channelBus))
script1.spawn(invisibleWall19, {"enabled":true}, createChannel(channelId, invisibleWall19, channelBus))
script1.spawn(invisibleWall20, {"enabled":true}, createChannel(channelId, invisibleWall20, channelBus))
script1.spawn(invisibleWall21, {"enabled":true}, createChannel(channelId, invisibleWall21, channelBus))
script2.spawn(verticalBlackPad, {"distance":42,"speed":5,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad, channelBus))
script3.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script1.spawn(invisibleWall6, {"enabled":true}, createChannel(channelId, invisibleWall6, channelBus))
script1.spawn(invisibleWall22, {"enabled":true}, createChannel(channelId, invisibleWall22, channelBus))
script1.spawn(invisibleWall23, {"enabled":true}, createChannel(channelId, invisibleWall23, channelBus))
script1.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script1.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script1.spawn(invisibleWall24, {"enabled":true}, createChannel(channelId, invisibleWall24, channelBus))
script1.spawn(invisibleWall25, {"enabled":true}, createChannel(channelId, invisibleWall25, channelBus))
script1.spawn(invisibleWall26, {"enabled":true}, createChannel(channelId, invisibleWall26, channelBus))
script1.spawn(invisibleWall27, {"enabled":true}, createChannel(channelId, invisibleWall27, channelBus))
script1.spawn(invisibleWall28, {"enabled":true}, createChannel(channelId, invisibleWall28, channelBus))
script1.spawn(invisibleWall29, {"enabled":true}, createChannel(channelId, invisibleWall29, channelBus))
script1.spawn(invisibleWall30, {"enabled":true}, createChannel(channelId, invisibleWall30, channelBus))
script1.spawn(invisibleWall31, {"enabled":true}, createChannel(channelId, invisibleWall31, channelBus))
script1.spawn(invisibleWall32, {"enabled":true}, createChannel(channelId, invisibleWall32, channelBus))
script1.spawn(invisibleWall33, {"enabled":true}, createChannel(channelId, invisibleWall33, channelBus))
script1.spawn(invisibleWall34, {"enabled":true}, createChannel(channelId, invisibleWall34, channelBus))
script1.spawn(invisibleWall35, {"enabled":true}, createChannel(channelId, invisibleWall35, channelBus))
script1.spawn(invisibleWall36, {"enabled":true}, createChannel(channelId, invisibleWall36, channelBus))
script1.spawn(invisibleWall37, {"enabled":true}, createChannel(channelId, invisibleWall37, channelBus))
script1.spawn(invisibleWall38, {"enabled":true}, createChannel(channelId, invisibleWall38, channelBus))
script1.spawn(invisibleWall39, {"enabled":true}, createChannel(channelId, invisibleWall39, channelBus))
script1.spawn(invisibleWall41, {"enabled":true}, createChannel(channelId, invisibleWall41, channelBus))
script1.spawn(invisibleWall40, {"enabled":true}, createChannel(channelId, invisibleWall40, channelBus))
script1.spawn(invisibleWall42, {"enabled":true}, createChannel(channelId, invisibleWall42, channelBus))
script1.spawn(invisibleWall43, {"enabled":true}, createChannel(channelId, invisibleWall43, channelBus))
script1.spawn(invisibleWall44, {"enabled":true}, createChannel(channelId, invisibleWall44, channelBus))
script1.spawn(invisibleWall45, {"enabled":true}, createChannel(channelId, invisibleWall45, channelBus))
script1.spawn(invisibleWall46, {"enabled":true}, createChannel(channelId, invisibleWall46, channelBus))
script1.spawn(invisibleWall47, {"enabled":true}, createChannel(channelId, invisibleWall47, channelBus))
script1.spawn(invisibleWall48, {"enabled":true}, createChannel(channelId, invisibleWall48, channelBus))
script1.spawn(invisibleWall49, {"enabled":true}, createChannel(channelId, invisibleWall49, channelBus))
script1.spawn(invisibleWall50, {"enabled":true}, createChannel(channelId, invisibleWall50, channelBus))
script1.spawn(invisibleWall51, {"enabled":true}, createChannel(channelId, invisibleWall51, channelBus))
script1.spawn(invisibleWall52, {"enabled":true}, createChannel(channelId, invisibleWall52, channelBus))
script1.spawn(invisibleWall53, {"enabled":true}, createChannel(channelId, invisibleWall53, channelBus))
script1.spawn(invisibleWall55, {"enabled":true}, createChannel(channelId, invisibleWall55, channelBus))
script1.spawn(invisibleWall57, {"enabled":true}, createChannel(channelId, invisibleWall57, channelBus))
script1.spawn(invisibleWall58, {"enabled":true}, createChannel(channelId, invisibleWall58, channelBus))
script1.spawn(invisibleWall59, {"enabled":true}, createChannel(channelId, invisibleWall59, channelBus))
script1.spawn(invisibleWall60, {"enabled":true}, createChannel(channelId, invisibleWall60, channelBus))
script1.spawn(invisibleWall61, {"enabled":true}, createChannel(channelId, invisibleWall61, channelBus))
script1.spawn(invisibleWall62, {"enabled":true}, createChannel(channelId, invisibleWall62, channelBus))
script1.spawn(invisibleWall63, {"enabled":true}, createChannel(channelId, invisibleWall63, channelBus))
script1.spawn(invisibleWall64, {"enabled":true}, createChannel(channelId, invisibleWall64, channelBus))
script1.spawn(invisibleWall65, {"enabled":true}, createChannel(channelId, invisibleWall65, channelBus))
script1.spawn(invisibleWall66, {"enabled":true}, createChannel(channelId, invisibleWall66, channelBus))
script1.spawn(invisibleWall67, {"enabled":true}, createChannel(channelId, invisibleWall67, channelBus))
script1.spawn(invisibleWall68, {"enabled":true}, createChannel(channelId, invisibleWall68, channelBus))
script1.spawn(invisibleWall69, {"enabled":true}, createChannel(channelId, invisibleWall69, channelBus))
script1.spawn(invisibleWall70, {"enabled":true}, createChannel(channelId, invisibleWall70, channelBus))
script1.spawn(invisibleWall71, {"enabled":true}, createChannel(channelId, invisibleWall71, channelBus))
script1.spawn(invisibleWall72, {"enabled":true}, createChannel(channelId, invisibleWall72, channelBus))
script1.spawn(invisibleWall81, {"enabled":true}, createChannel(channelId, invisibleWall81, channelBus))
script3.spawn(triggerArea3, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad2","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad2","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea3, channelBus))
script2.spawn(verticalBlackPad2, {"distance":42,"speed":5,"autoStart":false,"onReachEnd":[],"onReachStart":[]}, createChannel(channelId, verticalBlackPad2, channelBus))
script4.spawn(ropeLight, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight, channelBus))
script4.spawn(ropeLight2, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight2, channelBus))
script4.spawn(ropeLight3, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight3, channelBus))
script4.spawn(ropeLight4, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight4, channelBus))
script4.spawn(ropeLight5, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight5, channelBus))
script4.spawn(ropeLight6, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight6, channelBus))
script4.spawn(ropeLight7, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight7, channelBus))
script4.spawn(ropeLight8, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight8, channelBus))
script4.spawn(ropeLight9, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight9, channelBus))
script4.spawn(ropeLight10, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight10, channelBus))
script4.spawn(ropeLight11, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight11, channelBus))
script4.spawn(ropeLight12, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight12, channelBus))
script4.spawn(ropeLight13, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight13, channelBus))
script4.spawn(ropeLight14, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight14, channelBus))
script4.spawn(ropeLight15, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight15, channelBus))
script4.spawn(ropeLight16, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight16, channelBus))
script4.spawn(ropeLight17, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight17, channelBus))
script4.spawn(ropeLight18, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight18, channelBus))
script4.spawn(ropeLight19, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight19, channelBus))
script4.spawn(ropeLight20, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight20, channelBus))
script4.spawn(ropeLight22, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight22, channelBus))
script4.spawn(ropeLight23, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight23, channelBus))
script4.spawn(ropeLight24, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight24, channelBus))
script4.spawn(ropeLight25, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight25, channelBus))
script4.spawn(ropeLight26, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight26, channelBus))
script4.spawn(ropeLight27, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight27, channelBus))
script4.spawn(ropeLight28, {"startOn":true,"clickable":false}, createChannel(channelId, ropeLight28, channelBus))
script1.spawn(invisibleWall85, {"enabled":true}, createChannel(channelId, invisibleWall85, channelBus))
script1.spawn(invisibleWall86, {"enabled":true}, createChannel(channelId, invisibleWall86, channelBus))
script1.spawn(invisibleWall87, {"enabled":true}, createChannel(channelId, invisibleWall87, channelBus))
script1.spawn(invisibleWall88, {"enabled":true}, createChannel(channelId, invisibleWall88, channelBus))
script1.spawn(invisibleWall84, {"enabled":true}, createChannel(channelId, invisibleWall84, channelBus))
script1.spawn(invisibleWall98, {"enabled":true}, createChannel(channelId, invisibleWall98, channelBus))
script1.spawn(invisibleWall99, {"enabled":true}, createChannel(channelId, invisibleWall99, channelBus))
script1.spawn(invisibleWall54, {"enabled":true}, createChannel(channelId, invisibleWall54, channelBus))
script1.spawn(invisibleWall56, {"enabled":true}, createChannel(channelId, invisibleWall56, channelBus))
script1.spawn(invisibleWall73, {"enabled":true}, createChannel(channelId, invisibleWall73, channelBus))
script1.spawn(invisibleWall74, {"enabled":true}, createChannel(channelId, invisibleWall74, channelBus))
script1.spawn(invisibleWall75, {"enabled":true}, createChannel(channelId, invisibleWall75, channelBus))
script1.spawn(invisibleWall76, {"enabled":true}, createChannel(channelId, invisibleWall76, channelBus))
script1.spawn(invisibleWall77, {"enabled":true}, createChannel(channelId, invisibleWall77, channelBus))
script1.spawn(invisibleWall78, {"enabled":true}, createChannel(channelId, invisibleWall78, channelBus))
script1.spawn(invisibleWall79, {"enabled":true}, createChannel(channelId, invisibleWall79, channelBus))
script1.spawn(invisibleWall80, {"enabled":true}, createChannel(channelId, invisibleWall80, channelBus))
script1.spawn(invisibleWall83, {"enabled":true}, createChannel(channelId, invisibleWall83, channelBus))
script1.spawn(invisibleWall89, {"enabled":true}, createChannel(channelId, invisibleWall89, channelBus))
script1.spawn(invisibleWall90, {"enabled":true}, createChannel(channelId, invisibleWall90, channelBus))
script1.spawn(invisibleWall91, {"enabled":true}, createChannel(channelId, invisibleWall91, channelBus))
script1.spawn(invisibleWall92, {"enabled":true}, createChannel(channelId, invisibleWall92, channelBus))
script1.spawn(invisibleWall93, {"enabled":true}, createChannel(channelId, invisibleWall93, channelBus))
script5.spawn(nftPictureFrame, {"id":"72405646120007613708465591283795435405784754144165659770746301231704374771713","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script5.spawn(nftPictureFrame2, {"id":"72405646120007613708465591283795435405784754144165659770746301241599979421697","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script5.spawn(nftPictureFrame3, {"id":"72405646120007613708465591283795435405784754144165659770746301207515118960641","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script5.spawn(nftPictureFrame4, {"id":"72405646120007613708465591283795435405784754144165659770746301236102421282817","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script5.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301237201932910593","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script5.spawn(nftPictureFrame6, {"id":"72405646120007613708465591283795435405784754144165659770746301233903398027265","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script5.spawn(nftPictureFrame7, {"id":"72405646120007613708465591283795435405784754144165659770746301214112188727297","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script5.spawn(nftPictureFrame8, {"id":"72405646120007613708465591283795435405784754144165659770746301205316095705089","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script5.spawn(nftPictureFrame9, {"id":"72405646120007613708465591283795435405784754144165659770746301188823421288449","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .24 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script5.spawn(nftPictureFrame10, {"id":"72405646120007613708465591283795435405784754144165659770746301166833188732929","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script5.spawn(nftPictureFrame11, {"id":"72405646120007613708465591283795435405784754144165659770746301209714142216193","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script5.spawn(nftPictureFrame12, {"id":"72405646120007613708465591283795435405784754144165659770746301139345398038529","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script5.spawn(nftPictureFrame13, {"id":"72405646120007613708465591283795435405784754144165659770746301145942467805185","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame13, channelBus))
script5.spawn(nftPictureFrame14, {"id":"72405646120007613708465591283795435405784754144165659770746301187723909660673","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script5.spawn(nftPictureFrame15, {"id":"72405646120007613708465591283795435405784754144165659770746301200918049193985","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 4\nPrice: .16 ETH"}, createChannel(channelId, nftPictureFrame15, channelBus))
script5.spawn(nftPictureFrame16, {"id":"72405646120007613708465591283795435405784754144165659770746301210813653843969","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame16, channelBus))
script5.spawn(nftPictureFrame17, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script5.spawn(nftPictureFrame18, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script5.spawn(nftPictureFrame19, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame19, channelBus))
script5.spawn(nftPictureFrame20, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame20, channelBus))
script5.spawn(nftPictureFrame21, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame21, channelBus))
script5.spawn(nftPictureFrame22, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script5.spawn(nftPictureFrame23, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame23, channelBus))
script5.spawn(nftPictureFrame24, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame24, channelBus))
script5.spawn(nftPictureFrame25, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame25, channelBus))
script5.spawn(nftPictureFrame26, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame26, channelBus))
script5.spawn(nftPictureFrame27, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame27, channelBus))
script5.spawn(nftPictureFrame28, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame28, channelBus))
script5.spawn(nftPictureFrame29, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame29, channelBus))
script5.spawn(nftPictureFrame30, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script5.spawn(nftPictureFrame31, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame31, channelBus))
script5.spawn(nftPictureFrame32, {"id":"","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: \nPrice: . ETH"}, createChannel(channelId, nftPictureFrame32, channelBus))
script1.spawn(invisibleWall82, {"enabled":true}, createChannel(channelId, invisibleWall82, channelBus))
script1.spawn(invisibleWall94, {"enabled":true}, createChannel(channelId, invisibleWall94, channelBus))
script1.spawn(invisibleWall95, {"enabled":true}, createChannel(channelId, invisibleWall95, channelBus))
script1.spawn(invisibleWall96, {"enabled":true}, createChannel(channelId, invisibleWall96, channelBus))
script1.spawn(invisibleWall97, {"enabled":true}, createChannel(channelId, invisibleWall97, channelBus))
script1.spawn(invisibleWall100, {"enabled":true}, createChannel(channelId, invisibleWall100, channelBus))
script1.spawn(invisibleWall101, {"enabled":true}, createChannel(channelId, invisibleWall101, channelBus))
script1.spawn(invisibleWall102, {"enabled":true}, createChannel(channelId, invisibleWall102, channelBus))
script1.spawn(invisibleWall103, {"enabled":true}, createChannel(channelId, invisibleWall103, channelBus))
script1.spawn(invisibleWall104, {"enabled":true}, createChannel(channelId, invisibleWall104, channelBus))
script1.spawn(invisibleWall105, {"enabled":true}, createChannel(channelId, invisibleWall105, channelBus))
script1.spawn(invisibleWall106, {"enabled":true}, createChannel(channelId, invisibleWall106, channelBus))
script1.spawn(invisibleWall107, {"enabled":true}, createChannel(channelId, invisibleWall107, channelBus))
script1.spawn(invisibleWall108, {"enabled":true}, createChannel(channelId, invisibleWall108, channelBus))
script1.spawn(invisibleWall109, {"enabled":true}, createChannel(channelId, invisibleWall109, channelBus))
script1.spawn(invisibleWall110, {"enabled":true}, createChannel(channelId, invisibleWall110, channelBus))
script1.spawn(invisibleWall111, {"enabled":true}, createChannel(channelId, invisibleWall111, channelBus))
script1.spawn(invisibleWall112, {"enabled":true}, createChannel(channelId, invisibleWall112, channelBus))
script1.spawn(invisibleWall113, {"enabled":true}, createChannel(channelId, invisibleWall113, channelBus))
script1.spawn(invisibleWall114, {"enabled":true}, createChannel(channelId, invisibleWall114, channelBus))
script1.spawn(invisibleWall115, {"enabled":true}, createChannel(channelId, invisibleWall115, channelBus))
script1.spawn(invisibleWall116, {"enabled":true}, createChannel(channelId, invisibleWall116, channelBus))
script1.spawn(invisibleWall117, {"enabled":true}, createChannel(channelId, invisibleWall117, channelBus))
script1.spawn(invisibleWall118, {"enabled":true}, createChannel(channelId, invisibleWall118, channelBus))
script1.spawn(invisibleWall119, {"enabled":true}, createChannel(channelId, invisibleWall119, channelBus))
script1.spawn(invisibleWall120, {"enabled":true}, createChannel(channelId, invisibleWall120, channelBus))
script1.spawn(invisibleWall121, {"enabled":true}, createChannel(channelId, invisibleWall121, channelBus))
script1.spawn(invisibleWall122, {"enabled":true}, createChannel(channelId, invisibleWall122, channelBus))
script1.spawn(invisibleWall123, {"enabled":true}, createChannel(channelId, invisibleWall123, channelBus))
script1.spawn(invisibleWall124, {"enabled":true}, createChannel(channelId, invisibleWall124, channelBus))
script1.spawn(invisibleWall125, {"enabled":true}, createChannel(channelId, invisibleWall125, channelBus))
script1.spawn(invisibleWall126, {"enabled":true}, createChannel(channelId, invisibleWall126, channelBus))
script1.spawn(invisibleWall127, {"enabled":true}, createChannel(channelId, invisibleWall127, channelBus))
script1.spawn(invisibleWall128, {"enabled":true}, createChannel(channelId, invisibleWall128, channelBus))
script6.spawn(radio, {"startOn":true,"volume":0.39,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/QmS7rEUHBoTKB2GuCYhBhPc9utv6uZaNjBB4ptouYvuLiW"}, createChannel(channelId, radio, channelBus))