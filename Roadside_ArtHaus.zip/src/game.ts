import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script2 from "../7e78cd70-5414-4ec4-be5f-198ec9879a5e/src/item"
import Script3 from "../7abe1ec8-bd5c-4ffe-b318-f17a330296bf/src/item"
import Script4 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script5 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script6 from "../901e4555-8743-49bb-854c-c8b354a3e3e1/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(9.89513874053955, 14.104194641113281, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.279308319091797, 5.659231662750244, 0.5635298490524292)
})
nftPictureFrame8.addComponentOrReplace(transform2)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(14.351798057556152, 14.246642112731934, 3),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.6413965225219727, 4.815613746643066, 0.47952523827552795)
})
nftPictureFrame9.addComponentOrReplace(transform3)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(12.96322250366211, 14.282755851745605, 1.4503812789916992),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.815153121948242, 4.866322040557861, 0.5024067163467407)
})
nftPictureFrame16.addComponentOrReplace(transform4)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(8.145710945129395, 14.101085662841797, 6.224764823913574),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(4.650711536407471, 5.640412330627441, 0.6124390959739685)
})
nftPictureFrame17.addComponentOrReplace(transform5)

const signpostTree = new Entity('signpostTree')
engine.addEntity(signpostTree)
signpostTree.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(7.965038299560547, 7.293859481811523, 0.01829027757048607),
  rotation: new Quaternion(6.635589193187356e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(2.5668981075286865, 4.721567630767822, 1)
})
signpostTree.addComponentOrReplace(transform6)

const signpostTree3 = new Entity('signpostTree3')
engine.addEntity(signpostTree3)
signpostTree3.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(0.01338958740234375, 7.3901214599609375, 8.091915130615234),
  rotation: new Quaternion(-4.127578846475997e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.7857511043548584, 4.490051746368408, 1.0000090599060059)
})
signpostTree3.addComponentOrReplace(transform7)

const wallPlainBlack3 = new Entity('wallPlainBlack3')
engine.addEntity(wallPlainBlack3)
wallPlainBlack3.setParent(_scene)
const gltfShape = new GLTFShape("models/PlainBlackWall.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
wallPlainBlack3.addComponentOrReplace(gltfShape)
const transform8 = new Transform({
  position: new Vector3(5.628243923187256, 7.463967800140381, 0.01258540153503418),
  rotation: new Quaternion(-2.177062080483132e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(2.341846466064453, 1.1763044595718384, 0.3330826163291931)
})
wallPlainBlack3.addComponentOrReplace(transform8)

const wallPlainBlack4 = new Entity('wallPlainBlack4')
engine.addEntity(wallPlainBlack4)
wallPlainBlack4.setParent(_scene)
wallPlainBlack4.addComponentOrReplace(gltfShape)
const transform9 = new Transform({
  position: new Vector3(0.0057811737060546875, 7.529757976531982, 9.739882469177246),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.6606149673461914, 1.1292099952697754, 0.3330824077129364)
})
wallPlainBlack4.addComponentOrReplace(transform9)

const nftPictureFrame31 = new Entity('nftPictureFrame31')
engine.addEntity(nftPictureFrame31)
nftPictureFrame31.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(0.11842221021652222, 14.351461410522461, 8.042287826538086),
  rotation: new Quaternion(-1.9739713200605732e-15, 0.7071068286895752, -8.429368136830817e-8, 0.7071067690849304),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame31.addComponentOrReplace(transform10)

const nftPictureFrame34 = new Entity('nftPictureFrame34')
engine.addEntity(nftPictureFrame34)
nftPictureFrame34.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(0.12919005751609802, 14.339768409729004, 10.355381965637207),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.796921491622925, 5.128884315490723, 0.5000056624412537)
})
nftPictureFrame34.addComponentOrReplace(transform11)

const wallPlainGlass4 = new Entity('wallPlainGlass4')
engine.addEntity(wallPlainGlass4)
wallPlainGlass4.setParent(_scene)
const gltfShape2 = new GLTFShape("models/PlainGlassWall.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
wallPlainGlass4.addComponentOrReplace(gltfShape2)
const transform12 = new Transform({
  position: new Vector3(16, 6.487863540649414, 0),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(7.898340702056885, 3.918762445449829, 0.1881696730852127)
})
wallPlainGlass4.addComponentOrReplace(transform12)

const nftPictureFrame35 = new Entity('nftPictureFrame35')
engine.addEntity(nftPictureFrame35)
nftPictureFrame35.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(8.096426963806152, 14.079950332641602, 9.674392700195312),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.456194877624512, 5.55093240737915, 0.6876867413520813)
})
nftPictureFrame35.addComponentOrReplace(transform13)

const nftPictureFrame37 = new Entity('nftPictureFrame37')
engine.addEntity(nftPictureFrame37)
nftPictureFrame37.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(12.902239799499512, 14.257355690002441, 1.5118815898895264),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.68395471572876, 4.743313312530518, 0.6626132130622864)
})
nftPictureFrame37.addComponentOrReplace(transform14)

const nftPictureFrame38 = new Entity('nftPictureFrame38')
engine.addEntity(nftPictureFrame38)
nftPictureFrame38.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(6.286441802978516, 14.099328994750977, 7.9477763175964355),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.686256408691406, 5.7428388595581055, 0.6629368662834167)
})
nftPictureFrame38.addComponentOrReplace(transform15)

const nftPictureFrame39 = new Entity('nftPictureFrame39')
engine.addEntity(nftPictureFrame39)
nftPictureFrame39.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(14.300688743591309, 14.31505298614502, 2.980337619781494),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.575014114379883, 4.632970333099365, 0.6471990346908569)
})
nftPictureFrame39.addComponentOrReplace(transform16)

const nftPictureFrame64 = new Entity('nftPictureFrame64')
engine.addEntity(nftPictureFrame64)
nftPictureFrame64.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(15.87159252166748, 14.312610626220703, 10.702622413635254),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111867427825928, 5.241393089294434, 0.5000051856040955)
})
nftPictureFrame64.addComponentOrReplace(transform17)

const nftPictureFrame65 = new Entity('nftPictureFrame65')
engine.addEntity(nftPictureFrame65)
nftPictureFrame65.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(15.864352226257324, 14.330631256103516, 8.114668846130371),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.1118645668029785, 5.259216785430908, 0.5000048279762268)
})
nftPictureFrame65.addComponentOrReplace(transform18)

const nftPictureFrame68 = new Entity('nftPictureFrame68')
engine.addEntity(nftPictureFrame68)
nftPictureFrame68.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(15.867533683776855, 14.320284843444824, 5.515686988830566),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111865520477295, 5.259216785430908, 0.5000049471855164)
})
nftPictureFrame68.addComponentOrReplace(transform19)

const nftPictureFrame69 = new Entity('nftPictureFrame69')
engine.addEntity(nftPictureFrame69)
nftPictureFrame69.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(5.405656814575195, 14.299357414245605, 0.08283475041389465),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000022053718567)
})
nftPictureFrame69.addComponentOrReplace(transform20)

const nftPictureFrame72 = new Entity('nftPictureFrame72')
engine.addEntity(nftPictureFrame72)
nftPictureFrame72.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(10.417661666870117, 14.28583812713623, 0.07647567987442017),
  rotation: new Quaternion(3.552713678800501e-15, -3.6307097233033813e-22, -3.0456606983327635e-15, -1),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000022053718567)
})
nftPictureFrame72.addComponentOrReplace(transform21)

const wallPlainGlass23 = new Entity('wallPlainGlass23')
engine.addEntity(wallPlainGlass23)
wallPlainGlass23.setParent(_scene)
wallPlainGlass23.addComponentOrReplace(gltfShape2)
const transform22 = new Transform({
  position: new Vector3(0.00102996826171875, 13.75582218170166, 15.654935836791992),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.631282806396484, 0.13248126208782196, 0.39199891686439514)
})
wallPlainGlass23.addComponentOrReplace(transform22)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape3 = new GLTFShape("models/CityTile.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
entity.addComponentOrReplace(gltfShape3)
const transform23 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform23)

const nftPictureFrame41 = new Entity('nftPictureFrame41')
engine.addEntity(nftPictureFrame41)
nftPictureFrame41.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(7.901618003845215, 14.335114479064941, 0.07485027611255646),
  rotation: new Quaternion(-3.552713678800501e-15, -3.725290298461914e-8, 8.374730793017041e-15, 1),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame41.addComponentOrReplace(transform24)

const nftPictureFrame42 = new Entity('nftPictureFrame42')
engine.addEntity(nftPictureFrame42)
nftPictureFrame42.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(0.14432907104492188, 14.352632522583008, 5.613411903381348),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.7969253063201904, 5.128884315490723, 0.5000061392784119)
})
nftPictureFrame42.addComponentOrReplace(transform25)

const wallPlainGlass5 = new Entity('wallPlainGlass5')
engine.addEntity(wallPlainGlass5)
wallPlainGlass5.setParent(_scene)
wallPlainGlass5.addComponentOrReplace(gltfShape2)
const transform26 = new Transform({
  position: new Vector3(0.3155592978000641, 13.73597240447998, 2.2109933439651286e-8),
  rotation: new Quaternion(-2.7916168827263593e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(7.631290435791016, 0.13248126208782196, 0.391999751329422)
})
wallPlainGlass5.addComponentOrReplace(transform26)

const wallPlainGlass = new Entity('wallPlainGlass')
engine.addEntity(wallPlainGlass)
wallPlainGlass.setParent(_scene)
wallPlainGlass.addComponentOrReplace(gltfShape2)
const transform27 = new Transform({
  position: new Vector3(15.843307495117188, 13.75582218170166, 15.654935836791992),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.63128662109375, 0.13248126208782196, 0.3919992744922638)
})
wallPlainGlass.addComponentOrReplace(transform27)

const wallPlainGlass2 = new Entity('wallPlainGlass2')
engine.addEntity(wallPlainGlass2)
wallPlainGlass2.setParent(_scene)
wallPlainGlass2.addComponentOrReplace(gltfShape2)
const transform28 = new Transform({
  position: new Vector3(0.3155592978000641, 13.73597240447998, 15.823236465454102),
  rotation: new Quaternion(-2.7916168827263593e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(7.631290435791016, 0.13248126208782196, 0.391999751329422)
})
wallPlainGlass2.addComponentOrReplace(transform28)

const wallPlainGlass6 = new Entity('wallPlainGlass6')
engine.addEntity(wallPlainGlass6)
wallPlainGlass6.setParent(_scene)
wallPlainGlass6.addComponentOrReplace(gltfShape2)
const transform29 = new Transform({
  position: new Vector3(0.31555938720703125, 7.275947570800781, 15.823236465454102),
  rotation: new Quaternion(-2.7916168827263593e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(7.631290435791016, 0.13248126208782196, 0.391999751329422)
})
wallPlainGlass6.addComponentOrReplace(transform29)

const wallPlainGlass9 = new Entity('wallPlainGlass9')
engine.addEntity(wallPlainGlass9)
wallPlainGlass9.setParent(_scene)
wallPlainGlass9.addComponentOrReplace(gltfShape2)
const transform30 = new Transform({
  position: new Vector3(15.843307495117188, 7.295797348022461, 15.654935836791992),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.631290435791016, 0.13248126208782196, 0.39199963212013245)
})
wallPlainGlass9.addComponentOrReplace(transform30)

const wallPlainGlass10 = new Entity('wallPlainGlass10')
engine.addEntity(wallPlainGlass10)
wallPlainGlass10.setParent(_scene)
wallPlainGlass10.addComponentOrReplace(gltfShape2)
const transform31 = new Transform({
  position: new Vector3(0.00102996826171875, 7.295797348022461, 15.654935836791992),
  rotation: new Quaternion(-2.4085271740892887e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(7.63128662109375, 0.13248126208782196, 0.3919992744922638)
})
wallPlainGlass10.addComponentOrReplace(transform31)

const wallPlainGlass12 = new Entity('wallPlainGlass12')
engine.addEntity(wallPlainGlass12)
wallPlainGlass12.setParent(_scene)
wallPlainGlass12.addComponentOrReplace(gltfShape2)
const transform32 = new Transform({
  position: new Vector3(0.31555938720703125, 7.275947570800781, 0),
  rotation: new Quaternion(-2.7916168827263593e-15, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(7.631290435791016, 0.13248126208782196, 0.391999751329422)
})
wallPlainGlass12.addComponentOrReplace(transform32)

const wallPlainGlass19 = new Entity('wallPlainGlass19')
engine.addEntity(wallPlainGlass19)
wallPlainGlass19.setParent(_scene)
wallPlainGlass19.addComponentOrReplace(gltfShape2)
const transform33 = new Transform({
  position: new Vector3(9.818069458007812, 10.425972938537598, 6.255527019500732),
  rotation: new Quaternion(0.70710688829422, -0.7071067690849304, 0, 1.2344522737350871e-8),
  scale: new Vector3(4.688287734985352, 0.8449528813362122, 0.14495868980884552)
})
wallPlainGlass19.addComponentOrReplace(transform33)

const wallPlainGlass20 = new Entity('wallPlainGlass20')
engine.addEntity(wallPlainGlass20)
wallPlainGlass20.setParent(_scene)
wallPlainGlass20.addComponentOrReplace(gltfShape2)
const transform34 = new Transform({
  position: new Vector3(9.818069458007812, 10.425972938537598, 9.633153915405273),
  rotation: new Quaternion(0.70710688829422, -0.7071067690849304, 0, 1.2344522737350871e-8),
  scale: new Vector3(4.688294887542725, 0.8449532985687256, 0.14495894312858582)
})
wallPlainGlass20.addComponentOrReplace(transform34)

const wallPlainGlass21 = new Entity('wallPlainGlass21')
engine.addEntity(wallPlainGlass21)
wallPlainGlass21.setParent(_scene)
wallPlainGlass21.addComponentOrReplace(gltfShape2)
const transform35 = new Transform({
  position: new Vector3(9.818069458007812, 10.425972938537598, 6.301930904388428),
  rotation: new Quaternion(0.5, -0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(4.688265323638916, 0.8449410200119019, 0.14495877921581268)
})
wallPlainGlass21.addComponentOrReplace(transform35)

const wallPlainGlass26 = new Entity('wallPlainGlass26')
engine.addEntity(wallPlainGlass26)
wallPlainGlass26.setParent(_scene)
wallPlainGlass26.addComponentOrReplace(gltfShape2)
const transform36 = new Transform({
  position: new Vector3(14.305465698242188, 0.0065610408782958984, 1.4743218421936035),
  rotation: new Quaternion(0.70710688829422, -0.7071067690849304, 0, 1.2344522737350871e-8),
  scale: new Vector3(9.918547630310059, 0.7025015950202942, 0.12303899228572845)
})
wallPlainGlass26.addComponentOrReplace(transform36)

const wallPlainGlass28 = new Entity('wallPlainGlass28')
engine.addEntity(wallPlainGlass28)
wallPlainGlass28.setParent(_scene)
wallPlainGlass28.addComponentOrReplace(gltfShape2)
const transform37 = new Transform({
  position: new Vector3(14.305465698242188, 0.006560962647199631, 1.5137087106704712),
  rotation: new Quaternion(0.5, -0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(9.918512344360352, 0.7171716094017029, 0.12052103132009506)
})
wallPlainGlass28.addComponentOrReplace(transform37)

const verticalBlackPad = new Entity('verticalBlackPad')
engine.addEntity(verticalBlackPad)
verticalBlackPad.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.460805892944336, 0.12048319727182388, 1.460805892944336)
})
verticalBlackPad.addComponentOrReplace(transform38)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(9.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform39)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(8, 0, 8.041803359985352),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.473411798477173, 6.439352989196777, 2.4700629711151123)
})
triggerArea.addComponentOrReplace(transform40)

const verticalBlackPad2 = new Entity('verticalBlackPad2')
engine.addEntity(verticalBlackPad2)
verticalBlackPad2.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(13.032299995422363, 0, 2.8106436729431152),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1661232709884644, 0.09617859125137329, 1.1661232709884644)
})
verticalBlackPad2.addComponentOrReplace(transform41)

const nftPictureFrame43 = new Entity('nftPictureFrame43')
engine.addEntity(nftPictureFrame43)
nftPictureFrame43.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(14.351798057556152, 7.911952018737793, 3),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.6413984298706055, 4.815613746643066, 0.47952547669410706)
})
nftPictureFrame43.addComponentOrReplace(transform42)

const nftPictureFrame44 = new Entity('nftPictureFrame44')
engine.addEntity(nftPictureFrame44)
nftPictureFrame44.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(12.96322250366211, 7.948065757751465, 1.4503812789916992),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.815153121948242, 4.866322040557861, 0.5024067163467407)
})
nftPictureFrame44.addComponentOrReplace(transform43)

const nftPictureFrame49 = new Entity('nftPictureFrame49')
engine.addEntity(nftPictureFrame49)
nftPictureFrame49.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(12.902239799499512, 7.922665596008301, 1.5244994163513184),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.68395471572876, 4.743313312530518, 0.6626132130622864)
})
nftPictureFrame49.addComponentOrReplace(transform44)

const nftPictureFrame50 = new Entity('nftPictureFrame50')
engine.addEntity(nftPictureFrame50)
nftPictureFrame50.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(14.28385066986084, 7.980362892150879, 2.980337142944336),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.575015068054199, 4.632970333099365, 0.6471988558769226)
})
nftPictureFrame50.addComponentOrReplace(transform45)

const nftPictureFrame51 = new Entity('nftPictureFrame51')
engine.addEntity(nftPictureFrame51)
nftPictureFrame51.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(14.351798057556152, 2.709562301635742, 3),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.6413984298706055, 4.815613746643066, 0.47952547669410706)
})
nftPictureFrame51.addComponentOrReplace(transform46)

const nftPictureFrame52 = new Entity('nftPictureFrame52')
engine.addEntity(nftPictureFrame52)
nftPictureFrame52.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(12.96322250366211, 2.745676040649414, 1.4503812789916992),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.815153121948242, 4.866322040557861, 0.5024067163467407)
})
nftPictureFrame52.addComponentOrReplace(transform47)

const nftPictureFrame53 = new Entity('nftPictureFrame53')
engine.addEntity(nftPictureFrame53)
nftPictureFrame53.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(2.9395017623901367, 14.31505298614502, 1.5261929035186768),
  rotation: new Quaternion(5.446070332172041e-15, 0, -8.193957868446976e-15, -1),
  scale: new Vector3(4.575013160705566, 4.632970333099365, 0.6472004055976868)
})
nftPictureFrame53.addComponentOrReplace(transform48)

const nftPictureFrame54 = new Entity('nftPictureFrame54')
engine.addEntity(nftPictureFrame54)
nftPictureFrame54.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(1.4095454216003418, 14.282755851745605, 2.832066059112549),
  rotation: new Quaternion(-1.9739713200605732e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.8151559829711914, 4.866322040557861, 0.5024070739746094)
})
nftPictureFrame54.addComponentOrReplace(transform49)

const nftPictureFrame55 = new Entity('nftPictureFrame55')
engine.addEntity(nftPictureFrame55)
nftPictureFrame55.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(2.9591641426086426, 14.313499450683594, 1.4434900283813477),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.641397476196289, 4.815613746643066, 0.4795253574848175)
})
nftPictureFrame55.addComponentOrReplace(transform50)

const nftPictureFrame56 = new Entity('nftPictureFrame56')
engine.addEntity(nftPictureFrame56)
nftPictureFrame56.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(1.5415971279144287, 14.257355690002441, 2.8930482864379883),
  rotation: new Quaternion(1.9406350678719594e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(4.683959484100342, 4.743313312530518, 0.6626110672950745)
})
nftPictureFrame56.addComponentOrReplace(transform51)

const nftPictureFrame57 = new Entity('nftPictureFrame57')
engine.addEntity(nftPictureFrame57)
nftPictureFrame57.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(1.6119439601898193, 7.922665596008301, 2.8930492401123047),
  rotation: new Quaternion(1.9406350678719594e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(4.683957576751709, 4.743313312530518, 0.6626117825508118)
})
nftPictureFrame57.addComponentOrReplace(transform52)

const nftPictureFrame58 = new Entity('nftPictureFrame58')
engine.addEntity(nftPictureFrame58)
nftPictureFrame58.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(2.9395017623901367, 7.980362892150879, 1.5127696990966797),
  rotation: new Quaternion(5.446070332172041e-15, 0, -8.193957868446976e-15, -1),
  scale: new Vector3(4.575016021728516, 4.632970333099365, 0.6472004055976868)
})
nftPictureFrame58.addComponentOrReplace(transform53)

const nftPictureFrame59 = new Entity('nftPictureFrame59')
engine.addEntity(nftPictureFrame59)
nftPictureFrame59.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(2.959163188934326, 7.978809356689453, 1.443490982055664),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.6414003372192383, 4.815613746643066, 0.47952571511268616)
})
nftPictureFrame59.addComponentOrReplace(transform54)

const nftPictureFrame60 = new Entity('nftPictureFrame60')
engine.addEntity(nftPictureFrame60)
nftPictureFrame60.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(1.4095449447631836, 7.948065757751465, 2.832066535949707),
  rotation: new Quaternion(-1.9739713200605732e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.815155029296875, 4.866322040557861, 0.5024069547653198)
})
nftPictureFrame60.addComponentOrReplace(transform55)

const nftPictureFrame66 = new Entity('nftPictureFrame66')
engine.addEntity(nftPictureFrame66)
nftPictureFrame66.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(2.959162712097168, 2.7764196395874023, 1.4434916973114014),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(3.6414012908935547, 4.815613746643066, 0.4795258343219757)
})
nftPictureFrame66.addComponentOrReplace(transform56)

const nftPictureFrame67 = new Entity('nftPictureFrame67')
engine.addEntity(nftPictureFrame67)
nftPictureFrame67.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(1.4095439910888672, 2.745676040649414, 2.8320674896240234),
  rotation: new Quaternion(-1.9739713200605732e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.8151540756225586, 4.866322040557861, 0.5024068355560303)
})
nftPictureFrame67.addComponentOrReplace(transform57)

const wallPlainGlass3 = new Entity('wallPlainGlass3')
engine.addEntity(wallPlainGlass3)
wallPlainGlass3.setParent(_scene)
wallPlainGlass3.addComponentOrReplace(gltfShape2)
const transform58 = new Transform({
  position: new Vector3(1.472870945930481, 0.006560802459716797, 1.4898245334625244),
  rotation: new Quaternion(-5.960464477539063e-8, -5.960464477539063e-8, -0.70710688829422, 0.7071067690849304),
  scale: new Vector3(9.918513298034668, 0.7171716094017029, 0.12052104622125626)
})
wallPlainGlass3.addComponentOrReplace(transform58)

const wallPlainGlass8 = new Entity('wallPlainGlass8')
engine.addEntity(wallPlainGlass8)
wallPlainGlass8.setParent(_scene)
wallPlainGlass8.addComponentOrReplace(gltfShape2)
const transform59 = new Transform({
  position: new Vector3(1.4334840774536133, 0.006560802459716797, 1.4898244142532349),
  rotation: new Quaternion(0.5, -0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(9.91855239868164, 0.7025017142295837, 0.12303915619850159)
})
wallPlainGlass8.addComponentOrReplace(transform59)

const nftPictureFrame70 = new Entity('nftPictureFrame70')
engine.addEntity(nftPictureFrame70)
nftPictureFrame70.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(8.145710945129395, 10.689456939697266, 6.224764823913574),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(4.650711536407471, 5.640412330627441, 0.6124390959739685)
})
nftPictureFrame70.addComponentOrReplace(transform60)

const nftPictureFrame71 = new Entity('nftPictureFrame71')
engine.addEntity(nftPictureFrame71)
nftPictureFrame71.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(8.096426963806152, 10.66832160949707, 9.674392700195312),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.456194877624512, 5.55093240737915, 0.6876867413520813)
})
nftPictureFrame71.addComponentOrReplace(transform61)

const nftPictureFrame73 = new Entity('nftPictureFrame73')
engine.addEntity(nftPictureFrame73)
nftPictureFrame73.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(9.89513874053955, 10.69256591796875, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.279313087463379, 5.659231662750244, 0.563530445098877)
})
nftPictureFrame73.addComponentOrReplace(transform62)

const triggerArea2 = new Entity('triggerArea2')
engine.addEntity(triggerArea2)
triggerArea2.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(13.094732284545898, 0, 2.7227602005004883),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.39021635055542, 13.065084457397461, 2.4019737243652344)
})
triggerArea2.addComponentOrReplace(transform63)

const wallPlainGlass16 = new Entity('wallPlainGlass16')
engine.addEntity(wallPlainGlass16)
wallPlainGlass16.setParent(_scene)
wallPlainGlass16.addComponentOrReplace(gltfShape2)
const transform64 = new Transform({
  position: new Vector3(15.983480453491211, 13.203889846801758, 0.020088672637939453),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(3.0752971172332764, 3.9913971424102783, 0.1881696730852127)
})
wallPlainGlass16.addComponentOrReplace(transform64)

const triggerArea3 = new Entity('triggerArea3')
engine.addEntity(triggerArea3)
triggerArea3.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(2.792393445968628, 0, 2.7227604389190674),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.39021635055542, 19.960464477539062, 2.4019737243652344)
})
triggerArea3.addComponentOrReplace(transform65)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(12.795289039611816, 2.709562301635742, 14.766219139099121),
  rotation: new Quaternion(-5.875600316208223e-15, 0, 6.632166756563975e-15, -1),
  scale: new Vector3(3.6414012908935547, 4.815613746643066, 0.4795258343219757)
})
nftPictureFrame5.addComponentOrReplace(transform66)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(12.795289039611816, 7.911952018737793, 14.766218185424805),
  rotation: new Quaternion(-5.875600316208223e-15, 0, 6.632166756563975e-15, -1),
  scale: new Vector3(3.6414003372192383, 4.815613746643066, 0.47952571511268616)
})
nftPictureFrame6.addComponentOrReplace(transform67)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(12.7952880859375, 14.246642112731934, 14.766217231750488),
  rotation: new Quaternion(-5.875600316208223e-15, 0, 6.632166756563975e-15, -1),
  scale: new Vector3(3.641397476196289, 4.815613746643066, 0.4795253574848175)
})
nftPictureFrame10.addComponentOrReplace(transform68)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(14.277510643005371, 14.257355690002441, 13.316658973693848),
  rotation: new Quaternion(-3.95378589690778e-15, -0.7071068286895752, 8.429368136830817e-8, 0.7071068286895752),
  scale: new Vector3(4.683959484100342, 4.743313312530518, 0.6626129746437073)
})
nftPictureFrame12.addComponentOrReplace(transform69)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(14.255008697509766, 7.922665596008301, 13.316659927368164),
  rotation: new Quaternion(-3.95378589690778e-15, -0.7071068286895752, 8.429368136830817e-8, 0.7071068286895752),
  scale: new Vector3(4.683958530426025, 4.743313312530518, 0.6626125574111938)
})
nftPictureFrame13.addComponentOrReplace(transform70)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(14.344908714294434, 2.745676040649414, 13.377643585205078),
  rotation: new Quaternion(-1.223688339514143e-14, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.8151540756225586, 4.866322040557861, 0.5024068355560303)
})
nftPictureFrame15.addComponentOrReplace(transform71)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(14.344907760620117, 7.948065757751465, 13.377641677856445),
  rotation: new Quaternion(-1.223688339514143e-14, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.815155029296875, 4.866322040557861, 0.5024069547653198)
})
nftPictureFrame18.addComponentOrReplace(transform72)

const nftPictureFrame27 = new Entity('nftPictureFrame27')
engine.addEntity(nftPictureFrame27)
nftPictureFrame27.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(14.3449068069458, 14.282755851745605, 13.377641677856445),
  rotation: new Quaternion(-1.223688339514143e-14, -0.7071068286895752, 8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.8151559829711914, 4.866322040557861, 0.5024070739746094)
})
nftPictureFrame27.addComponentOrReplace(transform73)

const nftPictureFrame29 = new Entity('nftPictureFrame29')
engine.addEntity(nftPictureFrame29)
nftPictureFrame29.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(12.81495189666748, 7.980362892150879, 14.69222354888916),
  rotation: new Quaternion(-1.0989706154373568e-14, -1, 1.1920926112907182e-7, 0),
  scale: new Vector3(4.575016021728516, 4.632970333099365, 0.6472004055976868)
})
nftPictureFrame29.addComponentOrReplace(transform74)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(12.814950942993164, 14.31505298614502, 14.673063278198242),
  rotation: new Quaternion(-1.0989706154373568e-14, -1, 1.1920926112907182e-7, 0),
  scale: new Vector3(4.575013160705566, 4.632970333099365, 0.6472004055976868)
})
nftPictureFrame30.addComponentOrReplace(transform75)

const triggerArea4 = new Entity('triggerArea4')
engine.addEntity(triggerArea4)
triggerArea4.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(13.072528839111328, 0, 13.509153366088867),
  rotation: new Quaternion(-6.692902301134779e-16, 0.7071068286895752, -8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(2.390216827392578, 19.960464477539062, 2.4019742012023926)
})
triggerArea4.addComponentOrReplace(transform76)

const wallPlainGlass17 = new Entity('wallPlainGlass17')
engine.addEntity(wallPlainGlass17)
wallPlainGlass17.setParent(_scene)
wallPlainGlass17.addComponentOrReplace(gltfShape2)
const transform77 = new Transform({
  position: new Vector3(14.320967674255371, 0.006561279296875, 14.719886779785156),
  rotation: new Quaternion(-0.5000001192092896, 0.49999988079071045, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(9.91855239868164, 0.7025017142295837, 0.12303915619850159)
})
wallPlainGlass17.addComponentOrReplace(transform77)

const wallPlainGlass22 = new Entity('wallPlainGlass22')
engine.addEntity(wallPlainGlass22)
wallPlainGlass22.setParent(_scene)
wallPlainGlass22.addComponentOrReplace(gltfShape2)
const transform78 = new Transform({
  position: new Vector3(14.281580924987793, 0.006560802459716797, 14.719886779785156),
  rotation: new Quaternion(-0.70710688829422, 0.7071067690849304, -1.2344514743745094e-8, 0),
  scale: new Vector3(9.918513298034668, 0.7171716094017029, 0.12052107602357864)
})
wallPlainGlass22.addComponentOrReplace(transform78)

const verticalBlackPad3 = new Entity('verticalBlackPad3')
engine.addEntity(verticalBlackPad3)
verticalBlackPad3.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(12.98464584350586, 0, 13.446721076965332),
  rotation: new Quaternion(-6.692902301134779e-16, 0.7071068286895752, -8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.1661235094070435, 0.09617859125137329, 1.1661235094070435)
})
verticalBlackPad3.addComponentOrReplace(transform79)

const nftPictureFrame36 = new Entity('nftPictureFrame36')
engine.addEntity(nftPictureFrame36)
nftPictureFrame36.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(1.4026541709899902, 2.709562301635742, 13.209711074829102),
  rotation: new Quaternion(-7.304912087008862e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.641402244567871, 4.815613746643066, 0.47952595353126526)
})
nftPictureFrame36.addComponentOrReplace(transform80)

const nftPictureFrame45 = new Entity('nftPictureFrame45')
engine.addEntity(nftPictureFrame45)
nftPictureFrame45.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(1.4026546478271484, 7.911952018737793, 13.209710121154785),
  rotation: new Quaternion(-7.304912087008862e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.641402244567871, 4.815613746643066, 0.47952595353126526)
})
nftPictureFrame45.addComponentOrReplace(transform81)

const nftPictureFrame46 = new Entity('nftPictureFrame46')
engine.addEntity(nftPictureFrame46)
nftPictureFrame46.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(1.4026546478271484, 14.246642112731934, 13.209708213806152),
  rotation: new Quaternion(-7.304912087008862e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(3.6414003372192383, 4.815613746643066, 0.47952571511268616)
})
nftPictureFrame46.addComponentOrReplace(transform82)

const nftPictureFrame47 = new Entity('nftPictureFrame47')
engine.addEntity(nftPictureFrame47)
nftPictureFrame47.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(2.8522133827209473, 14.257355690002441, 14.691582679748535),
  rotation: new Quaternion(3.2211466550043045e-15, -1, 1.1920926112907182e-7, 0),
  scale: new Vector3(4.683958530426025, 4.743313312530518, 0.6626133322715759)
})
nftPictureFrame47.addComponentOrReplace(transform83)

const nftPictureFrame48 = new Entity('nftPictureFrame48')
engine.addEntity(nftPictureFrame48)
nftPictureFrame48.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(2.852212905883789, 7.922665596008301, 14.683819770812988),
  rotation: new Quaternion(3.2211466550043045e-15, -1, 1.1920926112907182e-7, 0),
  scale: new Vector3(4.683958530426025, 4.743313312530518, 0.6626133322715759)
})
nftPictureFrame48.addComponentOrReplace(transform84)

const nftPictureFrame61 = new Entity('nftPictureFrame61')
engine.addEntity(nftPictureFrame61)
nftPictureFrame61.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(2.791229724884033, 2.745676040649414, 14.759330749511719),
  rotation: new Quaternion(-7.5642515526015e-15, 0, -6.0168951526891334e-15, -1),
  scale: new Vector3(3.815156936645508, 4.866322040557861, 0.5024071931838989)
})
nftPictureFrame61.addComponentOrReplace(transform85)

const nftPictureFrame62 = new Entity('nftPictureFrame62')
engine.addEntity(nftPictureFrame62)
nftPictureFrame62.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(2.7912302017211914, 7.948065757751465, 14.759328842163086),
  rotation: new Quaternion(-7.5642515526015e-15, 0, -6.0168951526891334e-15, -1),
  scale: new Vector3(3.815156936645508, 4.866322040557861, 0.5024071931838989)
})
nftPictureFrame62.addComponentOrReplace(transform86)

const nftPictureFrame63 = new Entity('nftPictureFrame63')
engine.addEntity(nftPictureFrame63)
nftPictureFrame63.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(2.7912302017211914, 14.282755851745605, 14.759326934814453),
  rotation: new Quaternion(-7.5642515526015e-15, 0, -6.0168951526891334e-15, -1),
  scale: new Vector3(3.815156936645508, 4.866322040557861, 0.5024071931838989)
})
nftPictureFrame63.addComponentOrReplace(transform87)

const nftPictureFrame74 = new Entity('nftPictureFrame74')
engine.addEntity(nftPictureFrame74)
nftPictureFrame74.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(1.4612507820129395, 7.980362892150879, 13.229373931884766),
  rotation: new Quaternion(6.4399584636895026e-15, -0.7071068286895752, 8.429367426288081e-8, -0.7071068286895752),
  scale: new Vector3(4.575018882751465, 4.632970333099365, 0.6471996903419495)
})
nftPictureFrame74.addComponentOrReplace(transform88)

const nftPictureFrame75 = new Entity('nftPictureFrame75')
engine.addEntity(nftPictureFrame75)
nftPictureFrame75.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(1.4942221641540527, 14.31505298614502, 13.2293701171875),
  rotation: new Quaternion(6.4399584636895026e-15, -0.7071068286895752, 8.429367426288081e-8, -0.7071068286895752),
  scale: new Vector3(4.575016975402832, 4.632970333099365, 0.6472004055976868)
})
nftPictureFrame75.addComponentOrReplace(transform89)

const triggerArea5 = new Entity('triggerArea5')
engine.addEntity(triggerArea5)
triggerArea5.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(2.6597204208374023, 0, 13.48695182800293),
  rotation: new Quaternion(-6.49015448317674e-15, 1, -1.1920926823449918e-7, 0),
  scale: new Vector3(2.3902182579040527, 13.065084457397461, 2.401975631713867)
})
triggerArea5.addComponentOrReplace(transform90)

const wallPlainGlass25 = new Entity('wallPlainGlass25')
engine.addEntity(wallPlainGlass25)
wallPlainGlass25.setParent(_scene)
wallPlainGlass25.addComponentOrReplace(gltfShape2)
const transform91 = new Transform({
  position: new Vector3(1.4489867687225342, 0.006561279296875, 14.735389709472656),
  rotation: new Quaternion(-8.940696716308594e-8, -8.940696716308594e-8, -0.70710688829422, 0.7071067094802856),
  scale: new Vector3(9.91855239868164, 0.7025017738342285, 0.12303917109966278)
})
wallPlainGlass25.addComponentOrReplace(transform91)

const wallPlainGlass31 = new Entity('wallPlainGlass31')
engine.addEntity(wallPlainGlass31)
wallPlainGlass31.setParent(_scene)
wallPlainGlass31.addComponentOrReplace(gltfShape2)
const transform92 = new Transform({
  position: new Vector3(1.4489867687225342, 0.006560802459716797, 14.696002960205078),
  rotation: new Quaternion(-0.5000001192092896, 0.49999988079071045, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(9.91851806640625, 0.7171717286109924, 0.12052123993635178)
})
wallPlainGlass31.addComponentOrReplace(transform92)

const verticalBlackPad4 = new Entity('verticalBlackPad4')
engine.addEntity(verticalBlackPad4)
verticalBlackPad4.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(2.7221527099609375, 0, 13.399067878723145),
  rotation: new Quaternion(-6.49015448317674e-15, 1, -1.1920926823449918e-7, 0),
  scale: new Vector3(1.1661242246627808, 0.09617859125137329, 1.1661242246627808)
})
verticalBlackPad4.addComponentOrReplace(transform93)

const verticalBlackPad5 = new Entity('verticalBlackPad5')
engine.addEntity(verticalBlackPad5)
verticalBlackPad5.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(2.9248478412628174, 0, 2.859673500061035),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1661232709884644, 0.09617859125137329, 1.1661232709884644)
})
verticalBlackPad5.addComponentOrReplace(transform94)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(10.270454406738281, 14.299357414245605, 15.930009841918945),
  rotation: new Quaternion(-1.2357592366388746e-15, 1, -1.1920927533992653e-7, -2.9802322387695312e-8),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000022053718567)
})
nftPictureFrame.addComponentOrReplace(transform95)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(7.774493217468262, 14.335114479064941, 15.922941207885742),
  rotation: new Quaternion(3.475808169387494e-16, -1, 1.1920928244535389e-7, -7.450580596923828e-9),
  scale: new Vector3(3.79689359664917, 5.128884315490723, 0.5000022053718567)
})
nftPictureFrame2.addComponentOrReplace(transform96)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(5.258449554443359, 14.303322792053223, 15.921316146850586),
  rotation: new Quaternion(-1.2357592366388746e-15, 1, -1.1920927533992653e-7, -2.9802322387695312e-8),
  scale: new Vector3(4.111843585968018, 5.241391181945801, 0.5000022053718567)
})
nftPictureFrame3.addComponentOrReplace(transform97)

const wallPlainGlass14 = new Entity('wallPlainGlass14')
engine.addEntity(wallPlainGlass14)
wallPlainGlass14.setParent(_scene)
wallPlainGlass14.addComponentOrReplace(gltfShape2)
const transform98 = new Transform({
  position: new Vector3(6.408136367797852, 10.425972938537598, 6.301930904388428),
  rotation: new Quaternion(0.5, -0.5, -0.5000000596046448, 0.4999999403953552),
  scale: new Vector3(4.688265323638916, 0.8449410200119019, 0.14495877921581268)
})
wallPlainGlass14.addComponentOrReplace(transform98)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(6.402204990386963, 10.738622665405273, 7.952855110168457),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.111874103546143, 5.474271297454834, 0.5000060200691223)
})
nftPictureFrame4.addComponentOrReplace(transform99)

const lightDecor = new Entity('lightDecor')
engine.addEntity(lightDecor)
lightDecor.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(8, 19.78730010986328, 0.024652481079101562),
  rotation: new Quaternion(0.7071068286895752, 1.5394153601527394e-15, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(3.6163864135742188, 3.40386700630188, 1.0000026226043701)
})
lightDecor.addComponentOrReplace(transform100)
const gltfShape4 = new GLTFShape("models/Light_Decor7.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
lightDecor.addComponentOrReplace(gltfShape4)

const lightDecor2 = new Entity('lightDecor2')
engine.addEntity(lightDecor2)
lightDecor2.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(7.985186576843262, 18.168916702270508, 7.938965797424316),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6793038845062256, 1, 1.6665639877319336)
})
lightDecor2.addComponentOrReplace(transform101)
const gltfShape5 = new GLTFShape("models/Light_Decor9.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
lightDecor2.addComponentOrReplace(gltfShape5)

const wallPlainBlack = new Entity('wallPlainBlack')
engine.addEntity(wallPlainBlack)
wallPlainBlack.setParent(_scene)
wallPlainBlack.addComponentOrReplace(gltfShape)
const transform102 = new Transform({
  position: new Vector3(15.919906616210938, 7.529757976531982, 6.300779342651367),
  rotation: new Quaternion(-1.555036024128648e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.6606196165084839, 1.1292099952697754, 0.3330828547477722)
})
wallPlainBlack.addComponentOrReplace(transform102)

const signpostTree2 = new Entity('signpostTree2')
engine.addEntity(signpostTree2)
signpostTree2.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(15.910928726196289, 7.3901214599609375, 7.948746681213379),
  rotation: new Quaternion(-8.660462958213176e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.7857553958892822, 4.490051746368408, 1.0000112056732178)
})
signpostTree2.addComponentOrReplace(transform103)

const wallPlainBlack2 = new Entity('wallPlainBlack2')
engine.addEntity(wallPlainBlack2)
wallPlainBlack2.setParent(_scene)
wallPlainBlack2.addComponentOrReplace(gltfShape)
const transform104 = new Transform({
  position: new Vector3(10.099478721618652, 7.463967800140381, 15.970000267028809),
  rotation: new Quaternion(-3.552713678800501e-15, 4.331258849253477e-22, 3.633324110324798e-15, 1),
  scale: new Vector3(2.341846466064453, 1.1763044595718384, 0.3330826163291931)
})
wallPlainBlack2.addComponentOrReplace(transform104)

const signpostTree4 = new Entity('signpostTree4')
engine.addEntity(signpostTree4)
signpostTree4.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(7.762684345245361, 7.293859481811523, 15.964295387268066),
  rotation: new Quaternion(0, 1.483675757074845e-21, 1.2445975172237049e-14, 1),
  scale: new Vector3(2.5668981075286865, 4.721567630767822, 1)
})
signpostTree4.addComponentOrReplace(transform105)

const armchairA = new Entity('armchairA')
engine.addEntity(armchairA)
armchairA.setParent(_scene)
const transform106 = new Transform({
  position: new Vector3(9.187849044799805, 6.479016304016113, 14.906034469604492),
  rotation: new Quaternion(-8.619235217692349e-16, -0.9569403529167175, 1.1407617961367578e-7, 0.29028475284576416),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
armchairA.addComponentOrReplace(transform106)
const gltfShape6 = new GLTFShape("models/Armchair_A.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
armchairA.addComponentOrReplace(gltfShape6)

const armchairA2 = new Entity('armchairA2')
engine.addEntity(armchairA2)
armchairA2.setParent(_scene)
armchairA2.addComponentOrReplace(gltfShape6)
const transform107 = new Transform({
  position: new Vector3(6.621131896972656, 6.479016304016113, 14.940817832946777),
  rotation: new Quaternion(2.831150874990033e-15, -0.9743070006370544, 1.1614642403401376e-7, -0.22522443532943726),
  scale: new Vector3(1.0000028610229492, 1, 1.0000028610229492)
})
armchairA2.addComponentOrReplace(transform107)

const armchairD = new Entity('armchairD')
engine.addEntity(armchairD)
armchairD.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(1.0887458324432373, 6.4565300941467285, 6.723842620849609),
  rotation: new Quaternion(-6.65064594497863e-16, 0.4713967442512512, -5.6194867426029305e-8, 0.8819212913513184),
  scale: new Vector3(1, 1, 1)
})
armchairD.addComponentOrReplace(transform108)
const gltfShape7 = new GLTFShape("models/Armchair_D.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
armchairD.addComponentOrReplace(gltfShape7)

const armchairD2 = new Entity('armchairD2')
engine.addEntity(armchairD2)
armchairD2.setParent(_scene)
armchairD2.addComponentOrReplace(gltfShape7)
const transform109 = new Transform({
  position: new Vector3(1.0897173881530762, 6.4565300941467285, 9.384245872497559),
  rotation: new Quaternion(-1.5283430513453496e-15, 0.8819212913513184, -1.0513319637084351e-7, 0.47139671444892883),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
armchairD2.addComponentOrReplace(transform109)

const coffeeTable = new Entity('coffeeTable')
engine.addEntity(coffeeTable)
coffeeTable.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(2.1004679203033447, 6.478052616119385, 8.065657615661621),
  rotation: new Quaternion(-3.4728681180275743e-15, 0.7040969729423523, -8.393488570845875e-8, -0.7101039290428162),
  scale: new Vector3(1.0000017881393433, 1, 1.0000017881393433)
})
coffeeTable.addComponentOrReplace(transform110)
const gltfShape8 = new GLTFShape("models/Coffee_Table.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
coffeeTable.addComponentOrReplace(gltfShape8)

const radio = new Entity('radio')
engine.addEntity(radio)
radio.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(2.377851963043213, 6.982928276062012, 8.08378791809082),
  rotation: new Quaternion(2.5926168679225653e-15, 0.7137430906295776, -8.508479254487611e-8, 0.7004076838493347),
  scale: new Vector3(1.000001072883606, 1, 1.000001072883606)
})
radio.addComponentOrReplace(transform111)

const blueNeonTube = new Entity('blueNeonTube')
engine.addEntity(blueNeonTube)
blueNeonTube.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(8.000000953674316, 6.532801628112793, 0.08051204681396484),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(9.200916290283203, 1, 1)
})
blueNeonTube.addComponentOrReplace(transform112)
const gltfShape9 = new GLTFShape("models/NeonLightTube_04/NeonLightTube_04.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
blueNeonTube.addComponentOrReplace(gltfShape9)

const blueNeonTube2 = new Entity('blueNeonTube2')
engine.addEntity(blueNeonTube2)
blueNeonTube2.setParent(_scene)
blueNeonTube2.addComponentOrReplace(gltfShape9)
const transform113 = new Transform({
  position: new Vector3(8.000000953674316, 6.532801628112793, 15.788811683654785),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(9.200916290283203, 1, 1)
})
blueNeonTube2.addComponentOrReplace(transform113)

const blueNeonTube3 = new Entity('blueNeonTube3')
engine.addEntity(blueNeonTube3)
blueNeonTube3.setParent(_scene)
blueNeonTube3.addComponentOrReplace(gltfShape9)
const transform114 = new Transform({
  position: new Vector3(0.12279331684112549, 6.532801628112793, 7.89671516418457),
  rotation: new Quaternion(-6.692902301134779e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(9.200922012329102, 1, 1.0000007152557373)
})
blueNeonTube3.addComponentOrReplace(transform114)

const blueNeonTube4 = new Entity('blueNeonTube4')
engine.addEntity(blueNeonTube4)
blueNeonTube4.setParent(_scene)
blueNeonTube4.addComponentOrReplace(gltfShape9)
const transform115 = new Transform({
  position: new Vector3(15.920594215393066, 6.532801628112793, 7.89671516418457),
  rotation: new Quaternion(-6.692902301134779e-16, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(9.200923919677734, 1, 1.0000009536743164)
})
blueNeonTube4.addComponentOrReplace(transform115)

const greenNeonTube = new Entity('greenNeonTube')
engine.addEntity(greenNeonTube)
greenNeonTube.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(7.918112754821777, 13.26620101928711, 15.880193710327148),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(9.149171829223633, 1, 1.0000001192092896)
})
greenNeonTube.addComponentOrReplace(transform116)
const gltfShape10 = new GLTFShape("models/NeonLightTube_05/NeonLightTube_05.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
greenNeonTube.addComponentOrReplace(gltfShape10)

const greenNeonTube2 = new Entity('greenNeonTube2')
engine.addEntity(greenNeonTube2)
greenNeonTube2.setParent(_scene)
greenNeonTube2.addComponentOrReplace(gltfShape10)
const transform117 = new Transform({
  position: new Vector3(7.918112754821777, 13.26620101928711, 0.1178884506225586),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(9.149171829223633, 1, 1.0000001192092896)
})
greenNeonTube2.addComponentOrReplace(transform117)

const greenNeonTube3 = new Entity('greenNeonTube3')
engine.addEntity(greenNeonTube3)
greenNeonTube3.setParent(_scene)
greenNeonTube3.addComponentOrReplace(gltfShape10)
const transform118 = new Transform({
  position: new Vector3(0.10762478411197662, 13.26620101928711, 7.880193710327148),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(9.149177551269531, 1, 1.0000008344650269)
})
greenNeonTube3.addComponentOrReplace(transform118)

const greenNeonTube4 = new Entity('greenNeonTube4')
engine.addEntity(greenNeonTube4)
greenNeonTube4.setParent(_scene)
greenNeonTube4.addComponentOrReplace(gltfShape10)
const transform119 = new Transform({
  position: new Vector3(15.927152633666992, 13.26620101928711, 7.880193710327148),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(9.149179458618164, 1, 1.000001072883606)
})
greenNeonTube4.addComponentOrReplace(transform119)

const purpleNeonTube = new Entity('purpleNeonTube')
engine.addEntity(purpleNeonTube)
purpleNeonTube.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(1.328576922416687, 9.787853240966797, 14.731019020080566),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(11.497187614440918, 1.0000028610229492, 1)
})
purpleNeonTube.addComponentOrReplace(transform120)
const gltfShape11 = new GLTFShape("models/NeonLightTube_03/NeonLightTube_03.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
purpleNeonTube.addComponentOrReplace(gltfShape11)

const purpleNeonTube2 = new Entity('purpleNeonTube2')
engine.addEntity(purpleNeonTube2)
purpleNeonTube2.setParent(_scene)
purpleNeonTube2.addComponentOrReplace(gltfShape11)
const transform121 = new Transform({
  position: new Vector3(14.55721664428711, 9.787853240966797, 1.4260358810424805),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(11.49719524383545, 1.0000038146972656, 1)
})
purpleNeonTube2.addComponentOrReplace(transform121)

const redNeonTube = new Entity('redNeonTube')
engine.addEntity(redNeonTube)
redNeonTube.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(1.5000004768371582, 9.799456596374512, 1.6017746925354004),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(11.4797945022583, 1.0000033378601074, 1)
})
redNeonTube.addComponentOrReplace(transform122)
const gltfShape12 = new GLTFShape("models/NeonLightTube_06/NeonLightTube_06.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
redNeonTube.addComponentOrReplace(gltfShape12)

const redNeonTube2 = new Entity('redNeonTube2')
engine.addEntity(redNeonTube2)
redNeonTube2.setParent(_scene)
redNeonTube2.addComponentOrReplace(gltfShape12)
const transform123 = new Transform({
  position: new Vector3(14.322469711303711, 9.799456596374512, 14.798076629638672),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(11.479805946350098, 1.000004768371582, 1)
})
redNeonTube2.addComponentOrReplace(transform123)

const signpostTree5 = new Entity('signpostTree5')
engine.addEntity(signpostTree5)
signpostTree5.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(8.023031234741211, 4.845696449279785, 9.464295387268066),
  rotation: new Quaternion(0, 1.483675757074845e-21, 1.2445975172237049e-14, 1),
  scale: new Vector3(1.3049815893173218, 0.85685133934021, 1)
})
signpostTree5.addComponentOrReplace(transform124)

const wallPlainBlack5 = new Entity('wallPlainBlack5')
engine.addEntity(wallPlainBlack5)
wallPlainBlack5.setParent(_scene)
wallPlainBlack5.addComponentOrReplace(gltfShape)
const transform125 = new Transform({
  position: new Vector3(9.211030006408691, 4.8765668869018555, 9.470000267028809),
  rotation: new Quaternion(-3.552713678800501e-15, 4.331258849253477e-22, 3.633324110324798e-15, 1),
  scale: new Vector3(1.190567970275879, 0.21347105503082275, 0.3330826163291931)
})
wallPlainBlack5.addComponentOrReplace(transform125)

const wallPlainBlack6 = new Entity('wallPlainBlack6')
engine.addEntity(wallPlainBlack6)
wallPlainBlack6.setParent(_scene)
wallPlainBlack6.addComponentOrReplace(gltfShape)
const transform126 = new Transform({
  position: new Vector3(6.754734039306641, 4.8765668869018555, 6.789850234985352),
  rotation: new Quaternion(-2.2039534707343246e-15, 1, -1.1920927533992653e-7, 1.262177448353619e-29),
  scale: new Vector3(1.190567970275879, 0.21347105503082275, 0.3330826163291931)
})
wallPlainBlack6.addComponentOrReplace(transform126)

const signpostTree6 = new Entity('signpostTree6')
engine.addEntity(signpostTree6)
signpostTree6.setParent(_scene)
const transform127 = new Transform({
  position: new Vector3(7.942732810974121, 4.845696449279785, 6.795555114746094),
  rotation: new Quaternion(6.608697591177926e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1.3049815893173218, 0.85685133934021, 1)
})
signpostTree6.addComponentOrReplace(transform127)

const wallPlainBlack7 = new Entity('wallPlainBlack7')
engine.addEntity(wallPlainBlack7)
wallPlainBlack7.setParent(_scene)
wallPlainBlack7.addComponentOrReplace(gltfShape)
const transform128 = new Transform({
  position: new Vector3(6.710696220397949, 4.8765668869018555, 9.23653793334961),
  rotation: new Quaternion(-1.5584305086647696e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.1905689239501953, 0.21347105503082275, 0.3330828547477722)
})
wallPlainBlack7.addComponentOrReplace(transform128)

const signpostTree7 = new Entity('signpostTree7')
engine.addEntity(signpostTree7)
signpostTree7.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(6.716401100158691, 4.845696449279785, 8.048540115356445),
  rotation: new Quaternion(4.673055359013557e-15, 0.7071068286895752, -8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(1.3049825429916382, 0.85685133934021, 1.0000009536743164)
})
signpostTree7.addComponentOrReplace(transform129)

const wallPlainBlack8 = new Entity('wallPlainBlack8')
engine.addEntity(wallPlainBlack8)
wallPlainBlack8.setParent(_scene)
wallPlainBlack8.addComponentOrReplace(gltfShape)
const transform130 = new Transform({
  position: new Vector3(9.38228988647461, 4.8765668869018555, 6.890681266784668),
  rotation: new Quaternion(4.3797422489394965e-15, -0.7071068286895752, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.1905696392059326, 0.21347105503082275, 0.33308303356170654)
})
wallPlainBlack8.addComponentOrReplace(transform130)

const signpostTree8 = new Entity('signpostTree8')
engine.addEntity(signpostTree8)
signpostTree8.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(9.376585006713867, 4.845696449279785, 8.078679084777832),
  rotation: new Quaternion(-2.7256851086615054e-15, -0.7071068286895752, 8.429368136830817e-8, -0.7071068286895752),
  scale: new Vector3(1.3049832582473755, 0.85685133934021, 1.0000016689300537)
})
signpostTree8.addComponentOrReplace(transform131)

const wallPlainBlack9 = new Entity('wallPlainBlack9')
engine.addEntity(wallPlainBlack9)
wallPlainBlack9.setParent(_scene)
wallPlainBlack9.addComponentOrReplace(gltfShape)
const transform132 = new Transform({
  position: new Vector3(11.23321533203125, 4.8765668869018555, 13.46823787689209),
  rotation: new Quaternion(1.5165260946982048e-15, 0.9238795638084412, -1.1013501222123523e-7, -0.3826834559440613),
  scale: new Vector3(1.1905701160430908, 0.21347105503082275, 0.3330831825733185)
})
wallPlainBlack9.addComponentOrReplace(transform132)

const signpostTree9 = new Entity('signpostTree9')
engine.addEntity(signpostTree9)
signpostTree9.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(12.077291488647461, 4.845696449279785, 12.632229804992676),
  rotation: new Quaternion(6.105640488638861e-15, 0.9238795638084412, -1.1013501932666259e-7, -0.3826834559440613),
  scale: new Vector3(1.3049837350845337, 0.85685133934021, 1.0000014305114746)
})
signpostTree9.addComponentOrReplace(transform133)

const signpostTree10 = new Entity('signpostTree10')
engine.addEntity(signpostTree10)
signpostTree10.setParent(_scene)
const transform134 = new Transform({
  position: new Vector3(3.7039389610290527, 4.845696449279785, 3.725278854370117),
  rotation: new Quaternion(1.3238797799108837e-15, -0.3826834559440613, 4.5619408695074526e-8, -0.9238795638084412),
  scale: new Vector3(1.304985523223877, 0.85685133934021, 1.0000025033950806)
})
signpostTree10.addComponentOrReplace(transform134)

const wallPlainBlack10 = new Entity('wallPlainBlack10')
engine.addEntity(wallPlainBlack10)
wallPlainBlack10.setParent(_scene)
wallPlainBlack10.addComponentOrReplace(gltfShape)
const transform135 = new Transform({
  position: new Vector3(4.548015117645264, 4.8765668869018555, 2.889270782470703),
  rotation: new Quaternion(8.42930681987453e-15, -0.3826834559440613, 4.5619415800501883e-8, -0.9238795638084412),
  scale: new Vector3(1.1905717849731445, 0.21347105503082275, 0.3330836296081543)
})
wallPlainBlack10.addComponentOrReplace(transform135)

const wallPlainBlack11 = new Entity('wallPlainBlack11')
engine.addEntity(wallPlainBlack11)
wallPlainBlack11.setParent(_scene)
wallPlainBlack11.addComponentOrReplace(gltfShape)
const transform136 = new Transform({
  position: new Vector3(12.99583911895752, 4.876565933227539, 4.560980319976807),
  rotation: new Quaternion(8.987459180467752e-15, 0.35810062289237976, -4.268891018455179e-8, -0.9336829781532288),
  scale: new Vector3(1.190570592880249, 0.21347105503082275, 0.33308330178260803)
})
wallPlainBlack11.addComponentOrReplace(transform136)

const signpostTree11 = new Entity('signpostTree11')
engine.addEntity(signpostTree11)
signpostTree11.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(12.116344451904297, 4.845695495605469, 3.762317657470703),
  rotation: new Quaternion(4.68428828644357e-15, 0.35810062289237976, -4.26889243954065e-8, -0.9336829781532288),
  scale: new Vector3(1.304984211921692, 0.85685133934021, 1.0000016689300537)
})
signpostTree11.addComponentOrReplace(transform137)

const signpostTree12 = new Entity('signpostTree12')
engine.addEntity(signpostTree12)
signpostTree12.setParent(_scene)
const transform138 = new Transform({
  position: new Vector3(3.664884567260742, 4.845697402954102, 12.595191955566406),
  rotation: new Quaternion(-4.966786903363562e-15, -0.9336829781532288, 1.113036702804493e-7, -0.35810062289237976),
  scale: new Vector3(1.304985761642456, 0.85685133934021, 1.0000027418136597)
})
signpostTree12.addComponentOrReplace(transform138)

const wallPlainBlack12 = new Entity('wallPlainBlack12')
engine.addEntity(wallPlainBlack12)
wallPlainBlack12.setParent(_scene)
wallPlainBlack12.addComponentOrReplace(gltfShape)
const transform139 = new Transform({
  position: new Vector3(2.7853894233703613, 4.876567840576172, 11.796528816223145),
  rotation: new Quaternion(7.158687942291405e-15, -0.9336829781532288, 1.113036702804493e-7, -0.35810062289237976),
  scale: new Vector3(1.1905720233917236, 0.21347105503082275, 0.3330836892127991)
})
wallPlainBlack12.addComponentOrReplace(transform139)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform140 = new Transform({
  position: new Vector3(15.757591247558594, 7.8841962814331055, 7.952855110168457),
  rotation: new Quaternion(6.2051710951059776e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(6.366129398345947, 8.142498016357422, 0.7741246223449707)
})
nftPictureFrame7.addComponentOrReplace(transform140)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform141 = new Transform({
  position: new Vector3(7.953104019165039, 7.982729911804199, 0.12313609570264816),
  rotation: new Quaternion(-3.552713678800501e-15, -3.725290298461914e-8, 8.374730793017041e-15, 1),
  scale: new Vector3(9.23898696899414, 8.266758918762207, 0.805905818939209)
})
nftPictureFrame11.addComponentOrReplace(transform141)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(0.11496971547603607, 8.040781021118164, 8.09152889251709),
  rotation: new Quaternion(-1.9739713200605732e-15, 0.7071068286895752, -8.429368136830817e-8, 0.7071067690849304),
  scale: new Vector3(6.565490245819092, 7.907368183135986, 0.7708697319030762)
})
nftPictureFrame14.addComponentOrReplace(transform142)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform143 = new Transform({
  position: new Vector3(7.79766845703125, 7.915465354919434, 15.861930847167969),
  rotation: new Quaternion(3.475808169387494e-16, -1, 1.1920928244535389e-7, -7.450580596923828e-9),
  scale: new Vector3(8.972309112548828, 8.448015213012695, 0.823576033115387)
})
nftPictureFrame19.addComponentOrReplace(transform143)

const signpostTree13 = new Entity('signpostTree13')
engine.addEntity(signpostTree13)
signpostTree13.setParent(_scene)
const transform144 = new Transform({
  position: new Vector3(15.906331062316895, 13.943472862243652, 8.013051986694336),
  rotation: new Quaternion(-8.660462958213176e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.46439790725708, 3.1942670345306396, 1.0000133514404297)
})
signpostTree13.addComponentOrReplace(transform144)

const wallPlainBlack13 = new Entity('wallPlainBlack13')
engine.addEntity(wallPlainBlack13)
wallPlainBlack13.setParent(_scene)
wallPlainBlack13.addComponentOrReplace(gltfShape)
const transform145 = new Transform({
  position: new Vector3(15.91762638092041, 13.67489242553711, 3.5505166053771973),
  rotation: new Quaternion(-1.555036024128648e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.50251579284668, 0.953629195690155, 0.05368560552597046)
})
wallPlainBlack13.addComponentOrReplace(transform145)

const signpostTree14 = new Entity('signpostTree14')
engine.addEntity(signpostTree14)
signpostTree14.setParent(_scene)
const transform146 = new Transform({
  position: new Vector3(0.052809715270996094, 13.943471908569336, 8.050516128540039),
  rotation: new Quaternion(7.497071675488867e-15, -0.7071068286895752, 8.429368136830817e-8, 0.7071068286895752),
  scale: new Vector3(4.4644036293029785, 3.1942670345306396, 1.0000147819519043)
})
signpostTree14.addComponentOrReplace(transform146)

const wallPlainBlack14 = new Entity('wallPlainBlack14')
engine.addEntity(wallPlainBlack14)
wallPlainBlack14.setParent(_scene)
wallPlainBlack14.addComponentOrReplace(gltfShape)
const transform147 = new Transform({
  position: new Vector3(0.037465814501047134, 13.674893379211426, 12.513051986694336),
  rotation: new Quaternion(7.497071675488867e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(4.502521514892578, 0.953629195690155, 0.05958310142159462)
})
wallPlainBlack14.addComponentOrReplace(transform147)

const signpostTree15 = new Entity('signpostTree15')
engine.addEntity(signpostTree15)
signpostTree15.setParent(_scene)
const transform148 = new Transform({
  position: new Vector3(7.864767074584961, 13.943472862243652, 15.969377517700195),
  rotation: new Quaternion(-1.531816098187329e-15, 0, 1.3660591619479509e-14, -1),
  scale: new Vector3(4.464399814605713, 3.1942670345306396, 1.000013828277588)
})
signpostTree15.addComponentOrReplace(transform148)

const wallPlainBlack15 = new Entity('wallPlainBlack15')
engine.addEntity(wallPlainBlack15)
wallPlainBlack15.setParent(_scene)
wallPlainBlack15.addComponentOrReplace(gltfShape)
const transform149 = new Transform({
  position: new Vector3(12.327302932739258, 13.67489242553711, 15.980672836303711),
  rotation: new Quaternion(-6.5561112447135375e-15, 0, 6.5551651089114545e-15, -1),
  scale: new Vector3(4.5025177001953125, 0.953629195690155, 0.05368563532829285)
})
wallPlainBlack15.addComponentOrReplace(transform149)

const signpostTree16 = new Entity('signpostTree16')
engine.addEntity(signpostTree16)
signpostTree16.setParent(_scene)
const transform150 = new Transform({
  position: new Vector3(7.88359260559082, 13.943472862243652, 0.024450337514281273),
  rotation: new Quaternion(-7.986992144048966e-15, 1, -1.1920926823449918e-7, -1.628469118878921e-21),
  scale: new Vector3(4.464399814605713, 3.1942670345306396, 1.000013828277588)
})
signpostTree16.addComponentOrReplace(transform150)

const wallPlainBlack16 = new Entity('wallPlainBlack16')
engine.addEntity(wallPlainBlack16)
wallPlainBlack16.setParent(_scene)
wallPlainBlack16.addComponentOrReplace(gltfShape)
const transform151 = new Transform({
  position: new Vector3(3.4210567474365234, 13.67489242553711, 0.013155018910765648),
  rotation: new Quaternion(-8.815660569973845e-16, 1, -1.1920927533992653e-7, -7.814364745472082e-22),
  scale: new Vector3(4.5025177001953125, 0.953629195690155, 0.05368563532829285)
})
wallPlainBlack16.addComponentOrReplace(transform151)

const armchairA3 = new Entity('armchairA3')
engine.addEntity(armchairA3)
armchairA3.setParent(_scene)
armchairA3.addComponentOrReplace(gltfShape6)
const transform152 = new Transform({
  position: new Vector3(9.187849044799805, 6.479016304016113, 1.047460913658142),
  rotation: new Quaternion(1.3252558908128168e-15, -0.22522443532943726, 2.6848841372384413e-8, 0.9743070006370544),
  scale: new Vector3(1.0000025033950806, 1, 1.0000025033950806)
})
armchairA3.addComponentOrReplace(transform152)

const armchairA4 = new Entity('armchairA4')
engine.addEntity(armchairA4)
armchairA4.setParent(_scene)
armchairA4.addComponentOrReplace(gltfShape6)
const transform153 = new Transform({
  position: new Vector3(6.621131896972656, 6.479016304016113, 1.098487138748169),
  rotation: new Quaternion(1.9608201171149135e-14, 0.29028475284576416, -3.4604624943312956e-8, 0.9569403529167175),
  scale: new Vector3(1.0000005960464478, 1, 1.0000005960464478)
})
armchairA4.addComponentOrReplace(transform153)

const ringBlueLight = new Entity('ringBlueLight')
engine.addEntity(ringBlueLight)
ringBlueLight.setParent(_scene)
const transform154 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8842449188232422, 0.25108602643013, 1.8842449188232422)
})
ringBlueLight.addComponentOrReplace(transform154)
const gltfShape13 = new GLTFShape("models/Ring_Blue_Light.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
ringBlueLight.addComponentOrReplace(gltfShape13)

const ringBlueLight2 = new Entity('ringBlueLight2')
engine.addEntity(ringBlueLight2)
ringBlueLight2.setParent(_scene)
ringBlueLight2.addComponentOrReplace(gltfShape13)
const transform155 = new Transform({
  position: new Vector3(8, 6.590167999267578, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8842449188232422, 0.25108602643013, 1.8842449188232422)
})
ringBlueLight2.addComponentOrReplace(transform155)

const ringBlueLight3 = new Entity('ringBlueLight3')
engine.addEntity(ringBlueLight3)
ringBlueLight3.setParent(_scene)
ringBlueLight3.addComponentOrReplace(gltfShape13)
const transform156 = new Transform({
  position: new Vector3(8, 3.378354072570801, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.8842449188232422, 0.25108602643013, 1.8842449188232422)
})
ringBlueLight3.addComponentOrReplace(transform156)

const armchairD3 = new Entity('armchairD3')
engine.addEntity(armchairD3)
armchairD3.setParent(_scene)
armchairD3.addComponentOrReplace(gltfShape7)
const transform157 = new Transform({
  position: new Vector3(14.911080360412598, 6.45652961730957, 6.723841667175293),
  rotation: new Quaternion(4.35375358405184e-15, 0.47139671444892883, -5.6194867426029305e-8, -0.8819212913513184),
  scale: new Vector3(1.0000005960464478, 1, 1.0000005960464478)
})
armchairD3.addComponentOrReplace(transform157)

const coffeeTable2 = new Entity('coffeeTable2')
engine.addEntity(coffeeTable2)
coffeeTable2.setParent(_scene)
coffeeTable2.addComponentOrReplace(gltfShape8)
const transform158 = new Transform({
  position: new Vector3(13.813565254211426, 6.478052616119385, 7.968564033508301),
  rotation: new Quaternion(1.1250501669602536e-14, -0.7101039290428162, 8.465097067755778e-8, -0.7040969729423523),
  scale: new Vector3(1.0000022649765015, 1, 1.0000022649765015)
})
coffeeTable2.addComponentOrReplace(transform158)

const armchairD4 = new Entity('armchairD4')
engine.addEntity(armchairD4)
armchairD4.setParent(_scene)
armchairD4.addComponentOrReplace(gltfShape7)
const transform159 = new Transform({
  position: new Vector3(14.903568267822266, 6.456530570983887, 9.384244918823242),
  rotation: new Quaternion(-5.148019343307513e-15, 0.8819212913513184, -1.0513320347627086e-7, -0.4713967442512512),
  scale: new Vector3(1.0000005960464478, 1, 1.0000005960464478)
})
armchairD4.addComponentOrReplace(transform159)

const ringWhiteLight = new Entity('ringWhiteLight')
engine.addEntity(ringWhiteLight)
ringWhiteLight.setParent(_scene)
const transform160 = new Transform({
  position: new Vector3(13.03748607635498, 0, 2.8120663166046143),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight.addComponentOrReplace(transform160)
const gltfShape14 = new GLTFShape("models/Ring_White_Light.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
ringWhiteLight.addComponentOrReplace(gltfShape14)

const ringWhiteLight2 = new Entity('ringWhiteLight2')
engine.addEntity(ringWhiteLight2)
ringWhiteLight2.setParent(_scene)
ringWhiteLight2.addComponentOrReplace(gltfShape14)
const transform161 = new Transform({
  position: new Vector3(13.03748607635498, 2.6905977725982666, 2.8120663166046143),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight2.addComponentOrReplace(transform161)

const ringWhiteLight3 = new Entity('ringWhiteLight3')
engine.addEntity(ringWhiteLight3)
ringWhiteLight3.setParent(_scene)
ringWhiteLight3.addComponentOrReplace(gltfShape14)
const transform162 = new Transform({
  position: new Vector3(13.03748607635498, 5.7284979820251465, 2.8120663166046143),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight3.addComponentOrReplace(transform162)

const ringWhiteLight5 = new Entity('ringWhiteLight5')
engine.addEntity(ringWhiteLight5)
ringWhiteLight5.setParent(_scene)
ringWhiteLight5.addComponentOrReplace(gltfShape14)
const transform163 = new Transform({
  position: new Vector3(13.03748607635498, 10.331618309020996, 2.8120663166046143),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight5.addComponentOrReplace(transform163)

const ringWhiteLight6 = new Entity('ringWhiteLight6')
engine.addEntity(ringWhiteLight6)
ringWhiteLight6.setParent(_scene)
ringWhiteLight6.addComponentOrReplace(gltfShape14)
const transform164 = new Transform({
  position: new Vector3(13.03748607635498, 13.19426155090332, 2.8120663166046143),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight6.addComponentOrReplace(transform164)

const ringWhiteLight9 = new Entity('ringWhiteLight9')
engine.addEntity(ringWhiteLight9)
ringWhiteLight9.setParent(_scene)
ringWhiteLight9.addComponentOrReplace(gltfShape14)
const transform165 = new Transform({
  position: new Vector3(2.9346306324005127, 0, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight9.addComponentOrReplace(transform165)

const ringWhiteLight10 = new Entity('ringWhiteLight10')
engine.addEntity(ringWhiteLight10)
ringWhiteLight10.setParent(_scene)
ringWhiteLight10.addComponentOrReplace(gltfShape14)
const transform166 = new Transform({
  position: new Vector3(2.9346306324005127, 2.6905975341796875, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight10.addComponentOrReplace(transform166)

const ringWhiteLight11 = new Entity('ringWhiteLight11')
engine.addEntity(ringWhiteLight11)
ringWhiteLight11.setParent(_scene)
ringWhiteLight11.addComponentOrReplace(gltfShape14)
const transform167 = new Transform({
  position: new Vector3(2.9346306324005127, 5.7284979820251465, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight11.addComponentOrReplace(transform167)

const ringWhiteLight13 = new Entity('ringWhiteLight13')
engine.addEntity(ringWhiteLight13)
ringWhiteLight13.setParent(_scene)
ringWhiteLight13.addComponentOrReplace(gltfShape14)
const transform168 = new Transform({
  position: new Vector3(2.9346306324005127, 10.331618309020996, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight13.addComponentOrReplace(transform168)

const ringWhiteLight14 = new Entity('ringWhiteLight14')
engine.addEntity(ringWhiteLight14)
ringWhiteLight14.setParent(_scene)
ringWhiteLight14.addComponentOrReplace(gltfShape14)
const transform169 = new Transform({
  position: new Vector3(2.9346306324005127, 16.66078758239746, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight14.addComponentOrReplace(transform169)

const ringWhiteLight15 = new Entity('ringWhiteLight15')
engine.addEntity(ringWhiteLight15)
ringWhiteLight15.setParent(_scene)
ringWhiteLight15.addComponentOrReplace(gltfShape14)
const transform170 = new Transform({
  position: new Vector3(2.9346306324005127, 19.75080680847168, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight15.addComponentOrReplace(transform170)

const ringWhiteLight16 = new Entity('ringWhiteLight16')
engine.addEntity(ringWhiteLight16)
ringWhiteLight16.setParent(_scene)
ringWhiteLight16.addComponentOrReplace(gltfShape14)
const transform171 = new Transform({
  position: new Vector3(2.9346306324005127, 13.19426155090332, 2.873913288116455),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight16.addComponentOrReplace(transform171)

const ringWhiteLight17 = new Entity('ringWhiteLight17')
engine.addEntity(ringWhiteLight17)
ringWhiteLight17.setParent(_scene)
ringWhiteLight17.addComponentOrReplace(gltfShape14)
const transform172 = new Transform({
  position: new Vector3(2.745934247970581, 0, 13.393094062805176),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight17.addComponentOrReplace(transform172)

const ringWhiteLight18 = new Entity('ringWhiteLight18')
engine.addEntity(ringWhiteLight18)
ringWhiteLight18.setParent(_scene)
ringWhiteLight18.addComponentOrReplace(gltfShape14)
const transform173 = new Transform({
  position: new Vector3(2.745934247970581, 2.6905975341796875, 13.393094062805176),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight18.addComponentOrReplace(transform173)

const ringWhiteLight19 = new Entity('ringWhiteLight19')
engine.addEntity(ringWhiteLight19)
ringWhiteLight19.setParent(_scene)
ringWhiteLight19.addComponentOrReplace(gltfShape14)
const transform174 = new Transform({
  position: new Vector3(2.745934247970581, 5.7284979820251465, 13.393094062805176),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight19.addComponentOrReplace(transform174)

const ringWhiteLight21 = new Entity('ringWhiteLight21')
engine.addEntity(ringWhiteLight21)
ringWhiteLight21.setParent(_scene)
ringWhiteLight21.addComponentOrReplace(gltfShape14)
const transform175 = new Transform({
  position: new Vector3(2.745934247970581, 10.331618309020996, 13.393094062805176),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight21.addComponentOrReplace(transform175)

const ringWhiteLight24 = new Entity('ringWhiteLight24')
engine.addEntity(ringWhiteLight24)
ringWhiteLight24.setParent(_scene)
ringWhiteLight24.addComponentOrReplace(gltfShape14)
const transform176 = new Transform({
  position: new Vector3(2.745934247970581, 13.19426155090332, 13.393094062805176),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight24.addComponentOrReplace(transform176)

const ringWhiteLight25 = new Entity('ringWhiteLight25')
engine.addEntity(ringWhiteLight25)
ringWhiteLight25.setParent(_scene)
ringWhiteLight25.addComponentOrReplace(gltfShape14)
const transform177 = new Transform({
  position: new Vector3(12.969233512878418, 0, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight25.addComponentOrReplace(transform177)

const ringWhiteLight26 = new Entity('ringWhiteLight26')
engine.addEntity(ringWhiteLight26)
ringWhiteLight26.setParent(_scene)
ringWhiteLight26.addComponentOrReplace(gltfShape14)
const transform178 = new Transform({
  position: new Vector3(12.969233512878418, 2.6905975341796875, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight26.addComponentOrReplace(transform178)

const ringWhiteLight27 = new Entity('ringWhiteLight27')
engine.addEntity(ringWhiteLight27)
ringWhiteLight27.setParent(_scene)
ringWhiteLight27.addComponentOrReplace(gltfShape14)
const transform179 = new Transform({
  position: new Vector3(12.969233512878418, 5.7284979820251465, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight27.addComponentOrReplace(transform179)

const ringWhiteLight29 = new Entity('ringWhiteLight29')
engine.addEntity(ringWhiteLight29)
ringWhiteLight29.setParent(_scene)
ringWhiteLight29.addComponentOrReplace(gltfShape14)
const transform180 = new Transform({
  position: new Vector3(12.969233512878418, 10.331618309020996, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight29.addComponentOrReplace(transform180)

const ringWhiteLight30 = new Entity('ringWhiteLight30')
engine.addEntity(ringWhiteLight30)
ringWhiteLight30.setParent(_scene)
ringWhiteLight30.addComponentOrReplace(gltfShape14)
const transform181 = new Transform({
  position: new Vector3(12.969233512878418, 16.66078758239746, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight30.addComponentOrReplace(transform181)

const ringWhiteLight31 = new Entity('ringWhiteLight31')
engine.addEntity(ringWhiteLight31)
ringWhiteLight31.setParent(_scene)
ringWhiteLight31.addComponentOrReplace(gltfShape14)
const transform182 = new Transform({
  position: new Vector3(12.969233512878418, 19.75080680847168, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight31.addComponentOrReplace(transform182)

const ringWhiteLight32 = new Entity('ringWhiteLight32')
engine.addEntity(ringWhiteLight32)
ringWhiteLight32.setParent(_scene)
ringWhiteLight32.addComponentOrReplace(gltfShape14)
const transform183 = new Transform({
  position: new Vector3(12.969233512878418, 13.19426155090332, 13.422977447509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.330240249633789, 0.21389277279376984, 1.330240249633789)
})
ringWhiteLight32.addComponentOrReplace(transform183)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform184 = new Transform({
  position: new Vector3(9.89513874053955, 17.366601943969727, 8),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.2793121337890625, 4.149393558502197, 0.5635303258895874)
})
nftPictureFrame22.addComponentOrReplace(transform184)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform185 = new Transform({
  position: new Vector3(8.096426963806152, 17.348825454711914, 9.674392700195312),
  rotation: new Quaternion(3.552713678800501e-15, -3.558758035682535e-22, -2.9853032480937902e-15, -1),
  scale: new Vector3(4.456194877624512, 4.069988250732422, 0.6876867413520813)
})
nftPictureFrame23.addComponentOrReplace(transform185)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform186 = new Transform({
  position: new Vector3(6.286441802978516, 17.363035202026367, 7.9477763175964355),
  rotation: new Quaternion(6.162491645992675e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(4.686260223388672, 4.210695266723633, 0.662937343120575)
})
nftPictureFrame24.addComponentOrReplace(transform186)

const nftPictureFrame25 = new Entity('nftPictureFrame25')
engine.addEntity(nftPictureFrame25)
nftPictureFrame25.setParent(_scene)
const transform187 = new Transform({
  position: new Vector3(8.145710945129395, 17.36432456970215, 6.224764823913574),
  rotation: new Quaternion(-2.7916168827263593e-15, 1, -1.1920927533992653e-7, 0),
  scale: new Vector3(4.650711536407471, 4.135595321655273, 0.6124390959739685)
})
nftPictureFrame25.addComponentOrReplace(transform187)

const wallPlainBlack17 = new Entity('wallPlainBlack17')
engine.addEntity(wallPlainBlack17)
wallPlainBlack17.setParent(_scene)
wallPlainBlack17.addComponentOrReplace(gltfShape)
const transform188 = new Transform({
  position: new Vector3(11.23321533203125, 10.459915161132812, 13.46823787689209),
  rotation: new Quaternion(1.5165260946982048e-15, 0.9238795638084412, -1.1013501222123523e-7, -0.3826834559440613),
  scale: new Vector3(1.1905722618103027, 0.21347105503082275, 0.33308348059654236)
})
wallPlainBlack17.addComponentOrReplace(transform188)

const signpostTree17 = new Entity('signpostTree17')
engine.addEntity(signpostTree17)
signpostTree17.setParent(_scene)
const transform189 = new Transform({
  position: new Vector3(12.077291488647461, 10.429044723510742, 12.632229804992676),
  rotation: new Quaternion(6.105640488638861e-15, 0.9238795638084412, -1.1013501932666259e-7, -0.3826834559440613),
  scale: new Vector3(1.3049850463867188, 0.85685133934021, 1.000002145767212)
})
signpostTree17.addComponentOrReplace(transform189)

const wallPlainBlack18 = new Entity('wallPlainBlack18')
engine.addEntity(wallPlainBlack18)
wallPlainBlack18.setParent(_scene)
wallPlainBlack18.addComponentOrReplace(gltfShape)
const transform190 = new Transform({
  position: new Vector3(4.548015117645264, 10.459915161132812, 2.889270782470703),
  rotation: new Quaternion(8.42930681987453e-15, -0.3826834559440613, 4.5619415800501883e-8, -0.9238795638084412),
  scale: new Vector3(1.1905717849731445, 0.21347105503082275, 0.3330836296081543)
})
wallPlainBlack18.addComponentOrReplace(transform190)

const signpostTree18 = new Entity('signpostTree18')
engine.addEntity(signpostTree18)
signpostTree18.setParent(_scene)
const transform191 = new Transform({
  position: new Vector3(3.7039389610290527, 10.429044723510742, 3.725278854370117),
  rotation: new Quaternion(1.3238797799108837e-15, -0.3826834559440613, 4.5619408695074526e-8, -0.9238795638084412),
  scale: new Vector3(1.304985523223877, 0.85685133934021, 1.0000025033950806)
})
signpostTree18.addComponentOrReplace(transform191)

const wallPlainBlack19 = new Entity('wallPlainBlack19')
engine.addEntity(wallPlainBlack19)
wallPlainBlack19.setParent(_scene)
wallPlainBlack19.addComponentOrReplace(gltfShape)
const transform192 = new Transform({
  position: new Vector3(12.99583911895752, 10.486634254455566, 4.560980319976807),
  rotation: new Quaternion(8.987460027500699e-15, 0.35810065269470215, -4.2688913737265466e-8, -0.9336830377578735),
  scale: new Vector3(1.1905710697174072, 0.21347105503082275, 0.3330834209918976)
})
wallPlainBlack19.addComponentOrReplace(transform192)

const signpostTree19 = new Entity('signpostTree19')
engine.addEntity(signpostTree19)
signpostTree19.setParent(_scene)
const transform193 = new Transform({
  position: new Vector3(12.116344451904297, 10.455763816833496, 3.762317657470703),
  rotation: new Quaternion(4.684288709960044e-15, 0.35810065269470215, -4.268892794812018e-8, -0.9336830377578735),
  scale: new Vector3(1.30498468875885, 0.85685133934021, 1.000002145767212)
})
signpostTree19.addComponentOrReplace(transform193)

const wallPlainBlack20 = new Entity('wallPlainBlack20')
engine.addEntity(wallPlainBlack20)
wallPlainBlack20.setParent(_scene)
wallPlainBlack20.addComponentOrReplace(gltfShape)
const transform194 = new Transform({
  position: new Vector3(2.7853899002075195, 10.4866361618042, 11.796528816223145),
  rotation: new Quaternion(7.158688789324352e-15, -0.9336830377578735, 1.1130367738587665e-7, -0.35810065269470215),
  scale: new Vector3(1.19057297706604, 0.21347105503082275, 0.33308395743370056)
})
wallPlainBlack20.addComponentOrReplace(transform194)

const signpostTree20 = new Entity('signpostTree20')
engine.addEntity(signpostTree20)
signpostTree20.setParent(_scene)
const transform195 = new Transform({
  position: new Vector3(3.664884567260742, 10.455765724182129, 12.595191955566406),
  rotation: new Quaternion(-4.9667873268800355e-15, -0.9336830377578735, 1.1130367738587665e-7, -0.35810065269470215),
  scale: new Vector3(1.3049871921539307, 0.85685133934021, 1.000003695487976)
})
signpostTree20.addComponentOrReplace(transform195)

const armchairD5 = new Entity('armchairD5')
engine.addEntity(armchairD5)
armchairD5.setParent(_scene)
armchairD5.addComponentOrReplace(gltfShape7)
const transform196 = new Transform({
  position: new Vector3(1.0887458324432373, 13.1961030960083, 6.723842620849609),
  rotation: new Quaternion(-6.65064594497863e-16, 0.4713967442512512, -5.6194867426029305e-8, 0.8819212913513184),
  scale: new Vector3(1, 1, 1)
})
armchairD5.addComponentOrReplace(transform196)

const coffeeTable3 = new Entity('coffeeTable3')
engine.addEntity(coffeeTable3)
coffeeTable3.setParent(_scene)
coffeeTable3.addComponentOrReplace(gltfShape8)
const transform197 = new Transform({
  position: new Vector3(2.1004679203033447, 13.217625617980957, 8.065657615661621),
  rotation: new Quaternion(-3.4728681180275743e-15, 0.7040969729423523, -8.393488570845875e-8, -0.7101039290428162),
  scale: new Vector3(1.0000027418136597, 1, 1.0000027418136597)
})
coffeeTable3.addComponentOrReplace(transform197)

const armchairD6 = new Entity('armchairD6')
engine.addEntity(armchairD6)
armchairD6.setParent(_scene)
armchairD6.addComponentOrReplace(gltfShape7)
const transform198 = new Transform({
  position: new Vector3(1.0897173881530762, 13.1961030960083, 9.384245872497559),
  rotation: new Quaternion(-1.5283430513453496e-15, 0.8819212913513184, -1.0513319637084351e-7, 0.47139671444892883),
  scale: new Vector3(1.0000011920928955, 1, 1.0000011920928955)
})
armchairD6.addComponentOrReplace(transform198)

const armchairD7 = new Entity('armchairD7')
engine.addEntity(armchairD7)
armchairD7.setParent(_scene)
armchairD7.addComponentOrReplace(gltfShape7)
const transform199 = new Transform({
  position: new Vector3(14.903568267822266, 13.184867858886719, 9.384244918823242),
  rotation: new Quaternion(-5.148019343307513e-15, 0.8819212913513184, -1.0513320347627086e-7, -0.4713967442512512),
  scale: new Vector3(1.000001311302185, 1, 1.000001311302185)
})
armchairD7.addComponentOrReplace(transform199)

const armchairD8 = new Entity('armchairD8')
engine.addEntity(armchairD8)
armchairD8.setParent(_scene)
armchairD8.addComponentOrReplace(gltfShape7)
const transform200 = new Transform({
  position: new Vector3(14.911080360412598, 13.184866905212402, 6.723841667175293),
  rotation: new Quaternion(4.35375358405184e-15, 0.47139671444892883, -5.6194867426029305e-8, -0.8819212913513184),
  scale: new Vector3(1.0000005960464478, 1, 1.0000005960464478)
})
armchairD8.addComponentOrReplace(transform200)

const coffeeTable4 = new Entity('coffeeTable4')
engine.addEntity(coffeeTable4)
coffeeTable4.setParent(_scene)
coffeeTable4.addComponentOrReplace(gltfShape8)
const transform201 = new Transform({
  position: new Vector3(13.813565254211426, 13.206389427185059, 7.968564033508301),
  rotation: new Quaternion(1.1250501669602536e-14, -0.7101039290428162, 8.465097067755778e-8, -0.7040969729423523),
  scale: new Vector3(1.0000029802322388, 1, 1.0000029802322388)
})
coffeeTable4.addComponentOrReplace(transform201)

const wallPlainGlass11 = new Entity('wallPlainGlass11')
engine.addEntity(wallPlainGlass11)
wallPlainGlass11.setParent(_scene)
wallPlainGlass11.addComponentOrReplace(gltfShape2)
const transform202 = new Transform({
  position: new Vector3(6.443824768066406, 19.78186798095703, 0.02008984424173832),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(3.199953079223633, 3.9913971424102783, 0.1881696730852127)
})
wallPlainGlass11.addComponentOrReplace(transform202)

const wallPlainGlass13 = new Entity('wallPlainGlass13')
engine.addEntity(wallPlainGlass13)
wallPlainGlass13.setParent(_scene)
wallPlainGlass13.addComponentOrReplace(gltfShape2)
const transform203 = new Transform({
  position: new Vector3(9.847238540649414, 19.78186798095703, 0.020089441910386086),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.6997523307800293, 1.5673831701278687, 0.1881696730852127)
})
wallPlainGlass13.addComponentOrReplace(transform203)

const wallPlainGlass15 = new Entity('wallPlainGlass15')
engine.addEntity(wallPlainGlass15)
wallPlainGlass15.setParent(_scene)
wallPlainGlass15.addComponentOrReplace(gltfShape2)
const transform204 = new Transform({
  position: new Vector3(9.847238540649414, 13.203889846801758, 9.659360885620117),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.6997523307800293, 1.5790001153945923, 0.1881696730852127)
})
wallPlainGlass15.addComponentOrReplace(transform204)

const signpostTree21 = new Entity('signpostTree21')
engine.addEntity(signpostTree21)
signpostTree21.setParent(_scene)
const transform205 = new Transform({
  position: new Vector3(8.023031234741211, 19.762897491455078, 10.629568099975586),
  rotation: new Quaternion(-0.7071068286895752, 1.0340050518554359e-14, 8.429370268459024e-8, 0.7071068286895752),
  scale: new Vector3(1.3049815893173218, 0.8568520545959473, 1.0000007152557373)
})
signpostTree21.addComponentOrReplace(transform205)

const wallPlainBlack21 = new Entity('wallPlainBlack21')
engine.addEntity(wallPlainBlack21)
wallPlainBlack21.setParent(_scene)
wallPlainBlack21.addComponentOrReplace(gltfShape)
const transform206 = new Transform({
  position: new Vector3(9.211030006408691, 19.768604278564453, 10.598699569702148),
  rotation: new Quaternion(-0.7071068286895752, 4.108563803843085e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.190567970275879, 0.21347123384475708, 0.33308279514312744)
})
wallPlainBlack21.addComponentOrReplace(transform206)

const signpostTree22 = new Entity('signpostTree22')
engine.addEntity(signpostTree22)
signpostTree22.setParent(_scene)
const transform207 = new Transform({
  position: new Vector3(7.985696792602539, 19.762897491455078, 5.29841423034668),
  rotation: new Quaternion(-1.2644055402688537e-7, -0.70710688829422, -0.7071067690849304, 4.21468548950088e-8),
  scale: new Vector3(1.3049848079681396, 0.8568534851074219, 1.000002145767212)
})
signpostTree22.addComponentOrReplace(transform207)

const wallPlainBlack22 = new Entity('wallPlainBlack22')
engine.addEntity(wallPlainBlack22)
wallPlainBlack22.setParent(_scene)
wallPlainBlack22.addComponentOrReplace(gltfShape)
const transform208 = new Transform({
  position: new Vector3(6.797698020935059, 19.768604278564453, 5.329282760620117),
  rotation: new Quaternion(-1.2644053981603065e-7, -0.70710688829422, -0.7071067690849304, 4.214684778958144e-8),
  scale: new Vector3(1.1905701160430908, 0.21347159147262573, 0.3330831527709961)
})
wallPlainBlack22.addComponentOrReplace(transform208)

const signpostTree23 = new Entity('signpostTree23')
engine.addEntity(signpostTree23)
signpostTree23.setParent(_scene)
const transform209 = new Transform({
  position: new Vector3(5.3624773025512695, 19.762897491455078, 7.906163692474365),
  rotation: new Quaternion(0.5000001192092896, 0.5, 0.49999985098838806, -0.5000000596046448),
  scale: new Vector3(1.3049863576889038, 0.8568541407585144, 1.0000027418136597)
})
signpostTree23.addComponentOrReplace(transform209)

const wallPlainBlack23 = new Entity('wallPlainBlack23')
engine.addEntity(wallPlainBlack23)
wallPlainBlack23.setParent(_scene)
wallPlainBlack23.addComponentOrReplace(gltfShape)
const transform210 = new Transform({
  position: new Vector3(5.393345832824707, 19.768604278564453, 9.094161987304688),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.49999985098838806, -0.5000000596046448),
  scale: new Vector3(1.1905711889266968, 0.21347175538539886, 0.3330833315849304)
})
wallPlainBlack23.addComponentOrReplace(transform210)

const signpostTree24 = new Entity('signpostTree24')
engine.addEntity(signpostTree24)
signpostTree24.setParent(_scene)
const transform211 = new Transform({
  position: new Vector3(10.954354286193848, 19.762897491455078, 7.9195709228515625),
  rotation: new Quaternion(0.49999988079071045, -0.5000001192092896, -0.5000000596046448, -0.4999999403953552),
  scale: new Vector3(1.3049863576889038, 0.8568541407585144, 1.0000027418136597)
})
signpostTree24.addComponentOrReplace(transform211)

const wallPlainBlack24 = new Entity('wallPlainBlack24')
engine.addEntity(wallPlainBlack24)
wallPlainBlack24.setParent(_scene)
wallPlainBlack24.addComponentOrReplace(gltfShape)
const transform212 = new Transform({
  position: new Vector3(10.92348575592041, 19.768604278564453, 6.731573104858398),
  rotation: new Quaternion(0.49999988079071045, -0.5000001192092896, -0.5, -0.5),
  scale: new Vector3(1.1905711889266968, 0.21347175538539886, 0.3330833315849304)
})
wallPlainBlack24.addComponentOrReplace(transform212)

const wallPlainGlass7 = new Entity('wallPlainGlass7')
engine.addEntity(wallPlainGlass7)
wallPlainGlass7.setParent(_scene)
wallPlainGlass7.addComponentOrReplace(gltfShape2)
const transform213 = new Transform({
  position: new Vector3(15.983480453491211, 19.78186798095703, 0.02008870430290699),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(3.0752971172332764, 3.9913971424102783, 0.1881696730852127)
})
wallPlainGlass7.addComponentOrReplace(transform213)

const wallPlainGlass18 = new Entity('wallPlainGlass18')
engine.addEntity(wallPlainGlass18)
wallPlainGlass18.setParent(_scene)
wallPlainGlass18.addComponentOrReplace(gltfShape2)
const transform214 = new Transform({
  position: new Vector3(9.847238540649414, 13.203889846801758, 0.02008962631225586),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.6997523307800293, 1.5673831701278687, 0.1881696730852127)
})
wallPlainGlass18.addComponentOrReplace(transform214)

const wallPlainGlass24 = new Entity('wallPlainGlass24')
engine.addEntity(wallPlainGlass24)
wallPlainGlass24.setParent(_scene)
wallPlainGlass24.addComponentOrReplace(gltfShape2)
const transform215 = new Transform({
  position: new Vector3(6.443824768066406, 13.203889846801758, 0.02008962631225586),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(3.199953079223633, 3.9913971424102783, 0.1881696730852127)
})
wallPlainGlass24.addComponentOrReplace(transform215)

const wallPlainGlass27 = new Entity('wallPlainGlass27')
engine.addEntity(wallPlainGlass27)
wallPlainGlass27.setParent(_scene)
wallPlainGlass27.addComponentOrReplace(gltfShape2)
const transform216 = new Transform({
  position: new Vector3(9.847238540649414, 19.78186798095703, 9.659360885620117),
  rotation: new Quaternion(0.7071068286895752, -1.1038385137852273e-15, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.6997523307800293, 1.5790001153945923, 0.1881696730852127)
})
wallPlainGlass27.addComponentOrReplace(transform216)

const wallPlainBlack25 = new Entity('wallPlainBlack25')
engine.addEntity(wallPlainBlack25)
wallPlainBlack25.setParent(_scene)
wallPlainBlack25.addComponentOrReplace(gltfShape)
const transform217 = new Transform({
  position: new Vector3(11.23321533203125, 16.811290740966797, 13.46823787689209),
  rotation: new Quaternion(1.5165260946982048e-15, 0.9238795638084412, -1.1013501222123523e-7, -0.3826834559440613),
  scale: new Vector3(1.1905736923217773, 0.21347105503082275, 0.3330838084220886)
})
wallPlainBlack25.addComponentOrReplace(transform217)

const signpostTree25 = new Entity('signpostTree25')
engine.addEntity(signpostTree25)
signpostTree25.setParent(_scene)
const transform218 = new Transform({
  position: new Vector3(12.077291488647461, 16.780420303344727, 12.632229804992676),
  rotation: new Quaternion(6.105640488638861e-15, 0.9238795638084412, -1.1013501932666259e-7, -0.3826834559440613),
  scale: new Vector3(1.3049862384796143, 0.85685133934021, 1.0000028610229492)
})
signpostTree25.addComponentOrReplace(transform218)

const signpostTree26 = new Entity('signpostTree26')
engine.addEntity(signpostTree26)
signpostTree26.setParent(_scene)
const transform219 = new Transform({
  position: new Vector3(3.7039389610290527, 16.67340850830078, 3.725278854370117),
  rotation: new Quaternion(1.3238797799108837e-15, -0.3826834559440613, 4.5619408695074526e-8, -0.9238795638084412),
  scale: new Vector3(1.304985523223877, 0.85685133934021, 1.0000025033950806)
})
signpostTree26.addComponentOrReplace(transform219)

const wallPlainBlack26 = new Entity('wallPlainBlack26')
engine.addEntity(wallPlainBlack26)
wallPlainBlack26.setParent(_scene)
wallPlainBlack26.addComponentOrReplace(gltfShape)
const transform220 = new Transform({
  position: new Vector3(4.548015117645264, 16.70427894592285, 2.889270782470703),
  rotation: new Quaternion(8.42930681987453e-15, -0.3826834559440613, 4.5619415800501883e-8, -0.9238795638084412),
  scale: new Vector3(1.1905717849731445, 0.21347105503082275, 0.3330836296081543)
})
wallPlainBlack26.addComponentOrReplace(transform220)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script1.spawn(nftPictureFrame8, {"id":"72405646120007613708465591283795435405784754144165659770746301100862491066369","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script1.spawn(nftPictureFrame9, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script1.spawn(nftPictureFrame16, {"id":"72405646120007613708465591283795435405784754144165659770746301144842956177409","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame16, channelBus))
script1.spawn(nftPictureFrame17, {"id":"72405646120007613708465591283795435405784754144165659770746301134947351527425","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script2.spawn(signpostTree, {"text":"Snatch Up These\nCrypto Collectibles For\nSale Now At OpenSea!","fontSize":35}, createChannel(channelId, signpostTree, channelBus))
script2.spawn(signpostTree3, {"text":"Ignore “NOT \nFOR SALE” \nText In UI","fontSize":45}, createChannel(channelId, signpostTree3, channelBus))
script1.spawn(nftPictureFrame31, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame31, channelBus))
script1.spawn(nftPictureFrame34, {"id":"72405646120007613708465591283795435405784754144165659770746301128350281760769","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame34, channelBus))
script1.spawn(nftPictureFrame35, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame35, channelBus))
script1.spawn(nftPictureFrame37, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame37, channelBus))
script1.spawn(nftPictureFrame38, {"id":"72405646120007613708465591283795435405784754144165659770746301119554188738561","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame38, channelBus))
script1.spawn(nftPictureFrame39, {"id":"72405646120007613708465591283795435405784754144165659770746301117355165483009","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame39, channelBus))
script1.spawn(nftPictureFrame64, {"id":"72405646120007613708465591283795435405784754144165659770746301172330746871809","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .08 ETH"}, createChannel(channelId, nftPictureFrame64, channelBus))
script1.spawn(nftPictureFrame65, {"id":"72405646120007613708465591283795435405784754144165659770746301163534653849601","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame65, channelBus))
script1.spawn(nftPictureFrame68, {"id":"72405646120007613708465591283795435405784754144165659770746301123952235249665","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame68, channelBus))
script1.spawn(nftPictureFrame69, {"id":"72405646120007613708465591283795435405784754144165659770746301089867374788609","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame69, channelBus))
script1.spawn(nftPictureFrame72, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame72, channelBus))
script1.spawn(nftPictureFrame41, {"id":"72405646120007613708465591283795435405784754144165659770746301063479095721985","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame41, channelBus))
script1.spawn(nftPictureFrame42, {"id":"72405646120007613708465591283795435405784754144165659770746301062379584094209","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame42, channelBus))
script3.spawn(verticalBlackPad, {"distance":55,"speed":20,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad, channelBus))
script4.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script5.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad","actionId":"goToStart","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script3.spawn(verticalBlackPad2, {"distance":140,"speed":10,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad2","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad2, channelBus))
script1.spawn(nftPictureFrame43, {"id":"72405646120007613708465591283795435405784754144165659770746301133847839899649","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame43, channelBus))
script1.spawn(nftPictureFrame44, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame44, channelBus))
script1.spawn(nftPictureFrame49, {"id":"72405646120007613708465591283795435405784754144165659770746301143743444549633","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame49, channelBus))
script1.spawn(nftPictureFrame50, {"id":"72405646120007613708465591283795435405784754144165659770746301145942467805185","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame50, channelBus))
script1.spawn(nftPictureFrame51, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame51, channelBus))
script1.spawn(nftPictureFrame52, {"id":"72405646120007613708465591283795435405784754144165659770746301171231235244033","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame52, channelBus))
script1.spawn(nftPictureFrame53, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame53, channelBus))
script1.spawn(nftPictureFrame54, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame54, channelBus))
script1.spawn(nftPictureFrame55, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame55, channelBus))
script1.spawn(nftPictureFrame56, {"id":"72405646120007613708465591283795435405784754144165659770746301131648816644097","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame56, channelBus))
script1.spawn(nftPictureFrame57, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame57, channelBus))
script1.spawn(nftPictureFrame58, {"id":"72405646120007613708465591283795435405784754144165659770746301150340514316289","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame58, channelBus))
script1.spawn(nftPictureFrame59, {"id":"72405646120007613708465591283795435405784754144165659770746301139345398038529","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame59, channelBus))
script1.spawn(nftPictureFrame60, {"id":"72405646120007613708465591283795435405784754144165659770746301147041979432961","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame60, channelBus))
script1.spawn(nftPictureFrame66, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame66, channelBus))
script1.spawn(nftPictureFrame67, {"id":"72405646120007613708465591283795435405784754144165659770746301112957118971905","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame67, channelBus))
script1.spawn(nftPictureFrame70, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame70, channelBus))
script1.spawn(nftPictureFrame71, {"id":"72405646120007613708465591283795435405784754144165659770746301142643932921857","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame71, channelBus))
script1.spawn(nftPictureFrame73, {"id":"72405646120007613708465591283795435405784754144165659770746301149241002688513","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame73, channelBus))
script5.spawn(triggerArea2, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad2","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, triggerArea2, channelBus))
script5.spawn(triggerArea3, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad5","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad5","actionId":"goToEnd","values":{}}]}, createChannel(channelId, triggerArea3, channelBus))
script1.spawn(nftPictureFrame5, {"id":"72405646120007613708465591283795435405784754144165659770746301148141491060737","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script1.spawn(nftPictureFrame6, {"id":"72405646120007613708465591283795435405784754144165659770746301133847839899649","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script1.spawn(nftPictureFrame10, {"id":"72405646120007613708465591283795435405784754144165659770746301153639049199617","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script1.spawn(nftPictureFrame12, {"id":"72405646120007613708465591283795435405784754144165659770746301121753211994113","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script1.spawn(nftPictureFrame13, {"id":"72405646120007613708465591283795435405784754144165659770746301147041979432961","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame13, channelBus))
script1.spawn(nftPictureFrame15, {"id":"72405646120007613708465591283795435405784754144165659770746301108559072460801","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame15, channelBus))
script1.spawn(nftPictureFrame18, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script1.spawn(nftPictureFrame27, {"id":"72405646120007613708465591283795435405784754144165659770746301163534653849601","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame27, channelBus))
script1.spawn(nftPictureFrame29, {"id":"72405646120007613708465591283795435405784754144165659770746301061280072466433","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame29, channelBus))
script1.spawn(nftPictureFrame30, {"id":"72405646120007613708465591283795435405784754144165659770746301138245886410753","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script5.spawn(triggerArea4, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad3","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad3","actionId":"goToEnd","values":{}}]}, createChannel(channelId, triggerArea4, channelBus))
script3.spawn(verticalBlackPad3, {"distance":210,"speed":10,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad3","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad3, channelBus))
script1.spawn(nftPictureFrame36, {"id":"72405646120007613708465591283795435405784754144165659770746301120653700366337","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame36, channelBus))
script1.spawn(nftPictureFrame45, {"id":"72405646120007613708465591283795435405784754144165659770746301133847839899649","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame45, channelBus))
script1.spawn(nftPictureFrame46, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame46, channelBus))
script1.spawn(nftPictureFrame47, {"id":"72405646120007613708465591283795435405784754144165659770746301093165909671937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame47, channelBus))
script1.spawn(nftPictureFrame48, {"id":"72405646120007613708465591283795435405784754144165659770746301109658584088577","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame48, channelBus))
script1.spawn(nftPictureFrame61, {"id":"72405646120007613708465591283795435405784754144165659770746301144842956177409","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame61, channelBus))
script1.spawn(nftPictureFrame62, {"id":"72405646120007613708465591283795435405784754144165659770746301141544421294081","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame62, channelBus))
script1.spawn(nftPictureFrame63, {"id":"72405646120007613708465591283795435405784754144165659770746301171231235244033","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame63, channelBus))
script1.spawn(nftPictureFrame74, {"id":"72405646120007613708465591283795435405784754144165659770746301127250770132993","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame74, channelBus))
script1.spawn(nftPictureFrame75, {"id":"72405646120007613708465591283795435405784754144165659770746301117355165483009","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame75, channelBus))
script5.spawn(triggerArea5, {"enabled":true,"onEnter":[{"entityName":"verticalBlackPad4","actionId":"goToEnd","values":{}}],"onLeave":[{"entityName":"verticalBlackPad4","actionId":"goToEnd","values":{}}]}, createChannel(channelId, triggerArea5, channelBus))
script3.spawn(verticalBlackPad4, {"distance":140,"speed":10,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad4","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad4, channelBus))
script3.spawn(verticalBlackPad5, {"distance":210,"speed":10,"autoStart":false,"onReachEnd":[{"entityName":"verticalBlackPad5","actionId":"goToStart","values":{}}],"onReachStart":[]}, createChannel(channelId, verticalBlackPad5, channelBus))
script1.spawn(nftPictureFrame, {"id":"72405646120007613708465591283795435405784754144165659770746301126151258505217","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script1.spawn(nftPictureFrame2, {"id":"72405646120007613708465591283795435405784754144165659770746301115156142227457","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .03 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script1.spawn(nftPictureFrame3, {"id":"72405646120007613708465591283795435405784754144165659770746301166833188732929","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 2\nPrice: .06 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script1.spawn(nftPictureFrame4, {"id":"72405646120007613708465591283795435405784754144165659770746301163534653849601","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 3\nPrice: .12 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script2.spawn(signpostTree2, {"text":"Ignore “NOT \nFOR SALE” \nText In UI","fontSize":45}, createChannel(channelId, signpostTree2, channelBus))
script2.spawn(signpostTree4, {"text":"Snatch Up These\nCrypto Collectibles For\nSale Now At OpenSea!","fontSize":35}, createChannel(channelId, signpostTree4, channelBus))
script6.spawn(radio, {"startOn":true,"volume":1,"onClickText":"Radio On/Off","onClick":[{"entityName":"radio","actionId":"toggle","values":{}}],"customStation":"https://gateway.pinata.cloud/ipfs/Qmbvps2kDnrUcAMc7hJq9kJoAfFNEixbFEQkyGQKJdPT6n"}, createChannel(channelId, radio, channelBus))
script2.spawn(signpostTree5, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree5, channelBus))
script2.spawn(signpostTree6, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree6, channelBus))
script2.spawn(signpostTree7, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree7, channelBus))
script2.spawn(signpostTree8, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree8, channelBus))
script2.spawn(signpostTree9, {"text":"To Rooftop","fontSize":40}, createChannel(channelId, signpostTree9, channelBus))
script2.spawn(signpostTree10, {"text":"To Rooftop","fontSize":40}, createChannel(channelId, signpostTree10, channelBus))
script2.spawn(signpostTree11, {"text":"To Third Floor","fontSize":40}, createChannel(channelId, signpostTree11, channelBus))
script2.spawn(signpostTree12, {"text":"To Third Floor","fontSize":40}, createChannel(channelId, signpostTree12, channelBus))
script1.spawn(nftPictureFrame7, {"id":"72405646120007613708465591283795435405784754144165659770746301158037095710721","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script1.spawn(nftPictureFrame11, {"id":"72405646120007613708465591283795435405784754144165659770746301155838072455169","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script1.spawn(nftPictureFrame14, {"id":"72405646120007613708465591283795435405784754144165659770746301156937584082945","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script1.spawn(nftPictureFrame19, {"id":"72405646120007613708465591283795435405784754144165659770746301152539537571841","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame19, channelBus))
script2.spawn(signpostTree13, {"text":"Roadside\nArtHaus","fontSize":60}, createChannel(channelId, signpostTree13, channelBus))
script2.spawn(signpostTree14, {"text":"Roadside\nArtHaus","fontSize":60}, createChannel(channelId, signpostTree14, channelBus))
script2.spawn(signpostTree15, {"text":"Roadside\nArtHaus","fontSize":60}, createChannel(channelId, signpostTree15, channelBus))
script2.spawn(signpostTree16, {"text":"Roadside\nArtHaus","fontSize":60}, createChannel(channelId, signpostTree16, channelBus))
script1.spawn(nftPictureFrame22, {"id":"72405646120007613708465591283795435405784754144165659770746301164634165477377","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script1.spawn(nftPictureFrame23, {"id":"72405646120007613708465591283795435405784754144165659770746301156937584082945","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame23, channelBus))
script1.spawn(nftPictureFrame24, {"id":"72405646120007613708465591283795435405784754144165659770746301160236118966273","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame24, channelBus))
script1.spawn(nftPictureFrame25, {"id":"72405646120007613708465591283795435405784754144165659770746301159136607338497","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1 of 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame25, channelBus))
script2.spawn(signpostTree17, {"text":"To Rooftop","fontSize":40}, createChannel(channelId, signpostTree17, channelBus))
script2.spawn(signpostTree18, {"text":"To Rooftop","fontSize":40}, createChannel(channelId, signpostTree18, channelBus))
script2.spawn(signpostTree19, {"text":"To Third Floor","fontSize":40}, createChannel(channelId, signpostTree19, channelBus))
script2.spawn(signpostTree20, {"text":"To Third Floor","fontSize":40}, createChannel(channelId, signpostTree20, channelBus))
script2.spawn(signpostTree21, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree21, channelBus))
script2.spawn(signpostTree22, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree22, channelBus))
script2.spawn(signpostTree23, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree23, channelBus))
script2.spawn(signpostTree24, {"text":"To Second Floor","fontSize":40}, createChannel(channelId, signpostTree24, channelBus))
script2.spawn(signpostTree25, {"text":"To Rooftop","fontSize":40}, createChannel(channelId, signpostTree25, channelBus))
script2.spawn(signpostTree26, {"text":"To Rooftop","fontSize":40}, createChannel(channelId, signpostTree26, channelBus))