import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../b853061a-bf5a-4d76-b7f1-92ed9ea4a8bf/src/item"
import Script2 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script3 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script4 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script5 from "../3cf05054-0a57-4b00-ba77-a3f21876494d/src/item"
import Script6 from "../8d62d5a3-411c-43f8-a438-574ccf3d0fbe/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("da1fed3c954172146414a66adfa134f7a5e1cb49c902713481bf2fe94180c2cf/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const shroomChateauFinal = new Entity('shroomChateauFinal')
engine.addEntity(shroomChateauFinal)
shroomChateauFinal.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(8, 9.655184745788574, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5929985046386719, 2.5158255100250244, 1.5929985046386719)
})
shroomChateauFinal.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("21736cf87999afc95aeb29fdb397afcad68637e208645bc7436ff812c0d9e66a/shroom chateau final.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
shroomChateauFinal.addComponentOrReplace(gltfShape2)

const stairsSpiral = new Entity('stairsSpiral')
engine.addEntity(stairsSpiral)
stairsSpiral.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(8, 0, 7.694108009338379),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral.addComponentOrReplace(transform4)
const gltfShape3 = new GLTFShape("7ad467d63d496decec898c7fce7b617d49f13761363e9374f11e0f75d440814d/SpiralStairs.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
stairsSpiral.addComponentOrReplace(gltfShape3)

const stairsSpiral2 = new Entity('stairsSpiral2')
engine.addEntity(stairsSpiral2)
stairsSpiral2.setParent(_scene)
stairsSpiral2.addComponentOrReplace(gltfShape3)
const transform5 = new Transform({
  position: new Vector3(8, 4, 7.694108009338379),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral2.addComponentOrReplace(transform5)

const stairsSpiral3 = new Entity('stairsSpiral3')
engine.addEntity(stairsSpiral3)
stairsSpiral3.setParent(_scene)
stairsSpiral3.addComponentOrReplace(gltfShape3)
const transform6 = new Transform({
  position: new Vector3(8, 8, 7.694108009338379),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral3.addComponentOrReplace(transform6)

const stairsSpiral4 = new Entity('stairsSpiral4')
engine.addEntity(stairsSpiral4)
stairsSpiral4.setParent(_scene)
stairsSpiral4.addComponentOrReplace(gltfShape3)
const transform7 = new Transform({
  position: new Vector3(8, 12, 7.694108009338379),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stairsSpiral4.addComponentOrReplace(transform7)

const invisibleCylinder = new Entity('invisibleCylinder')
engine.addEntity(invisibleCylinder)
invisibleCylinder.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(8.000000953674316, 10.423158645629883, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(15.854578971862793, 0.03125, 15.97305679321289)
})
invisibleCylinder.addComponentOrReplace(transform8)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(8, 9.591974258422852, 7.931771278381348),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.869709014892578, 1.5264780521392822, 5.320813179016113)
})
triggerArea.addComponentOrReplace(transform9)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(7.994338035583496, 10.829065322875977, 15.811873435974121),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.0597550868988037, 7.49750280380249, 0.0625)
})
invisibleWall.addComponentOrReplace(transform10)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(7.994338035583496, 10.82908821105957, 0.17687225341796875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0625)
})
invisibleWall2.addComponentOrReplace(transform11)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(15.811840057373047, 10.829087257385254, 7.9943718910217285),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0597553253173828, 0.31270503997802734, 0.0625000149011612)
})
invisibleWall3.addComponentOrReplace(transform12)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(0.17683649063110352, 10.829089164733887, 7.994373798370361),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0597553253173828, 0.31270503997802734, 0.0625000149011612)
})
invisibleWall4.addComponentOrReplace(transform13)

const invisibleWall5 = new Entity('invisibleWall5')
engine.addEntity(invisibleWall5)
invisibleWall5.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(13.522146224975586, 10.829086303710938, 2.4665637016296387),
  rotation: new Quaternion(-1.5792435904864654e-15, 0.9238796234130859, -1.1013502643208994e-7, 0.38268348574638367),
  scale: new Vector3(1.059755802154541, 0.31270503997802734, 0.06250003725290298)
})
invisibleWall5.addComponentOrReplace(transform14)

const invisibleWall6 = new Entity('invisibleWall6')
engine.addEntity(invisibleWall6)
invisibleWall6.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(2.4665307998657227, 10.829090118408203, 13.52218246459961),
  rotation: new Quaternion(-1.579243484607347e-15, 0.9238795638084412, -1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.0597560405731201, 0.701763927936554, 0.06250004470348358)
})
invisibleWall6.addComponentOrReplace(transform15)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(13.522146224975586, 10.82908821105957, 13.522180557250977),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(1.0597550868988037, 0.6873777508735657, 0.0625)
})
invisibleWall7.addComponentOrReplace(transform16)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(2.4665298461914062, 10.82908821105957, 2.4665660858154297),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0625)
})
invisibleWall8.addComponentOrReplace(transform17)

const invisibleWall9 = new Entity('invisibleWall9')
engine.addEntity(invisibleWall9)
invisibleWall9.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(10.985965728759766, 10.829086303710938, 0.7719426155090332),
  rotation: new Quaternion(-3.3252556863095674e-15, 0.9807853698730469, -1.1691872003893877e-7, 0.19509032368659973),
  scale: new Vector3(1.0597562789916992, 0.31270503997802734, 0.06250005960464478)
})
invisibleWall9.addComponentOrReplace(transform18)

const invisibleWall10 = new Entity('invisibleWall10')
engine.addEntity(invisibleWall10)
invisibleWall10.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(5.002711296081543, 10.829113006591797, 15.216803550720215),
  rotation: new Quaternion(-3.3252556863095674e-15, 0.9807853698730469, -1.1691872003893877e-7, 0.19509032368659973),
  scale: new Vector3(1.0597591400146484, 7.49750280380249, 0.06250018626451492)
})
invisibleWall10.addComponentOrReplace(transform19)

const invisibleWall11 = new Entity('invisibleWall11')
engine.addEntity(invisibleWall11)
invisibleWall11.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(15.216768264770508, 10.82908821105957, 10.986000061035156),
  rotation: new Quaternion(-1.1059565196698366e-15, 0.5555702447891235, -6.622913417686505e-8, 0.8314696550369263),
  scale: new Vector3(1.0597552061080933, 0.31270503997802734, 0.0625)
})
invisibleWall11.addComponentOrReplace(transform20)

const invisibleWall12 = new Entity('invisibleWall12')
engine.addEntity(invisibleWall12)
invisibleWall12.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(0.771909236907959, 10.82908821105957, 5.00274658203125),
  rotation: new Quaternion(-1.1059565196698366e-15, 0.5555702447891235, -6.622913417686505e-8, 0.8314696550369263),
  scale: new Vector3(1.0597552061080933, 0.31270503997802734, 0.0625)
})
invisibleWall12.addComponentOrReplace(transform21)

const invisibleWall13 = new Entity('invisibleWall13')
engine.addEntity(invisibleWall13)
invisibleWall13.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(15.216768264770508, 10.829087257385254, 5.002743244171143),
  rotation: new Quaternion(-3.286192856122804e-15, 0.831469714641571, -9.911890685998515e-8, 0.5555703043937683),
  scale: new Vector3(1.059755802154541, 0.31270503997802734, 0.06250004470348358)
})
invisibleWall13.addComponentOrReplace(transform22)

const invisibleWall14 = new Entity('invisibleWall14')
engine.addEntity(invisibleWall14)
invisibleWall14.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(5.00270938873291, 10.82908821105957, 0.7719440460205078),
  rotation: new Quaternion(0, 0.19509033858776093, -2.3256577108554666e-8, 0.9807853102684021),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0625)
})
invisibleWall14.addComponentOrReplace(transform23)

const invisibleWall15 = new Entity('invisibleWall15')
engine.addEntity(invisibleWall15)
invisibleWall15.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(0.7719087600708008, 10.82908821105957, 10.986002922058105),
  rotation: new Quaternion(-3.2861924326063304e-15, 0.8314695954322815, -9.911889264913043e-8, 0.5555702447891235),
  scale: new Vector3(1.0597556829452515, 0.701763927936554, 0.06250003725290298)
})
invisibleWall15.addComponentOrReplace(transform24)

const invisibleWall16 = new Entity('invisibleWall16')
engine.addEntity(invisibleWall16)
invisibleWall16.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(10.985966682434082, 10.829065322875977, 15.216801643371582),
  rotation: new Quaternion(0, 0.19509033858776093, -2.3256577108554666e-8, 0.9807853102684021),
  scale: new Vector3(1.0597550868988037, 7.49750280380249, 0.0625)
})
invisibleWall16.addComponentOrReplace(transform25)

const invisibleWall17 = new Entity('invisibleWall17')
engine.addEntity(invisibleWall17)
invisibleWall17.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(9.519455909729004, 10.829086303710938, 0.32708168029785156),
  rotation: new Quaternion(-4.197421795174797e-15, 0.9951847791671753, -1.1863526339084274e-7, 0.0980171337723732),
  scale: new Vector3(1.0597567558288574, 0.31270503997802734, 0.06250009685754776)
})
invisibleWall17.addComponentOrReplace(transform26)

const invisibleWall18 = new Entity('invisibleWall18')
engine.addEntity(invisibleWall18)
invisibleWall18.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(6.469221115112305, 10.829113006591797, 15.661664962768555),
  rotation: new Quaternion(-4.197421795174797e-15, 0.9951847791671753, -1.1863526339084274e-7, 0.0980171337723732),
  scale: new Vector3(1.0597578287124634, 7.49750280380249, 0.06250017136335373)
})
invisibleWall18.addComponentOrReplace(transform27)

const invisibleWall19 = new Entity('invisibleWall19')
engine.addEntity(invisibleWall19)
invisibleWall19.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(15.661628723144531, 10.82908821105957, 9.519490242004395),
  rotation: new Quaternion(-1.9888094314723373e-15, 0.6343932747840881, -7.56255715828047e-8, 0.7730104923248291),
  scale: new Vector3(1.0597553253173828, 0.31270503997802734, 0.0625000074505806)
})
invisibleWall19.addComponentOrReplace(transform28)

const invisibleWall20 = new Entity('invisibleWall20')
engine.addEntity(invisibleWall20)
invisibleWall20.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(0.32704877853393555, 10.82908821105957, 6.4692559242248535),
  rotation: new Quaternion(-1.9888094314723373e-15, 0.6343932747840881, -7.56255715828047e-8, 0.7730104923248291),
  scale: new Vector3(1.0597553253173828, 0.31270503997802734, 0.0625000074505806)
})
invisibleWall20.addComponentOrReplace(transform29)

const invisibleWall21 = new Entity('invisibleWall21')
engine.addEntity(invisibleWall21)
invisibleWall21.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(14.494353294372559, 10.829087257385254, 3.651200294494629),
  rotation: new Quaternion(-4.158547218060561e-15, 0.8819212317466736, -1.0513319637084351e-7, 0.4713967442512512),
  scale: new Vector3(1.059755563735962, 0.31270503997802734, 0.06250003725290298)
})
invisibleWall21.addComponentOrReplace(transform30)

const invisibleWall22 = new Entity('invisibleWall22')
engine.addEntity(invisibleWall22)
invisibleWall22.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(3.6511664390563965, 10.82908821105957, 1.4943585395812988),
  rotation: new Quaternion(0, 0.2902846932411194, -3.4604628496026635e-8, 0.9569403529167175),
  scale: new Vector3(1.0597549676895142, 0.31270503997802734, 0.0624999962747097)
})
invisibleWall22.addComponentOrReplace(transform31)

const invisibleWall23 = new Entity('invisibleWall23')
engine.addEntity(invisibleWall23)
invisibleWall23.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(1.49432373046875, 10.82908821105957, 12.337545394897461),
  rotation: new Quaternion(-4.158547641577035e-15, 0.8819212913513184, -1.0513320347627086e-7, 0.4713967740535736),
  scale: new Vector3(1.0597560405731201, 0.701763927936554, 0.06250005960464478)
})
invisibleWall23.addComponentOrReplace(transform32)

const invisibleWall24 = new Entity('invisibleWall24')
engine.addEntity(invisibleWall24)
invisibleWall24.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(12.337509155273438, 10.82908821105957, 14.494386672973633),
  rotation: new Quaternion(0, 0.2902846932411194, -3.4604628496026635e-8, 0.9569403529167175),
  scale: new Vector3(1.0597549676895142, 0.6873777508735657, 0.0624999925494194)
})
invisibleWall24.addComponentOrReplace(transform33)

const invisibleWall25 = new Entity('invisibleWall25')
engine.addEntity(invisibleWall25)
invisibleWall25.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(9.51945686340332, 10.829065322875977, 15.661663055419922),
  rotation: new Quaternion(0, 0.0980171412229538, -1.1684551992630077e-8, 0.9951847195625305),
  scale: new Vector3(1.059755563735962, 7.49750280380249, 0.0624999962747097)
})
invisibleWall25.addComponentOrReplace(transform34)

const invisibleWall26 = new Entity('invisibleWall26')
engine.addEntity(invisibleWall26)
invisibleWall26.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(12.337509155273438, 10.829086303710938, 1.4943575859069824),
  rotation: new Quaternion(-2.4598175601443784e-15, 0.9569404125213623, -1.1407617250824842e-7, 0.2902846932411194),
  scale: new Vector3(1.0597561597824097, 0.31270503997802734, 0.06250005960464478)
})
invisibleWall26.addComponentOrReplace(transform35)

const invisibleWall27 = new Entity('invisibleWall27')
engine.addEntity(invisibleWall27)
invisibleWall27.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(14.494352340698242, 10.82908821105957, 12.337543487548828),
  rotation: new Quaternion(-6.65064594497863e-16, 0.4713967442512512, -5.6194867426029305e-8, 0.8819212913513184),
  scale: new Vector3(1.059755802154541, 0.6873777508735657, 0.0625)
})
invisibleWall27.addComponentOrReplace(transform36)

const invisibleWall28 = new Entity('invisibleWall28')
engine.addEntity(invisibleWall28)
invisibleWall28.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(15.661628723144531, 10.829087257385254, 6.469253063201904),
  rotation: new Quaternion(-2.420181076894087e-15, 0.7730104923248291, -9.215002449991516e-8, 0.6343933343887329),
  scale: new Vector3(1.059755563735962, 0.31270503997802734, 0.06250002980232239)
})
invisibleWall28.addComponentOrReplace(transform37)

const invisibleWall29 = new Entity('invisibleWall29')
engine.addEntity(invisibleWall29)
invisibleWall29.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(6.469219207763672, 10.82908821105957, 0.32708311080932617),
  rotation: new Quaternion(0, 0.0980171412229538, -1.1684551992630077e-8, 0.9951847195625305),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0624999962747097)
})
invisibleWall29.addComponentOrReplace(transform38)

const invisibleWall30 = new Entity('invisibleWall30')
engine.addEntity(invisibleWall30)
invisibleWall30.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(3.6511683464050293, 10.829090118408203, 14.494388580322266),
  rotation: new Quaternion(-2.4598175601443784e-15, 0.9569404125213623, -1.1407617250824842e-7, 0.2902846932411194),
  scale: new Vector3(1.0597569942474365, 0.701763927936554, 0.06250008940696716)
})
invisibleWall30.addComponentOrReplace(transform39)

const invisibleWall31 = new Entity('invisibleWall31')
engine.addEntity(invisibleWall31)
invisibleWall31.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(0.32704782485961914, 10.829089164733887, 9.519493103027344),
  rotation: new Quaternion(-2.420181076894087e-15, 0.7730104923248291, -9.215002449991516e-8, 0.6343933343887329),
  scale: new Vector3(1.059755563735962, 0.31270503997802734, 0.06250002980232239)
})
invisibleWall31.addComponentOrReplace(transform40)

const invisibleWall32 = new Entity('invisibleWall32')
engine.addEntity(invisibleWall32)
invisibleWall32.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(1.49432373046875, 10.82908821105957, 3.6512036323547363),
  rotation: new Quaternion(-6.65064594497863e-16, 0.4713967442512512, -5.6194867426029305e-8, 0.8819212913513184),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0625)
})
invisibleWall32.addComponentOrReplace(transform41)

const invisibleWall33 = new Entity('invisibleWall33')
engine.addEntity(invisibleWall33)
invisibleWall33.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(14.037833213806152, 10.829087257385254, 3.0355916023254395),
  rotation: new Quaternion(-5.039273865407217e-15, 0.9039684534072876, -1.077614300015739e-7, 0.42759931087493896),
  scale: new Vector3(1.0597559213638306, 0.31270503997802734, 0.06250005960464478)
})
invisibleWall33.addComponentOrReplace(transform42)

const invisibleWall34 = new Entity('invisibleWall34')
engine.addEntity(invisibleWall34)
invisibleWall34.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(11.680156707763672, 10.829086303710938, 1.1003117561340332),
  rotation: new Quaternion(-2.899439094714148e-15, 0.9700194597244263, -1.1563531643332681e-7, 0.24302759766578674),
  scale: new Vector3(1.0597567558288574, 0.31270503997802734, 0.06250009685754776)
})
invisibleWall34.addComponentOrReplace(transform43)

const invisibleWall35 = new Entity('invisibleWall35')
engine.addEntity(invisibleWall35)
invisibleWall35.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(10.264369010925293, 10.829086303710938, 0.5137119293212891),
  rotation: new Quaternion(-4.208421788544315e-15, 0.9891694784164429, -1.1791818366191364e-7, 0.14677880704402924),
  scale: new Vector3(1.0597572326660156, 0.31270503997802734, 0.06250011175870895)
})
invisibleWall35.addComponentOrReplace(transform44)

const invisibleWall36 = new Entity('invisibleWall36')
engine.addEntity(invisibleWall36)
invisibleWall36.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(8.761345863342285, 10.829086303710938, 0.21458911895751953),
  rotation: new Quaternion(-5.524133735623944e-15, 0.9987931251525879, -1.1906541175221719e-7, 0.04911646991968155),
  scale: new Vector3(1.059757113456726, 0.31270503997802734, 0.06250011920928955)
})
invisibleWall36.addComponentOrReplace(transform45)

const invisibleWall37 = new Entity('invisibleWall37')
engine.addEntity(invisibleWall37)
invisibleWall37.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(7.228848934173584, 10.82908821105957, 0.21444082260131836),
  rotation: new Quaternion(5.2039702502221835e-18, 0.04901887848973274, -5.843504347069484e-9, 0.9987978935241699),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0625)
})
invisibleWall37.addComponentOrReplace(transform46)

const invisibleWall38 = new Entity('invisibleWall38')
engine.addEntity(invisibleWall38)
invisibleWall38.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(14.889119148254395, 10.829087257385254, 4.309900283813477),
  rotation: new Quaternion(-4.167529155433246e-15, 0.8577035069465637, -1.0224621860288607e-7, 0.5141446590423584),
  scale: new Vector3(1.059755802154541, 0.31270503997802734, 0.06250004470348358)
})
invisibleWall38.addComponentOrReplace(transform47)

const invisibleWall39 = new Entity('invisibleWall39')
engine.addEntity(invisibleWall39)
invisibleWall39.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(15.475442886352539, 10.829087257385254, 5.725801944732666),
  rotation: new Quaternion(-2.8580596294166443e-15, 0.8031784892082214, -9.574632997555454e-8, 0.5957386493682861),
  scale: new Vector3(1.0597561597824097, 0.31270503997802734, 0.06250006705522537)
})
invisibleWall39.addComponentOrReplace(transform48)

const invisibleWall40 = new Entity('invisibleWall40')
engine.addEntity(invisibleWall40)
invisibleWall40.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(12.95429801940918, 10.829086303710938, 1.9518461227416992),
  rotation: new Quaternion(-2.463532223134562e-15, 0.9415276646614075, -1.1223883689126524e-7, 0.3369358777999878),
  scale: new Vector3(1.0597562789916992, 0.31270503997802734, 0.06250006705522537)
})
invisibleWall40.addComponentOrReplace(transform49)

const invisibleWall41 = new Entity('invisibleWall41')
engine.addEntity(invisibleWall41)
invisibleWall41.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(15.774271011352539, 10.829087257385254, 7.228882789611816),
  rotation: new Quaternion(-1.9779741860110603e-15, 0.7409183979034424, -8.832434872374506e-8, 0.6715952157974243),
  scale: new Vector3(1.0597556829452515, 0.31270503997802734, 0.06250003725290298)
})
invisibleWall41.addComponentOrReplace(transform50)

const invisibleWall42 = new Entity('invisibleWall42')
engine.addEntity(invisibleWall42)
invisibleWall42.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(15.774121284484863, 10.82908821105957, 8.761380195617676),
  rotation: new Quaternion(-2.8705743294540897e-15, 0.6715227961540222, -8.005175544667509e-8, 0.7409840226173401),
  scale: new Vector3(1.059755563735962, 0.31270503997802734, 0.06250002235174179)
})
invisibleWall42.addComponentOrReplace(transform51)

const invisibleWall43 = new Entity('invisibleWall43')
engine.addEntity(invisibleWall43)
invisibleWall43.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(15.474998474121094, 10.82908821105957, 10.264403343200684),
  rotation: new Quaternion(-1.9884786651064345e-15, 0.5956600904464722, -7.100821619587805e-8, 0.803236722946167),
  scale: new Vector3(1.0597554445266724, 0.31270503997802734, 0.0625000074505806)
})
invisibleWall43.addComponentOrReplace(transform52)

const invisibleWall44 = new Entity('invisibleWall44')
engine.addEntity(invisibleWall44)
invisibleWall44.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(14.888398170471191, 10.82908821105957, 11.680191040039062),
  rotation: new Quaternion(-1.1037647160396977e-15, 0.5140608549118042, -6.128082929990342e-8, 0.8577537536621094),
  scale: new Vector3(1.0597552061080933, 0.31270503997802734, 0.0625000074505806)
})
invisibleWall44.addComponentOrReplace(transform53)

const invisibleWall45 = new Entity('invisibleWall45')
engine.addEntity(invisibleWall45)
invisibleWall45.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(14.036863327026367, 10.82908821105957, 12.954333305358887),
  rotation: new Quaternion(-4.390144501746049e-16, 0.42751097679138184, -5.09632727130338e-8, 0.9040102362632751),
  scale: new Vector3(1.0597546100616455, 0.6873777508735657, 0.0625000149011612)
})
invisibleWall45.addComponentOrReplace(transform54)

const invisibleWall46 = new Entity('invisibleWall46')
engine.addEntity(invisibleWall46)
invisibleWall46.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(12.953117370605469, 10.82908821105957, 14.037866592407227),
  rotation: new Quaternion(-2.1706471293966606e-16, 0.336843878030777, -4.015491583686526e-8, 0.9415605664253235),
  scale: new Vector3(1.0597550868988037, 0.6873777508735657, 0.0625000074505806)
})
invisibleWall46.addComponentOrReplace(transform55)

const invisibleWall47 = new Entity('invisibleWall47')
engine.addEntity(invisibleWall47)
invisibleWall47.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(11.678808212280273, 10.82908821105957, 14.889152526855469),
  rotation: new Quaternion(-1.0591831353293276e-16, 0.24293279647827148, -2.895984074768876e-8, 0.9700431227684021),
  scale: new Vector3(1.0597552061080933, 0.6873777508735657, 0.0625)
})
invisibleWall47.addComponentOrReplace(transform56)

const invisibleWall48 = new Entity('invisibleWall48')
engine.addEntity(invisibleWall48)
invisibleWall48.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(10.262907981872559, 10.829065322875977, 15.47547721862793),
  rotation: new Quaternion(5.178911640745502e-18, 0.14668215811252594, -1.7485872305655903e-8, 0.9891837239265442),
  scale: new Vector3(1.0597553253173828, 7.49750280380249, 0.0624999962747097)
})
invisibleWall48.addComponentOrReplace(transform57)

const invisibleWall49 = new Entity('invisibleWall49')
engine.addEntity(invisibleWall49)
invisibleWall49.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(8.75982666015625, 10.829065322875977, 15.77430534362793),
  rotation: new Quaternion(5.2039702502221835e-18, 0.04901887848973274, -5.843504347069484e-9, 0.9987978935241699),
  scale: new Vector3(1.0597550868988037, 7.49750280380249, 0.0625)
})
invisibleWall49.addComponentOrReplace(transform58)

const invisibleWall50 = new Entity('invisibleWall50')
engine.addEntity(invisibleWall50)
invisibleWall50.setParent(_scene)
const transform59 = new Transform({
  position: new Vector3(7.227330684661865, 10.829113006591797, 15.774157524108887),
  rotation: new Quaternion(-5.524133735623944e-15, 0.9987931251525879, -1.1906541175221719e-7, 0.04911646991968155),
  scale: new Vector3(1.0597578287124634, 7.49750280380249, 0.06250020861625671)
})
invisibleWall50.addComponentOrReplace(transform59)

const invisibleWall51 = new Entity('invisibleWall51')
engine.addEntity(invisibleWall51)
invisibleWall51.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(5.724308013916016, 10.829113006591797, 15.475034713745117),
  rotation: new Quaternion(-4.208421365027842e-15, 0.9891693592071533, -1.1791816945105893e-7, 0.14677879214286804),
  scale: new Vector3(1.0597575902938843, 7.49750280380249, 0.06250013411045074)
})
invisibleWall51.addComponentOrReplace(transform60)

const invisibleWall52 = new Entity('invisibleWall52')
engine.addEntity(invisibleWall52)
invisibleWall52.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(4.308521270751953, 10.829090118408203, 14.888434410095215),
  rotation: new Quaternion(-2.899439094714148e-15, 0.9700194597244263, -1.1563531643332681e-7, 0.24302759766578674),
  scale: new Vector3(1.0597578287124634, 0.701763927936554, 0.06250013411045074)
})
invisibleWall52.addComponentOrReplace(transform61)

const invisibleWall53 = new Entity('invisibleWall53')
engine.addEntity(invisibleWall53)
invisibleWall53.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(3.0343785285949707, 10.829090118408203, 14.03689956665039),
  rotation: new Quaternion(-2.463532223134562e-15, 0.9415276646614075, -1.1223883689126524e-7, 0.3369358777999878),
  scale: new Vector3(1.059756875038147, 0.701763927936554, 0.06250008940696716)
})
invisibleWall53.addComponentOrReplace(transform62)

const invisibleWall54 = new Entity('invisibleWall54')
engine.addEntity(invisibleWall54)
invisibleWall54.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(1.9508438110351562, 10.82908821105957, 12.953153610229492),
  rotation: new Quaternion(-5.039273865407217e-15, 0.9039684534072876, -1.077614300015739e-7, 0.42759931087493896),
  scale: new Vector3(1.0597574710845947, 0.701763927936554, 0.06250008940696716)
})
invisibleWall54.addComponentOrReplace(transform63)

const invisibleWall55 = new Entity('invisibleWall55')
engine.addEntity(invisibleWall55)
invisibleWall55.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(1.099557876586914, 10.82908821105957, 11.678845405578613),
  rotation: new Quaternion(-4.167529155433246e-15, 0.8577035069465637, -1.0224621860288607e-7, 0.5141446590423584),
  scale: new Vector3(1.0597559213638306, 0.701763927936554, 0.06250005215406418)
})
invisibleWall55.addComponentOrReplace(transform64)

const invisibleWall56 = new Entity('invisibleWall56')
engine.addEntity(invisibleWall56)
invisibleWall56.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(0.5132341384887695, 10.82908821105957, 10.262944221496582),
  rotation: new Quaternion(-2.8580594176584075e-15, 0.8031784296035767, -9.574632287012719e-8, 0.5957386493682861),
  scale: new Vector3(1.0597561597824097, 0.701763927936554, 0.06250006705522537)
})
invisibleWall56.addComponentOrReplace(transform65)

const invisibleWall57 = new Entity('invisibleWall57')
engine.addEntity(invisibleWall57)
invisibleWall57.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(0.21440505981445312, 10.829089164733887, 8.759862899780273),
  rotation: new Quaternion(-1.9779741860110603e-15, 0.7409183979034424, -8.832434872374506e-8, 0.6715952157974243),
  scale: new Vector3(1.0597556829452515, 0.31270503997802734, 0.06250003725290298)
})
invisibleWall57.addComponentOrReplace(transform66)

const invisibleWall58 = new Entity('invisibleWall58')
engine.addEntity(invisibleWall58)
invisibleWall58.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(0.21455621719360352, 10.82908821105957, 7.227365493774414),
  rotation: new Quaternion(-2.8705743294540897e-15, 0.6715227961540222, -8.005175544667509e-8, 0.7409840226173401),
  scale: new Vector3(1.059755563735962, 0.31270503997802734, 0.06250002235174179)
})
invisibleWall58.addComponentOrReplace(transform67)

const invisibleWall59 = new Entity('invisibleWall59')
engine.addEntity(invisibleWall59)
invisibleWall59.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(0.5136785507202148, 10.82908821105957, 5.724343299865723),
  rotation: new Quaternion(-1.9884786651064345e-15, 0.5956600904464722, -7.100821619587805e-8, 0.803236722946167),
  scale: new Vector3(1.0597554445266724, 0.31270503997802734, 0.0625000074505806)
})
invisibleWall59.addComponentOrReplace(transform68)

const invisibleWall60 = new Entity('invisibleWall60')
engine.addEntity(invisibleWall60)
invisibleWall60.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(1.100278377532959, 10.82908821105957, 4.30855655670166),
  rotation: new Quaternion(-1.1037647160396977e-15, 0.5140608549118042, -6.128082929990342e-8, 0.8577537536621094),
  scale: new Vector3(1.0597552061080933, 0.31270503997802734, 0.0625000074505806)
})
invisibleWall60.addComponentOrReplace(transform69)

const invisibleWall61 = new Entity('invisibleWall61')
engine.addEntity(invisibleWall61)
invisibleWall61.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(1.951812744140625, 10.82908821105957, 3.0344138145446777),
  rotation: new Quaternion(-4.390144501746049e-16, 0.42751097679138184, -5.09632727130338e-8, 0.9040102362632751),
  scale: new Vector3(1.0597552061080933, 0.31270503997802734, 0.0625)
})
invisibleWall61.addComponentOrReplace(transform70)

const invisibleWall62 = new Entity('invisibleWall62')
engine.addEntity(invisibleWall62)
invisibleWall62.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(3.035557746887207, 10.82908821105957, 1.950878620147705),
  rotation: new Quaternion(-2.1706471293966606e-16, 0.336843878030777, -4.015491583686526e-8, 0.9415605664253235),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0625)
})
invisibleWall62.addComponentOrReplace(transform71)

const invisibleWall63 = new Entity('invisibleWall63')
engine.addEntity(invisibleWall63)
invisibleWall63.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(4.309866905212402, 10.82908821105957, 1.099593162536621),
  rotation: new Quaternion(-1.0591832676782256e-16, 0.24293282628059387, -2.8959844300402438e-8, 0.9700432419776917),
  scale: new Vector3(1.0597552061080933, 0.31270503997802734, 0.0625)
})
invisibleWall63.addComponentOrReplace(transform72)

const invisibleWall64 = new Entity('invisibleWall64')
engine.addEntity(invisibleWall64)
invisibleWall64.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(5.725768089294434, 10.82908821105957, 0.5132694244384766),
  rotation: new Quaternion(5.178911640745502e-18, 0.14668215811252594, -1.7485872305655903e-8, 0.9891837239265442),
  scale: new Vector3(1.0597550868988037, 0.31270503997802734, 0.0624999925494194)
})
invisibleWall64.addComponentOrReplace(transform73)

const invisibleWall65 = new Entity('invisibleWall65')
engine.addEntity(invisibleWall65)
invisibleWall65.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(10.829038619995117, 0.32909271121025085, 6.187190532684326),
  rotation: new Quaternion(-3.720928916411048e-15, 0.8777756094932556, -1.0463899968726764e-7, 0.47907206416130066),
  scale: new Vector3(1.0597598552703857, 15.855340957641602, 0.06250029057264328)
})
invisibleWall65.addComponentOrReplace(transform74)

const invisibleWall66 = new Entity('invisibleWall66')
engine.addEntity(invisibleWall66)
invisibleWall66.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(5.172541618347168, 0.32909271121025085, 9.708179473876953),
  rotation: new Quaternion(-3.720928916411048e-15, 0.8777756094932556, -1.0463899968726764e-7, 0.47907206416130066),
  scale: new Vector3(1.0597612857818604, 15.855340957641602, 0.06250038743019104)
})
invisibleWall66.addComponentOrReplace(transform75)

const invisibleWall67 = new Entity('invisibleWall67')
engine.addEntity(invisibleWall67)
invisibleWall67.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(9.175691604614258, 0.32909271121025085, 11.065044403076172),
  rotation: new Quaternion(9.656054472987567e-15, -0.9824497699737549, 1.1711712488704507e-7, 0.18652722239494324),
  scale: new Vector3(1.0597593784332275, 15.855340957641602, 0.06250029057264328)
})
invisibleWall67.addComponentOrReplace(transform76)

const invisibleWall68 = new Entity('invisibleWall68')
engine.addEntity(invisibleWall68)
invisibleWall68.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(6.825886249542236, 0.3290819227695465, 4.830324649810791),
  rotation: new Quaternion(9.656054472987567e-15, -0.9824497699737549, 1.1711712488704507e-7, 0.18652722239494324),
  scale: new Vector3(1.0597584247589111, 15.855340957641602, 0.06250020861625671)
})
invisibleWall68.addComponentOrReplace(transform77)

const invisibleWall69 = new Entity('invisibleWall69')
engine.addEntity(invisibleWall69)
invisibleWall69.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(10.279219627380371, 0.32908737659454346, 10.378133773803711),
  rotation: new Quaternion(1.1246872980456499e-14, -0.927182674407959, 1.105287736891114e-7, 0.3746096193790436),
  scale: new Vector3(1.0597596168518066, 0.31270503997802734, 0.06250030547380447)
})
invisibleWall69.addComponentOrReplace(transform78)

const invisibleWall70 = new Entity('invisibleWall70')
engine.addEntity(invisibleWall70)
invisibleWall70.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(5.722358703613281, 0.32908713817596436, 5.51723575592041),
  rotation: new Quaternion(1.1246872980456499e-14, -0.927182674407959, 1.105287736891114e-7, 0.3746096193790436),
  scale: new Vector3(1.0597586631774902, 0.31270503997802734, 0.0625002458691597)
})
invisibleWall70.addComponentOrReplace(transform79)

const invisibleWall71 = new Entity('invisibleWall71')
engine.addEntity(invisibleWall71)
invisibleWall71.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(6.061541557312012, 0.32909271121025085, 10.656493186950684),
  rotation: new Quaternion(-5.425789398799457e-15, 0.9543717503547668, -1.1376997122169996e-7, 0.2986212968826294),
  scale: new Vector3(1.0597630739212036, 15.855340957641602, 0.06250046193599701)
})
invisibleWall71.addComponentOrReplace(transform80)

const invisibleWall72 = new Entity('invisibleWall72')
engine.addEntity(invisibleWall72)
invisibleWall72.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(9.940038681030273, 0.32909271121025085, 5.2388763427734375),
  rotation: new Quaternion(-5.425789398799457e-15, 0.9543717503547668, -1.1376997122169996e-7, 0.2986212968826294),
  scale: new Vector3(1.0597615242004395, 15.855340957641602, 0.06250033527612686)
})
invisibleWall72.addComponentOrReplace(transform81)

const invisibleWall73 = new Entity('invisibleWall73')
engine.addEntity(invisibleWall73)
invisibleWall73.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(11.035877227783203, 0.32909271121025085, 9.321208953857422),
  rotation: new Quaternion(1.1030767770557615e-14, -0.8362843990325928, 9.969286196565008e-8, 0.5482959747314453),
  scale: new Vector3(1.0597612857818604, 15.855340957641602, 0.06250037252902985)
})
invisibleWall73.addComponentOrReplace(transform82)

const invisibleWall74 = new Entity('invisibleWall74')
engine.addEntity(invisibleWall74)
invisibleWall74.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(4.965701103210449, 0.32909271121025085, 6.574160575866699),
  rotation: new Quaternion(1.1030767770557615e-14, -0.8362843990325928, 9.969286196565008e-8, 0.5482959747314453),
  scale: new Vector3(1.059760332107544, 15.855340957641602, 0.06250031292438507)
})
invisibleWall74.addComponentOrReplace(transform83)

const invisibleWall75 = new Entity('invisibleWall75')
engine.addEntity(invisibleWall75)
invisibleWall75.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(6.8346099853515625, 0.32909271121025085, 11.068317413330078),
  rotation: new Quaternion(-7.08336130229208e-15, 0.9853466153144836, -1.1746246286747919e-7, 0.17056448757648468),
  scale: new Vector3(1.0597665309906006, 15.855340957641602, 0.06250065565109253)
})
invisibleWall75.addComponentOrReplace(transform84)

const invisibleWall76 = new Entity('invisibleWall76')
engine.addEntity(invisibleWall76)
invisibleWall76.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(9.166970252990723, 0.32909271121025085, 4.827051162719727),
  rotation: new Quaternion(-7.08336130229208e-15, 0.9853466153144836, -1.1746246286747919e-7, 0.17056448757648468),
  scale: new Vector3(1.059765100479126, 15.855340957641602, 0.06250053644180298)
})
invisibleWall76.addComponentOrReplace(transform85)

const invisibleWall77 = new Entity('invisibleWall77')
engine.addEntity(invisibleWall77)
invisibleWall77.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(5.722358703613281, 0.32908686995506287, 5.51723575592041),
  rotation: new Quaternion(1.1246872980456499e-14, -0.927182674407959, 1.105287736891114e-7, 0.3746096193790436),
  scale: new Vector3(1.059760570526123, 15.855340957641602, 0.06250035762786865)
})
invisibleWall77.addComponentOrReplace(transform86)

const invisibleWall78 = new Entity('invisibleWall78')
engine.addEntity(invisibleWall78)
invisibleWall78.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(9.940038681030273, 0.32908710837364197, 5.2388763427734375),
  rotation: new Quaternion(-5.425789398799457e-15, 0.9543717503547668, -1.1376997122169996e-7, 0.2986212968826294),
  scale: new Vector3(1.0597586631774902, 0.31270503997802734, 0.06250022351741791)
})
invisibleWall78.addComponentOrReplace(transform87)

const invisibleWall79 = new Entity('invisibleWall79')
engine.addEntity(invisibleWall79)
invisibleWall79.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(10.279219627380371, 0.32909271121025085, 10.378133773803711),
  rotation: new Quaternion(1.1246872980456499e-14, -0.927182674407959, 1.105287736891114e-7, 0.3746096193790436),
  scale: new Vector3(1.0597621202468872, 15.855340957641602, 0.06250041723251343)
})
invisibleWall79.addComponentOrReplace(transform88)

const invisibleWall80 = new Entity('invisibleWall80')
engine.addEntity(invisibleWall80)
invisibleWall80.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(6.061541557312012, 0.32908740639686584, 10.656493186950684),
  rotation: new Quaternion(-5.425789398799457e-15, 0.9543717503547668, -1.1376997122169996e-7, 0.2986212968826294),
  scale: new Vector3(1.0597602128982544, 0.31270503997802734, 0.06250031292438507)
})
invisibleWall80.addComponentOrReplace(transform89)

const invisibleWall81 = new Entity('invisibleWall81')
engine.addEntity(invisibleWall81)
invisibleWall81.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(11.235922813415527, 0.32909271121025085, 7.152545928955078),
  rotation: new Quaternion(-1.871690397613722e-15, 0.7915331125259399, -9.435809289470853e-8, 0.6111263632774353),
  scale: new Vector3(1.0597599744796753, 15.855340957641602, 0.06250029802322388)
})
invisibleWall81.addComponentOrReplace(transform90)

const invisibleWall82 = new Entity('invisibleWall82')
engine.addEntity(invisibleWall82)
invisibleWall82.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(4.765657424926758, 0.3290877640247345, 8.74282455444336),
  rotation: new Quaternion(-1.871690397613722e-15, 0.7915331125259399, -9.435809289470853e-8, 0.6111263632774353),
  scale: new Vector3(1.0597610473632812, 15.855340957641602, 0.06250040233135223)
})
invisibleWall82.addComponentOrReplace(transform91)

const invisibleWall83 = new Entity('invisibleWall83')
engine.addEntity(invisibleWall83)
invisibleWall83.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(11.318414688110352, 0.32909271121025085, 8.25049877166748),
  rotation: new Quaternion(-3.696501333245181e-15, 0.6796606779098511, -8.102185944380835e-8, 0.7335267663002014),
  scale: new Vector3(1.0597611665725708, 15.855340957641602, 0.06250036507844925)
})
invisibleWall83.addComponentOrReplace(transform92)

const invisibleWall84 = new Entity('invisibleWall84')
engine.addEntity(invisibleWall84)
invisibleWall84.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(4.683165550231934, 0.3290819227695465, 7.644872188568115),
  rotation: new Quaternion(-3.696501333245181e-15, 0.6796606779098511, -8.102185944380835e-8, 0.7335267663002014),
  scale: new Vector3(1.0597623586654663, 15.855340957641602, 0.06250046193599701)
})
invisibleWall84.addComponentOrReplace(transform93)

const invisibleWall85 = new Entity('invisibleWall85')
engine.addEntity(invisibleWall85)
invisibleWall85.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(7.948317527770996, 0.32909271121025085, 11.2786865234375),
  rotation: new Quaternion(-1.0554134707841095e-14, 0.9999998807907104, -1.1920926823449918e-7, 0.0004631429328583181),
  scale: new Vector3(1.0597655773162842, 15.855340957641602, 0.06250036507844925)
})
invisibleWall85.addComponentOrReplace(transform94)

const invisibleWall86 = new Entity('invisibleWall86')
engine.addEntity(invisibleWall86)
invisibleWall86.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(9.017064094543457, 16.20848846435547, 11.656493186950684),
  rotation: new Quaternion(0.0004842221096623689, 0.6843648552894592, -0.7291396260261536, 0.00005255267387838103),
  scale: new Vector3(1.7631696462631226, 3.963843584060669, 0.06254826486110687)
})
invisibleWall86.addComponentOrReplace(transform95)

const invisibleWall87 = new Entity('invisibleWall87')
engine.addEntity(invisibleWall87)
invisibleWall87.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(8.003469467163086, 16.969995498657227, 11.656493186950684),
  rotation: new Quaternion(0.0004842221096623689, 0.6843648552894592, -0.7291396260261536, 0.00005255267387838103),
  scale: new Vector3(0.05794432759284973, 4.065488338470459, 1.7914379835128784)
})
invisibleWall87.addComponentOrReplace(transform96)

const invisibleWall88 = new Entity('invisibleWall88')
engine.addEntity(invisibleWall88)
invisibleWall88.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(9.960902214050293, 17.07671546936035, 11.656493186950684),
  rotation: new Quaternion(0.0004842221096623689, 0.6843648552894592, -0.7291396260261536, 0.00005255267387838103),
  scale: new Vector3(0.05794435366988182, 4.065489292144775, 1.791438341140747)
})
invisibleWall88.addComponentOrReplace(transform97)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(8, 11.5, 0.18770217895507812),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.2802672386169434, 2.2802672386169434, 0.5700668096542358)
})
nftPictureFrame.addComponentOrReplace(transform98)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(8, 11.5, 15.722864151000977),
  rotation: new Quaternion(-5.837277581059123e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(2.3834729194641113, 2.3834729194641113, 0.5958682298660278)
})
nftPictureFrame2.addComponentOrReplace(transform99)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(0.19668865203857422, 11.500000953674316, 7.919554710388184),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.278810739517212, 2.2788093090057373, 0.569702684879303)
})
nftPictureFrame3.addComponentOrReplace(transform100)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(15.791003227233887, 11.499999046325684, 7.919553756713867),
  rotation: new Quaternion(-4.573476471668447e-15, -0.7071068286895752, 8.429370268459024e-8, 0.7071068286895752),
  scale: new Vector3(2.212724208831787, 2.2127230167388916, 0.5531810522079468)
})
nftPictureFrame4.addComponentOrReplace(transform101)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(2.5129761695861816, 11.5, 2.401780128479004),
  rotation: new Quaternion(-2.382198213715073e-15, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(2.2496585845947266, 2.2496578693389893, 0.5624146461486816)
})
nftPictureFrame5.addComponentOrReplace(transform102)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(13.51777458190918, 11.5, 13.437328338623047),
  rotation: new Quaternion(-7.935063942184593e-15, -0.9238795638084412, 1.1013502643208994e-7, 0.3826834559440613),
  scale: new Vector3(2.1627354621887207, 2.162731409072876, 0.5406838655471802)
})
nftPictureFrame6.addComponentOrReplace(transform103)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform104 = new Transform({
  position: new Vector3(2.4822263717651367, 11.5, 13.437326431274414),
  rotation: new Quaternion(-5.3929414611049355e-15, -0.9238795638084412, 1.1013501932666259e-7, -0.3826834559440613),
  scale: new Vector3(2.314263343811035, 2.3142616748809814, 0.5785658359527588)
})
nftPictureFrame7.addComponentOrReplace(transform104)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(13.419663429260254, 11.5, 2.563682794570923),
  rotation: new Quaternion(-2.220446049250313e-16, -0.3826834559440613, 4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(2.455291748046875, 2.425645351409912, 0.6138229370117188)
})
nftPictureFrame8.addComponentOrReplace(transform105)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform106 = new Transform({
  position: new Vector3(0.790679931640625, 11.5, 4.933357238769531),
  rotation: new Quaternion(-3.2246033964620493e-15, 0.5555702447891235, -6.622913417686505e-8, 0.8314696550369263),
  scale: new Vector3(2.249757766723633, 2.249755382537842, 0.5624394416809082)
})
nftPictureFrame9.addComponentOrReplace(transform106)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform107 = new Transform({
  position: new Vector3(15.209320068359375, 11.5, 10.90575122833252),
  rotation: new Quaternion(-4.229880097713582e-15, -0.8314696550369263, 9.911890685998515e-8, 0.5555702447891235),
  scale: new Vector3(2.1886496543884277, 2.1886467933654785, 0.5471624135971069)
})
nftPictureFrame10.addComponentOrReplace(transform107)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform108 = new Transform({
  position: new Vector3(5.0138020515441895, 11.5, 15.12887191772461),
  rotation: new Quaternion(-3.512960728519962e-15, -0.9807853698730469, 1.1691872003893877e-7, -0.19509032368659973),
  scale: new Vector3(2.3896114826202393, 2.3896069526672363, 0.5974028706550598)
})
nftPictureFrame11.addComponentOrReplace(transform108)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform109 = new Transform({
  position: new Vector3(10.971061706542969, 11.5, 0.7762837409973145),
  rotation: new Quaternion(6.704003197304138e-16, -0.19509032368659973, 2.3256578884911505e-8, 0.9807853698730469),
  scale: new Vector3(2.298638343811035, 2.298638343811035, 0.5746595859527588)
})
nftPictureFrame12.addComponentOrReplace(transform109)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(10.986198425292969, 11.5, 15.12887191772461),
  rotation: new Quaternion(-3.9487591798823e-15, -0.9807853102684021, 1.1691871293351142e-7, 0.19509033858776093),
  scale: new Vector3(2.3597962856292725, 2.359795093536377, 0.5899490714073181)
})
nftPictureFrame13.addComponentOrReplace(transform110)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform111 = new Transform({
  position: new Vector3(4.944314956665039, 11.5, 0.8407812118530273),
  rotation: new Quaternion(0, 0.19509033858776093, -2.3256577108554666e-8, 0.9807853102684021),
  scale: new Vector3(2.3233609199523926, 2.3233609199523926, 0.5808402299880981)
})
nftPictureFrame14.addComponentOrReplace(transform111)

const nftPictureFrame15 = new Entity('nftPictureFrame15')
engine.addEntity(nftPictureFrame15)
nftPictureFrame15.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(15.131453514099121, 11.499999046325684, 4.933355331420898),
  rotation: new Quaternion(-2.709241234539984e-15, -0.5555702447891235, 6.622913417686505e-8, 0.8314695954322815),
  scale: new Vector3(2.264261484146118, 2.2642605304718018, 0.5660653710365295)
})
nftPictureFrame15.addComponentOrReplace(transform112)

const nftPictureFrame16 = new Entity('nftPictureFrame16')
engine.addEntity(nftPictureFrame16)
nftPictureFrame16.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(0.7906804084777832, 11.500000953674316, 10.905753135681152),
  rotation: new Quaternion(-4.138604250833932e-15, 0.8314695954322815, -9.911889264913043e-8, 0.5555702447891235),
  scale: new Vector3(2.310422897338867, 2.31042218208313, 0.5776057243347168)
})
nftPictureFrame16.addComponentOrReplace(transform113)

const nftPictureFrame20 = new Entity('nftPictureFrame20')
engine.addEntity(nftPictureFrame20)
nftPictureFrame20.setParent(_scene)
const transform114 = new Transform({
  position: new Vector3(9.29703140258789, 4.601168155670166, 4.974818229675293),
  rotation: new Quaternion(1.0048542435690897e-15, -0.19509032368659973, 2.3256585990338863e-8, 0.9807853698730469),
  scale: new Vector3(2.007392644882202, 2.0073909759521484, 0.5018481612205505)
})
nftPictureFrame20.addComponentOrReplace(transform114)

const nftPictureFrame29 = new Entity('nftPictureFrame29')
engine.addEntity(nftPictureFrame29)
nftPictureFrame29.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(5.050703525543213, 3.7541000843048096, 6.675831317901611),
  rotation: new Quaternion(-9.273304001045871e-15, -0.5555702447891235, 6.622911996601033e-8, -0.8314695954322815),
  scale: new Vector3(2.470127820968628, 2.470120668411255, 0.617531955242157)
})
nftPictureFrame29.addComponentOrReplace(transform115)

const nftPictureFrame36 = new Entity('nftPictureFrame36')
engine.addEntity(nftPictureFrame36)
nftPictureFrame36.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(11.177794456481934, 0.9999990463256836, 7.337618827819824),
  rotation: new Quaternion(2.3726165770157322e-15, 0.6343933343887329, -7.56255715828047e-8, -0.7730104923248291),
  scale: new Vector3(2.008768320083618, 2.008763313293457, 0.5021920800209045)
})
nftPictureFrame36.addComponentOrReplace(transform116)

const nftPictureFrame44 = new Entity('nftPictureFrame44')
engine.addEntity(nftPictureFrame44)
nftPictureFrame44.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(9.823646545410156, 1.9999990463256836, 10.532980918884277),
  rotation: new Quaternion(-2.6598204619577214e-15, -0.9569403529167175, 1.140761582973937e-7, 0.2902847230434418),
  scale: new Vector3(2.252453327178955, 2.2524397373199463, 0.5631133317947388)
})
nftPictureFrame44.addComponentOrReplace(transform117)

const nftPictureFrame49 = new Entity('nftPictureFrame49')
engine.addEntity(nftPictureFrame49)
nftPictureFrame49.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(6.247707843780518, 2.8404433727264404, 10.621829986572266),
  rotation: new Quaternion(2.7619529418805664e-15, -0.9569404125213623, 1.1407617250824842e-7, -0.2902846932411194),
  scale: new Vector3(2.386805534362793, 2.3867852687835693, 0.5967013835906982)
})
nftPictureFrame49.addComponentOrReplace(transform118)

const nftPictureFrame17 = new Entity('nftPictureFrame17')
engine.addEntity(nftPictureFrame17)
nftPictureFrame17.setParent(_scene)
const transform119 = new Transform({
  position: new Vector3(9.29703140258789, 8.999999046325684, 4.974818229675293),
  rotation: new Quaternion(1.0048542435690897e-15, -0.19509032368659973, 2.3256585990338863e-8, 0.9807853698730469),
  scale: new Vector3(1.9560537338256836, 1.9560521841049194, 0.4890134334564209)
})
nftPictureFrame17.addComponentOrReplace(transform119)

const nftPictureFrame19 = new Entity('nftPictureFrame19')
engine.addEntity(nftPictureFrame19)
nftPictureFrame19.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(9.858915328979492, 6.1243157386779785, 10.621830940246582),
  rotation: new Quaternion(-2.6598204619577214e-15, -0.9569403529167175, 1.140761582973937e-7, 0.2902847230434418),
  scale: new Vector3(2.1596903800964355, 2.1596755981445312, 0.5399225950241089)
})
nftPictureFrame19.addComponentOrReplace(transform120)

const nftPictureFrame21 = new Entity('nftPictureFrame21')
engine.addEntity(nftPictureFrame21)
nftPictureFrame21.setParent(_scene)
const transform121 = new Transform({
  position: new Vector3(5.050703525543213, 7.999998092651367, 6.675831317901611),
  rotation: new Quaternion(-9.273304001045871e-15, -0.5555702447891235, 6.622911996601033e-8, -0.8314695954322815),
  scale: new Vector3(2.203518867492676, 2.203512668609619, 0.550879716873169)
})
nftPictureFrame21.addComponentOrReplace(transform121)

const nftPictureFrame22 = new Entity('nftPictureFrame22')
engine.addEntity(nftPictureFrame22)
nftPictureFrame22.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(6.247707843780518, 7.149006366729736, 10.621829986572266),
  rotation: new Quaternion(2.7619529418805664e-15, -0.9569404125213623, 1.1407617250824842e-7, -0.2902846932411194),
  scale: new Vector3(2.0359292030334473, 2.0359108448028564, 0.5089823007583618)
})
nftPictureFrame22.addComponentOrReplace(transform122)

const nftPictureFrame23 = new Entity('nftPictureFrame23')
engine.addEntity(nftPictureFrame23)
nftPictureFrame23.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(9.29703140258789, 12.877961158752441, 4.974818229675293),
  rotation: new Quaternion(1.0048542435690897e-15, -0.19509032368659973, 2.3256585990338863e-8, 0.9807853698730469),
  scale: new Vector3(1.7681235074996948, 1.7681218385696411, 0.4420308768749237)
})
nftPictureFrame23.addComponentOrReplace(transform123)

const nftPictureFrame27 = new Entity('nftPictureFrame27')
engine.addEntity(nftPictureFrame27)
nftPictureFrame27.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(9.7900972366333, 9.999999046325684, 10.621830940246582),
  rotation: new Quaternion(-2.6598204619577214e-15, -0.9569403529167175, 1.140761582973937e-7, 0.2902847230434418),
  scale: new Vector3(1.7973663806915283, 1.7973545789718628, 0.4493415951728821)
})
nftPictureFrame27.addComponentOrReplace(transform124)

const nftPictureFrame30 = new Entity('nftPictureFrame30')
engine.addEntity(nftPictureFrame30)
nftPictureFrame30.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(5.050703525543213, 11.999998092651367, 6.675831317901611),
  rotation: new Quaternion(-9.273304001045871e-15, -0.5555702447891235, 6.622911996601033e-8, -0.8314695954322815),
  scale: new Vector3(1.8266279697418213, 1.8266223669052124, 0.4566569924354553)
})
nftPictureFrame30.addComponentOrReplace(transform125)

const nftPictureFrame31 = new Entity('nftPictureFrame31')
engine.addEntity(nftPictureFrame31)
nftPictureFrame31.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(6.247707843780518, 10.999999046325684, 10.621829986572266),
  rotation: new Quaternion(2.7619529418805664e-15, -0.9569404125213623, 1.1407617250824842e-7, -0.2902846932411194),
  scale: new Vector3(1.8513293266296387, 1.8513133525848389, 0.46283233165740967)
})
nftPictureFrame31.addComponentOrReplace(transform126)

const nftPictureFrame32 = new Entity('nftPictureFrame32')
engine.addEntity(nftPictureFrame32)
nftPictureFrame32.setParent(_scene)
const transform127 = new Transform({
  position: new Vector3(11.121509552001953, 5.337909698486328, 7.370254039764404),
  rotation: new Quaternion(2.3726165770157322e-15, 0.6343933343887329, -7.56255715828047e-8, -0.7730104923248291),
  scale: new Vector3(2.1056439876556396, 2.105637311935425, 0.5264109969139099)
})
nftPictureFrame32.addComponentOrReplace(transform127)

const nftPictureFrame33 = new Entity('nftPictureFrame33')
engine.addEntity(nftPictureFrame33)
nftPictureFrame33.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(11.129823684692383, 9.499999046325684, 7.337618827819824),
  rotation: new Quaternion(2.3726165770157322e-15, 0.6343933343887329, -7.56255715828047e-8, -0.7730104923248291),
  scale: new Vector3(1.7695472240447998, 1.7695423364639282, 0.44238680601119995)
})
nftPictureFrame33.addComponentOrReplace(transform128)

const nftPictureFrame34 = new Entity('nftPictureFrame34')
engine.addEntity(nftPictureFrame34)
nftPictureFrame34.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(11.14604663848877, 13.451580047607422, 7.337618827819824),
  rotation: new Quaternion(2.3726165770157322e-15, 0.6343933343887329, -7.56255715828047e-8, -0.7730104923248291),
  scale: new Vector3(1.8035221099853516, 1.8035171031951904, 0.4508805274963379)
})
nftPictureFrame34.addComponentOrReplace(transform129)

const nftPictureFrame18 = new Entity('nftPictureFrame18')
engine.addEntity(nftPictureFrame18)
nftPictureFrame18.setParent(_scene)
const transform130 = new Transform({
  position: new Vector3(6.247707843780518, 14.911027908325195, 10.621829986572266),
  rotation: new Quaternion(2.7619529418805664e-15, -0.9569404125213623, 1.1407617250824842e-7, -0.2902846932411194),
  scale: new Vector3(1.649319052696228, 1.6492998600006104, 0.412329763174057)
})
nftPictureFrame18.addComponentOrReplace(transform130)

const nftPictureFrame24 = new Entity('nftPictureFrame24')
engine.addEntity(nftPictureFrame24)
nftPictureFrame24.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(9.858915328979492, 14.164947509765625, 10.621830940246582),
  rotation: new Quaternion(-2.6598204619577214e-15, -0.9569403529167175, 1.140761582973937e-7, 0.2902847230434418),
  scale: new Vector3(1.9694855213165283, 1.9694706201553345, 0.4923713803291321)
})
nftPictureFrame24.addComponentOrReplace(transform131)

const ringPurpleLight = new Entity('ringPurpleLight')
engine.addEntity(ringPurpleLight)
ringPurpleLight.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(8.01081371307373, 10.311345100402832, 7.9378662109375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.945113658905029, 1.9862784147262573, 7.945113658905029)
})
ringPurpleLight.addComponentOrReplace(transform132)
const gltfShape4 = new GLTFShape("bfeef52c5e7dc28e46b49de7535ddbb0112817437e0bcf02b3f3d52aa5e44463/Ring_Purple_Light.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
ringPurpleLight.addComponentOrReplace(gltfShape4)

const ropeLight = new Entity('ropeLight')
engine.addEntity(ropeLight)
ropeLight.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(7.322100639343262, 7.80052375793457, 4.698333263397217),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.3736196756362915, 1.0000052452087402, 1.9512548446655273)
})
ropeLight.addComponentOrReplace(transform133)

const ropeLight2 = new Entity('ropeLight2')
engine.addEntity(ropeLight2)
ropeLight2.setParent(_scene)
const transform134 = new Transform({
  position: new Vector3(8.632859230041504, 7.80052375793457, 4.698333263397217),
  rotation: new Quaternion(0, 0, -0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(1.3736199140548706, 1.0000057220458984, 1.9512548446655273)
})
ropeLight2.addComponentOrReplace(transform134)

const ropeLight3 = new Entity('ropeLight3')
engine.addEntity(ropeLight3)
ropeLight3.setParent(_scene)
const transform135 = new Transform({
  position: new Vector3(9.869776725769043, 16.236331939697266, 9.67883586883545),
  rotation: new Quaternion(0.47691550850868225, 0.484565794467926, -0.5235647559165955, 0.5134468674659729),
  scale: new Vector3(0.34626543521881104, 1.3834936618804932, 4.8084869384765625)
})
ropeLight3.addComponentOrReplace(transform135)

const ropeLight4 = new Entity('ropeLight4')
engine.addEntity(ropeLight4)
ropeLight4.setParent(_scene)
const transform136 = new Transform({
  position: new Vector3(8.056814193725586, 16.25345230102539, 9.7178316116333),
  rotation: new Quaternion(0.47691550850868225, 0.484565794467926, -0.5235647559165955, 0.5134468674659729),
  scale: new Vector3(0.34626543521881104, 1.3834929466247559, 4.808487892150879)
})
ropeLight4.addComponentOrReplace(transform136)

const ropeLight5 = new Entity('ropeLight5')
engine.addEntity(ropeLight5)
ropeLight5.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(5.032384872436523, 12.986026763916016, 0.025415241718292236),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.29915329813957214, -2.0000181198120117, 1.9512548446655273)
})
ropeLight5.addComponentOrReplace(transform137)

const ropeLight6 = new Entity('ropeLight6')
engine.addEntity(ropeLight6)
ropeLight6.setParent(_scene)
const transform138 = new Transform({
  position: new Vector3(10.82028579711914, 12.986026763916016, 0.02541452646255493),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(0.29915347695350647, -2.0000195503234863, 1.9512548446655273)
})
ropeLight6.addComponentOrReplace(transform138)

const ropeLight7 = new Entity('ropeLight7')
engine.addEntity(ropeLight7)
ropeLight7.setParent(_scene)
const transform139 = new Transform({
  position: new Vector3(8.01919937133789, 14.638565063476562, 0.02541452646255493),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5022158622741699, 1.7691290378570557, 1.951256275177002)
})
ropeLight7.addComponentOrReplace(transform139)

const ropeLight8 = new Entity('ropeLight8')
engine.addEntity(ropeLight8)
ropeLight8.setParent(_scene)
const transform140 = new Transform({
  position: new Vector3(8.01919937133789, 11.214146614074707, 0.025415241718292236),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5022156834602356, 1.7691282033920288, 1.951256275177002)
})
ropeLight8.addComponentOrReplace(transform140)

const scSign2 = new Entity('scSign2')
engine.addEntity(scSign2)
scSign2.setParent(_scene)
const transform141 = new Transform({
  position: new Vector3(8, 13, 0.007936954498291016),
  rotation: new Quaternion(4.214685134229512e-8, -0.7071068286895752, 4.2146844236867764e-8, -0.7071068286895752),
  scale: new Vector3(0.12500056624412537, 1.0000057220458984, 1.000004529953003)
})
scSign2.addComponentOrReplace(transform141)
const gltfShape5 = new GLTFShape("da49f636b2050e768578bc7be79ebcf430e003cd4ec8e4c7352b52133a0c908b/SC Sign.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
scSign2.addComponentOrReplace(gltfShape5)

const radioCyberpunk = new Entity('radioCyberpunk')
engine.addEntity(radioCyberpunk)
radioCyberpunk.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(7, 15.779467582702637, 9.932376861572266),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
radioCyberpunk.addComponentOrReplace(transform142)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script1.spawn(invisibleCylinder, {"enabled":true}, createChannel(channelId, invisibleCylinder, channelBus))
script2.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"invisibleCylinder","actionId":"disable","values":{}}],"onLeave":[{"entityName":"invisibleCylinder","actionId":"enable","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script3.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script3.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script3.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script3.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script3.spawn(invisibleWall5, {"enabled":true}, createChannel(channelId, invisibleWall5, channelBus))
script3.spawn(invisibleWall6, {"enabled":true}, createChannel(channelId, invisibleWall6, channelBus))
script3.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script3.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script3.spawn(invisibleWall9, {"enabled":true}, createChannel(channelId, invisibleWall9, channelBus))
script3.spawn(invisibleWall10, {"enabled":true}, createChannel(channelId, invisibleWall10, channelBus))
script3.spawn(invisibleWall11, {"enabled":true}, createChannel(channelId, invisibleWall11, channelBus))
script3.spawn(invisibleWall12, {"enabled":true}, createChannel(channelId, invisibleWall12, channelBus))
script3.spawn(invisibleWall13, {"enabled":true}, createChannel(channelId, invisibleWall13, channelBus))
script3.spawn(invisibleWall14, {"enabled":true}, createChannel(channelId, invisibleWall14, channelBus))
script3.spawn(invisibleWall15, {"enabled":true}, createChannel(channelId, invisibleWall15, channelBus))
script3.spawn(invisibleWall16, {"enabled":true}, createChannel(channelId, invisibleWall16, channelBus))
script3.spawn(invisibleWall17, {"enabled":true}, createChannel(channelId, invisibleWall17, channelBus))
script3.spawn(invisibleWall18, {"enabled":true}, createChannel(channelId, invisibleWall18, channelBus))
script3.spawn(invisibleWall19, {"enabled":true}, createChannel(channelId, invisibleWall19, channelBus))
script3.spawn(invisibleWall20, {"enabled":true}, createChannel(channelId, invisibleWall20, channelBus))
script3.spawn(invisibleWall21, {"enabled":true}, createChannel(channelId, invisibleWall21, channelBus))
script3.spawn(invisibleWall22, {"enabled":true}, createChannel(channelId, invisibleWall22, channelBus))
script3.spawn(invisibleWall23, {"enabled":true}, createChannel(channelId, invisibleWall23, channelBus))
script3.spawn(invisibleWall24, {"enabled":true}, createChannel(channelId, invisibleWall24, channelBus))
script3.spawn(invisibleWall25, {"enabled":true}, createChannel(channelId, invisibleWall25, channelBus))
script3.spawn(invisibleWall26, {"enabled":true}, createChannel(channelId, invisibleWall26, channelBus))
script3.spawn(invisibleWall27, {"enabled":true}, createChannel(channelId, invisibleWall27, channelBus))
script3.spawn(invisibleWall28, {"enabled":true}, createChannel(channelId, invisibleWall28, channelBus))
script3.spawn(invisibleWall29, {"enabled":true}, createChannel(channelId, invisibleWall29, channelBus))
script3.spawn(invisibleWall30, {"enabled":true}, createChannel(channelId, invisibleWall30, channelBus))
script3.spawn(invisibleWall31, {"enabled":true}, createChannel(channelId, invisibleWall31, channelBus))
script3.spawn(invisibleWall32, {"enabled":true}, createChannel(channelId, invisibleWall32, channelBus))
script3.spawn(invisibleWall33, {"enabled":true}, createChannel(channelId, invisibleWall33, channelBus))
script3.spawn(invisibleWall34, {"enabled":true}, createChannel(channelId, invisibleWall34, channelBus))
script3.spawn(invisibleWall35, {"enabled":true}, createChannel(channelId, invisibleWall35, channelBus))
script3.spawn(invisibleWall36, {"enabled":true}, createChannel(channelId, invisibleWall36, channelBus))
script3.spawn(invisibleWall37, {"enabled":true}, createChannel(channelId, invisibleWall37, channelBus))
script3.spawn(invisibleWall38, {"enabled":true}, createChannel(channelId, invisibleWall38, channelBus))
script3.spawn(invisibleWall39, {"enabled":true}, createChannel(channelId, invisibleWall39, channelBus))
script3.spawn(invisibleWall40, {"enabled":true}, createChannel(channelId, invisibleWall40, channelBus))
script3.spawn(invisibleWall41, {"enabled":true}, createChannel(channelId, invisibleWall41, channelBus))
script3.spawn(invisibleWall42, {"enabled":true}, createChannel(channelId, invisibleWall42, channelBus))
script3.spawn(invisibleWall43, {"enabled":true}, createChannel(channelId, invisibleWall43, channelBus))
script3.spawn(invisibleWall44, {"enabled":true}, createChannel(channelId, invisibleWall44, channelBus))
script3.spawn(invisibleWall45, {"enabled":true}, createChannel(channelId, invisibleWall45, channelBus))
script3.spawn(invisibleWall46, {"enabled":true}, createChannel(channelId, invisibleWall46, channelBus))
script3.spawn(invisibleWall47, {"enabled":true}, createChannel(channelId, invisibleWall47, channelBus))
script3.spawn(invisibleWall48, {"enabled":true}, createChannel(channelId, invisibleWall48, channelBus))
script3.spawn(invisibleWall49, {"enabled":true}, createChannel(channelId, invisibleWall49, channelBus))
script3.spawn(invisibleWall50, {"enabled":true}, createChannel(channelId, invisibleWall50, channelBus))
script3.spawn(invisibleWall51, {"enabled":true}, createChannel(channelId, invisibleWall51, channelBus))
script3.spawn(invisibleWall52, {"enabled":true}, createChannel(channelId, invisibleWall52, channelBus))
script3.spawn(invisibleWall53, {"enabled":true}, createChannel(channelId, invisibleWall53, channelBus))
script3.spawn(invisibleWall54, {"enabled":true}, createChannel(channelId, invisibleWall54, channelBus))
script3.spawn(invisibleWall55, {"enabled":true}, createChannel(channelId, invisibleWall55, channelBus))
script3.spawn(invisibleWall56, {"enabled":true}, createChannel(channelId, invisibleWall56, channelBus))
script3.spawn(invisibleWall57, {"enabled":true}, createChannel(channelId, invisibleWall57, channelBus))
script3.spawn(invisibleWall58, {"enabled":true}, createChannel(channelId, invisibleWall58, channelBus))
script3.spawn(invisibleWall59, {"enabled":true}, createChannel(channelId, invisibleWall59, channelBus))
script3.spawn(invisibleWall60, {"enabled":true}, createChannel(channelId, invisibleWall60, channelBus))
script3.spawn(invisibleWall61, {"enabled":true}, createChannel(channelId, invisibleWall61, channelBus))
script3.spawn(invisibleWall62, {"enabled":true}, createChannel(channelId, invisibleWall62, channelBus))
script3.spawn(invisibleWall63, {"enabled":true}, createChannel(channelId, invisibleWall63, channelBus))
script3.spawn(invisibleWall64, {"enabled":true}, createChannel(channelId, invisibleWall64, channelBus))
script3.spawn(invisibleWall65, {"enabled":true}, createChannel(channelId, invisibleWall65, channelBus))
script3.spawn(invisibleWall66, {"enabled":true}, createChannel(channelId, invisibleWall66, channelBus))
script3.spawn(invisibleWall67, {"enabled":true}, createChannel(channelId, invisibleWall67, channelBus))
script3.spawn(invisibleWall68, {"enabled":true}, createChannel(channelId, invisibleWall68, channelBus))
script3.spawn(invisibleWall69, {"enabled":true}, createChannel(channelId, invisibleWall69, channelBus))
script3.spawn(invisibleWall70, {"enabled":true}, createChannel(channelId, invisibleWall70, channelBus))
script3.spawn(invisibleWall71, {"enabled":true}, createChannel(channelId, invisibleWall71, channelBus))
script3.spawn(invisibleWall72, {"enabled":true}, createChannel(channelId, invisibleWall72, channelBus))
script3.spawn(invisibleWall73, {"enabled":true}, createChannel(channelId, invisibleWall73, channelBus))
script3.spawn(invisibleWall74, {"enabled":true}, createChannel(channelId, invisibleWall74, channelBus))
script3.spawn(invisibleWall75, {"enabled":true}, createChannel(channelId, invisibleWall75, channelBus))
script3.spawn(invisibleWall76, {"enabled":true}, createChannel(channelId, invisibleWall76, channelBus))
script3.spawn(invisibleWall77, {"enabled":true}, createChannel(channelId, invisibleWall77, channelBus))
script3.spawn(invisibleWall78, {"enabled":true}, createChannel(channelId, invisibleWall78, channelBus))
script3.spawn(invisibleWall79, {"enabled":true}, createChannel(channelId, invisibleWall79, channelBus))
script3.spawn(invisibleWall80, {"enabled":true}, createChannel(channelId, invisibleWall80, channelBus))
script3.spawn(invisibleWall81, {"enabled":true}, createChannel(channelId, invisibleWall81, channelBus))
script3.spawn(invisibleWall82, {"enabled":true}, createChannel(channelId, invisibleWall82, channelBus))
script3.spawn(invisibleWall83, {"enabled":true}, createChannel(channelId, invisibleWall83, channelBus))
script3.spawn(invisibleWall84, {"enabled":true}, createChannel(channelId, invisibleWall84, channelBus))
script3.spawn(invisibleWall85, {"enabled":true}, createChannel(channelId, invisibleWall85, channelBus))
script3.spawn(invisibleWall86, {"enabled":true}, createChannel(channelId, invisibleWall86, channelBus))
script3.spawn(invisibleWall87, {"enabled":true}, createChannel(channelId, invisibleWall87, channelBus))
script3.spawn(invisibleWall88, {"enabled":true}, createChannel(channelId, invisibleWall88, channelBus))
script4.spawn(nftPictureFrame, {"id":"69478819454877515899718247009675975988331405547157132439541098690086845808641","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame, channelBus))
script4.spawn(nftPictureFrame2, {"id":"69478819454877515899718247009675975988331405547157132439541098693385380691969","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame2, channelBus))
script4.spawn(nftPictureFrame3, {"id":"69478819454877515899718247009675975988331405547157132439541098702181473714177","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame3, channelBus))
script4.spawn(nftPictureFrame4, {"id":"69478819454877515899718247009675975988331405547157132439541098714276101619713","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame4, channelBus))
script4.spawn(nftPictureFrame5, {"id":"69478819454877515899718247009675975988331405547157132439541098723072194641921","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame5, channelBus))
script4.spawn(nftPictureFrame6, {"id":"69478819454877515899718247009675975988331405547157132439541098676892706275329","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame6, channelBus))
script4.spawn(nftPictureFrame7, {"id":"69478819454877515899718247009675975988331405547157132439541098684589287669761","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame7, channelBus))
script4.spawn(nftPictureFrame8, {"id":"69478819454877515899718247009675975988331405547157132439541098694484892319745","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame8, channelBus))
script4.spawn(nftPictureFrame9, {"id":"69478819454877515899718247009675975988331405547157132439541098707679031853057","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame9, channelBus))
script4.spawn(nftPictureFrame10, {"id":"69478819454877515899718247009675975988331405547157132439541098679091729530881","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame10, channelBus))
script4.spawn(nftPictureFrame11, {"id":"69478819454877515899718247009675975988331405547157132439541098721972683014145","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame11, channelBus))
script4.spawn(nftPictureFrame12, {"id":"69478819454877515899718247009675975988331405547157132439541098705480008597505","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame12, channelBus))
script4.spawn(nftPictureFrame13, {"id":"69478819454877515899718247009675975988331405547157132439541098717574636503041","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame13, channelBus))
script4.spawn(nftPictureFrame14, {"id":"69478819454877515899718247009675975988331405547157132439541098687887822553089","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame14, channelBus))
script4.spawn(nftPictureFrame15, {"id":"69478819454877515899718247009675975988331405547157132439541098713176589991937","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame15, channelBus))
script4.spawn(nftPictureFrame16, {"id":"69478819454877515899718247009675975988331405547157132439541098691186357436417","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame16, channelBus))
script4.spawn(nftPictureFrame20, {"id":"69478819454877515899718247009675975988331405547157132439541098703280985341953","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame20, channelBus))
script4.spawn(nftPictureFrame29, {"id":"69478819454877515899718247009675975988331405547157132439541098718674148130817","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame29, channelBus))
script4.spawn(nftPictureFrame36, {"id":"69478819454877515899718247009675975988331405547157132439541098698882938830849","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame36, channelBus))
script4.spawn(nftPictureFrame44, {"id":"69478819454877515899718247009675975988331405547157132439541098724171706269697","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame44, channelBus))
script4.spawn(nftPictureFrame49, {"id":"69478819454877515899718247009675975988331405547157132439541098681290752786433","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame49, channelBus))
script4.spawn(nftPictureFrame17, {"id":"69478819454877515899718247009675975988331405547157132439541098685688799297537","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame17, channelBus))
script4.spawn(nftPictureFrame19, {"id":"69478819454877515899718247009675975988331405547157132439541098686788310925313","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame19, channelBus))
script4.spawn(nftPictureFrame21, {"id":"69478819454877515899718247009675975988331405547157132439541098683489776041985","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame21, channelBus))
script4.spawn(nftPictureFrame22, {"id":"69478819454877515899718247009675975988331405547157132439541098682390264414209","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame22, channelBus))
script4.spawn(nftPictureFrame23, {"id":"69478819454877515899718247009675975988331405547157132439541098715375613247489","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame23, channelBus))
script4.spawn(nftPictureFrame27, {"id":"69478819454877515899718247009675975988331405547157132439541098716475124875265","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame27, channelBus))
script4.spawn(nftPictureFrame30, {"id":"69478819454877515899718247009675975988331405547157132439541098701081962086401","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame30, channelBus))
script4.spawn(nftPictureFrame31, {"id":"69478819454877515899718247009675975988331405547157132439541098699982450458625","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame31, channelBus))
script4.spawn(nftPictureFrame32, {"id":"69478819454877515899718247009675975988331405547157132439541098688987334180865","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame32, channelBus))
script4.spawn(nftPictureFrame33, {"id":"69478819454877515899718247009675975988331405547157132439541098697783427203073","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame33, channelBus))
script4.spawn(nftPictureFrame34, {"id":"69478819454877515899718247009675975988331405547157132439541098704380496969729","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame34, channelBus))
script4.spawn(nftPictureFrame18, {"id":"69478819454877515899718247009675975988331405547157132439541098708778543480833","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame18, channelBus))
script4.spawn(nftPictureFrame24, {"id":"69478819454877515899718247009675975988331405547157132439541098706579520225281","contract":"0x495f947276749ce646f68ac8c248420045cb7b5e","style":"Classic","color":"#FFFFFF","ui":true,"uiText":"Mint #: 1\nPrice: .01 ETH"}, createChannel(channelId, nftPictureFrame24, channelBus))
script5.spawn(ropeLight, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight, channelBus))
script5.spawn(ropeLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight2, channelBus))
script5.spawn(ropeLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight3, channelBus))
script5.spawn(ropeLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight4, channelBus))
script5.spawn(ropeLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight5, channelBus))
script5.spawn(ropeLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight6, channelBus))
script5.spawn(ropeLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight7, channelBus))
script5.spawn(ropeLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ropeLight8, channelBus))
script6.spawn(radioCyberpunk, {"startOn":true,"volume":0.53,"onClickText":"Radio On/Off","onClick":[],"customStation":"https://gateway.pinata.cloud/ipfs/QmPEax67nAFiLmeDHfGwXwqqLE1dzH33rP7FyRLx6hqBkj"}, createChannel(channelId, radioCyberpunk, channelBus))